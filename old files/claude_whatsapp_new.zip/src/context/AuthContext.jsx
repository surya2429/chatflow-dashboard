import { createContext, useContext, useState } from 'react'
import { NAV_ITEMS } from '../constants/navigation'

const AuthContext = createContext(null)

/* ── Role definitions ─────────────────────────────────────────── */
const ROLE_NAV = {
  admin:      null, // null = all items
  supervisor: ['home', 'conversations', 'contacts', 'broadcasting', 'analytics', 'templates', 'settings'],
  agent:      ['conversations', 'contacts', 'settings'],
}

export const DEMO_USERS = [
  {
    role:     'admin',
    roleLabel:'Admin',
    name:     'Deepak Kumar',
    email:    'admin@acmecorp.com',
    password: 'admin123',
    initials: 'DK',
    color:    '#0066ff',
    desc:     'Full platform access — manage bots, analytics, billing & team',
    workspace:{ name: 'Acme Corp', plan: 'Growth' },
    creditBalance: 4250,
  },
  {
    role:     'supervisor',
    roleLabel:'Supervisor',
    name:     'Priya Das',
    email:    'priya@acmecorp.com',
    password: 'super123',
    initials: 'PD',
    color:    '#8B5CF6',
    desc:     'Team oversight — analytics, broadcasts & conversation management',
    workspace:{ name: 'Acme Corp', plan: 'Growth' },
    creditBalance: 0,
  },
  {
    role:     'agent',
    roleLabel:'Agent',
    name:     'Rahul Mehta',
    email:    'rahul@acmecorp.com',
    password: 'agent123',
    initials: 'RM',
    color:    '#22C55E',
    desc:     'Handle conversations & manage contacts',
    workspace:{ name: 'Acme Corp', plan: 'Growth' },
    creditBalance: 0,
  },
]

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)

  /* filtered nav for the logged-in role */
  const allowedNav = currentUser
    ? ROLE_NAV[currentUser.role] === null
      ? NAV_ITEMS
      : NAV_ITEMS.filter(item => ROLE_NAV[currentUser.role].includes(item.id))
    : []

  function login(email, password) {
    const found = DEMO_USERS.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    )
    if (!found) return { ok: false, error: 'Invalid email or password.' }
    setCurrentUser(found)
    return { ok: true }
  }

  function loginAs(user) {
    setCurrentUser(user)
  }

  function logout() {
    setCurrentUser(null)
  }

  return (
    <AuthContext.Provider value={{
      currentUser,
      isAuthenticated: !!currentUser,
      allowedNav,
      login,
      loginAs,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
