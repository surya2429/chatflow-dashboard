import { useState, useRef, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { ChevronDown, Check } from 'lucide-react'
import clsx from 'clsx'

/**
 * Modern custom Select component
 *
 * Props:
 *   value       — current selected value
 *   onChange    — fn(value) called on selection
 *   options     — [{ value, label, icon?, sub? }]  OR  [{ label, options: [...] }] for groups
 *   placeholder — shown when value is empty / undefined
 *   className   — extra classes on the trigger button
 *   disabled    — disable the select
 *   size        — 'sm' | 'md' (default 'md')
 */
export default function Select({
  value,
  onChange,
  options = [],
  placeholder = 'Select…',
  className = '',
  disabled = false,
  size = 'md',
}) {
  const [open, setOpen] = useState(false)
  const [pos, setPos]   = useState({ top: 0, left: 0, width: 0 })
  const btnRef = useRef(null)
  const dropRef = useRef(null)

  // Flatten options (support grouped and flat)
  const flatOptions = options.flatMap(o => o.options ? o.options : [o])
  const selected = flatOptions.find(o => o.value === value)

  function openDrop() {
    if (disabled) return
    const r = btnRef.current.getBoundingClientRect()
    setPos({ top: r.bottom + 4, left: r.left, width: r.width })
    setOpen(true)
  }

  // Close on outside click
  useEffect(() => {
    if (!open) return
    function handle(e) {
      if (
        !btnRef.current?.contains(e.target) &&
        !dropRef.current?.contains(e.target)
      ) setOpen(false)
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [open])

  const sm = size === 'sm'

  const triggerCls = clsx(
    'flex items-center justify-between gap-2 w-full rounded-lg border transition-all duration-150 text-left',
    sm ? 'px-2.5 py-1.5 text-[11px]' : 'px-3 py-2 text-xs',
    open
      ? 'border-primary ring-2 ring-primary/10 bg-white text-slate-800'
      : 'border-surface-border bg-white text-slate-700 hover:border-primary/40',
    disabled && 'opacity-50 cursor-not-allowed',
    className
  )

  function renderOptions(opts) {
    return opts.map(opt => {
      const isSelected = opt.value === value
      return (
        <button
          key={opt.value}
          onClick={() => { onChange(opt.value); setOpen(false) }}
          className={clsx(
            'w-full flex items-center gap-2.5 px-3 py-2 text-left transition-colors',
            sm ? 'text-[11px]' : 'text-xs',
            isSelected
              ? 'bg-primary-50 text-primary font-semibold'
              : 'text-slate-700 hover:bg-surface-hover'
          )}
        >
          {opt.icon && <opt.icon size={12} className="flex-shrink-0 text-slate-400" />}
          <span className="flex-1 truncate">{opt.label}</span>
          {opt.sub && <span className="text-[10px] text-slate-400">{opt.sub}</span>}
          {isSelected && <Check size={11} className="flex-shrink-0 text-primary" />}
        </button>
      )
    })
  }

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        disabled={disabled}
        onClick={open ? () => setOpen(false) : openDrop}
        className={triggerCls}
      >
        <span className={clsx('truncate', !selected && 'text-slate-400')}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown
          size={12}
          className={clsx('flex-shrink-0 text-slate-400 transition-transform duration-150', open && 'rotate-180')}
        />
      </button>

      {open && createPortal(
        <div
          ref={dropRef}
          className="bg-white rounded-xl border border-surface-border shadow-modal overflow-hidden"
          style={{
            position: 'fixed',
            top: pos.top,
            left: pos.left,
            width: Math.max(pos.width, 160),
            zIndex: 99999,
            maxHeight: 260,
            overflowY: 'auto',
          }}
        >
          {options.some(o => o.options) ? (
            options.map(group => (
              <div key={group.label}>
                <p className="px-3 pt-2.5 pb-1 text-[9px] font-bold text-slate-400 uppercase tracking-wide">
                  {group.label}
                </p>
                {renderOptions(group.options)}
              </div>
            ))
          ) : (
            <div className="py-1">{renderOptions(options)}</div>
          )}
        </div>,
        document.body
      )}
    </>
  )
}

/**
 * NativeSelect — wraps a plain <select> with consistent styling + custom ChevronDown icon
 * Usage: <NativeSelect value={v} onChange={e => setV(e.target.value)} sm>
 *          <option value="">...</option>
 *        </NativeSelect>
 */
export function NativeSelect({ value, onChange, children, className = '', sm = false, disabled = false }) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={onChange}
        disabled={disabled}
        className={clsx(
          'appearance-none w-full rounded-lg border border-surface-border bg-white text-slate-700 cursor-pointer transition-all',
          'focus:outline-none focus:ring-2 focus:ring-primary/15 focus:border-primary/40',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          sm ? 'pl-2.5 pr-8 py-1.5 text-[11px]' : 'pl-3 pr-9 py-2 text-xs',
          className
        )}
      >
        {children}
      </select>
      <ChevronDown
        size={12}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none flex-shrink-0"
      />
    </div>
  )
}
