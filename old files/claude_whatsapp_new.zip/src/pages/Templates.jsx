import { useState, useRef, useEffect, useMemo } from 'react'
import {
  Plus, Search, BarChart2, RefreshCw, MoreHorizontal,
  Eye, Pencil, Copy, Trash2, X,
  ChevronUp, ChevronDown, ChevronsUpDown,
} from 'lucide-react'
import clsx from 'clsx'
import Select from '../components/Select'

/* ─── DESIGN TOKENS (matches dashboard) ──────────────────────────────────── */
const C = {
  primary:    '#0066ff',
  primaryLt:  '#eff4ff',
  primaryHov: '#0052cc',
  bg:         '#f8fafc',
  border:     '#e2e8f0',
  card:       '#ffffff',
  textDark:   '#0f172a',
  textMid:    '#475569',
  textMuted:  '#94a3b8',
  danger:     '#ef4444',
  dangerLt:   '#fef2f2',
  success:    '#22c55e',
  successLt:  '#f0fdf4',
  warn:       '#f59e0b',
  warnLt:     '#fffbeb',
  disabled:   '#cbd5e1',
}

/* ─── LANGUAGES ───────────────────────────────────────────────────────────── */
const LANGUAGES = [
  { value: 'af', label: 'Afrikaans' }, { value: 'sq', label: 'Albanian' },
  { value: 'ar', label: 'Arabic' }, { value: 'az', label: 'Azerbaijani' },
  { value: 'bn', label: 'Bengali' }, { value: 'bg', label: 'Bulgarian' },
  { value: 'ca', label: 'Catalan' }, { value: 'zh_CN', label: 'Chinese (Simplified)' },
  { value: 'zh_TW', label: 'Chinese (Traditional)' }, { value: 'hr', label: 'Croatian' },
  { value: 'cs', label: 'Czech' }, { value: 'da', label: 'Danish' },
  { value: 'nl', label: 'Dutch' }, { value: 'en', label: 'English' },
  { value: 'en_GB', label: 'English (UK)' }, { value: 'en_US', label: 'English (US)' },
  { value: 'et', label: 'Estonian' }, { value: 'fil', label: 'Filipino' },
  { value: 'fi', label: 'Finnish' }, { value: 'fr', label: 'French' },
  { value: 'de', label: 'German' }, { value: 'ka', label: 'Georgian' },
  { value: 'el', label: 'Greek' }, { value: 'gu', label: 'Gujarati' },
  { value: 'ha', label: 'Hausa' }, { value: 'he', label: 'Hebrew' },
  { value: 'hi', label: 'Hindi' }, { value: 'hu', label: 'Hungarian' },
  { value: 'id', label: 'Indonesian' }, { value: 'ga', label: 'Irish' },
  { value: 'it', label: 'Italian' }, { value: 'ja', label: 'Japanese' },
  { value: 'kn', label: 'Kannada' }, { value: 'kk', label: 'Kazakh' },
  { value: 'ko', label: 'Korean' }, { value: 'lo', label: 'Lao' },
  { value: 'lv', label: 'Latvian' }, { value: 'lt', label: 'Lithuanian' },
  { value: 'mk', label: 'Macedonian' }, { value: 'ms', label: 'Malay' },
  { value: 'ml', label: 'Malayalam' }, { value: 'mr', label: 'Marathi' },
  { value: 'nb', label: 'Norwegian' }, { value: 'fa', label: 'Persian' },
  { value: 'pl', label: 'Polish' }, { value: 'pt_BR', label: 'Portuguese (Brazil)' },
  { value: 'pt_PT', label: 'Portuguese (Portugal)' }, { value: 'pa', label: 'Punjabi' },
  { value: 'ro', label: 'Romanian' }, { value: 'ru', label: 'Russian' },
  { value: 'sr', label: 'Serbian' }, { value: 'sk', label: 'Slovak' },
  { value: 'sl', label: 'Slovenian' }, { value: 'es', label: 'Spanish' },
  { value: 'es_AR', label: 'Spanish (Argentina)' }, { value: 'es_ES', label: 'Spanish (Spain)' },
  { value: 'es_MX', label: 'Spanish (Mexico)' }, { value: 'sw', label: 'Swahili' },
  { value: 'sv', label: 'Swedish' }, { value: 'ta', label: 'Tamil' },
  { value: 'te', label: 'Telugu' }, { value: 'th', label: 'Thai' },
  { value: 'tr', label: 'Turkish' }, { value: 'uk', label: 'Ukrainian' },
  { value: 'ur', label: 'Urdu' }, { value: 'uz', label: 'Uzbek' },
  { value: 'vi', label: 'Vietnamese' }, { value: 'zu', label: 'Zulu' },
]

/* ─── CATEGORY DEFINITIONS ────────────────────────────────────────────────── */
const CATEGORY_DEFS = [
  {
    value: 'MARKETING', label: 'Marketing', tabIcon: '📣',
    goodFor: 'Welcome messages, promotions, offers, coupons, newsletters, announcements',
    areas: 'Media, header, body, footer, button',
    subTypes: [
      { value: 'default', label: 'Default', desc: 'Send messages with media and customised buttons to engage your customers.' },
      { value: 'catalog', label: 'Catalogue', desc: 'Send messages that drive sales by connecting your product catalogue.' },
      { value: 'flows', label: 'Flows', desc: 'Send a form to capture customer interests, appointment requests or run surveys.' },
      { value: 'order_details', label: 'Order details', desc: 'Send messages through which customers can pay you.' },
      { value: 'calling_permissions', label: 'Calling permissions request', desc: 'Ask customers if you can call them on WhatsApp.' },
    ],
  },
  {
    value: 'UTILITY', label: 'Utility', tabIcon: '🔔',
    goodFor: 'Order confirmations, account update, receipts, appointment reminders, billing',
    areas: 'Media, header, body, footer, button',
    subTypes: [
      { value: 'default', label: 'Default', desc: 'Send messages about an existing order or account.' },
      { value: 'flows', label: 'Flows', desc: 'Send a form to collect feedback, send reminders or manage orders.' },
      { value: 'order_status', label: 'Order status', desc: 'Send messages to tell customers about the progress of their orders.' },
      { value: 'order_details', label: 'Order details', desc: 'Send messages through which customers can pay you.' },
      { value: 'calling_permissions', label: 'Calling permissions request', desc: 'Ask customers if you can call them on WhatsApp.' },
    ],
  },
  {
    value: 'AUTHENTICATION', label: 'Authentication', tabIcon: '✏️',
    goodFor: 'One-time password, account recovery code, account verification, integrity challenges',
    areas: 'Code delivery method',
    subTypes: [
      { value: 'otp', label: 'One-time passcode', desc: 'Send codes to verify a transaction or login.' },
    ],
  },
]

const COUNTRY_CODES = [
  { value: 'US +1', label: 'United States (+1)' }, { value: 'UK +44', label: 'United Kingdom (+44)' },
  { value: 'IN +91', label: 'India (+91)' }, { value: 'AU +61', label: 'Australia (+61)' },
  { value: 'CA +1', label: 'Canada (+1)' }, { value: 'DE +49', label: 'Germany (+49)' },
  { value: 'FR +33', label: 'France (+33)' }, { value: 'BR +55', label: 'Brazil (+55)' },
  { value: 'MX +52', label: 'Mexico (+52)' }, { value: 'AE +971', label: 'UAE (+971)' },
  { value: 'SA +966', label: 'Saudi Arabia (+966)' }, { value: 'SG +65', label: 'Singapore (+65)' },
  { value: 'PK +92', label: 'Pakistan (+92)' }, { value: 'BD +880', label: 'Bangladesh (+880)' },
  { value: 'NG +234', label: 'Nigeria (+234)' }, { value: 'ID +62', label: 'Indonesia (+62)' },
]

const ACTIVE_FOR_OPTS = [
  { value: '1 day', label: '1 day' }, { value: '3 days', label: '3 days' },
  { value: '7 days', label: '7 days' }, { value: '14 days', label: '14 days' },
  { value: '30 days', label: '30 days' },
]

const TTL_OPTIONS = [
  { value: '5m', label: '5 minutes' }, { value: '10m', label: '10 minutes' },
  { value: '15m', label: '15 minutes' }, { value: '30m', label: '30 minutes' },
  { value: '1h', label: '1 hour' }, { value: '3h', label: '3 hours' },
  { value: '6h', label: '6 hours' }, { value: '12h', label: '12 hours' },
  { value: '24h', label: '24 hours' }, { value: '48h', label: '48 hours' },
  { value: '7d', label: '7 days' },
]

const FLOW_ICONS = [
  { value: 'DEFAULT', label: 'Default' }, { value: 'DOCUMENT', label: 'Document' },
  { value: 'PROMOTION', label: 'Promotion' }, { value: 'REVIEW', label: 'Review' },
]

const MEDIA_ICONS = { none: '', image: '🖼', video: '▶', document: '📄', location: '📍' }

/* ─── UTILITIES ───────────────────────────────────────────────────────────── */
function extractVariables(text) {
  if (!text) return []
  return [...new Set([...text.matchAll(/\{\{(\d+)\}\}/g)].map(m => parseInt(m[1])))].sort((a, b) => a - b)
}

function parseWAText(text, samples = {}) {
  if (!text) return null
  let s = text.replace(/\{\{(\d+)\}\}/g, (_, n) => samples[n] ? `\x00S:${samples[n]}\x00` : `{{${n}}}`)
  const parts = []
  s.split(/(\*[^*\n]+\*|_[^_\n]+_|~[^~\n]+~|`[^`\n]+`|\x00S:[^\x00]+\x00|\{\{\d+\}\})/g).forEach((t, i) => {
    if (!t) return
    if (t.startsWith('\x00S:')) parts.push(<span key={i} style={{ background: '#dbeafe', borderRadius: 3, padding: '0 3px', color: '#1d4ed8' }}>{t.slice(3, -1)}</span>)
    else if (/^\{\{\d+\}\}$/.test(t)) parts.push(<span key={i} style={{ background: '#fef3c7', borderRadius: 3, padding: '0 3px', color: '#92400e', fontFamily: 'monospace', fontSize: 11 }}>{t}</span>)
    else if (t.startsWith('*') && t.endsWith('*')) parts.push(<strong key={i}>{t.slice(1, -1)}</strong>)
    else if (t.startsWith('_') && t.endsWith('_')) parts.push(<em key={i}>{t.slice(1, -1)}</em>)
    else if (t.startsWith('~') && t.endsWith('~')) parts.push(<s key={i}>{t.slice(1, -1)}</s>)
    else if (t.startsWith('`') && t.endsWith('`')) parts.push(<code key={i} style={{ fontFamily: 'monospace', background: '#f1f5f9', borderRadius: 3, padding: '0 3px' }}>{t.slice(1, -1)}</code>)
    else parts.push(<span key={i}>{t}</span>)
  })
  return parts
}

function buildAPIPayload(form) {
  const components = []
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  if (hasMedia) {
    components.push({ type: 'HEADER', format: form.mediaSample.toUpperCase(), example: { header_handle: ['PLACEHOLDER'] } })
  } else if (form.headerText) {
    const vars = extractVariables(form.headerText)
    const comp = { type: 'HEADER', format: 'TEXT', text: form.headerText }
    if (vars.length) comp.example = { header_text: vars.map(n => form.samples?.[`h${n}`] || `val${n}`) }
    components.push(comp)
  }
  if (form.body) {
    const vars = extractVariables(form.body)
    const comp = { type: 'BODY', text: form.body }
    if (vars.length) comp.example = { body_text: [vars.map(n => form.samples?.[`b${n}`] || `val${n}`)] }
    components.push(comp)
  }
  if (form.footer) components.push({ type: 'FOOTER', text: form.footer })
  if (form.buttons?.length) {
    components.push({
      type: 'BUTTONS',
      buttons: form.buttons.map(b => {
        if (b.kind === 'custom') return { type: 'QUICK_REPLY', text: b.text }
        if (b.kind === 'url') return { type: 'URL', text: b.text, url: b.url || '', ...(b.urlType === 'dynamic' ? { example: [b.dynamicSample || '/example'] } : {}) }
        if (b.kind === 'phone') return { type: 'PHONE_NUMBER', text: b.text, phone_number: b.phone || '' }
        if (b.kind === 'wa_call') return { type: 'VOICE_CALL', text: b.text }
        if (b.kind === 'flow') return { type: 'FLOW', text: b.text, flow_id: b.flowId || '' }
        if (b.kind === 'copy_code') return { type: 'COPY_CODE', example: b.code || 'CODE10' }
        return { type: 'QUICK_REPLY', text: b.text }
      }),
    })
  }
  return { name: form.name, language: form.language, category: form.category, components }
}

/* ─── CLICK OUTSIDE HOOK ──────────────────────────────────────────────────── */
function useClickOutside(ref, callback) {
  const cbRef = useRef(callback)
  cbRef.current = callback
  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target)) cbRef.current()
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [ref])
}

/* ─── CUSTOM SELECT ───────────────────────────────────────────────────────── */
function CustomSelect({ value, options, onChange, placeholder = 'Select...', disabled = false, style = {} }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  useClickOutside(ref, () => setOpen(false))
  const selected = options.find(o => o.value === value)

  return (
    <div ref={ref} style={{ position: 'relative', ...style }}>
      <button
        type="button"
        onClick={() => !disabled && setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 10px', border: `1px solid ${open ? C.primary : C.border}`,
          borderRadius: 8, background: disabled ? C.bg : C.card,
          color: selected ? (disabled ? C.textMuted : C.textDark) : C.textMuted,
          fontSize: 13, cursor: disabled ? 'not-allowed' : 'pointer',
          outline: 'none', boxSizing: 'border-box', transition: 'border-color .15s',
          boxShadow: open ? `0 0 0 3px ${C.primaryLt}` : 'none',
        }}
      >
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'left' }}>
          {selected?.label || placeholder}
        </span>
        <svg width="10" height="6" viewBox="0 0 10 6" style={{ flexShrink: 0, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}>
          <path d="M1 1l4 4 4-4" stroke={C.textMuted} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {open && !disabled && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 4px)', left: 0, minWidth: '100%',
          background: C.card, border: `1px solid ${C.border}`, borderRadius: 10,
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)', zIndex: 9999,
          maxHeight: 260, overflowY: 'auto',
        }}>
          {options.map(opt => (
            <button
              key={opt.value}
              type="button"
              onClick={() => { if (!opt.disabled) { onChange(opt.value); setOpen(false) } }}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                width: '100%', padding: '9px 12px', border: 'none',
                background: opt.value === value ? C.primaryLt : 'transparent',
                color: opt.disabled ? C.disabled : opt.value === value ? C.primary : C.textDark,
                fontSize: 13, cursor: opt.disabled ? 'not-allowed' : 'pointer', textAlign: 'left',
              }}
              onMouseEnter={e => { if (!opt.disabled && opt.value !== value) e.currentTarget.style.background = C.bg }}
              onMouseLeave={e => { if (opt.value !== value) e.currentTarget.style.background = 'transparent' }}
            >
              <span style={{ whiteSpace: 'nowrap' }}>{opt.label}</span>
              {opt.note && <span style={{ fontSize: 11, color: C.textMuted, marginLeft: 12, flexShrink: 0 }}>{opt.note}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── SEARCHABLE SELECT ───────────────────────────────────────────────────── */
function SearchableSelect({ value, options, onChange, placeholder = 'Select...', disabled = false, style = {} }) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const ref = useRef(null)
  const searchRef = useRef(null)
  useClickOutside(ref, () => { setOpen(false); setSearch('') })
  const selected = options.find(o => o.value === value)
  const filtered = options.filter(o => o.label.toLowerCase().includes(search.toLowerCase()))

  function handleOpen() {
    if (disabled) return
    setOpen(o => !o)
    setTimeout(() => searchRef.current?.focus(), 50)
  }

  return (
    <div ref={ref} style={{ position: 'relative', ...style }}>
      <button
        type="button"
        onClick={handleOpen}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 10px', border: `1px solid ${open ? C.primary : C.border}`,
          borderRadius: 8, background: disabled ? C.bg : C.card,
          color: selected ? (disabled ? C.textMuted : C.textDark) : C.textMuted,
          fontSize: 13, cursor: disabled ? 'not-allowed' : 'pointer',
          outline: 'none', boxSizing: 'border-box', transition: 'border-color .15s',
          boxShadow: open ? `0 0 0 3px ${C.primaryLt}` : 'none',
        }}
      >
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'left' }}>
          {selected?.label || placeholder}
        </span>
        <svg width="10" height="6" viewBox="0 0 10 6" style={{ flexShrink: 0, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}>
          <path d="M1 1l4 4 4-4" stroke={C.textMuted} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {open && !disabled && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 4px)', left: 0, minWidth: '100%',
          background: C.card, border: `1px solid ${C.border}`, borderRadius: 10,
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)', zIndex: 9999,
        }}>
          <div style={{ padding: '8px 8px 4px', borderBottom: `1px solid ${C.bg}` }}>
            <div style={{ position: 'relative' }}>
              <svg style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input
                ref={searchRef}
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search language..."
                style={{ width: '100%', padding: '6px 8px 6px 26px', border: `1px solid ${C.border}`, borderRadius: 6, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark }}
              />
            </div>
          </div>
          <div style={{ maxHeight: 220, overflowY: 'auto' }}>
            {filtered.length === 0 ? (
              <div style={{ padding: '12px', textAlign: 'center', fontSize: 13, color: C.textMuted }}>No results</div>
            ) : filtered.map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => { onChange(opt.value); setOpen(false); setSearch('') }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '9px 12px', border: 'none',
                  background: opt.value === value ? C.primaryLt : 'transparent',
                  color: opt.value === value ? C.primary : C.textDark,
                  fontSize: 13, cursor: 'pointer', textAlign: 'left',
                }}
                onMouseEnter={e => { if (opt.value !== value) e.currentTarget.style.background = C.bg }}
                onMouseLeave={e => { if (opt.value !== value) e.currentTarget.style.background = 'transparent' }}
              >
                {opt.value === value && (
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: C.primary, flexShrink: 0 }} />
                )}
                {opt.value !== value && <div style={{ width: 8, flexShrink: 0 }} />}
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

/* ─── STEP BAR ────────────────────────────────────────────────────────────── */
function StepBar({ step }) {
  const steps = ['Set up template', 'Edit template', 'Submit for Review']
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '0 24px', height: 50, background: C.card, borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
      {steps.map((s, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 22, height: 22, borderRadius: '50%', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 10, fontWeight: 700, flexShrink: 0,
              background: i < step ? C.success : i === step ? C.primary : 'transparent',
              color: i <= step ? '#fff' : C.textMuted,
              border: i <= step ? 'none' : `2px solid ${C.border}`,
            }}>
              {i < step ? '✓' : i + 1}
            </div>
            <span style={{ fontSize: 13, fontWeight: i === step ? 600 : 400, color: i === step ? C.primary : i < step ? C.success : C.textMuted }}>{s}</span>
          </div>
          {i < steps.length - 1 && (
            <div style={{ width: 36, height: 2, background: i < step ? C.success : C.border, margin: '0 12px', borderRadius: 1 }} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ─── PHONE PREVIEW ───────────────────────────────────────────────────────── */
function PhonePreview({ form }) {
  const bSamples = useMemo(() => {
    const s = {}; extractVariables(form.body || '').forEach(n => { s[n] = form.samples?.[`b${n}`] || '' }); return s
  }, [form.body, form.samples])
  const hSamples = useMemo(() => {
    const s = {}; extractVariables(form.headerText || '').forEach(n => { s[n] = form.samples?.[`h${n}`] || '' }); return s
  }, [form.headerText, form.samples])
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const ctaBtns = (form.buttons || []).filter(b => b.kind !== 'custom')
  const qrBtns = (form.buttons || []).filter(b => b.kind === 'custom')
  const btnIco = { url: '🔗', phone: '📞', wa_call: '📲', flow: '▶', copy_code: '📋' }

  return (
    <div>
      <div style={{ width: 240, margin: '0 auto', background: '#111827', borderRadius: 28, padding: 6, boxShadow: '0 12px 36px rgba(0,0,0,0.3)' }}>
        <div style={{ borderRadius: 22, overflow: 'hidden', background: '#eae6df', minHeight: 380 }}>
          <div style={{ background: '#075e54', padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#128c7e', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11 }}>👤</div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#fff' }}>Business</div>
              <div style={{ fontSize: 9, color: '#b2dfdb' }}>via WhatsApp</div>
            </div>
          </div>
          <div style={{ padding: '10px 8px', minHeight: 220 }}>
            <div style={{ maxWidth: '90%', marginLeft: 'auto' }}>
              <div style={{ background: '#fff', borderRadius: '10px 2px 10px 10px', overflow: 'hidden', boxShadow: '0 1px 2px rgba(0,0,0,.08)' }}>
                {hasMedia && (
                  <div style={{ height: 90, background: form.mediaSample === 'image' ? 'linear-gradient(135deg,#e5e7eb,#d1d5db)' : form.mediaSample === 'video' ? 'linear-gradient(135deg,#1f2937,#374151)' : '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>
                    {MEDIA_ICONS[form.mediaSample]}
                  </div>
                )}
                {!hasMedia && form.headerText && (
                  <div style={{ padding: '8px 9px 3px', fontSize: 12, fontWeight: 700, color: '#111' }}>{parseWAText(form.headerText, hSamples)}</div>
                )}
                <div style={{ padding: '6px 9px', fontSize: 11, color: '#111', lineHeight: 1.55, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                  {form.body ? parseWAText(form.body, bSamples) : <span style={{ color: '#9ca3af', fontStyle: 'italic' }}>Message body…</span>}
                </div>
                {form.footer && <div style={{ padding: '0 9px 4px', fontSize: 10, color: '#6b7280' }}>{form.footer}</div>}
                <div style={{ padding: '1px 8px 4px', textAlign: 'right', fontSize: 9, color: '#9ca3af' }}>11:59 ✓✓</div>
                {ctaBtns.map(b => (
                  <div key={b.id} style={{ borderTop: '1px solid #f0f0f0', padding: '5px 9px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, fontSize: 11, color: '#128c7e', fontWeight: 600 }}>
                    <span>{btnIco[b.kind] || ''}</span>{b.text || <span style={{ color: '#9ca3af' }}>Button</span>}
                  </div>
                ))}
              </div>
              {qrBtns.length > 0 && (
                <div style={{ marginTop: 3, display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                  {qrBtns.map(b => (
                    <div key={b.id} style={{ background: '#fff', borderRadius: 6, padding: '4px 7px', fontSize: 10, color: '#128c7e', fontWeight: 600, boxShadow: '0 1px 2px rgba(0,0,0,.1)', flex: '1 1 auto', textAlign: 'center' }}>
                      {b.text || <span style={{ color: '#9ca3af' }}>Reply</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── VALIDATION PANEL ────────────────────────────────────────────────────── */
function ValidationPanel({ form }) {
  const bodyVars = extractVariables(form.body || '')
  const headerVars = extractVariables(form.headerText || '')
  const allSampleKeys = [...bodyVars.map(n => `b${n}`), ...headerVars.map(n => `h${n}`)]
  const missingSamples = allSampleKeys.filter(k => !form.samples?.[k]?.trim()).length
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const urlBtns = (form.buttons || []).filter(b => b.kind === 'url')
  const phoneBtns = (form.buttons || []).filter(b => b.kind === 'phone')
  const qrTexts = (form.buttons || []).filter(b => b.kind === 'custom').map(b => (b.text || '').trim().toLowerCase())
  const hasDupQr = new Set(qrTexts).size !== qrTexts.length

  const checks = [
    { label: 'Template name', ok: !!(form.name && /^[a-z0-9_]+$/.test(form.name) && form.name.length <= 512), detail: !form.name ? 'Required' : !/^[a-z0-9_]+$/.test(form.name) ? 'Lowercase & underscores only' : `${form.name.length}/512` },
    { label: 'Body content', ok: !!(form.body?.trim()), detail: form.body?.trim() ? `${form.body.length}/1024 chars` : 'Required' },
    { label: 'Sample values', ok: allSampleKeys.length === 0 || missingSamples === 0, detail: allSampleKeys.length === 0 ? 'No variables' : `${allSampleKeys.length - missingSamples}/${allSampleKeys.length} filled` },
    { label: 'Media upload', ok: !hasMedia || !!(form.mediaUrl), detail: !hasMedia ? 'Not required' : form.mediaUrl ? 'Uploaded ✓' : 'Upload required' },
    { label: 'Button limits', ok: (form.buttons || []).length <= 10 && urlBtns.length <= 2 && phoneBtns.length <= 1 && !hasDupQr, detail: `${(form.buttons || []).length}/10 buttons${hasDupQr ? ' · Duplicate QR' : ''}` },
    { label: 'Variable sequence', ok: bodyVars.every((v, i) => v === i + 1), detail: bodyVars.length === 0 ? 'No variables' : bodyVars.every((v, i) => v === i + 1) ? `${bodyVars.length} variable(s) ✓` : 'Non-sequential!' },
  ]
  const allOk = checks.every(c => c.ok)

  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, overflow: 'hidden', marginTop: 12 }}>
      <div style={{ padding: '8px 12px', background: C.bg, borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: C.textDark }}>Checklist</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: allOk ? C.success : C.danger }}>{allOk ? '✓ Ready to submit' : `${checks.filter(c => !c.ok).length} issue(s)`}</span>
      </div>
      {checks.map((c, i) => (
        <div key={i} style={{ display: 'flex', gap: 8, padding: '7px 12px', borderBottom: i < checks.length - 1 ? `1px solid ${C.bg}` : 'none' }}>
          <div style={{ width: 14, height: 14, borderRadius: '50%', background: c.ok ? '#dcfce7' : '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2, fontSize: 7, color: c.ok ? '#059669' : C.danger, fontWeight: 900 }}>{c.ok ? '✓' : '✗'}</div>
          <div>
            <div style={{ fontSize: 12, color: C.textDark, fontWeight: 500 }}>{c.label}</div>
            <div style={{ fontSize: 11, color: c.ok ? C.textMuted : C.danger }}>{c.detail}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

/* ─── SETUP STEP ──────────────────────────────────────────────────────────── */
const CAT_STYLE = {
  MARKETING:      { emoji: '📣', accent: '#0066ff', light: '#eff4ff', badge: 'Most used',    badgeBg: '#0066ff' },
  UTILITY:        { emoji: '🔔', accent: '#f59e0b', light: '#fffbeb', badge: null,            badgeBg: null      },
  AUTHENTICATION: { emoji: '🔐', accent: '#22c55e', light: '#f0fdf4', badge: 'Instant approval', badgeBg: '#22c55e' },
}

const SUBTYPE_ICONS = {
  default:              '💬',
  catalog:              '🛍️',
  flows:                '📋',
  order_details:        '🧾',
  calling_permissions:  '📞',
  order_status:         '📦',
  otp:                  '🔑',
}

function SetupStep({ form, setForm }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)

  function setCategory(cat) {
    const def = CATEGORY_DEFS.find(c => c.value === cat)
    setForm(f => ({ ...f, category: cat, subType: def.subTypes[0].value }))
  }

  return (
    <div style={{ flex: 1, overflowY: 'auto', background: C.bg, padding: '36px 0' }}>
      <div style={{ maxWidth: 820, margin: '0 auto', padding: '0 32px' }}>

        {/* ── Step header ── */}
        <div style={{ marginBottom: 32, textAlign: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', background: C.primaryLt, border: `1px solid ${C.primary}25`, borderRadius: 20, marginBottom: 12 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.primary }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: C.primary, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Step 1 of 3</span>
          </div>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: C.textDark, margin: '0 0 8px', letterSpacing: '-0.3px' }}>
            What type of template?
          </h2>
          <p style={{ fontSize: 14, color: C.textMid, margin: 0, lineHeight: 1.6, maxWidth: 480, marginInline: 'auto' }}>
            Choose a category that best describes your message. Meta uses this to determine pricing and approval requirements.
          </p>
        </div>

        {/* ── Category cards ── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 36 }}>
          {CATEGORY_DEFS.map(cat => {
            const s = CAT_STYLE[cat.value]
            const isSelected = form.category === cat.value
            return (
              <button key={cat.value} type="button" onClick={() => setCategory(cat.value)}
                style={{
                  padding: '24px 20px', border: `2px solid ${isSelected ? s.accent : C.border}`,
                  borderRadius: 16, background: isSelected ? s.light : C.card,
                  cursor: 'pointer', textAlign: 'left', position: 'relative',
                  transition: 'all .18s', outline: 'none',
                  boxShadow: isSelected ? `0 0 0 4px ${s.accent}15, 0 4px 16px ${s.accent}10` : '0 1px 4px rgba(0,0,0,0.05)',
                }}>

                {/* Badge */}
                {s.badge && (
                  <div style={{ position: 'absolute', top: -1, left: 18, padding: '2px 9px', background: s.badgeBg, color: '#fff', fontSize: 10, fontWeight: 700, borderRadius: '0 0 7px 7px', letterSpacing: '0.03em' }}>
                    {s.badge}
                  </div>
                )}

                {/* Check */}
                {isSelected && (
                  <div style={{ position: 'absolute', top: 14, right: 14, width: 22, height: 22, borderRadius: '50%', background: s.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: '#fff', fontWeight: 900 }}>✓</div>
                )}

                {/* Icon circle */}
                <div style={{ width: 48, height: 48, borderRadius: 14, background: isSelected ? s.accent : C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, marginBottom: 14, transition: 'background .18s' }}>
                  {cat.tabIcon}
                </div>

                <div style={{ fontSize: 16, fontWeight: 700, color: isSelected ? s.accent : C.textDark, marginBottom: 6, transition: 'color .18s' }}>
                  {cat.label}
                </div>
                <div style={{ fontSize: 12, color: C.textMid, lineHeight: 1.55 }}>
                  {cat.goodFor.split(',').slice(0, 3).join(', ')}
                </div>

                {/* Areas tag */}
                <div style={{ marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', background: isSelected ? `${s.accent}18` : C.bg, borderRadius: 20 }}>
                  <span style={{ fontSize: 11, color: isSelected ? s.accent : C.textMuted, fontWeight: 600 }}>
                    {cat.areas}
                  </span>
                </div>
              </button>
            )
          })}
        </div>

        {/* ── Template type ── */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <div style={{ flex: 1, height: 1, background: C.border }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>
              Select template type
            </span>
            <div style={{ flex: 1, height: 1, background: C.border }} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(230px, 1fr))', gap: 10 }}>
            {catDef?.subTypes.map(st => {
              const isSelected = form.subType === st.value
              const icon = SUBTYPE_ICONS[st.value] || '💬'
              return (
                <button key={st.value} type="button"
                  onClick={() => setForm(f => ({ ...f, subType: st.value }))}
                  style={{
                    padding: '14px 16px', border: `2px solid ${isSelected ? C.primary : C.border}`,
                    borderRadius: 12, background: isSelected ? C.primaryLt : C.card,
                    cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'flex-start', gap: 12,
                    transition: 'all .15s', outline: 'none',
                    boxShadow: isSelected ? `0 0 0 3px ${C.primary}12` : 'none',
                  }}>
                  <div style={{ width: 34, height: 34, borderRadius: 9, background: isSelected ? `${C.primary}20` : C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
                    {icon}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: isSelected ? C.primary : C.textDark }}>{st.label}</span>
                      {isSelected && (
                        <div style={{ width: 14, height: 14, borderRadius: '50%', background: C.primary, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 7, color: '#fff', fontWeight: 900, flexShrink: 0 }}>✓</div>
                      )}
                    </div>
                    <div style={{ fontSize: 12, color: C.textMid, lineHeight: 1.45 }}>{st.desc}</div>
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        {/* ── Pre-approved banner ── */}
        {(form.category === 'UTILITY' || form.category === 'AUTHENTICATION') && (
          <div style={{ border: `1px solid ${C.border}`, borderRadius: 14, padding: '18px 22px', display: 'flex', gap: 16, alignItems: 'center', background: C.card, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
            <div style={{ width: 46, height: 46, borderRadius: 12, background: C.primaryLt, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>📋</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: C.textDark, marginBottom: 3 }}>Start with a pre-approved template</div>
              <div style={{ fontSize: 13, color: C.textMid, lineHeight: 1.5 }}>Skip the build — choose from our library of ready-made templates that are already approved by Meta.</div>
            </div>
            <button type="button" style={{ padding: '9px 18px', border: `1px solid ${C.border}`, borderRadius: 9, background: C.card, fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0, fontWeight: 600, color: C.textDark }}>Browse library</button>
          </div>
        )}

        <div style={{ height: 24 }} />
      </div>
    </div>
  )
}

/* ─── TOOLBAR BUTTON ──────────────────────────────────────────────────────── */
function TBtn({ title, onClick, children }) {
  return (
    <button type="button" title={title} onClick={onClick}
      style={{ padding: '3px 7px', border: 'none', background: 'none', cursor: 'pointer', borderRadius: 5, fontSize: 13, color: C.textMid }}
      onMouseEnter={e => e.currentTarget.style.background = C.border}
      onMouseLeave={e => e.currentTarget.style.background = 'none'}
    >{children}</button>
  )
}

/* ─── DRAG DROP UPLOAD ────────────────────────────────────────────────────── */
function DragDropUpload({ type, value, onChange }) {
  const [drag, setDrag] = useState(false)
  const ref = useRef(null)
  function handleFile(f) { if (f) onChange(URL.createObjectURL(f)) }
  return (
    <div
      onClick={() => ref.current?.click()}
      onDragOver={e => { e.preventDefault(); setDrag(true) }}
      onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]) }}
      style={{ border: `2px dashed ${drag ? C.primary : value ? C.success : C.border}`, borderRadius: 10, padding: '20px 16px', textAlign: 'center', cursor: 'pointer', background: drag ? C.primaryLt : value ? C.successLt : C.bg, margin: '8px 0', transition: 'all .15s' }}
    >
      <input ref={ref} type="file" accept={type === 'image' ? 'image/*' : type === 'video' ? 'video/*' : '.pdf,.doc,.docx'} style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
      {value ? (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          <span style={{ fontSize: 16 }}>{MEDIA_ICONS[type]}</span>
          <span style={{ fontSize: 13, color: C.success, fontWeight: 500 }}>File uploaded ✓</span>
          <button type="button" onClick={e => { e.stopPropagation(); onChange('') }} style={{ fontSize: 11, color: C.danger, background: 'none', border: 'none', cursor: 'pointer' }}>Remove</button>
        </div>
      ) : (
        <div>
          <div style={{ fontSize: 13, color: C.textDark, marginBottom: 4 }}>Drag and drop to upload</div>
          <div style={{ fontSize: 12, color: C.primary, cursor: 'pointer' }}>Or choose files from your device</div>
        </div>
      )}
    </div>
  )
}

/* ─── SECTION ─────────────────────────────────────────────────────────────── */
function Section({ title, subtitle, children }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 12 }}>
      <div style={{ padding: '14px 20px 12px', borderBottom: `1px solid ${C.bg}` }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: C.textDark }}>{title}</div>
        {subtitle && <div style={{ fontSize: 13, color: C.textMid, marginTop: 3, lineHeight: 1.5 }}>{subtitle}</div>}
      </div>
      <div style={{ padding: '16px 20px' }}>{children}</div>
    </div>
  )
}

/* ─── FIELD LABEL ─────────────────────────────────────────────────────────── */
function FieldLabel({ children, optional, count, max, info }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: C.textDark, display: 'flex', alignItems: 'center', gap: 5 }}>
        {children}
        {optional && <span style={{ fontWeight: 400, fontSize: 12, color: C.textMuted }}>· Optional</span>}
        {info && (
          <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 15, height: 15, borderRadius: '50%', background: C.bg, fontSize: 9, color: C.textMuted, cursor: 'help', fontWeight: 700, border: `1px solid ${C.border}` }} title={info}>i</span>
        )}
      </div>
      {count !== undefined && (
        <span style={{ fontSize: 11, color: count > (max * 0.9) ? C.danger : C.textMuted }}>{count}/{max}</span>
      )}
    </div>
  )
}

const inputStyle = { width: '100%', padding: '9px 10px', border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark, transition: 'border-color .15s' }

/* ─── CONTENT SECTION ─────────────────────────────────────────────────────── */
function ContentSection({ form, setForm }) {
  const taRef = useRef(null)
  const isCatalog = form.subType === 'catalog'
  const isCatMsg = form.catalogFormat === 'catalogue_message'
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const bodyVars = extractVariables(form.body || '')
  const headerVars = extractVariables(form.headerText || '')

  function wrapBody(pre, suf) {
    const ta = taRef.current; if (!ta) return
    const s = ta.selectionStart, e = ta.selectionEnd
    const next = (form.body || '').slice(0, s) + pre + (form.body || '').slice(s, e) + suf + (form.body || '').slice(e)
    setForm(f => ({ ...f, body: next }))
    setTimeout(() => { ta.focus(); ta.setSelectionRange(s + pre.length, e + pre.length) }, 0)
  }

  function addBodyVar() {
    const vars = extractVariables(form.body || '')
    const next = vars.length ? Math.max(...vars) + 1 : 1
    const ta = taRef.current
    const pos = ta ? ta.selectionStart : (form.body || '').length
    setForm(f => ({ ...f, body: (f.body || '').slice(0, pos) + `{{${next}}}` + (f.body || '').slice(pos) }))
    setTimeout(() => ta?.focus(), 0)
  }

  return (
    <Section
      title="Content"
      subtitle={<>Add a header, body and footer for your template. <span style={{ color: C.primary, cursor: 'pointer' }}>About templates</span></>}
    >
      {/* Type of variable */}
      <div style={{ marginBottom: 14 }}>
        <FieldLabel info="Choose how template variables are referenced in your message">Type of variable</FieldLabel>
        <CustomSelect
          value={form.varType || 'number'}
          onChange={v => setForm(f => ({ ...f, varType: v }))}
          options={[{ value: 'number', label: 'Number' }, { value: 'name', label: 'Name' }]}
          style={{ maxWidth: 260 }}
        />
      </div>

      {/* Media sample */}
      {!isCatalog && (
        <div style={{ marginBottom: 14 }}>
          <FieldLabel optional>Media sample</FieldLabel>
          <CustomSelect
            value={form.mediaSample || 'none'}
            onChange={v => setForm(f => ({ ...f, mediaSample: v, mediaUrl: '' }))}
            options={[
              { value: 'none', label: 'None' },
              { value: 'image', label: '🖼  Image' },
              { value: 'video', label: '▶  Video' },
              { value: 'document', label: '📄  Document' },
              { value: 'location', label: '📍  Location' },
            ]}
            style={{ maxWidth: 260 }}
          />
          {['image', 'video', 'document'].includes(form.mediaSample) && (
            <DragDropUpload type={form.mediaSample} value={form.mediaUrl} onChange={url => setForm(f => ({ ...f, mediaUrl: url }))} />
          )}
          {form.mediaSample === 'location' && (
            <div style={{ marginTop: 8, padding: '10px 12px', background: C.successLt, border: '1px solid #bbf7d0', borderRadius: 8, fontSize: 13, color: '#166534' }}>
              📍 The user's location pin will be shown. No additional configuration needed.
            </div>
          )}
        </div>
      )}

      {/* Header */}
      {!(isCatalog && isCatMsg) && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: C.textDark }}>
              Header <span style={{ fontWeight: 400, fontSize: 12, color: C.textMuted }}>· Optional</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              {!hasMedia && <span style={{ fontSize: 11, color: C.textMuted }}>{(form.headerText || '').length}/60</span>}
              {!hasMedia && headerVars.length === 0 && (
                <button type="button" onClick={() => setForm(f => ({ ...f, headerText: (f.headerText || '') + '{{1}}' }))}
                  style={{ fontSize: 12, color: C.primary, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500 }}>
                  + Add variable
                </button>
              )}
            </div>
          </div>
          <input
            value={form.headerText || ''}
            onChange={e => !hasMedia && setForm(f => ({ ...f, headerText: e.target.value.slice(0, 60) }))}
            placeholder={`Add a short header text in ${LANGUAGES.find(l => l.value === form.language)?.label || 'English'}`}
            maxLength={60}
            disabled={hasMedia}
            style={{ ...inputStyle, background: hasMedia ? C.bg : '#fff', color: hasMedia ? C.textMuted : C.textDark, cursor: hasMedia ? 'not-allowed' : 'text' }}
            onFocus={e => e.target.style.borderColor = C.primary}
            onBlur={e => e.target.style.borderColor = C.border}
          />
          {headerVars.length > 0 && !hasMedia && (
            <div style={{ marginTop: 8, padding: '10px 12px', background: C.primaryLt, border: `1px solid ${C.primary}30`, borderRadius: 8 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: C.primary, marginBottom: 6 }}>Header sample value</div>
              {headerVars.map(n => (
                <div key={n} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 11, fontFamily: 'monospace', background: '#dbeafe', color: '#1d4ed8', padding: '2px 6px', borderRadius: 4 }}>{`{{${n}}}`}</span>
                  <input value={form.samples?.[`h${n}`] || ''} onChange={e => setForm(f => ({ ...f, samples: { ...f.samples, [`h${n}`]: e.target.value } }))}
                    placeholder="Enter sample value"
                    style={{ flex: 1, padding: '6px 9px', border: `1px solid ${C.border}`, borderRadius: 7, fontSize: 13, outline: 'none' }}
                    onFocus={e => e.target.style.borderColor = C.primary}
                    onBlur={e => e.target.style.borderColor = C.border}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Body */}
      <div style={{ marginBottom: 14 }}>
        <FieldLabel count={(form.body || '').length} max={1024}>Body</FieldLabel>
        <div style={{ position: 'relative' }}>
          <textarea
            ref={taRef}
            value={form.body || ''}
            onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
            rows={5}
            maxLength={1024}
            placeholder={`Enter text in ${LANGUAGES.find(l => l.value === form.language)?.label || 'English'}`}
            style={{ width: '100%', padding: '9px 10px', border: `1px solid ${C.border}`, borderRadius: '8px 8px 0 0', fontSize: 13, resize: 'vertical', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', lineHeight: 1.55, color: C.textDark }}
            onFocus={e => e.target.style.borderColor = C.primary}
            onBlur={e => e.target.style.borderColor = C.border}
          />
        </div>
        {/* Toolbar */}
        <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1, padding: '4px 6px', border: `1px solid ${C.border}`, borderTop: 'none', borderRadius: '0 0 8px 8px', background: C.bg, justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <TBtn title="Emoji" onClick={() => {
              const ta = taRef.current; if (!ta) return
              const pos = ta.selectionStart
              setForm(f => ({ ...f, body: (f.body || '').slice(0, pos) + '😊' + (f.body || '').slice(pos) }))
              setTimeout(() => { ta.focus(); ta.setSelectionRange(pos + 2, pos + 2) }, 0)
            }}>😊</TBtn>
            <TBtn title="Bold" onClick={() => wrapBody('*', '*')}><strong style={{ fontSize: 12 }}>B</strong></TBtn>
            <TBtn title="Italic" onClick={() => wrapBody('_', '_')}><em style={{ fontSize: 12 }}>I</em></TBtn>
            <TBtn title="Strikethrough" onClick={() => wrapBody('~', '~')}><s style={{ fontSize: 12 }}>S</s></TBtn>
            <TBtn title="Monospace" onClick={() => wrapBody('`', '`')}><code style={{ fontSize: 10 }}>{'</>'}</code></TBtn>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <button type="button" onClick={addBodyVar}
              style={{ fontSize: 12, color: C.primary, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, padding: '3px 4px' }}>
              + Add variable
            </button>
          </div>
        </div>
        {bodyVars.length > 0 && (
          <div style={{ marginTop: 10, padding: '10px 12px', background: C.primaryLt, border: `1px solid ${C.primary}30`, borderRadius: 8 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: C.primary, marginBottom: 6 }}>Body sample values — required before submission</div>
            {bodyVars.map(n => (
              <div key={n} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontFamily: 'monospace', background: '#dbeafe', color: '#1d4ed8', padding: '2px 6px', borderRadius: 4, flexShrink: 0 }}>{`{{${n}}}`}</span>
                <input value={form.samples?.[`b${n}`] || ''} onChange={e => setForm(f => ({ ...f, samples: { ...f.samples, [`b${n}`]: e.target.value } }))}
                  placeholder={`Sample for {{${n}}}`}
                  style={{ flex: 1, padding: '6px 9px', border: `1px solid ${C.border}`, borderRadius: 7, fontSize: 13, outline: 'none' }}
                  onFocus={e => e.target.style.borderColor = C.primary}
                  onBlur={e => e.target.style.borderColor = C.border}
                />
              </div>
            ))}
          </div>
        )}
        {bodyVars.length > 0 && !bodyVars.every((v, i) => v === i + 1) && (
          <div style={{ marginTop: 6, fontSize: 12, color: C.danger }}>⚠ Variables must be sequential starting from {'{{1}}'}</div>
        )}
      </div>

      {/* Footer */}
      <div>
        <FieldLabel optional count={(form.footer || '').length} max={60}>Footer</FieldLabel>
        <input
          value={form.footer || ''}
          onChange={e => setForm(f => ({ ...f, footer: e.target.value.slice(0, 60) }))}
          placeholder="Add a short line of text to the bottom of your message"
          maxLength={60}
          style={inputStyle}
          onFocus={e => e.target.style.borderColor = C.primary}
          onBlur={e => e.target.style.borderColor = C.border}
        />
      </div>
    </Section>
  )
}

/* ─── BUTTON ROW ──────────────────────────────────────────────────────────── */
function ButtonRow({ btn, onUpdate, onRemove, allButtons, isQR }) {
  const isDupQR = isQR && allButtons.filter(b => b.kind === 'custom' && b.id !== btn.id && (b.text || '').trim().toLowerCase() === (btn.text || '').trim().toLowerCase()).length > 0
  const inp = { width: '100%', padding: '7px 9px', border: `1px solid ${isDupQR ? '#fca5a5' : C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark }

  return (
    <div style={{ border: `1px solid ${isDupQR ? '#fca5a5' : C.border}`, borderRadius: 10, marginBottom: 8, background: C.card }}>
      {/* Main row */}
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, padding: '12px 12px 10px' }}>
        <span style={{ fontSize: 14, color: C.textMuted, cursor: 'grab', paddingBottom: 8, flexShrink: 0 }}>⠿</span>

        {isQR ? (
          <>
            <div style={{ width: 120, flexShrink: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Type</div>
              <div style={{ padding: '7px 10px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.bg, color: C.textMid, fontSize: 13 }}>Custom reply</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button text</div>
              <div style={{ position: 'relative' }}>
                <input value={btn.text || ''} onChange={e => onUpdate({ text: e.target.value })} maxLength={25} placeholder="Enter text"
                  style={{ ...inp, paddingRight: 42 }}
                  onFocus={e => e.target.style.borderColor = C.primary}
                  onBlur={e => e.target.style.borderColor = isDupQR ? '#fca5a5' : C.border}
                />
                <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: C.textMuted }}>{(btn.text || '').length}/25</span>
              </div>
              {isDupQR && <div style={{ fontSize: 11, color: C.danger, marginTop: 3 }}>Duplicate button text</div>}
            </div>
          </>
        ) : (
          <>
            <div style={{ width: 165, flexShrink: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Type of action</div>
              <CustomSelect
                value={btn.kind}
                onChange={v => onUpdate({ kind: v, text: v === 'wa_call' ? 'Call on WhatsApp' : v === 'copy_code' ? 'Copy offer code' : '' })}
                options={[
                  { value: 'url', label: 'Visit website' },
                  { value: 'wa_call', label: 'Call on WhatsApp' },
                  { value: 'phone', label: 'Call Phone Number' },
                  { value: 'flow', label: 'Complete flow' },
                  { value: 'copy_code', label: 'Copy offer code' },
                ]}
              />
            </div>

            {btn.kind !== 'copy_code' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button text</div>
                <div style={{ position: 'relative' }}>
                  <input value={btn.text || ''} onChange={e => onUpdate({ text: e.target.value })} maxLength={25}
                    readOnly={btn.kind === 'wa_call'}
                    placeholder="Enter text"
                    style={{ ...inp, paddingRight: 42, background: btn.kind === 'wa_call' ? C.bg : '#fff', color: btn.kind === 'wa_call' ? C.textMuted : C.textDark }}
                    onFocus={e => { if (btn.kind !== 'wa_call') e.target.style.borderColor = C.primary }}
                    onBlur={e => e.target.style.borderColor = C.border}
                  />
                  <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: C.textMuted }}>{(btn.text || '').length}/25</span>
                </div>
              </div>
            )}

            {btn.kind === 'url' && (
              <div style={{ width: 120, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>URL type</div>
                <CustomSelect value={btn.urlType || 'static'} onChange={v => onUpdate({ urlType: v })}
                  options={[{ value: 'static', label: 'Static' }, { value: 'dynamic', label: 'Dynamic' }]} />
              </div>
            )}

            {btn.kind === 'wa_call' && (
              <div style={{ width: 130, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Active for</div>
                <CustomSelect value={btn.activeFor || '7 days'} onChange={v => onUpdate({ activeFor: v })} options={ACTIVE_FOR_OPTS} />
              </div>
            )}

            {btn.kind === 'phone' && (
              <div style={{ width: 180, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Country</div>
                <CustomSelect value={btn.country || 'US +1'} onChange={v => onUpdate({ country: v })} options={COUNTRY_CODES} />
              </div>
            )}

            {btn.kind === 'copy_code' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button text</div>
                <div style={{ padding: '7px 9px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.bg, color: C.textMuted, fontSize: 13 }}>Copy offer code</div>
              </div>
            )}

            {btn.kind === 'flow' && (
              <div style={{ width: 130, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button icon</div>
                <CustomSelect value={btn.icon || 'DEFAULT'} onChange={v => onUpdate({ icon: v })} options={FLOW_ICONS} />
              </div>
            )}
          </>
        )}

        <button type="button" onClick={onRemove}
          style={{ padding: '6px 8px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 15, color: C.textMuted, flexShrink: 0, lineHeight: 1, alignSelf: 'flex-end', marginBottom: 2 }}
          onMouseEnter={e => e.currentTarget.style.color = C.danger}
          onMouseLeave={e => e.currentTarget.style.color = C.textMuted}
        >✕</button>
      </div>

      {/* URL expanded */}
      {btn.kind === 'url' && (
        <div style={{ padding: '0 12px 12px 36px', borderTop: `1px solid ${C.bg}` }}>
          <div style={{ paddingTop: 10 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Website URL</div>
            <input value={btn.url || ''} onChange={e => onUpdate({ url: e.target.value })} maxLength={2000}
              placeholder={btn.urlType === 'dynamic' ? 'https://www.example.com/{{1}}' : 'https://www.example.com'}
              style={{ width: '100%', padding: '7px 9px', border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark }}
              onFocus={e => e.target.style.borderColor = C.primary}
              onBlur={e => e.target.style.borderColor = C.border}
            />
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: C.textDark, cursor: 'pointer', marginTop: 10 }}>
            <input type="checkbox" checked={!!btn.trackConversions} onChange={e => onUpdate({ trackConversions: e.target.checked })} />
            Track app conversions <span style={{ color: C.textMuted, fontSize: 12 }}>(Marketing Messages API only)</span>
          </label>
          {btn.urlType === 'dynamic' && (
            <div style={{ marginTop: 10 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Sample dynamic URL path</div>
              <input value={btn.dynamicSample || ''} onChange={e => onUpdate({ dynamicSample: e.target.value })}
                placeholder="/orders/12345"
                style={{ width: '100%', padding: '7px 9px', border: `1px solid ${C.primary}50`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', background: C.primaryLt, color: C.textDark }}
              />
            </div>
          )}
        </div>
      )}

      {/* Phone number */}
      {btn.kind === 'phone' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: `1px solid ${C.bg}` }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Phone number</div>
          <input value={btn.phone || ''} onChange={e => onUpdate({ phone: e.target.value })} maxLength={20}
            placeholder="Enter phone number"
            style={{ width: '100%', padding: '7px 9px', border: `1px solid ${!btn.phone ? '#fca5a5' : C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark }}
            onFocus={e => e.target.style.borderColor = C.primary}
            onBlur={e => e.target.style.borderColor = !btn.phone ? '#fca5a5' : C.border}
          />
          {!btn.phone && <div style={{ fontSize: 11, color: C.danger, marginTop: 4 }}>Phone number is required.</div>}
        </div>
      )}

      {/* WA Call info */}
      {btn.kind === 'wa_call' && (
        <div style={{ padding: '8px 12px 10px 36px', borderTop: `1px solid ${C.bg}`, display: 'flex', gap: 6 }}>
          <span style={{ fontSize: 13, flexShrink: 0, marginTop: 1 }}>ℹ</span>
          <div style={{ fontSize: 12, color: C.textMid, lineHeight: 1.5 }}>
            Turn on calling in the <span style={{ color: C.primary, cursor: 'pointer' }}>WhatsApp Manager portal</span>. Alternatively, use the Phone Number Settings API.{' '}
            <span style={{ color: C.primary, cursor: 'pointer' }}>About calling on WhatsApp</span>
          </div>
        </div>
      )}

      {/* Flow options */}
      {btn.kind === 'flow' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: `1px solid ${C.bg}` }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10 }}>
            {btn.flowName ? (
              <>
                <span style={{ fontSize: 13, color: C.primary, fontWeight: 500 }}>{btn.flowName}</span>
                <button type="button" style={{ padding: '4px 10px', border: `1px solid ${C.border}`, borderRadius: 7, background: C.card, fontSize: 12, cursor: 'pointer', color: C.textDark }}>Preview</button>
                <button type="button" onClick={() => onUpdate({ flowName: '', flowId: '' })} style={{ padding: '4px 10px', border: `1px solid ${C.border}`, borderRadius: 7, background: C.card, fontSize: 12, cursor: 'pointer', color: C.danger }}>Remove</button>
              </>
            ) : (
              <>
                <button type="button" onClick={() => onUpdate({ flowName: 'new_flow', flowId: `flow_${Date.now()}` })} style={{ padding: '5px 12px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.card, fontSize: 13, cursor: 'pointer', color: C.textDark }}>+ Create new</button>
                <button type="button" onClick={() => onUpdate({ flowName: 'existing_flow', flowId: 'flow_001' })} style={{ padding: '5px 12px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.card, fontSize: 13, cursor: 'pointer', color: C.textDark }}>⚙ Use existing</button>
              </>
            )}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Flow starts with</div>
              <CustomSelect value={btn.screenType || 'predefined'} onChange={v => onUpdate({ screenType: v })}
                options={[{ value: 'predefined', label: 'Pre-defined screen' }, { value: 'network', label: 'Network request' }]} />
            </div>
            {btn.screenType !== 'network' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Select pre-defined screen</div>
                <CustomSelect value={btn.predefinedScreen || ''} onChange={v => onUpdate({ predefinedScreen: v })} placeholder="Select screen..."
                  options={[{ value: 'screen_1', label: 'Book a Demo' }, { value: 'screen_2', label: 'Get a Quote' }, { value: 'screen_3', label: 'Contact Us' }]} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Copy code */}
      {btn.kind === 'copy_code' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: `1px solid ${C.bg}` }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Offer code sample</div>
          <input value={btn.code || ''} onChange={e => onUpdate({ code: e.target.value })} maxLength={20} placeholder="Enter sample code"
            style={{ width: '100%', padding: '7px 9px', border: `1px solid ${!btn.code ? '#fca5a5' : C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', fontFamily: btn.code ? 'monospace' : 'inherit', color: C.textDark }}
            onFocus={e => e.target.style.borderColor = C.primary}
            onBlur={e => e.target.style.borderColor = !btn.code ? '#fca5a5' : C.border}
          />
          {!btn.code && <div style={{ fontSize: 11, color: C.primary, marginTop: 4 }}>Add a sample offer code</div>}
        </div>
      )}
    </div>
  )
}

/* ─── BUTTONS SECTION ─────────────────────────────────────────────────────── */
function ButtonsSection({ form, setForm }) {
  const [showMenu, setShowMenu] = useState(false)
  const menuRef = useRef(null)
  useClickOutside(menuRef, () => setShowMenu(false))
  const { subType, buttons = [] } = form

  function addBtn(kind) {
    const id = `btn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    const defaults = {
      custom: { text: '' },
      url: { text: '', urlType: 'static', url: '', trackConversions: false },
      wa_call: { text: 'Call on WhatsApp', activeFor: '7 days' },
      phone: { text: '', country: 'US +1', phone: '' },
      flow: { text: '', icon: 'DEFAULT', flowId: '', flowName: '', screenType: 'predefined', predefinedScreen: '' },
      copy_code: { code: '' },
    }
    setForm(f => ({ ...f, buttons: [...(f.buttons || []), { id, kind, ...defaults[kind] }] }))
    setShowMenu(false)
  }

  function removeBtn(id) { setForm(f => ({ ...f, buttons: (f.buttons || []).filter(b => b.id !== id) })) }
  function updateBtn(id, patch) { setForm(f => ({ ...f, buttons: (f.buttons || []).map(b => b.id === id ? { ...b, ...patch } : b) })) }

  const qrBtns = buttons.filter(b => b.kind === 'custom')
  const ctaBtns = buttons.filter(b => b.kind !== 'custom')
  const urlCount = buttons.filter(b => b.kind === 'url').length
  const phoneCount = buttons.filter(b => b.kind === 'phone').length
  const waCallCount = buttons.filter(b => b.kind === 'wa_call').length
  const flowCount = buttons.filter(b => b.kind === 'flow').length
  const copyCodeCount = buttons.filter(b => b.kind === 'copy_code').length

  const infoNote = (
    <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', padding: '8px 10px', background: C.primaryLt, borderRadius: 8, marginBottom: 12 }}>
      <span style={{ fontSize: 13 }}>ℹ</span>
      <span style={{ fontSize: 13, color: C.textDark }}>Only one button is supported for this type of template. The button text is not editable.</span>
    </div>
  )

  if (subType === 'order_details') {
    return (
      <Section title="Button">
        {infoNote}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ minWidth: 160 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Type of action</div>
            <div style={{ padding: '7px 9px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.bg, color: C.textMid, fontSize: 13 }}>Open order details</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button text</div>
            <div style={{ position: 'relative' }}>
              <div style={{ padding: '7px 50px 7px 9px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.bg, color: C.textMid, fontSize: 13 }}>Review and Pay</div>
              <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: C.textMuted }}>14/25</span>
            </div>
          </div>
        </div>
      </Section>
    )
  }

  if (subType === 'catalog') {
    const btnText = form.catalogFormat === 'catalogue_message' ? 'View catalog' : 'View Items'
    return (
      <Section title="Button">
        {infoNote}
        <div style={{ display: 'inline-flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Button text</div>
          <div style={{ position: 'relative' }}>
            <div style={{ padding: '7px 50px 7px 9px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.bg, color: C.textMid, fontSize: 13, minWidth: 140 }}>{btnText}</div>
            <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: C.textMuted }}>{btnText.length}/25</span>
          </div>
        </div>
      </Section>
    )
  }

  if (subType === 'calling_permissions') {
    return (
      <Section title="Buttons">
        {infoNote}
      </Section>
    )
  }

  const menuItems = [
    { label: 'Custom reply', kind: 'custom', note: null, disabled: false },
    { label: 'Visit website', kind: 'url', note: `${urlCount}/2 max`, disabled: urlCount >= 2 },
    { label: 'Call on WhatsApp', kind: 'wa_call', note: `${waCallCount}/1 max`, disabled: waCallCount >= 1 },
    { label: 'Call Phone Number', kind: 'phone', note: `${phoneCount}/1 max`, disabled: phoneCount >= 1 },
    { label: 'Complete flow', kind: 'flow', note: `${flowCount}/1 max`, disabled: flowCount >= 1 },
    { label: 'Copy offer code', kind: 'copy_code', note: `${copyCodeCount}/1 max`, disabled: copyCodeCount >= 1 },
  ]

  return (
    <Section
      title={<>Buttons <span style={{ fontWeight: 400, fontSize: 13, color: C.textMuted }}>· Optional</span></>}
      subtitle="Create buttons that let customers respond or take action. You can add up to ten buttons. More than three will appear as a list.">
      <div ref={menuRef} style={{ position: 'relative', display: 'inline-block', marginBottom: 16 }}>
        <button type="button" onClick={() => setShowMenu(m => !m)}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.card, fontSize: 13, fontWeight: 600, cursor: 'pointer', color: C.textDark }}>
          + Add button
          <svg width="10" height="6" viewBox="0 0 10 6" style={{ transition: 'transform .2s', transform: showMenu ? 'rotate(180deg)' : 'none' }}>
            <path d="M1 1l4 4 4-4" stroke={C.textMuted} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        {showMenu && (
          <div style={{ position: 'absolute', top: 'calc(100% + 4px)', left: 0, background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, boxShadow: '0 8px 24px rgba(0,0,0,0.12)', zIndex: 9999, minWidth: 230, overflow: 'hidden' }}>
            {menuItems.map(item => (
              <button key={item.kind} type="button" onClick={() => !item.disabled && addBtn(item.kind)} disabled={item.disabled}
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '10px 14px', border: 'none', background: 'none', cursor: item.disabled ? 'not-allowed' : 'pointer', textAlign: 'left' }}
                onMouseEnter={e => { if (!item.disabled) e.currentTarget.style.background = C.bg }}
                onMouseLeave={e => e.currentTarget.style.background = 'none'}
              >
                <span style={{ fontSize: 14, color: item.disabled ? C.disabled : C.textDark }}>{item.label}</span>
                {item.note && <span style={{ fontSize: 11, color: C.textMuted, marginLeft: 12 }}>{item.note}</span>}
              </button>
            ))}
          </div>
        )}
      </div>

      {qrBtns.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: C.textMuted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Quick reply</div>
          {qrBtns.map(b => <ButtonRow key={b.id} btn={b} onUpdate={p => updateBtn(b.id, p)} onRemove={() => removeBtn(b.id)} allButtons={buttons} isQR={true} />)}
        </div>
      )}

      {ctaBtns.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: C.textMuted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Call to action</div>
          {ctaBtns.map(b => <ButtonRow key={b.id} btn={b} onUpdate={p => updateBtn(b.id, p)} onRemove={() => removeBtn(b.id)} allButtons={buttons} isQR={false} />)}
        </div>
      )}

      {buttons.length >= 10 && (
        <div style={{ fontSize: 13, color: C.warn, background: C.warnLt, border: `1px solid #fde68a`, borderRadius: 8, padding: '7px 10px', marginTop: 8 }}>⚠ Maximum 10 buttons reached</div>
      )}
    </Section>
  )
}

/* ─── TTL SECTION ─────────────────────────────────────────────────────────── */
function TTLSection({ form, setForm }) {
  const { ttl = {} } = form
  return (
    <Section title="Message validity period">
      <p style={{ fontSize: 13, color: C.textMid, margin: '0 0 14px', lineHeight: 1.6 }}>
        Set a custom validity period that your marketing message must be delivered before it expires. If not delivered within this time, you will not be charged and the customer will not see the message.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: ttl.enabled ? 14 : 0 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.textDark }}>Set custom validity period</div>
          {!ttl.enabled && <div style={{ fontSize: 12, color: C.textMid, marginTop: 2 }}>Default: 10 minutes (WhatsApp standard)</div>}
        </div>
        {/* Toggle switch */}
        <label style={{ position: 'relative', display: 'inline-block', width: 40, height: 22, cursor: 'pointer', flexShrink: 0, marginLeft: 20 }}>
          <input type="checkbox" checked={!!ttl.enabled} onChange={e => setForm(f => ({ ...f, ttl: { ...(f.ttl || {}), enabled: e.target.checked } }))} style={{ opacity: 0, width: 0, height: 0, position: 'absolute' }} />
          <span style={{ position: 'absolute', inset: 0, background: ttl.enabled ? C.primary : C.border, borderRadius: 11, transition: '.2s' }} />
          <span style={{ position: 'absolute', width: 16, height: 16, background: '#fff', borderRadius: '50%', top: 3, left: ttl.enabled ? 21 : 3, transition: '.2s', boxShadow: '0 1px 3px rgba(0,0,0,.2)' }} />
        </label>
      </div>
      {ttl.enabled && (
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.textDark, marginBottom: 6 }}>Validity period</div>
          <CustomSelect value={ttl.duration || '12h'} onChange={v => setForm(f => ({ ...f, ttl: { ...f.ttl, duration: v } }))} options={TTL_OPTIONS} style={{ maxWidth: 260 }} />
        </div>
      )}
    </Section>
  )
}

/* ─── CATALOGUE FORMAT SECTION ────────────────────────────────────────────── */
function CatalogueFormatSection({ form, setForm }) {
  const opts = [
    { value: 'catalogue_message', label: 'Catalogue message', desc: 'Include the entire catalogue to give your users a comprehensive view of all your products.' },
    { value: 'multi_product_message', label: 'Multi-product message', desc: 'Include up to 30 products from the catalogue. Useful for showcasing new collections or a specific product category.' },
  ]
  return (
    <Section title="Catalogue format" subtitle={<><span style={{ color: C.primary, cursor: 'pointer' }}>Choose the message format that best fits your needs.</span></>}>
      {opts.map(o => {
        const sel = form.catalogFormat === o.value
        return (
          <label key={o.value} onClick={() => setForm(f => ({ ...f, catalogFormat: o.value }))} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '8px 0', cursor: 'pointer' }}>
            <div style={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${sel ? C.primary : C.border}`, background: sel ? C.primary : '#fff', flexShrink: 0, marginTop: 3, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {sel && <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fff' }} />}
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: sel ? 600 : 400, color: C.textDark }}>{o.label}</div>
              <div style={{ fontSize: 12, color: C.textMid, marginTop: 2, lineHeight: 1.4 }}>{o.desc}</div>
            </div>
          </label>
        )
      })}
    </Section>
  )
}

/* ─── CATALOGUE SETUP SECTION ─────────────────────────────────────────────── */
function CatalogueSetupSection() {
  return (
    <Section title="Catalogue setup" subtitle={<>Connect a catalogue to let customers view, message and send carts via WhatsApp. <span style={{ color: C.primary, cursor: 'pointer' }}>Learn more</span></>}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', padding: '9px 12px', background: C.primaryLt, borderRadius: 8, marginBottom: 12 }}>
        <span style={{ fontSize: 13 }}>ℹ</span>
        <span style={{ fontSize: 13, color: C.textDark }}>You cannot add media to this template. Instead, <span style={{ color: C.primary, cursor: 'pointer' }}>link your catalogue</span> to showcase your products.</span>
      </div>
      <div style={{ marginBottom: 10 }}>
        <span style={{ fontSize: 13, color: C.primary, cursor: 'pointer', fontWeight: 500 }}>My Business Catalogue</span>
      </div>
      <button type="button" style={{ padding: '8px 16px', border: `1px solid ${C.border}`, borderRadius: 8, background: C.card, fontSize: 13, cursor: 'pointer', fontWeight: 500, color: C.textDark }}>Manage catalogue connection</button>
    </Section>
  )
}

/* ─── EDIT STEP ───────────────────────────────────────────────────────────── */
function EditStep({ form, setForm }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)
  const subDef = catDef?.subTypes.find(s => s.value === form.subType)
  const langLabel = LANGUAGES.find(l => l.value === form.language)?.label || 'English'
  const showTTL = ['default', 'calling_permissions'].includes(form.subType) && form.category === 'MARKETING'
  const catStyle = CAT_STYLE[form.category] || CAT_STYLE.MARKETING

  return (
    <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

      {/* ── Left: scrollable form ── */}
      <div style={{ flex: 1, overflowY: 'auto', background: C.bg, padding: '24px 28px' }}>
        <div style={{ maxWidth: 720, margin: '0 auto' }}>

          {/* Context chip */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: C.card, border: `1px solid ${C.border}`, borderRadius: 20, marginBottom: 20 }}>
            <div style={{ width: 22, height: 22, borderRadius: 6, background: catStyle.light, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>
              {catDef?.tabIcon}
            </div>
            <span style={{ fontSize: 12, fontWeight: 600, color: C.textDark }}>{catDef?.label}</span>
            <span style={{ color: C.border }}>·</span>
            <span style={{ fontSize: 12, color: C.textMid }}>{subDef?.label}</span>
            {form.name && (
              <>
                <span style={{ color: C.border }}>·</span>
                <span style={{ fontSize: 12, color: C.primary, fontWeight: 600, fontFamily: 'monospace' }}>{form.name}</span>
              </>
            )}
          </div>

          {/* Template name & language */}
          <Section title="Template name & language">
            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div style={{ fontSize: 13, color: C.textDark, marginBottom: 6, fontWeight: 500 }}>Template name</div>
                <div style={{ position: 'relative' }}>
                  <input
                    value={form.name || ''}
                    onChange={e => {
                      const v = e.target.value.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
                      setForm(f => ({ ...f, name: v }))
                    }}
                    placeholder="e.g. welcome_message"
                    maxLength={512}
                    style={{ width: '100%', padding: '9px 60px 9px 10px', border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: C.textDark }}
                    onFocus={e => e.target.style.borderColor = C.primary}
                    onBlur={e => e.target.style.borderColor = C.border}
                  />
                  <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: C.textMuted }}>{(form.name || '').length}/512</span>
                </div>
                {form.name && !/^[a-z0-9_]+$/.test(form.name) && (
                  <div style={{ fontSize: 11, color: C.danger, marginTop: 4 }}>Only lowercase letters, numbers and underscores allowed</div>
                )}
              </div>
              <div style={{ minWidth: 200 }}>
                <div style={{ fontSize: 13, color: C.textDark, marginBottom: 6, fontWeight: 500 }}>Language</div>
                <SearchableSelect
                  value={form.language || 'en'}
                  onChange={v => setForm(f => ({ ...f, language: v }))}
                  options={LANGUAGES}
                />
              </div>
            </div>
          </Section>

          {form.subType === 'catalog' && (
            <>
              <CatalogueFormatSection form={form} setForm={setForm} />
              <CatalogueSetupSection />
            </>
          )}

          <ContentSection form={form} setForm={setForm} />
          <ButtonsSection form={form} setForm={setForm} />
          {showTTL && <TTLSection form={form} setForm={setForm} />}

          <div style={{ height: 20 }} />
        </div>
      </div>

      {/* ── Right: sticky preview + readiness ── */}
      <div style={{ width: 290, flexShrink: 0, borderLeft: `1px solid ${C.border}`, background: C.card, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>

        {/* Preview header */}
        <div style={{ padding: '14px 16px 10px', borderBottom: `1px solid ${C.bg}`, flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22c55e' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: C.textDark }}>Live preview</span>
          </div>
          <p style={{ fontSize: 11, color: C.textMuted, margin: '3px 0 0' }}>Updates as you type</p>
        </div>

        {/* Phone preview */}
        <div style={{ padding: '16px 14px 0' }}>
          <PhonePreview form={form} />
        </div>

        {/* Readiness checklist */}
        <div style={{ padding: '14px 14px 16px', flex: 1 }}>
          <ValidationPanel form={form} />
        </div>
      </div>
    </div>
  )
}

/* ─── REVIEW STEP ─────────────────────────────────────────────────────────── */
function ReviewStep({ form }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)
  const subDef = catDef?.subTypes.find(s => s.value === form.subType)
  const payload = buildAPIPayload(form)
  const catStyle = CAT_STYLE[form.category] || CAT_STYLE.MARKETING
  const [showPayload, setShowPayload] = useState(false)

  const rows = [
    { label: 'Name',     icon: '🏷️', value: form.name || '—', mono: true },
    { label: 'Category', icon: '📁', value: `${catDef?.label} · ${subDef?.label}` },
    { label: 'Language', icon: '🌐', value: LANGUAGES.find(l => l.value === form.language)?.label || form.language },
    { label: 'Header',   icon: '📝', value: form.mediaSample && form.mediaSample !== 'none' ? `Media: ${form.mediaSample}` : form.headerText ? `"${form.headerText.slice(0, 50)}"` : 'None' },
    { label: 'Body',     icon: '💬', value: `${(form.body || '').length} chars · ${extractVariables(form.body || '').length} variable(s)` },
    { label: 'Buttons',  icon: '🔘', value: (form.buttons || []).length > 0 ? `${(form.buttons || []).length} button(s): ${(form.buttons || []).map(b => b.text || b.kind).join(', ')}` : 'None' },
    { label: 'Validity', icon: '⏱️', value: form.ttl?.enabled ? TTL_OPTIONS.find(o => o.value === form.ttl?.duration)?.label || form.ttl?.duration : 'Default (10 min)' },
  ]

  const bodyVars = extractVariables(form.body || '')
  const missingSamples = bodyVars.filter(n => !form.samples?.[`b${n}`]?.trim()).length
  const hasIssues = !form.name || !form.body?.trim() || missingSamples > 0

  return (
    <div style={{ flex: 1, overflowY: 'auto', background: C.bg, padding: '36px 0' }}>
      <div style={{ maxWidth: 840, margin: '0 auto', padding: '0 32px' }}>

        {/* ── Step header ── */}
        <div style={{ marginBottom: 28, textAlign: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 20, marginBottom: 12 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#22c55e' }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#15803d', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Step 3 of 3 · Final review</span>
          </div>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: C.textDark, margin: '0 0 8px', letterSpacing: '-0.3px' }}>
            Ready to submit?
          </h2>
          <p style={{ fontSize: 14, color: C.textMid, margin: 0, lineHeight: 1.6, maxWidth: 460, marginInline: 'auto' }}>
            Double-check everything below before sending to Meta for review. Approval usually takes a few minutes to 24 hours.
          </p>
        </div>

        {/* ── Main layout ── */}
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>

          {/* Left column */}
          <div style={{ flex: 1 }}>

            {/* Status banner */}
            <div style={{ padding: '14px 18px', borderRadius: 12, background: hasIssues ? '#fef2f2' : '#f0fdf4', border: `1px solid ${hasIssues ? '#fca5a5' : '#bbf7d0'}`, display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ fontSize: 20 }}>{hasIssues ? '⚠️' : '✅'}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: hasIssues ? '#991b1b' : '#15803d', marginBottom: 2 }}>
                  {hasIssues ? 'Some fields need attention' : 'All checks passed — ready to submit'}
                </div>
                <div style={{ fontSize: 12, color: hasIssues ? '#dc2626' : '#16a34a' }}>
                  {hasIssues
                    ? (!form.name ? 'Template name is missing. ' : '') + (!form.body?.trim() ? 'Body text is missing. ' : '') + (missingSamples > 0 ? `${missingSamples} sample value(s) missing.` : '')
                    : 'Template will be submitted to Meta for review immediately.'}
                </div>
              </div>
            </div>

            {/* Summary card */}
            <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, overflow: 'hidden', marginBottom: 14 }}>
              {/* Card header */}
              <div style={{ padding: '14px 20px', borderBottom: `1px solid ${C.bg}`, display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: 9, background: catStyle.light, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
                  {catDef?.tabIcon}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.textDark }}>{form.name || <em style={{ color: C.textMuted, fontWeight: 400 }}>Unnamed template</em>}</div>
                  <div style={{ fontSize: 12, color: C.textMuted }}>{catDef?.label} · {subDef?.label}</div>
                </div>
              </div>
              {/* Rows */}
              {rows.map((row, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '10px 20px', borderBottom: i < rows.length - 1 ? `1px solid ${C.bg}` : 'none' }}>
                  <span style={{ fontSize: 14, flexShrink: 0, width: 20, marginTop: 1 }}>{row.icon}</span>
                  <span style={{ width: 90, fontSize: 12, color: C.textMuted, flexShrink: 0, fontWeight: 500, paddingTop: 1 }}>{row.label}</span>
                  <span style={{ fontSize: 13, color: C.textDark, fontWeight: 500, fontFamily: row.mono ? 'monospace' : 'inherit', flex: 1, wordBreak: 'break-all' }}>{row.value}</span>
                </div>
              ))}
            </div>

            {/* API payload collapsible */}
            <div style={{ background: '#0f172a', borderRadius: 12, overflow: 'hidden' }}>
              <button type="button"
                onClick={() => setShowPayload(p => !p)}
                style={{ width: '100%', padding: '11px 16px', border: 'none', background: 'none', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 12, color: '#94a3b8', fontWeight: 700, letterSpacing: '0.04em' }}>META CLOUD API PAYLOAD</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <button type="button" onClick={e => { e.stopPropagation(); navigator.clipboard?.writeText(JSON.stringify(payload, null, 2)) }}
                    style={{ fontSize: 11, color: '#38bdf8', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>📋 Copy</button>
                  <span style={{ fontSize: 11, color: '#64748b' }}>{showPayload ? '▲ Hide' : '▼ Show'}</span>
                </div>
              </button>
              {showPayload && (
                <pre style={{ margin: 0, padding: '0 16px 14px', fontSize: 11, color: '#94a3b8', overflowX: 'auto', lineHeight: 1.7, maxHeight: 280, overflowY: 'auto' }}>
                  {JSON.stringify(payload, null, 2)}
                </pre>
              )}
            </div>
          </div>

          {/* Right column — preview */}
          <div style={{ width: 270, flexShrink: 0 }}>
            <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: '16px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22c55e' }} />
                <span style={{ fontSize: 12, fontWeight: 700, color: C.textDark }}>Message preview</span>
              </div>
              <PhonePreview form={form} />
            </div>
          </div>
        </div>

        <div style={{ height: 24 }} />
      </div>
    </div>
  )
}

/* ─── TEMPLATE BUILDER ────────────────────────────────────────────────────── */
export function TemplateBuilder({ onBack }) {
  const [step, setStep] = useState(0)
  const [done, setDone] = useState(false)
  const [form, setForm] = useState({
    category: 'MARKETING', subType: 'default',
    name: '', language: 'en',
    varType: 'number', mediaSample: 'none', mediaUrl: '',
    headerText: '', body: '', footer: '',
    buttons: [], samples: {},
    ttl: { enabled: false, duration: '12h' },
    catalogFormat: 'catalogue_message',
  })

  const hasIssues = !form.name || !/^[a-z0-9_]+$/.test(form.name) || !form.body?.trim()

  if (done) return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 60px)', margin: '-20px', background: C.bg, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center', maxWidth: 420 }}>
        {/* Animated success ring */}
        <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'linear-gradient(135deg, #22c55e, #16a34a)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, margin: '0 auto 24px', boxShadow: '0 8px 32px #22c55e30' }}>✓</div>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: C.textDark, margin: '0 0 10px', letterSpacing: '-0.4px' }}>Template submitted!</h2>
        <p style={{ fontSize: 14, color: C.textMid, margin: '0 0 10px', lineHeight: 1.7 }}>
          <strong style={{ color: C.textDark, fontFamily: 'monospace', background: C.bg, padding: '1px 6px', borderRadius: 5 }}>{form.name}</strong> has been sent to Meta for review.
        </p>
        <p style={{ fontSize: 13, color: C.textMuted, margin: '0 0 28px', lineHeight: 1.6 }}>
          Approval typically takes a few minutes to 24 hours. You'll be notified when it's ready.
        </p>
        <button type="button" onClick={onBack}
          style={{ padding: '11px 28px', background: C.primary, color: '#fff', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: `0 4px 14px ${C.primary}40` }}>
          ← Back to Templates
        </button>
      </div>
    </div>
  )

  const STEP_LABELS = ['Set up', 'Edit content', 'Review & Submit']

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 60px)', margin: '-20px', background: C.bg, overflow: 'hidden' }}>

      {/* ── Top bar ── */}
      <div style={{ height: 56, background: C.card, borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', flexShrink: 0 }}>
        <button type="button" onClick={onBack}
          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', fontSize: 13, color: C.textMid, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 8, cursor: 'pointer', fontWeight: 500, flexShrink: 0 }}>
          ← Back
        </button>
        <div style={{ width: 1, height: 20, background: C.border, flexShrink: 0 }} />
        <span style={{ fontSize: 14, fontWeight: 700, color: C.textDark, flexShrink: 0 }}>Create template</span>

        {/* Step progress — centered in bar */}
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 0 }}>
          {STEP_LABELS.map((label, i) => {
            const isDone = i < step
            const isActive = i === step
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center' }}>
                {/* Connector line before step */}
                {i > 0 && (
                  <div style={{ width: 40, height: 2, background: isDone ? '#22c55e' : C.border, transition: 'background .3s' }} />
                )}
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '5px 12px', borderRadius: 20,
                  background: isDone ? '#f0fdf4' : isActive ? C.primaryLt : 'transparent',
                  border: `1.5px solid ${isDone ? '#bbf7d0' : isActive ? C.primary : C.border}`,
                  transition: 'all .2s',
                }}>
                  <div style={{ width: 18, height: 18, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: isDone ? '#22c55e' : isActive ? C.primary : C.border,
                    fontSize: 8, fontWeight: 900, color: '#fff', flexShrink: 0, transition: 'background .2s' }}>
                    {isDone ? '✓' : i + 1}
                  </div>
                  <span style={{ fontSize: 12, fontWeight: isActive ? 700 : 500,
                    color: isDone ? '#15803d' : isActive ? C.primary : C.textMuted, whiteSpace: 'nowrap' }}>
                    {label}
                  </span>
                </div>
              </div>
            )
          })}
        </div>

        {/* Spacer to balance back button */}
        <div style={{ width: 80, flexShrink: 0 }} />
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {step === 0 && <SetupStep form={form} setForm={setForm} />}
        {step === 1 && <EditStep form={form} setForm={setForm} />}
        {step === 2 && <ReviewStep form={form} />}
      </div>

      {/* ── Bottom footer: single CTA bar ── */}
      <div style={{ background: C.card, borderTop: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 28px', flexShrink: 0 }}>
        {/* Left: subtle cancel */}
        <button type="button" onClick={onBack}
          style={{ padding: '0', border: 'none', background: 'none', fontSize: 13, cursor: 'pointer', color: C.textMuted, fontWeight: 500, textDecoration: 'underline', textUnderlineOffset: 3 }}>
          Cancel
        </button>

        {/* Right: step-aware navigation */}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          {/* Helper text for disabled state */}
          {step === 1 && hasIssues && (
            <span style={{ fontSize: 12, color: C.textMuted, fontStyle: 'italic' }}>
              Fill in template name & body to continue
            </span>
          )}

          {step > 0 && (
            <button type="button" onClick={() => setStep(s => s - 1)}
              style={{ padding: '9px 20px', border: `1px solid ${C.border}`, borderRadius: 9, background: C.card, fontSize: 13, cursor: 'pointer', color: C.textDark, fontWeight: 600 }}>
              ← Previous
            </button>
          )}

          {step < 2 && (
            <button type="button"
              onClick={() => { if (step === 1 && hasIssues) return; setStep(s => s + 1) }}
              disabled={step === 1 && hasIssues}
              style={{
                padding: '9px 26px', border: 'none', borderRadius: 9, fontSize: 13, fontWeight: 700, cursor: (step === 1 && hasIssues) ? 'not-allowed' : 'pointer',
                background: (step === 1 && hasIssues) ? C.bg : C.primary,
                color: (step === 1 && hasIssues) ? C.disabled : '#fff',
                boxShadow: (step === 1 && hasIssues) ? 'none' : `0 4px 14px ${C.primary}35`,
                transition: 'all .15s',
              }}>
              {step === 0 ? 'Continue →' : 'Review →'}
            </button>
          )}

          {step === 2 && (
            <button type="button" onClick={() => setDone(true)} disabled={hasIssues}
              style={{
                padding: '9px 28px', border: 'none', borderRadius: 9, fontSize: 13, fontWeight: 700, cursor: hasIssues ? 'not-allowed' : 'pointer',
                background: hasIssues ? C.bg : '#22c55e',
                color: hasIssues ? C.disabled : '#fff',
                boxShadow: hasIssues ? 'none' : '0 4px 14px #22c55e35',
                transition: 'all .15s',
              }}>
              ✓ Submit for Review
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─── STATUS CONFIG ───────────────────────────────────────────────────────── */
const STATUS_META = {
  APPROVED: { dot: '#22c55e', bg: '#f0fdf4', color: '#15803d', label: 'Active' },
  PENDING:  { dot: '#f59e0b', bg: '#fffbeb', color: '#92400e', label: 'In review' },
  REJECTED: { dot: '#ef4444', bg: '#fef2f2', color: '#991b1b', label: 'Rejected' },
  DRAFT:    { dot: '#94a3b8', bg: '#f8fafc', color: '#475569', label: 'Draft' },
}

/* ─── TEMPLATE STATUS PILL (Tailwind — matches Broadcasting) ──────────────── */
function TemplatePill({ status }) {
  const cfg = {
    APPROVED: { bg: 'bg-emerald-50', text: 'text-emerald-700', ring: 'ring-emerald-200', dot: 'bg-emerald-500', label: 'Active'    },
    PENDING:  { bg: 'bg-amber-50',   text: 'text-amber-700',   ring: 'ring-amber-200',   dot: 'bg-amber-400',  label: 'In review' },
    REJECTED: { bg: 'bg-red-50',     text: 'text-red-700',     ring: 'ring-red-200',     dot: 'bg-red-500',    label: 'Rejected'  },
    DRAFT:    { bg: 'bg-slate-50',   text: 'text-slate-600',   ring: 'ring-slate-200',   dot: 'bg-slate-400',  label: 'Draft'     },
  }[status] || { bg: 'bg-slate-50', text: 'text-slate-600', ring: 'ring-slate-200', dot: 'bg-slate-400', label: status }
  return (
    <span className={clsx('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ring-1', cfg.bg, cfg.text, cfg.ring)}>
      <span className={clsx('w-1.5 h-1.5 rounded-full flex-shrink-0', cfg.dot)} />
      {cfg.label}
    </span>
  )
}

/* ─── DEMO DATA ───────────────────────────────────────────────────────────── */
const DEMO = [
  { id: 1, name: 'elets_leads1', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hey {{1}}! What is your opinion on automating your sales and marketing?', buttons: [{ id: 'b1', kind: 'url', text: 'Visit us' }], mediaSample: 'none', footer: '', samples: {}, delivered: 648, readRate: '59% (383)', topBlock: '—', lastEdited: '20 Apr 2026' },
  { id: 2, name: 'elogic_tech_sample', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hello {{1}}. This is to inform you that a system update is scheduled.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0%', topBlock: '—', lastEdited: '20 Mar 2026' },
  { id: 3, name: 'email_opens_re3', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'The new academic year is about to begin. Register now for early access.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0%', topBlock: '—', lastEdited: '16 Mar 2026' },
  { id: 4, name: 'deepaksample', category: 'MARKETING', status: 'PENDING', language: 'en', body: 'Deepak', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '—', topBlock: '—', lastEdited: '13 Mar 2026' },
  { id: 5, name: 'nisus_test', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hi {{1}}. Welcome to SmartBot! Thanks for joining us.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0%', topBlock: '—', lastEdited: '10 Mar 2026' },
  { id: 6, name: 'template_click', category: 'UTILITY', status: 'APPROVED', language: 'en', body: 'We are testing the clicks and replies, please respond.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0%', topBlock: '—', lastEdited: '9 Mar 2026' },
  { id: 7, name: 'lost_deals_2', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Just following up on our earlier message. Still interested?', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0%', topBlock: '—', lastEdited: '9 Mar 2026' },
  { id: 8, name: 'order_confirmation', category: 'UTILITY', status: 'REJECTED', language: 'en_US', body: 'Hi {{1}}, your order #{{2}} is confirmed! Estimated delivery: {{3}}.', buttons: [{ id: 'b1', kind: 'url', text: 'Track Order' }], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '—', topBlock: 'Policy violation', lastEdited: '25 Feb 2026' },
]

/* ─── TEMPLATE ROW ────────────────────────────────────────────────────────── */
function TemplateRow({ tpl, onPreview, onCreate, onDelete }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef(null)
  useClickOutside(menuRef, () => setMenuOpen(false))
  const catDef = CATEGORY_DEFS.find(c => c.value === tpl.category)
  const langLabel = LANGUAGES.find(l => l.value === tpl.language)?.label || tpl.language

  const MENU_ITEMS = [
    { Icon: Eye,     label: 'Preview',       fn: onPreview },
    { Icon: Pencil,  label: 'Edit template', fn: onCreate  },
    { Icon: Copy,    label: 'Duplicate',     fn: () => {}  },
    { Icon: Trash2,  label: 'Delete',        fn: onDelete, danger: true },
  ]

  return (
    <tr className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors group">
      <td className="px-4 py-3 w-10 align-middle" onClick={e => e.stopPropagation()}>
        <input type="checkbox" className="cursor-pointer accent-primary mt-0.5" />
      </td>
      <td className="px-4 py-3 align-top cursor-pointer max-w-xs" onClick={onPreview}>
        <div className="text-xs font-semibold text-slate-900 mb-0.5">{tpl.name}</div>
        <div className="text-xs text-slate-500 line-clamp-2">{tpl.body || 'No body text'}</div>
      </td>
      <td className="px-4 py-3 align-middle cursor-pointer" onClick={onPreview}>
        <span className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 rounded-md text-xs font-medium text-slate-600">
          {catDef?.tabIcon} {catDef?.label || tpl.category}
        </span>
      </td>
      <td className="px-4 py-3 align-middle text-xs text-slate-600 cursor-pointer" onClick={onPreview}>{langLabel}</td>
      <td className="px-4 py-3 align-middle cursor-pointer" onClick={onPreview}>
        <TemplatePill status={tpl.status} />
      </td>
      <td className="px-4 py-3 align-middle text-xs font-semibold text-slate-900 cursor-pointer" onClick={onPreview}>
        {(tpl.delivered ?? 0).toLocaleString()}
      </td>
      <td className="px-4 py-3 align-middle text-xs text-slate-600 cursor-pointer" onClick={onPreview}>{tpl.readRate ?? '—'}</td>
      <td className="px-4 py-3 align-middle text-xs text-slate-500 cursor-pointer" onClick={onPreview}>{tpl.topBlock ?? '—'}</td>
      <td className="px-4 py-3 align-middle">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-slate-400 whitespace-nowrap cursor-pointer" onClick={onPreview}>{tpl.lastEdited || '—'}</span>
          <div ref={menuRef} className="relative">
            <button type="button"
              onClick={e => { e.stopPropagation(); setMenuOpen(m => !m) }}
              className={clsx('p-1.5 rounded-lg transition-colors', menuOpen ? 'bg-slate-100 text-slate-700' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100')}>
              <MoreHorizontal size={15} />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-surface-border rounded-xl shadow-lg z-50 min-w-[160px] overflow-hidden py-1">
                {MENU_ITEMS.map(item => (
                  <button key={item.label} type="button"
                    onClick={() => { setMenuOpen(false); item.fn?.() }}
                    className={clsx('flex items-center gap-2.5 w-full px-3 py-2 text-left text-sm transition-colors',
                      item.danger ? 'text-red-600 hover:bg-red-50' : 'text-slate-700 hover:bg-slate-50')}>
                    <item.Icon size={13} className="flex-shrink-0" />
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </td>
    </tr>
  )
}

/* ─── PREVIEW MODAL ───────────────────────────────────────────────────────── */
function PreviewModal({ tpl, onClose, onCreate }) {
  if (!tpl) return null
  const mockForm = { headerText: tpl.headerText || '', mediaSample: tpl.mediaSample || 'none', mediaUrl: '', body: tpl.body || '', footer: tpl.footer || '', buttons: tpl.buttons || [], samples: tpl.samples || {} }
  const catDef = CATEGORY_DEFS.find(c => c.value === tpl.category)
  return (
    <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-[10000] p-5" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl min-w-[340px] max-h-[90vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-surface-border">
          <div>
            <div className="text-xs font-semibold text-slate-900">{tpl.name}</div>
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <span className="text-xs text-slate-500">{catDef?.tabIcon} {catDef?.label}</span>
              <span className="text-xs text-slate-300">·</span>
              <span className="text-xs text-slate-500">{LANGUAGES.find(l => l.value === tpl.language)?.label || tpl.language}</span>
              <TemplatePill status={tpl.status} />
            </div>
          </div>
          <button type="button" onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors ml-3 flex-shrink-0">
            <X size={14} />
          </button>
        </div>
        {/* Body */}
        <div className="p-5 overflow-y-auto">
          <PhonePreview form={mockForm} />
          {tpl.body && (
            <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-surface-border">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Body text</div>
              <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">{tpl.body}</div>
            </div>
          )}
        </div>
        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-surface-border">
          <button type="button" onClick={onClose}
            className="px-3 py-1.5 text-[11px] font-medium text-slate-700 border border-surface-border rounded-xl bg-white hover:bg-slate-50 transition-colors">
            Close
          </button>
          <button type="button" onClick={() => { onClose(); onCreate() }}
            className="px-3 py-1.5 text-[11px] font-semibold text-white bg-primary rounded-xl hover:bg-blue-700 transition-colors">
            Edit template
          </button>
        </div>
      </div>
    </div>
  )
}

/* ─── TEMPLATE GROUPS TAB ─────────────────────────────────────────────────── */
function TemplateGroupsTab() {
  return (
    <div className="rounded-2xl border border-surface-border bg-white py-16 text-center">
      <div className="text-4xl mb-3">📂</div>
      <div className="text-xs font-semibold text-slate-900 mb-2">No template groups yet</div>
      <div className="text-sm text-slate-500 max-w-xs mx-auto mb-5 leading-relaxed">
        Group related templates together to organise your library and apply bulk actions.
      </div>
      <button type="button" className="px-3 py-1.5 bg-primary text-white rounded-xl text-[11px] font-semibold hover:bg-blue-700 transition-colors shadow-sm">
        + Create group
      </button>
    </div>
  )
}

/* ─── TEMPLATE LIST ───────────────────────────────────────────────────────── */
function TemplateList({ onCreate }) {
  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('ALL')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [templates, setTemplates] = useState(DEMO)
  const [preview, setPreview] = useState(null)
  const [activeTab, setActiveTab] = useState('templates')
  const [sortBy, setSortBy] = useState('lastEdited')
  const [sortDir, setSortDir] = useState('desc')
  const [selected, setSelected] = useState(new Set())

  const filtered = useMemo(() => {
    let list = templates.filter(t => {
      const q = search.toLowerCase()
      return (!q || t.name.toLowerCase().includes(q) || (t.body || '').toLowerCase().includes(q)) &&
        (catFilter === 'ALL' || t.category === catFilter) &&
        (statusFilter === 'ALL' || t.status === statusFilter)
    })
    list = [...list].sort((a, b) => {
      let av = a[sortBy] ?? '', bv = b[sortBy] ?? ''
      if (typeof av === 'string') { av = av.toLowerCase(); bv = bv.toLowerCase() }
      return sortDir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1)
    })
    return list
  }, [templates, search, catFilter, statusFilter, sortBy, sortDir])

  function toggleSort(col) {
    if (sortBy === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortBy(col); setSortDir('asc') }
  }

  function SortIcon({ col }) {
    if (sortBy !== col) return <ChevronsUpDown size={11} className="inline ml-0.5 text-slate-400" />
    return sortDir === 'asc'
      ? <ChevronUp size={11} className="inline ml-0.5 text-primary" />
      : <ChevronDown size={11} className="inline ml-0.5 text-primary" />
  }

  const allSelected = filtered.length > 0 && filtered.every(t => selected.has(t.id))
  function toggleAll() {
    if (allSelected) setSelected(new Set())
    else setSelected(new Set(filtered.map(t => t.id)))
  }

  const cols = [
    { key: 'name',        label: 'Template name',    w: '22%' },
    { key: 'category',    label: 'Category',         w: '10%' },
    { key: 'language',    label: 'Language',          w: '9%'  },
    { key: 'status',      label: 'Status',            w: '10%' },
    { key: 'delivered',   label: 'Delivered',         w: '8%'  },
    { key: 'readRate',    label: 'Read rate',         w: '8%'  },
    { key: 'topBlock',    label: 'Top block reason',  w: '11%' },
    { key: 'lastEdited',  label: 'Last edited',       w: '10%' },
  ]

  const summaryStats = [
    { label: 'Total templates', value: templates.length,                                          twColor: 'text-slate-900'   },
    { label: 'Active',          value: templates.filter(t => t.status === 'APPROVED').length,     twColor: 'text-emerald-600' },
    { label: 'In review',       value: templates.filter(t => t.status === 'PENDING').length,      twColor: 'text-amber-500'   },
    { label: 'Rejected',        value: templates.filter(t => t.status === 'REJECTED').length,     twColor: 'text-red-500'     },
  ]

  return (
    <div>
      {/* ── Page header ── */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-[15px] font-bold text-slate-900">Message Templates</h1>
          <p className="text-[11px] text-slate-500 mt-1">Create and manage your WhatsApp message templates</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="button"
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-[11px] font-semibold border border-surface-border text-slate-700 bg-white hover:bg-slate-50 transition-colors">
            <BarChart2 size={13} /> Compare
          </button>
          <button type="button" onClick={onCreate}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-[11px] font-semibold bg-primary text-white hover:bg-blue-700 transition-colors shadow-sm">
            <Plus size={13} /> Create Template
          </button>
        </div>
      </div>

      {/* ── KPI tiles ── */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {summaryStats.map(s => (
          <div key={s.label} className="rounded-2xl border border-surface-border bg-white p-4">
            <p className="text-xs font-medium text-slate-500 mb-1.5">{s.label}</p>
            <p className={clsx('text-lg font-bold', s.twColor)}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* ── Tabs ── */}
      <div className="flex gap-1 border-b border-surface-border mb-5">
        {[['templates', 'Templates', templates.length], ['groups', 'Template groups', 0]].map(([val, lbl, count]) => (
          <button key={val} type="button" onClick={() => setActiveTab(val)}
            className={clsx('flex items-center gap-2 px-4 py-2 text-xs font-medium transition-colors border-b-2 -mb-px',
              activeTab === val ? 'text-primary border-primary font-semibold' : 'text-slate-500 border-transparent hover:text-slate-700')}>
            {lbl}
            {count > 0 && (
              <span className={clsx('text-xs px-2 py-0.5 rounded-full font-semibold',
                activeTab === val ? 'bg-blue-50 text-primary' : 'bg-slate-100 text-slate-500')}>
                {count}
              </span>
            )}
          </button>
        ))}
      </div>

      {activeTab === 'groups' ? <TemplateGroupsTab /> : (
        <>
          {/* ── Search + filters ── */}
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Search templates..."
                className="pl-9 pr-3 py-2 text-sm border border-surface-border rounded-xl bg-white text-slate-900 placeholder-slate-400 outline-none focus:border-primary focus:ring-2 focus:ring-blue-50 transition-colors w-52"
              />
            </div>
            <Select
              value={catFilter}
              onChange={v => setCatFilter(v)}
              options={[
                { value: 'ALL', label: 'All categories' },
                { value: 'MARKETING', label: '📣 Marketing' },
                { value: 'UTILITY', label: '🔔 Utility' },
                { value: 'AUTHENTICATION', label: '✏️ Authentication' },
              ]}
            />
            <Select
              options={[{ value: 'all', label: 'All languages' }]}
              placeholder="All languages"
            />
            <Select
              value={statusFilter}
              onChange={v => setStatusFilter(v)}
              options={[
                { value: 'ALL', label: 'All statuses' },
                { value: 'APPROVED', label: 'Active' },
                { value: 'PENDING', label: 'In review' },
                { value: 'REJECTED', label: 'Rejected' },
                { value: 'DRAFT', label: 'Draft' },
              ]}
            />
            <Select
              options={[
                { value: '7d', label: 'Last 7 days' },
                { value: '30d', label: 'Last 30 days' },
                { value: '90d', label: 'Last 90 days' },
              ]}
              placeholder="Last 7 days"
            />
            <button type="button" onClick={() => { setSearch(''); setCatFilter('ALL'); setStatusFilter('ALL') }}
              className="flex items-center gap-1.5 px-3 py-2 text-sm border border-surface-border rounded-xl bg-white text-slate-500 font-medium hover:bg-slate-50 hover:text-slate-700 transition-colors">
              <RefreshCw size={13} /> Reset
            </button>
          </div>

          {/* ── Bulk bar ── */}
          {selected.size > 0 && (
            <div className="flex items-center gap-3 px-4 py-2.5 bg-blue-50 border border-blue-100 rounded-xl mb-4">
              <span className="text-xs font-semibold text-primary">{selected.size} selected</span>
              <div className="w-px h-4 bg-blue-200" />
              <button type="button"
                className="flex items-center gap-1 text-xs text-red-600 font-medium hover:text-red-700 transition-colors"
                onClick={() => { setTemplates(ts => ts.filter(t => !selected.has(t.id))); setSelected(new Set()) }}>
                <Trash2 size={12} /> Delete selected
              </button>
              <button type="button"
                className="text-xs text-slate-500 ml-auto hover:text-slate-700 transition-colors"
                onClick={() => setSelected(new Set())}>
                Clear selection
              </button>
            </div>
          )}

          {/* ── Table ── */}
          <div className="rounded-2xl border border-surface-border bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[700px] border-collapse">
                <thead>
                  <tr className="border-b border-surface-border bg-slate-50">
                    <th className="w-10 px-4 py-3 text-center">
                      <input type="checkbox" checked={allSelected} onChange={toggleAll} className="cursor-pointer accent-primary" />
                    </th>
                    {cols.map(col => (
                      <th key={col.key} onClick={() => toggleSort(col.key)} style={{ width: col.w }}
                        className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer select-none hover:text-slate-700 transition-colors">
                        {col.label}<SortIcon col={col.key} />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="text-center py-16">
                        <div className="text-3xl mb-3">📋</div>
                        <div className="text-xs font-semibold text-slate-900 mb-1">No templates found</div>
                        <div className="text-sm text-slate-500">Try adjusting your search or filter criteria.</div>
                      </td>
                    </tr>
                  ) : filtered.map(tpl => (
                    <TemplateRow key={tpl.id} tpl={tpl}
                      onPreview={() => setPreview(tpl)}
                      onCreate={onCreate}
                      onDelete={() => { setTemplates(ts => ts.filter(t => t.id !== tpl.id)); setSelected(s => { s.delete(tpl.id); return new Set(s) }) }}
                    />
                  ))}
                </tbody>
              </table>
            </div>

            {/* Table footer */}
            {filtered.length > 0 && (
              <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100">
                <span className="text-xs text-slate-400">Showing {filtered.length} of {templates.length} templates</span>
                <div className="flex gap-1">
                  <button type="button"
                    className="w-7 h-7 rounded-lg bg-primary text-white text-xs font-semibold border border-primary">
                    1
                  </button>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {preview && (
        <PreviewModal tpl={preview} onClose={() => setPreview(null)} onCreate={onCreate} />
      )}
    </div>
  )
}

/* ─── MAIN EXPORT ─────────────────────────────────────────────────────────── */
export default function Templates() {
  const [view, setView] = useState('list')
  return view === 'list'
    ? <TemplateList onCreate={() => setView('create')} />
    : <TemplateBuilder onBack={() => setView('list')} />
}
