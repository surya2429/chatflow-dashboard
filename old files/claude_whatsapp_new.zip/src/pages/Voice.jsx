/**
 * Voice.jsx — WhatsApp Calling (User-focused)
 * Simple, clear setup flow + essentials only.
 */
import { useState, useMemo } from 'react'
import {
  PhoneCall, PhoneOff, PhoneMissed, PhoneIncoming, PhoneOutgoing,
  CheckCircle2, Clock, AlertCircle, ChevronRight, Search,
  Download, RefreshCw, Users, Calendar, ToggleLeft, ToggleRight,
  ArrowRight, Zap, Shield, Bell,
} from 'lucide-react'
import clsx from 'clsx'
import Select, { NativeSelect } from '../components/Select'

// ── Mock call history ─────────────────────────────────────────────────────────
const MOCK_CALLS = [
  { id: 'wacid.001', direction: 'USER_INITIATED',     status: 'COMPLETED', name: 'Rahul Mehta',  phone: '+91 98765 43210', duration: 187, ts: Date.now() - 3600000  },
  { id: 'wacid.002', direction: 'BUSINESS_INITIATED', status: 'COMPLETED', name: 'Priya Das',    phone: '+91 87654 32109', duration: 312, ts: Date.now() - 7200000  },
  { id: 'wacid.003', direction: 'USER_INITIATED',     status: 'MISSED',    name: 'Amit Patel',   phone: '+91 76543 21098', duration: 0,   ts: Date.now() - 10800000 },
  { id: 'wacid.004', direction: 'BUSINESS_INITIATED', status: 'COMPLETED', name: 'Kavya Nair',   phone: '+91 65432 10987', duration: 95,  ts: Date.now() - 86400000 },
  { id: 'wacid.005', direction: 'USER_INITIATED',     status: 'MISSED',    name: 'Rohan Gupta',  phone: '+91 54321 09876', duration: 0,   ts: Date.now() - 90000000 },
  { id: 'wacid.006', direction: 'USER_INITIATED',     status: 'COMPLETED', name: 'Sneha Reddy',  phone: '+91 43210 98765', duration: 241, ts: Date.now() - 172800000},
  { id: 'wacid.007', direction: 'BUSINESS_INITIATED', status: 'COMPLETED', name: 'Vikram Singh', phone: '+91 32109 87654', duration: 178, ts: Date.now() - 259200000},
]

const DEFAULT_HOURS = [
  { day: 'Monday',    open: '09:00', close: '18:00', enabled: true  },
  { day: 'Tuesday',   open: '09:00', close: '18:00', enabled: true  },
  { day: 'Wednesday', open: '09:00', close: '18:00', enabled: true  },
  { day: 'Thursday',  open: '09:00', close: '18:00', enabled: true  },
  { day: 'Friday',    open: '09:00', close: '17:00', enabled: true  },
  { day: 'Saturday',  open: '10:00', close: '14:00', enabled: false },
  { day: 'Sunday',    open: '10:00', close: '14:00', enabled: false },
]

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmtDuration(s) {
  if (!s) return '—'
  return `${Math.floor(s / 60)}m ${s % 60}s`
}
function fmtTime(ts) {
  const d = new Date(ts)
  const now = new Date()
  const diffH = Math.floor((now - d) / 3600000)
  if (diffH < 1) return 'Just now'
  if (diffH < 24) return `${diffH}h ago`
  const diffD = Math.floor(diffH / 24)
  if (diffD === 1) return 'Yesterday'
  return `${diffD} days ago`
}

// ── Small reusable pieces ─────────────────────────────────────────────────────
function StatusPill({ on }) {
  return (
    <span className={clsx(
      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold',
      on ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
    )}>
      <span className={clsx('w-1.5 h-1.5 rounded-full', on ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400')} />
      {on ? 'Active' : 'Inactive'}
    </span>
  )
}

function CallBadge({ direction }) {
  const out = direction === 'BUSINESS_INITIATED'
  return (
    <span className={clsx(
      'inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full',
      out ? 'bg-violet-50 text-violet-600' : 'bg-blue-50 text-blue-600'
    )}>
      {out ? <PhoneOutgoing size={9} /> : <PhoneIncoming size={9} />}
      {out ? 'Outgoing' : 'Incoming'}
    </span>
  )
}

function StatusDot({ status }) {
  const cfg = {
    COMPLETED: { color: 'bg-emerald-500', label: 'Completed' },
    MISSED:    { color: 'bg-red-400',     label: 'Missed'    },
    FAILED:    { color: 'bg-red-500',     label: 'Failed'    },
    REJECTED:  { color: 'bg-amber-400',   label: 'Rejected'  },
  }[status] || { color: 'bg-slate-400', label: status }
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={clsx('w-1.5 h-1.5 rounded-full flex-shrink-0', cfg.color)} />
      <span className="text-xs text-slate-600">{cfg.label}</span>
    </span>
  )
}

function ToggleSwitch({ on, onChange }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={clsx(
        'w-11 h-6 rounded-full relative transition-colors duration-200 flex-shrink-0',
        on ? 'bg-primary' : 'bg-slate-200'
      )}>
      <span className={clsx(
        'absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform duration-200',
        on ? 'translate-x-6' : 'translate-x-1'
      )} />
    </button>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════════
const TABS = ['Overview', 'Settings', 'Call History']

export default function Voice() {
  const [tab,           setTab]           = useState('Overview')
  const [callingOn,     setCallingOn]     = useState(false)   // start unconfigured for setup flow
  const [permRequests,  setPermRequests]  = useState(true)
  const [callHours,     setCallHours]     = useState(DEFAULT_HOURS)
  const [search,        setSearch]        = useState('')
  const [filterStatus,  setFilterStatus]  = useState('all')

  // Setup steps: calling on = step 2 done, hours enabled = step 3 done
  const step1Done = true            // WA Business account always connected
  const step2Done = callingOn
  const step3Done = callingOn && callHours.some(h => h.enabled)
  const allDone   = step1Done && step2Done && step3Done

  // Stats from mock data
  const totalCalls   = MOCK_CALLS.length
  const completedCalls = MOCK_CALLS.filter(c => c.status === 'COMPLETED').length
  const missedCalls  = MOCK_CALLS.filter(c => c.status === 'MISSED').length
  const avgDuration  = Math.round(
    MOCK_CALLS.filter(c => c.duration).reduce((a, c) => a + c.duration, 0) /
    MOCK_CALLS.filter(c => c.duration).length
  )

  const filteredCalls = useMemo(() =>
    MOCK_CALLS.filter(c => {
      const matchSearch = !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.phone.includes(search)
      const matchStatus = filterStatus === 'all' || c.status === filterStatus.toUpperCase()
      return matchSearch && matchStatus
    }), [search, filterStatus])

  function toggleHourDay(idx, field, val) {
    setCallHours(h => h.map((row, i) => i === idx ? { ...row, [field]: val } : row))
  }

  return (
    <div className="space-y-5 animate-fade-in">

      {/* ── Header ── */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <h1 className="text-[15px] font-bold text-slate-900">WhatsApp Calling</h1>
            <StatusPill on={callingOn} />
          </div>
          <p className="text-[11px] text-slate-400">Let customers call you directly from WhatsApp</p>
        </div>
        {callingOn && (
          <button
            onClick={() => setCallingOn(false)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50 transition-colors">
            <PhoneOff size={12} /> Disable Calling
          </button>
        )}
      </div>

      {/* ── Tabs ── */}
      <div className="flex items-center gap-0.5 bg-slate-100 p-1 rounded-xl w-fit">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={clsx(
              'px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap',
              tab === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            )}>
            {t}
          </button>
        ))}
      </div>

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* OVERVIEW                                                            */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {tab === 'Overview' && (
        <div className="space-y-5">

          {/* Setup guide — shown until all steps done */}
          {!allDone && (
            <div className="card p-6">
              <div className="flex items-start gap-3 mb-5">
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Zap size={15} className="text-primary" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800">Set up WhatsApp Calling</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">Complete these 3 steps to start receiving calls from your customers.</p>
                </div>
              </div>

              <div className="space-y-3">
                {/* Step 1 */}
                <div className={clsx('flex items-center gap-4 p-4 rounded-xl border', step1Done ? 'bg-emerald-50/50 border-emerald-100' : 'border-surface-border')}>
                  <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold',
                    step1Done ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400')}>
                    {step1Done ? <CheckCircle2 size={15} /> : '1'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={clsx('text-xs font-semibold', step1Done ? 'text-emerald-700' : 'text-slate-700')}>
                      WhatsApp Business Account connected
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Your business number is linked and verified</p>
                  </div>
                  {step1Done && <span className="text-[10px] font-semibold text-emerald-600">Done</span>}
                </div>

                {/* Step 2 */}
                <div className={clsx('flex items-center gap-4 p-4 rounded-xl border', step2Done ? 'bg-emerald-50/50 border-emerald-100' : 'border-blue-100 bg-blue-50/40')}>
                  <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold',
                    step2Done ? 'bg-emerald-500 text-white' : 'bg-blue-500 text-white')}>
                    {step2Done ? <CheckCircle2 size={15} /> : '2'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={clsx('text-xs font-semibold', step2Done ? 'text-emerald-700' : 'text-slate-700')}>
                      Enable calling for your number
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Customers will see a call button on your WhatsApp profile</p>
                  </div>
                  {step2Done
                    ? <span className="text-[10px] font-semibold text-emerald-600">Done</span>
                    : (
                      <button
                        onClick={() => { setCallingOn(true); setTab('Overview') }}
                        className="flex items-center gap-1.5 px-3.5 py-2 bg-primary text-white text-xs font-semibold rounded-xl hover:bg-primary-hover transition-colors shadow-sm flex-shrink-0">
                        Enable <ArrowRight size={11} />
                      </button>
                    )}
                </div>

                {/* Step 3 */}
                <div className={clsx('flex items-center gap-4 p-4 rounded-xl border',
                  !step2Done ? 'border-surface-border opacity-50' :
                  step3Done  ? 'bg-emerald-50/50 border-emerald-100' : 'border-blue-100 bg-blue-50/40')}>
                  <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold',
                    step3Done ? 'bg-emerald-500 text-white' : step2Done ? 'bg-blue-500 text-white' : 'bg-slate-100 text-slate-400')}>
                    {step3Done ? <CheckCircle2 size={15} /> : '3'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={clsx('text-xs font-semibold', step3Done ? 'text-emerald-700' : 'text-slate-700')}>
                      Set your call hours
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Choose when customers can reach you</p>
                  </div>
                  {step3Done
                    ? <span className="text-[10px] font-semibold text-emerald-600">Done</span>
                    : step2Done && (
                      <button
                        onClick={() => setTab('Settings')}
                        className="flex items-center gap-1.5 px-3.5 py-2 bg-primary text-white text-xs font-semibold rounded-xl hover:bg-primary-hover transition-colors shadow-sm flex-shrink-0">
                        Configure <ArrowRight size={11} />
                      </button>
                    )}
                </div>
              </div>

              {allDone && (
                <div className="mt-4 p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-500 flex-shrink-0" />
                  <p className="text-xs font-semibold text-emerald-700">You're all set! Customers can now call you on WhatsApp.</p>
                </div>
              )}
            </div>
          )}

          {/* All done banner */}
          {allDone && (
            <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <PhoneCall size={14} className="text-emerald-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-bold text-emerald-800">Calling is active</p>
                <p className="text-[11px] text-emerald-600 mt-0.5">Customers can call you directly from your WhatsApp profile</p>
              </div>
              <button onClick={() => setTab('Settings')} className="text-[11px] font-semibold text-emerald-700 hover:underline flex-shrink-0">
                Manage settings →
              </button>
            </div>
          )}

          {/* Stats — only show if calling was ever active (mock data exists) */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Total Calls',  value: totalCalls,    sub: 'Last 30 days',    icon: PhoneCall,    bg: 'bg-blue-50',    ic: 'text-blue-500'    },
              { label: 'Answered',     value: completedCalls, sub: `${Math.round(completedCalls/totalCalls*100)}% answer rate`, icon: CheckCircle2, bg: 'bg-emerald-50', ic: 'text-emerald-500' },
              { label: 'Missed',       value: missedCalls,   sub: 'Not answered',    icon: PhoneMissed,  bg: 'bg-red-50',     ic: 'text-red-400'     },
              { label: 'Avg Duration', value: fmtDuration(avgDuration), sub: 'Per call', icon: Clock,   bg: 'bg-amber-50',   ic: 'text-amber-500'   },
            ].map(s => (
              <div key={s.label} className="card p-4">
                <div className={clsx('w-8 h-8 rounded-xl flex items-center justify-center mb-3', s.bg)}>
                  <s.icon size={14} className={s.ic} />
                </div>
                <p className="text-xl font-bold text-slate-900 tabular-nums">{s.value}</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{s.label}</p>
                <p className="text-[10px] text-slate-400">{s.sub}</p>
              </div>
            ))}
          </div>

          {/* Recent calls */}
          <div className="card p-0 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-surface-border">
              <p className="text-xs font-bold text-slate-700">Recent Calls</p>
              <button onClick={() => setTab('Call History')} className="text-[11px] text-primary font-semibold hover:underline">
                View all →
              </button>
            </div>
            {MOCK_CALLS.slice(0, 5).length === 0 ? (
              <div className="py-12 text-center">
                <PhoneCall size={28} className="text-slate-200 mx-auto mb-2" />
                <p className="text-xs text-slate-400">No calls yet</p>
              </div>
            ) : (
              <div className="divide-y divide-surface-border">
                {MOCK_CALLS.slice(0, 5).map(c => (
                  <div key={c.id} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50/60 transition-colors">
                    <div className={clsx('w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold',
                      c.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500')}>
                      {c.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-slate-800 truncate">{c.name}</p>
                      <p className="text-[10px] text-slate-400">{c.phone}</p>
                    </div>
                    <CallBadge direction={c.direction} />
                    <StatusDot status={c.status} />
                    <span className="text-xs text-slate-400 tabular-nums w-12 text-right">{fmtDuration(c.duration)}</span>
                    <span className="text-[10px] text-slate-400 w-16 text-right">{fmtTime(c.ts)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* SETTINGS                                                            */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {tab === 'Settings' && (
        <div className="max-w-2xl space-y-5">

          {/* Enable / disable */}
          <div className="card p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-800">Enable WhatsApp Calling</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {callingOn
                    ? 'Customers can call you from your WhatsApp profile'
                    : 'Turn this on to allow customers to call you via WhatsApp'}
                </p>
              </div>
              <ToggleSwitch on={callingOn} onChange={setCallingOn} />
            </div>
            {callingOn && (
              <div className="mt-4 pt-4 border-t border-surface-border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-700">Allow customers to request a callback</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Customers who miss you can ask you to call them back</p>
                  </div>
                  <ToggleSwitch on={permRequests} onChange={setPermRequests} />
                </div>
              </div>
            )}
          </div>

          {/* Call hours — only relevant when calling is on */}
          <div className={clsx('card p-5 transition-opacity', !callingOn && 'opacity-40 pointer-events-none')}>
            <div className="flex items-center gap-2 mb-1">
              <Calendar size={13} className="text-slate-400" />
              <p className="text-xs font-bold text-slate-800">Call Hours</p>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">Customers can only call you during these hours</p>

            <div className="space-y-2">
              {callHours.map((row, i) => (
                <div key={row.day} className={clsx('flex items-center gap-3 py-2 rounded-xl px-3 transition-colors',
                  row.enabled ? 'bg-slate-50' : '')}>
                  {/* Day toggle */}
                  <div className="w-28 flex items-center gap-2 flex-shrink-0">
                    <ToggleSwitch on={row.enabled} onChange={v => toggleHourDay(i, 'enabled', v)} />
                    <span className={clsx('text-xs font-semibold', row.enabled ? 'text-slate-700' : 'text-slate-400')}>
                      {row.day.slice(0, 3)}
                    </span>
                  </div>

                  {row.enabled ? (
                    <div className="flex items-center gap-2 flex-1">
                      <input
                        type="time"
                        value={row.open}
                        onChange={e => toggleHourDay(i, 'open', e.target.value)}
                        className="text-xs border border-surface-border rounded-lg px-2 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-primary/30"
                      />
                      <span className="text-[10px] text-slate-400">to</span>
                      <input
                        type="time"
                        value={row.close}
                        onChange={e => toggleHourDay(i, 'close', e.target.value)}
                        className="text-xs border border-surface-border rounded-lg px-2 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-primary/30"
                      />
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 flex-1">Closed</span>
                  )}
                </div>
              ))}
            </div>

            <button className="mt-4 w-full py-2 rounded-xl bg-primary text-white text-xs font-semibold hover:bg-primary-hover transition-colors">
              Save Hours
            </button>
          </div>

          {/* Info note */}
          {callingOn && (
            <div className="flex items-start gap-2.5 p-3.5 bg-blue-50 border border-blue-100 rounded-xl">
              <Shield size={13} className="text-blue-500 flex-shrink-0 mt-0.5" />
              <p className="text-[11px] text-blue-700 leading-relaxed">
                <span className="font-semibold">Privacy note:</span> You can only receive calls from customers who have your number saved, or who have given you calling permission. Cold calling from unknown numbers is not allowed.
              </p>
            </div>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* CALL HISTORY                                                        */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {tab === 'Call History' && (
        <div className="space-y-4">

          {/* Filters */}
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by name or number…"
                className="w-full pl-8 pr-3 py-2 text-xs border border-surface-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white"
              />
            </div>
            <NativeSelect value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">All calls</option>
              <option value="completed">Answered</option>
              <option value="missed">Missed</option>
            </NativeSelect>
            <button className="ml-auto flex items-center gap-1.5 px-3 py-2 border border-surface-border rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors">
              <Download size={11} /> Export
            </button>
          </div>

          {/* Table */}
          <div className="card p-0 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-surface-border bg-slate-50/60">
                  <th className="px-5 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wide">Customer</th>
                  <th className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wide">Type</th>
                  <th className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wide">Status</th>
                  <th className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wide">Duration</th>
                  <th className="px-5 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wide">When</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border">
                {filteredCalls.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center">
                      <PhoneOff size={24} className="text-slate-200 mx-auto mb-2" />
                      <p className="text-xs text-slate-400">No calls match your filter</p>
                    </td>
                  </tr>
                ) : filteredCalls.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                          c.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-400')}>
                          {c.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-slate-800">{c.name}</p>
                          <p className="text-[10px] text-slate-400">{c.phone}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5"><CallBadge direction={c.direction} /></td>
                    <td className="px-4 py-3.5"><StatusDot status={c.status} /></td>
                    <td className="px-4 py-3.5 text-xs text-slate-500 tabular-nums">{fmtDuration(c.duration)}</td>
                    <td className="px-5 py-3.5 text-[11px] text-slate-400">{fmtTime(c.ts)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="text-[10px] text-slate-400 text-center">Showing {filteredCalls.length} of {MOCK_CALLS.length} calls</p>
        </div>
      )}
    </div>
  )
}
