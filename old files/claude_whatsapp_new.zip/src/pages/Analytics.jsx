import { useState, useRef, useEffect } from 'react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts'
import {
  MessageSquare, Users, Bot, PhoneForwarded, CheckCircle2,
  XCircle, Activity, GitBranch, TrendingDown, AlertCircle,
  ShieldAlert, Timer, Clock, ThumbsUp, TrendingUp,
  Globe, Star, AlertTriangle, Wifi, RefreshCw, Coffee,
  Send, Eye, Zap, CalendarCheck, CalendarX, CalendarClock,
  ArrowUpRight, ArrowDownRight, Download, ChevronDown,
  Megaphone, Search, Calendar,
} from 'lucide-react'
import clsx from 'clsx'
import { subDays, format } from 'date-fns'
import { NativeSelect } from '../components/Select'

/* ─── helpers ───────────────────────────────────────────────────── */
const rand  = (a, b) => Math.floor(a + Math.random() * (b - a))
const today = new Date()
const days  = (n) => Array.from({ length: n }, (_, i) => format(subDays(today, n - 1 - i), 'MMM d'))

/* ─── mock data ─────────────────────────────────────────────────── */
const makeChat = (n) => days(n).map(d => {
  const botHandled = rand(100, 320)
  const resolved   = rand(40, 140)
  const closed     = rand(20, 80)
  const active     = rand(5, 30)
  const handoff    = resolved + closed + active
  const totalChats = botHandled + handoff
  const ctwa       = rand(40, 180)
  const gCtwa      = rand(20, 90)
  const attended   = rand(30, 130)
  const unattended = rand(5, 40)
  return { date: d, totalChats, messages: rand(900, 3800), botHandled, handoff, resolved, closed, active, flowCompleted: rand(30, 160), dropOff: rand(10, 70), fallback: rand(5, 40), uniqueUsers: rand(100, 420), slaBreached: rand(1, 12), ctwa, gCtwa, attended, unattended }
})
const CHAT_30 = makeChat(30), CHAT_7 = makeChat(7), CHAT_1 = makeChat(1)

const HOURS    = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2,'0')}:00`)
const WEEKDAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
const HEATMAP  = WEEKDAYS.map(day => ({
  day,
  hours: HOURS.map(h => {
    const hr = parseInt(h), isWe = day === 'Sat' || day === 'Sun', peak = hr >= 9 && hr <= 20
    return { hour: h, value: rand(peak ? (isWe ? 5 : 30) : 0, peak ? (isWe ? 40 : 180) : 15) }
  }),
}))

const LEAD_SOURCES = [
  { source: 'Instagram DM',  count: 1284, url: 'instagram.com',      color: '#E1306C' },
  { source: 'Website Chat',  count: 892,  url: 'yoursite.com/chat',  color: '#0066ff' },
  { source: 'Facebook Page', count: 641,  url: 'facebook.com/page',  color: '#1877F2' },
  { source: 'WhatsApp Link', count: 520,  url: 'wa.me/91xxxxxxxxxx', color: '#25D366' },
  { source: 'QR Code',       count: 318,  url: '—',                  color: '#8B5CF6' },
  { source: 'API / Other',   count: 147,  url: '—',                  color: '#94a3b8' },
]
const LEAD_TOTAL = LEAD_SOURCES.reduce((s, l) => s + l.count, 0)

const RT_AGENTS = [
  { name: 'Rahul Mehta',  avatar: 'RM', status: 'online',  active: 4, queue: 2, avgReply: '1m 12s', avgHandle: '12m 30s', longest: '18m 04s', resolved: 18, transferred: 2, csat: 4.9, sla: 0 },
  { name: 'Priya Das',    avatar: 'PD', status: 'online',  active: 3, queue: 1, avgReply: '2m 04s', avgHandle: '16m 10s', longest: '22m 15s', resolved: 14, transferred: 1, csat: 4.6, sla: 1 },
  { name: 'Aryan Kapoor', avatar: 'AK', status: 'busy',    active: 5, queue: 3, avgReply: '3m 41s', avgHandle: '21m 45s', longest: '35m 50s', resolved: 11, transferred: 3, csat: 4.3, sla: 3 },
  { name: 'Sunita Rao',   avatar: 'SR', status: 'break',   active: 0, queue: 0, avgReply: '—',      avgHandle: '—',       longest: '—',       resolved: 9,  transferred: 0, csat: 4.7, sla: 0 },
  { name: 'Vikram Singh', avatar: 'VS', status: 'offline', active: 0, queue: 0, avgReply: '—',      avgHandle: '—',       longest: '—',       resolved: 6,  transferred: 1, csat: 4.5, sla: 0 },
]

const makeAppt = (n) => days(n).map(d => ({ date: d, booked: rand(4,22), completed: rand(3,18), cancelled: rand(0,5), noShow: rand(0,3), rescheduled: rand(0,4) }))
const APPT_30 = makeAppt(30), APPT_7 = makeAppt(7), APPT_1 = makeAppt(1)
const APPT_STATUS = [
  { name: 'Completed',   value: 61, color: '#22C55E' },
  { name: 'Cancelled',   value: 16, color: '#F87171' },
  { name: 'No Show',     value: 9,  color: '#F59E0B' },
  { name: 'Rescheduled', value: 9,  color: '#8B5CF6' },
  { name: 'Upcoming',    value: 5,  color: '#0066ff' },
]

const makeBc = (n) => days(n).map(d => ({ date: d, sent: rand(600,2400), delivered: rand(580,2200), read: rand(200,900), clicked: rand(40,220) }))
const BC_30 = makeBc(30), BC_7 = makeBc(7), BC_1 = makeBc(1)
const BC_CAMPAIGNS = [
  { name: 'Summer Sale',       sent: 4820, delivered: 4680, read: 2140, clicked: 386, readRate: 45.7, clickRate: 8.0  },
  { name: 'Reorder Reminder',  sent: 2310, delivered: 2280, read: 1560, clicked: 290, readRate: 68.4, clickRate: 12.7 },
  { name: 'New Feature Alert', sent: 6100, delivered: 5920, read: 1890, clicked: 220, readRate: 31.9, clickRate: 3.7  },
  { name: 'Feedback Request',  sent: 1850, delivered: 1820, read: 980,  clicked: 148, readRate: 53.8, clickRate: 8.1  },
]

// ── Template-level analytics ──────────────────────────────────────────────────
const BC_TEMPLATES = [
  {
    id: 'tpl_summer_sale',
    name: 'Summer Sale Offer',
    category: 'Marketing',
    status: 'APPROVED',
    campaigns: ['Summer Sale'],
    attempted: 48200, sent: 46800, delivered: 45100, read: 21400, clicked: 3860, failed: 1400,
    readRate: 47.5, clickRate: 8.6, deliveryRate: 96.4,
    replied: 1920, userInitiated: 4100,
    errors: [
      { code: '130111', type: "User's number part of an experiment", count: 820 },
      { code: '131026', type: 'Limit Reached',                       count: 580 },
    ],
    dailySent: BC_30.map(d => ({ date: d.date, sent: rand(800,2200), delivered: rand(760,2100), read: rand(300,900), clicked: rand(40,200) })),
  },
  {
    id: 'tpl_reorder',
    name: 'Reorder Reminder',
    category: 'Utility',
    status: 'APPROVED',
    campaigns: ['Reorder Reminder'],
    attempted: 23100, sent: 22800, delivered: 22400, read: 15600, clicked: 2900, failed: 400,
    readRate: 69.6, clickRate: 12.9, deliveryRate: 98.2,
    replied: 3100, userInitiated: 2200,
    errors: [
      { code: '100', type: 'Parameter is invalid', count: 400 },
    ],
    dailySent: BC_30.map(d => ({ date: d.date, sent: rand(300,900), delivered: rand(280,880), read: rand(180,620), clicked: rand(30,130) })),
  },
  {
    id: 'tpl_feature_alert',
    name: 'New Feature Alert',
    category: 'Marketing',
    status: 'APPROVED',
    campaigns: ['New Feature Alert'],
    attempted: 61000, sent: 59200, delivered: 56800, read: 18900, clicked: 2200, failed: 2400,
    readRate: 33.3, clickRate: 3.9, deliveryRate: 95.9,
    replied: 980, userInitiated: 1800,
    errors: [
      { code: '100',    type: 'Parameter is invalid',   count: 1200 },
      { code: '132000', type: 'Template parameter mismatch', count: 1200 },
    ],
    dailySent: BC_30.map(d => ({ date: d.date, sent: rand(1200,2800), delivered: rand(1100,2600), read: rand(280,800), clicked: rand(20,100) })),
  },
  {
    id: 'tpl_feedback',
    name: 'Feedback Request',
    category: 'Service',
    status: 'APPROVED',
    campaigns: ['Feedback Request'],
    attempted: 18500, sent: 18200, delivered: 17800, read: 9800, clicked: 1480, failed: 400,
    readRate: 55.1, clickRate: 8.3, deliveryRate: 97.8,
    replied: 2100, userInitiated: 1600,
    errors: [
      { code: '130111', type: 'Message Undeliverable', count: 400 },
    ],
    dailySent: BC_30.map(d => ({ date: d.date, sent: rand(300,750), delivered: rand(280,730), read: rand(120,400), clicked: rand(15,80) })),
  },
  {
    id: 'tpl_welcome',
    name: 'Welcome Message',
    category: 'Marketing',
    status: 'APPROVED',
    campaigns: [],
    attempted: 9200, sent: 9100, delivered: 8800, read: 6100, clicked: 820, failed: 300,
    readRate: 69.3, clickRate: 9.3, deliveryRate: 96.7,
    replied: 1400, userInitiated: 900,
    errors: [],
    dailySent: BC_30.map(d => ({ date: d.date, sent: rand(100,400), delivered: rand(95,390), read: rand(60,270), clicked: rand(5,40) })),
  },
]

const makeAI = (n) => days(n).map(d => ({ date: d, tokens: rand(12000,80000), sessions: rand(40,200), suggested: rand(30,160), accepted: rand(20,120) }))
const AI_30 = makeAI(30), AI_7 = makeAI(7), AI_1 = makeAI(1)
const AI_FEATURES = [
  { name: 'Intent Detection',   uses: 6120, rate: 89, color: '#1e293b' },
  { name: 'Sentiment Analysis', uses: 4210, rate: 100, color: '#374151' },
  { name: 'Smart Replies',      uses: 3840, rate: 77, color: '#6b7280' },
  { name: 'Auto Summarise',     uses: 1680, rate: 76, color: '#9ca3af' },
  { name: 'Flow Suggestions',   uses: 940,  rate: 64, color: '#d1d5db' },
]

const PRESETS = [
  { id: 'today', label: 'Today'   },
  { id: '7d',    label: '7 Days'  },
  { id: '30d',   label: '30 Days' },
]
const TABS = [
  { id: 'chat',      label: 'Chatbot & Live Agents' },
  { id: 'appt',      label: 'Appointments'          },
  { id: 'broadcast', label: 'Broadcasts'            },
  { id: 'ai',        label: 'AI Usage'              },
]

/* ─── tooltip ───────────────────────────────────────────────────── */
const ChartTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white border border-surface-border rounded-xl px-3 py-2 text-[10px] shadow-modal">
      <p className="font-semibold text-slate-600 mb-1.5">{label}</p>
      {payload.map(p => (
        <div key={p.dataKey} className="flex items-center gap-1.5 mb-0.5">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }}/>
          <span className="text-slate-400">{p.name}:</span>
          <span className="font-bold text-slate-700">{typeof p.value === 'number' ? p.value.toLocaleString() : p.value}</span>
        </div>
      ))}
    </div>
  )
}

/* ─── metric card ───────────────────────────────────────────────── */
function MetricCard({ icon: Icon, label, value, sub, trend, color = '#0066ff', warn = false, pro = false }) {
  const up = trend > 0
  return (
    <div className={clsx(
      'bg-white border rounded-xl p-4 flex flex-col gap-2.5',
      warn ? 'border-red-200' : 'border-surface-border'
    )}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: '#f5f5f5' }}>
            <Icon size={13} style={{ color: warn ? '#ef4444' : '#374151' }}/>
          </div>
          {pro && <ProBadge/>}
        </div>
        {trend != null && (
          <span className={clsx(
            'flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full',
            up ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'
          )}>
            {up ? <ArrowUpRight size={8}/> : <ArrowDownRight size={8}/>}{Math.abs(trend)}%
          </span>
        )}
      </div>
      <div>
        <p className={clsx('text-[20px] font-bold leading-none', warn ? 'text-red-500' : 'text-slate-800')}>
          {value}
        </p>
        <p className="text-[10px] font-medium text-slate-400 mt-1">{label}</p>
        {sub && <p className="text-[9px] text-slate-300 mt-0.5">{sub}</p>}
      </div>
    </div>
  )
}

/* ─── chart card ─────────────────────────────────────────────────── */
function ChartCard({ title, sub, right, children, noPad = false, className = '' }) {
  return (
    <div className={clsx('bg-white border border-surface-border rounded-xl overflow-hidden flex flex-col', className)}>
      <div className="flex items-center justify-between px-4 py-3 border-b border-surface-border flex-shrink-0">
        <div>
          <p className="text-[12px] font-semibold text-slate-700">{title}</p>
          {sub && <p className="text-[10px] text-slate-400 mt-0.5">{sub}</p>}
        </div>
        {right}
      </div>
      <div className={clsx(noPad ? '' : 'p-4', 'flex-1')}>{children}</div>
    </div>
  )
}

/* ─── legend ─────────────────────────────────────────────────────── */
function Legend({ items }) {
  return (
    <div className="flex items-center gap-4 mt-3 flex-wrap">
      {items.map(l => (
        <span key={l.label} className="flex items-center gap-1.5 text-[10px] text-slate-400">
          <span className="w-2 h-2 rounded-sm flex-shrink-0" style={{ background: l.color }}/>{l.label}
        </span>
      ))}
    </div>
  )
}

/* ─── section label ─────────────────────────────────────────────── */
function SLabel({ children }) {
  return (
    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
      {children}
    </p>
  )
}

/* ─── status badge ──────────────────────────────────────────────── */
const STATUS_CFG = {
  online:  { dot: 'bg-emerald-400', text: 'text-emerald-600', label: 'Online'  },
  busy:    { dot: 'bg-amber-400',   text: 'text-amber-600',   label: 'Busy'    },
  break:   { dot: 'bg-blue-400',    text: 'text-blue-600',    label: 'Break'   },
  offline: { dot: 'bg-slate-300',   text: 'text-slate-400',   label: 'Offline' },
}
function StatusDot({ status }) {
  const c = STATUS_CFG[status] || STATUS_CFG.offline
  return (
    <span className={clsx('inline-flex items-center gap-1 text-[10px] font-medium', c.text)}>
      <span className={clsx('w-1.5 h-1.5 rounded-full', c.dot)}/>{c.label}
    </span>
  )
}

/* ════════════════════════════════════════════════════════════════
   CHAT TAB
════════════════════════════════════════════════════════════════ */
function ChatTab({ range }) {
  const data = range === 'today' ? CHAT_1 : range === '7d' ? CHAT_7 : CHAT_30
  const sum  = (k) => data.reduce((a, d) => a + d[k], 0)

  const botHandled  = sum('botHandled')
  const handoff     = sum('handoff')
  const totalChats  = botHandled + handoff
  const resolved    = sum('resolved')
  const closed      = sum('closed')
  const activeNow   = data[data.length - 1]?.active ?? 0
  const flowDone    = sum('flowCompleted')
  const dropOff     = sum('dropOff')
  const fallback    = sum('fallback')
  const uniqueUsers = sum('uniqueUsers')
  const slaBreached = sum('slaBreached')
  const totalMsgs   = sum('messages')
  const ctwa        = sum('ctwa')
  const gCtwa       = sum('gCtwa')
  const attended    = sum('attended')
  const unattended  = sum('unattended')

  const heatMax = Math.max(...HEATMAP.flatMap(r => r.hours.map(h => h.value)))
  const heatClr = (v) => {
    const t = v / heatMax
    if (t < 0.15) return '#f8fafc'
    if (t < 0.35) return '#bfdbfe'
    if (t < 0.6)  return '#60a5fa'
    if (t < 0.8)  return '#2563eb'
    return '#0066ff'
  }

  const rtOnline = RT_AGENTS.filter(a => a.status === 'online').length
  const rtActive = RT_AGENTS.reduce((s, a) => s + a.active, 0)
  const rtQueue  = RT_AGENTS.reduce((s, a) => s + a.queue, 0)
  const rtBreak  = RT_AGENTS.filter(a => a.status === 'break').length

  return (
    <div className="space-y-5">

      {/* ── Volume ── */}
      <div>
        <SLabel>Chat Volume</SLabel>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <MetricCard icon={MessageSquare} label="Total Chats"    value={totalChats.toLocaleString()}  sub="Bot + Handoff"  trend={8}  color="#0066ff"/>
          <MetricCard icon={MessageSquare} label="Total Messages" value={totalMsgs.toLocaleString()}   trend={11}                      color="#8B5CF6"/>
          <MetricCard icon={Users}         label="Unique Users"   value={uniqueUsers.toLocaleString()} trend={6}                       color="#14B8A6"/>
          <MetricCard icon={Bot}           label="Bot Handled"    value={botHandled.toLocaleString()}  sub="Auto-resolved"  trend={3}  color="#0066ff"/>
          <MetricCard icon={Megaphone}     label="CTWA Chats"     value={ctwa.toLocaleString()}        sub="WhatsApp Ads"   trend={14} color="#0066ff"/>
          <MetricCard icon={Search}        label="G-CTWA Chats"   value={gCtwa.toLocaleString()}       sub="Google Ads"     trend={9}  color="#0066ff"/>
        </div>
      </div>

      {/* ── Live Agents ── */}
      <div>
        <SLabel>Live Agents</SLabel>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <MetricCard icon={PhoneForwarded} label="Handoff to Agents"       value={handoff.toLocaleString()}    sub="Resolved + Closed + Active" trend={-2} color="#F59E0B"/>
          <MetricCard icon={CheckCircle2}   label="Resolved by Agents"      value={resolved.toLocaleString()}   trend={5}  color="#22C55E"/>
          <MetricCard icon={XCircle}        label="Closed by Agents"        value={closed.toLocaleString()}     trend={1}  color="#64748b"/>
          <MetricCard icon={Activity}       label="Active Chats Right Now"  value={activeNow}                   sub="ongoing" color="#EC4899"/>
          <MetricCard icon={CheckCircle2}   label="Attended Chats"          value={attended.toLocaleString()}   sub="Handoff to Agent" trend={7}  color="#22C55E"/>
          <MetricCard icon={AlertCircle}    label="Unattended Chats"        value={unattended.toLocaleString()} sub="Handoff to Agent" trend={-3} color="#64748b"/>
        </div>
      </div>

      {/* ── Engagement ── */}
      <div>
        <SLabel>Engagement & Quality</SLabel>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <MetricCard icon={GitBranch}    label="Flow Completion"     value={flowDone.toLocaleString()}    trend={9}   color="#8B5CF6"/>
          <MetricCard icon={TrendingDown} label="Drop-Off Users"      value={dropOff.toLocaleString()}     trend={-4}  color="#F87171"/>
          <MetricCard icon={AlertCircle}  label="Fallback Triggers"   value={fallback.toLocaleString()}    trend={-7}  color="#F59E0B"/>
          <MetricCard icon={ShieldAlert}  label="SLA Breached"        value={slaBreached.toLocaleString()} trend={2}   color="#64748b"/>
          <MetricCard icon={Timer}        label="Avg Resolution Time" value="14m 38s"                      trend={-5}  color="#0066ff"/>
          <MetricCard icon={Clock}        label="Avg First Response"  value="1m 52s"                       trend={-8}  color="#22C55E"/>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mt-3">
          <MetricCard icon={ThumbsUp}   label="CSAT Score"       value="4.6 / 5" sub="avg"  color="#F59E0B"/>
          <MetricCard icon={TrendingUp} label="Escalation Rate"  value="6.2%"    trend={-1}  color="#64748b"/>
        </div>
      </div>

      {/* ── Daily Chats Chart ── */}
      <ChartCard title="Daily Chats" sub="Volume breakdown over time"
        right={
          <div className="flex items-center gap-3">
            {[{color:'#374151',label:'Total'},{color:'#6b7280',label:'Bot'},{color:'#9ca3af',label:'Handoff'}].map(l => (
              <span key={l.label} className="flex items-center gap-1 text-[9px] text-slate-400">
                <span className="w-2 h-2 rounded-sm" style={{ background: l.color }}/>{l.label}
              </span>
            ))}
          </div>
        }>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <defs>
              {[{id:'dT',c:'#374151'},{id:'dB',c:'#6b7280'},{id:'dH',c:'#9ca3af'}].map(g => (
                <linearGradient key={g.id} id={g.id} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%"   stopColor={g.c} stopOpacity={0.15}/>
                  <stop offset="100%" stopColor={g.c} stopOpacity={0}/>
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
            <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false}
              interval={range==='30d'?5:0}/>
            <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
            <Tooltip content={<ChartTip/>}/>
            <Area type="monotone" dataKey="totalChats" name="Total Chats"       stroke="#374151" strokeWidth={2}   fill="url(#dT)" dot={false}/>
            <Area type="monotone" dataKey="botHandled" name="Bot Handled"       stroke="#6b7280" strokeWidth={1.5} fill="url(#dB)" dot={false}/>
            <Area type="monotone" dataKey="handoff"    name="Handoff to Agents" stroke="#9ca3af" strokeWidth={1.5} fill="url(#dH)" dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* ── Heatmap ── */}
      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-surface-border">
          <div>
            <p className="text-[12px] font-semibold text-slate-700">User Visiting Timing</p>
            <p className="text-[10px] text-slate-400 mt-0.5">When your users are most active — darker = busier</p>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[9px] text-slate-400">Low</span>
            {['#f8fafc','#bfdbfe','#60a5fa','#2563eb','#0066ff'].map(c => (
              <div key={c} className="w-4 h-3 rounded-sm" style={{ background: c }}/>
            ))}
            <span className="text-[9px] text-slate-400">High</span>
          </div>
        </div>
        <div className="p-4 overflow-x-auto">
          <div className="min-w-[600px]">
            <div className="flex mb-1.5 pl-9">
              {HOURS.filter((_,i) => i % 3 === 0).map(h => (
                <div key={h} className="flex-1 text-[8px] text-slate-400 text-center">{h}</div>
              ))}
            </div>
            {HEATMAP.map(row => (
              <div key={row.day} className="flex items-center mb-0.5">
                <span className="w-9 text-[9px] text-slate-400 font-medium flex-shrink-0">{row.day}</span>
                <div className="flex flex-1 gap-px">
                  {row.hours.map(h => (
                    <div key={h.hour} className="flex-1 h-5 rounded-sm cursor-default hover:opacity-80 transition-opacity"
                      style={{ background: heatClr(h.value) }}
                      title={`${row.day} ${h.hour}: ${h.value} chats`}/>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Lead Sources ── */}
      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-surface-border">
          <div>
            <p className="text-[12px] font-semibold text-slate-700">Lead Sources</p>
            <p className="text-[10px] text-slate-400 mt-0.5">{LEAD_TOTAL.toLocaleString()} total chats tracked</p>
          </div>
          <button
            onClick={() => {
              const rows = [['Source','URL / Ref','Chats','Share %']]
              LEAD_SOURCES.forEach(s => rows.push([s.source, s.url, s.count, Math.round((s.count/LEAD_TOTAL)*100)+'%']))
              const csv = rows.map(r => r.join(',')).join('\n')
              const a = document.createElement('a')
              a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
              a.download = 'lead-sources.csv'
              a.click()
            }}
            className="btn-secondary">
            <Download size={11}/> Download All
          </button>
        </div>
        <table className="w-full text-[11px]">
          <thead>
            <tr className="bg-slate-50 border-b border-surface-border">
              <th className="px-4 py-2 text-left font-bold text-slate-400 uppercase tracking-wider" style={{ fontSize: '9px' }}>Source</th>
              <th className="px-4 py-2 text-left font-bold text-slate-400 uppercase tracking-wider hidden md:table-cell" style={{ fontSize: '9px' }}>URL / Ref</th>
              <th className="px-4 py-2 text-right font-bold text-slate-400 uppercase tracking-wider" style={{ fontSize: '9px' }}>Chats</th>
              <th className="px-4 py-2 text-right font-bold text-slate-400 uppercase tracking-wider w-32" style={{ fontSize: '9px' }}>Share</th>
              <th className="px-4 py-2 text-right font-bold text-slate-400 uppercase tracking-wider w-16" style={{ fontSize: '9px' }}></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {LEAD_SOURCES.map(src => {
              const pct = Math.round((src.count / LEAD_TOTAL) * 100)
              const downloadSrc = () => {
                const csv = ['Source,URL / Ref,Chats,Share %', `${src.source},${src.url},${src.count},${pct}%`].join('\n')
                const a = document.createElement('a')
                a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
                a.download = `leads-${src.source.toLowerCase().replace(/\s+/g,'-')}.csv`
                a.click()
              }
              return (
                <tr key={src.source} className="hover:bg-slate-50/60 transition-colors group">
                  <td className="px-4 py-2.5" style={{ fontSize: '11px' }}>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ background: '#f5f5f5' }}>
                        <Globe size={11} style={{ color: '#374151' }}/>
                      </div>
                      <span className="font-medium text-slate-700">{src.source}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-slate-700 font-medium hidden md:table-cell" style={{ fontSize: '11px' }}>{src.url}</td>
                  <td className="px-4 py-2.5 text-right font-medium text-slate-700" style={{ fontSize: '11px' }}>{src.count.toLocaleString()}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width:`${pct}%`, background: src.color }}/>
                      </div>
                      <span className="text-[9px] text-slate-400 w-7 text-right">{pct}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <button onClick={downloadSrc}
                      className="btn-secondary opacity-0 group-hover:opacity-100 transition-opacity">
                      <Download size={9}/> CSV
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* ── Realtime Agent Analytics ── */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <SLabel>Realtime Agent Analytics</SLabel>
          <span className="flex items-center gap-1 text-[9px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full -mt-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"/>LIVE
          </span>
        </div>

        {/* live KPI strip */}
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mb-3">
          {[
            { icon: Wifi,          label: 'Agents Online', value: rtOnline, color: '#22C55E' },
            { icon: MessageSquare, label: 'Active Chats',  value: rtActive, color: '#0066ff' },
            { icon: RefreshCw,     label: 'In Queue',      value: rtQueue,  color: rtQueue > 3 ? '#ef4444' : '#F59E0B', warn: rtQueue > 3 },
            { icon: Coffee,        label: 'On Break',      value: rtBreak,  color: '#8B5CF6' },
          ].map(k => {
            const KIcon = k.icon
            return (
              <div key={k.label} className={clsx(
                'bg-white border rounded-xl px-4 py-3 flex items-center gap-3',
                k.warn ? 'border-red-200' : 'border-surface-border'
              )}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: '#f5f5f5' }}>
                  <KIcon size={13} style={{ color: '#374151' }}/>
                </div>
                <div>
                  <p className="text-[18px] font-bold leading-none" style={{ color: k.color }}>{k.value}</p>
                  <p className="text-[9px] font-medium text-slate-400 mt-0.5">{k.label}</p>
                </div>
              </div>
            )
          })}
        </div>

        {/* agent table */}
        <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-[11px] min-w-[860px]">
              <thead>
                <tr className="bg-slate-50 border-b border-surface-border">
                  {['Agent','Status','Active','Queue','Avg Reply','Avg Handle','Longest Chat','Resolved','Transferred','CSAT','SLA'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-[9px] font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap first:pl-4">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border">
                {RT_AGENTS.map(a => (
                  <tr key={a.name} className="hover:bg-slate-50/60 transition-colors">
                    <td className="pl-4 pr-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 bg-slate-600">
                          {a.avatar}</div>
                        <span className="font-semibold text-slate-700 whitespace-nowrap">{a.name}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3"><StatusDot status={a.status}/></td>
                    <td className="px-3 py-3">
                      <span className={clsx('font-bold text-[13px]', a.active > 4 ? 'text-red-500' : a.active > 0 ? 'text-slate-700' : 'text-slate-300')}>
                        {a.active || '—'}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <span className={clsx('font-bold text-[13px]', a.queue > 2 ? 'text-amber-500' : a.queue > 0 ? 'text-slate-700' : 'text-slate-300')}>
                        {a.queue || '—'}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-slate-500">{a.avgReply}</td>
                    <td className="px-3 py-3 text-slate-500">{a.avgHandle}</td>
                    <td className="px-3 py-3">
                      <span className={clsx(a.longest !== '—' && parseInt(a.longest) > 25 ? 'text-red-400 font-semibold' : 'text-slate-500')}>
                        {a.longest}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="font-bold text-emerald-600 text-[13px]">{a.resolved}</span>
                    </td>
                    <td className="px-3 py-3 text-slate-500">{a.transferred}</td>
                    <td className="px-3 py-3">
                      <span className="flex items-center gap-0.5 font-bold text-slate-700">
                        <Star size={9} className="text-amber-400 fill-amber-400"/>{a.csat}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      {a.sla > 0
                        ? <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-red-50 text-red-500 text-[9px] font-bold border border-red-100">
                            <AlertTriangle size={8}/>{a.sla}
                          </span>
                        : <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600 text-[9px] font-bold">✓ OK</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50 border-t border-surface-border">
                  <td className="pl-4 pr-3 py-2.5 text-[9px] font-bold text-slate-500 uppercase tracking-wide">Team Total</td>
                  <td/>
                  <td className="px-3 py-2.5 font-bold text-slate-700">{RT_AGENTS.reduce((s,a)=>s+a.active,0)}</td>
                  <td className="px-3 py-2.5 font-bold text-slate-700">{RT_AGENTS.reduce((s,a)=>s+a.queue,0)}</td>
                  <td colSpan={3}/>
                  <td className="px-3 py-2.5 font-bold text-emerald-600">{RT_AGENTS.reduce((s,a)=>s+a.resolved,0)}</td>
                  <td className="px-3 py-2.5 font-bold text-slate-700">{RT_AGENTS.reduce((s,a)=>s+a.transferred,0)}</td>
                  <td className="px-3 py-2.5 text-[10px] text-slate-500">
                    ★ {(RT_AGENTS.filter(a=>a.csat>0).reduce((s,a)=>s+a.csat,0)/RT_AGENTS.filter(a=>a.csat>0).length).toFixed(1)} avg
                  </td>
                  <td className="px-3 py-2.5 text-[10px] font-bold text-red-500">
                    {RT_AGENTS.reduce((s,a)=>s+a.sla,0)} total
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>

    </div>
  )
}

/* ════════════════════════════════════════════════════════════════
   APPOINTMENTS TAB
════════════════════════════════════════════════════════════════ */
function AppointmentsTab({ range }) {
  const data = range === 'today' ? APPT_1 : range === '7d' ? APPT_7 : APPT_30
  const sum  = (k) => data.reduce((a,d) => a + d[k], 0)
  const booked = sum('booked'), completed = sum('completed'), cancelled = sum('cancelled'), noShow = sum('noShow'), rescheduled = sum('rescheduled')
  const rate = Math.round((completed / booked) * 100)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <MetricCard icon={CalendarCheck}  label="Total Booked"    value={booked.toLocaleString()}       trend={6}  color="#0066ff"/>
        <MetricCard icon={CheckCircle2}   label="Completed"       value={completed.toLocaleString()}     trend={9}  color="#22C55E"/>
        <MetricCard icon={CalendarX}      label="Cancelled"       value={cancelled.toLocaleString()}     trend={-3} color="#F87171"/>
        <MetricCard icon={CalendarClock}  label="Rescheduled"     value={rescheduled.toLocaleString()}   trend={4}  color="#8B5CF6"/>
        <MetricCard icon={Timer}          label="Completion Rate"  value={`${rate}%`}                    trend={2}  color="#0066ff"/>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <ChartCard title="Appointment Trends" sub="Booked vs completed over time">
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={data} margin={{ top:4, right:4, left:-20, bottom:0 }}>
                <defs>
                  <linearGradient id="aBk" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#374151" stopOpacity={0.15}/><stop offset="100%" stopColor="#374151" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="aCp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6b7280" stopOpacity={0.15}/><stop offset="100%" stopColor="#6b7280" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
                <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={range==='30d'?5:0}/>
                <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
                <Tooltip content={<ChartTip/>}/>
                <Area type="monotone" dataKey="booked"    name="Booked"    stroke="#374151" strokeWidth={2}   fill="url(#aBk)" dot={false}/>
                <Area type="monotone" dataKey="completed" name="Completed" stroke="#6b7280" strokeWidth={1.5} fill="url(#aCp)" dot={false}/>
              </AreaChart>
            </ResponsiveContainer>
            <Legend items={[{color:'#374151',label:'Booked'},{color:'#6b7280',label:'Completed'}]}/>
          </ChartCard>
        </div>

        <ChartCard title="Status Breakdown">
          <div className="flex flex-col items-center">
            <div className="relative">
              <ResponsiveContainer width={120} height={120}>
                <PieChart>
                  <Pie data={APPT_STATUS} cx="50%" cy="50%" innerRadius={36} outerRadius={56} dataKey="value" strokeWidth={2} stroke="#fff">
                    {APPT_STATUS.map((e,i) => <Cell key={i} fill={e.color}/>)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-[18px] font-bold text-slate-800">{rate}%</p>
                <p className="text-[8px] text-slate-400">done</p>
              </div>
            </div>
            <div className="w-full space-y-2 mt-3">
              {APPT_STATUS.map(s => (
                <div key={s.name} className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-[10px] text-slate-500">
                    <span className="w-2 h-2 rounded-sm" style={{ background: s.color }}/>{s.name}
                  </span>
                  <span className="text-[12px] font-bold text-slate-700">{s.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>
      </div>

      <ChartCard title="Cancellations, Rescheduled & No-Shows" sub="Last 7 days">
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-red-50 border border-red-100 rounded-xl p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f5f5f5' }}>
              <CalendarX size={14} style={{ color: '#374151' }}/>
            </div>
            <div>
              <p className="text-[20px] font-bold text-red-500">{cancelled}</p>
              <p className="text-[9px] text-red-400 font-semibold">Cancelled</p>
            </div>
          </div>
          <div className="bg-violet-50 border border-violet-100 rounded-xl p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f5f5f5' }}>
              <CalendarClock size={14} style={{ color: '#374151' }}/>
            </div>
            <div>
              <p className="text-[20px] font-bold text-violet-500">{rescheduled}</p>
              <p className="text-[9px] text-violet-500 font-semibold">Rescheduled</p>
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f5f5f5' }}>
              <AlertCircle size={14} style={{ color: '#374151' }}/>
            </div>
            <div>
              <p className="text-[20px] font-bold text-amber-500">{noShow}</p>
              <p className="text-[9px] text-amber-500 font-semibold">No-Shows</p>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={110}>
          <BarChart data={data.slice(-7)} margin={{ top:4, right:4, left:-20, bottom:0 }} barSize={14}>
            <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
            <XAxis dataKey="date" tick={{ fontSize:8, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
            <YAxis tick={{ fontSize:8, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
            <Tooltip content={<ChartTip/>}/>
            <Bar dataKey="cancelled"   name="Cancelled"   fill="#F87171" radius={[3,3,0,0]} stackId="a"/>
            <Bar dataKey="rescheduled" name="Rescheduled" fill="#8B5CF6" radius={[0,0,0,0]} stackId="a"/>
            <Bar dataKey="noShow"      name="No Show"     fill="#F59E0B" radius={[3,3,0,0]} stackId="a"/>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}

/* ════════════════════════════════════════════════════════════════
   BROADCASTS TAB
════════════════════════════════════════════════════════════════ */
function ProBadge() {
  return <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-bold bg-blue-600 text-white leading-none">Pro</span>
}

function BroadcastsTab({ range, selTemplateId, setSelTemplateId }) {
  const selTpl   = selTemplateId === 'all' ? null : BC_TEMPLATES.find(t => t.id === selTemplateId)
  const data     = range === 'today' ? BC_1 : range === '7d' ? BC_7 : BC_30
  const chartData = selTpl ? selTpl.dailySent : data

  /* funnel numbers — switch between template-level and aggregate */
  const attempted     = selTpl ? selTpl.attempted     : 1234567
  const sent          = selTpl ? selTpl.sent          : 124345
  const delivered     = selTpl ? selTpl.delivered     : 98200
  const read          = selTpl ? selTpl.read          : 11122
  const replied       = selTpl ? selTpl.replied       : 5000
  const clicked       = selTpl ? selTpl.clicked       : 4000
  const failed        = selTpl ? selTpl.failed        : 12313
  const userInitiated = selTpl ? selTpl.userInitiated : 10000

  const FUNNEL = [
    { label: 'Total Attempted', value: attempted, pro: false },
    { label: 'Sent',            value: sent,      pro: false },
    { label: 'Delivered',       value: delivered, pro: false },
    { label: 'Read',            value: read,      pro: false },
    { label: 'Replied',         value: replied,   pro: true  },
    { label: 'Clicked',         value: clicked,   pro: true  },
  ]

  /* conversation category data */
  const convData = selTpl
    ? selTpl.dailySent.map(d => ({ date: d.date, sent: d.sent, delivered: d.delivered, read: d.read, clicked: d.clicked }))
    : data.map(d => ({
        date: d.date,
        marketing:      rand(5000, 45000),
        service:        rand(3000, 25000),
        authentication: rand(1000, 30000),
        utility:        rand(2000, 20000),
      }))

  /* approx charges data */
  const chargesData = data.map(d => ({
    date:           d.date,
    marketing:      rand(4000, 40000),
    service:        rand(2000, 18000),
    authentication: rand(800,  22000),
    utility:        rand(1500, 14000),
  }))

  /* conversation category summary */
  const CATS = [
    { cat: 'Marketing',            paid: 200000, charges: 40000 },
    { cat: 'Utility',              paid: 12340,  charges: 12340 },
    { cat: 'Authentication',       paid: 0,      charges: 0     },
    { cat: 'Authentication (Int)', paid: 0,      charges: 0     },
    { cat: 'Service',              paid: 144679, charges: 4679  },
  ]
  const totalPaid    = CATS.reduce((s,r) => s + r.paid, 0)
  const totalCharges = CATS.reduce((s,r) => s + r.charges, 0)

  /* WA errors — template-specific or aggregate */
  const WA_ERRORS = selTpl?.errors?.length ? selTpl.errors : [
    { code: '100',    type: 'Parameter is invalid',                count: 6000 },
    { code: '130111', type: "User's number part of an experiment", count: 5800 },
    { code: '130111', type: 'Message Undeliverable',               count: 4200 },
    { code: '130111', type: 'WhatsApp Not Available',              count: 3100 },
    { code: '131026', type: 'Limit Reached',                       count: 2900 },
    { code: '132000', type: 'Template parameter count mismatch',   count: 1500 },
  ]
  const totalErrors = WA_ERRORS.reduce((s,e) => s + e.count, 0)

  const AREA_LINES = [
    { key: 'marketing',      name: 'Marketing',      color: '#374151' },
    { key: 'service',        name: 'Service',        color: '#6b7280' },
    { key: 'authentication', name: 'Authentication', color: '#9ca3af' },
    { key: 'utility',        name: 'Utility',        color: '#d1d5db' },
  ]

  const CAT_COLOR = { Marketing: '#8B5CF6', Utility: '#0066ff', Service: '#22C55E', Authentication: '#F59E0B' }

  return (
    <div className="space-y-5">

      {/* ── Template context bar — shown when a template is selected ── */}
      {selTpl && (
        <div className="flex items-center gap-2 py-2 px-3 bg-slate-50 border border-surface-border rounded-xl">
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
            style={{ background: CAT_COLOR[selTpl.category] + '18', color: CAT_COLOR[selTpl.category] }}>
            {selTpl.category}
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600">
            {selTpl.status}
          </span>
          {selTpl.campaigns.length > 0 && (
            <span className="text-[10px] text-slate-400">
              Used in: <span className="font-semibold text-slate-600">{selTpl.campaigns.join(', ')}</span>
            </span>
          )}
          <div className="flex-1" />
          <button
            onClick={() => setSelTemplateId('all')}
            className="text-[10px] text-slate-400 hover:text-slate-600 font-semibold transition-colors">
            ✕ Clear filter
          </button>
        </div>
      )}

      {/* ── Overview metric cards ── */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <MetricCard icon={Send}          label="Total Attempted" value={attempted.toLocaleString()}     trend={20}  color="#0066ff"/>
        <MetricCard icon={CheckCircle2}  label="Sent"            value={sent.toLocaleString()}          trend={12}  color="#0066ff"/>
        <MetricCard icon={Eye}           label="Delivered"       value={delivered.toLocaleString()}     trend={-2}  color="#0066ff"/>
        <MetricCard icon={XCircle}       label="Failed"          value={failed.toLocaleString()}        trend={-8}  color="#0066ff"/>
        <MetricCard icon={Eye}           label="Read"            value={read.toLocaleString()}          trend={-22} color="#0066ff"/>
        <MetricCard icon={Users}         label="User Initiated"  value={userInitiated.toLocaleString()} trend={5}   color="#0066ff"/>
        <MetricCard icon={MessageSquare} label="Replied"         value={replied.toLocaleString()}       trend={18}  color="#8B5CF6" pro/>
        <MetricCard icon={TrendingUp}    label="Clicked"         value={clicked.toLocaleString()}       trend={18}  color="#8B5CF6" pro/>
      </div>

      {/* ── Delivery Funnel ── */}
      <ChartCard
        title="Message Delivery Funnel"
        sub="Step-by-step conversion from attempted to clicked"
        right={
          <span className="text-[10px] text-slate-400 font-medium">
            Overall CTR: <span className="font-bold text-slate-700">{((clicked/attempted)*100).toFixed(2)}%</span>
          </span>
        }
      >
        <div className="space-y-2">
          {FUNNEL.map((step, i) => {
            const pct      = ((step.value / attempted) * 100).toFixed(1)
            const convRate = i > 0 ? ((step.value / FUNNEL[i-1].value) * 100).toFixed(1) : null
            const barW     = Math.max((step.value / attempted) * 100, 0.5)
            return (
              <div key={step.label}>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[9px] font-bold text-slate-500 flex-shrink-0">
                    {i + 1}
                  </div>
                  <div className="w-28 flex-shrink-0 flex items-center gap-1.5">
                    <span className="text-[11px] font-medium text-slate-600 leading-tight">{step.label}</span>
                    {step.pro && <ProBadge/>}
                  </div>
                  <div className="flex-1 h-7 bg-slate-50 rounded-lg border border-surface-border overflow-hidden">
                    <div className="h-full bg-slate-800 rounded-lg flex items-center justify-end pr-2.5 transition-all duration-700"
                      style={{ width: `${barW}%` }}>
                      {barW > 12 && (
                        <span className="text-[9px] font-bold text-white whitespace-nowrap">{step.value.toLocaleString()}</span>
                      )}
                    </div>
                  </div>
                  <div className="w-28 flex-shrink-0 flex items-center justify-end gap-3">
                    <span className="text-[11px] font-bold text-slate-700">{pct}%</span>
                    {convRate !== null && (
                      <span className={clsx(
                        'text-[9px] font-semibold px-1.5 py-0.5 rounded-full',
                        Number(convRate) >= 70 ? 'bg-emerald-50 text-emerald-600' :
                        Number(convRate) >= 30 ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-500'
                      )}>↓{convRate}%</span>
                    )}
                  </div>
                </div>
                {i < FUNNEL.length - 1 && (
                  <div className="flex items-center gap-3 h-2 mt-0.5">
                    <div className="w-5 flex-shrink-0"/>
                    <div className="w-28 flex-shrink-0"/>
                    <div className="flex-1 flex"><div className="ml-3 w-px h-2 bg-slate-200"/></div>
                    <div className="w-28"/>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </ChartCard>

      {/* ── Conversation Insights + Paid Conversations ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-stretch">
        <div className="lg:col-span-2 flex flex-col">
          {selTpl ? (
            /* ── Template-specific delivery trend ── */
            <ChartCard
              className="flex-1"
              title={`Delivery Trend — ${selTpl.name}`}
              sub="Sent → Delivered → Read → Clicked over time"
              right={
                <div className="flex items-center gap-3 flex-wrap">
                  {[{color:'#374151',label:'Sent'},{color:'#6b7280',label:'Delivered'},{color:'#22C55E',label:'Read'},{color:'#8B5CF6',label:'Clicked'}].map(l => (
                    <span key={l.label} className="flex items-center gap-1 text-[9px] text-slate-400">
                      <span className="w-2 h-2 rounded-sm" style={{ background: l.color }}/>{l.label}
                    </span>
                  ))}
                </div>
              }
            >
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={convData} margin={{ top:4, right:4, left:-10, bottom:0 }}>
                  <defs>
                    {[{id:'tSent',c:'#374151'},{id:'tDlv',c:'#6b7280'},{id:'tRd',c:'#22C55E'},{id:'tClk',c:'#8B5CF6'}].map(g => (
                      <linearGradient key={g.id} id={g.id} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={g.c} stopOpacity={0.15}/><stop offset="100%" stopColor={g.c} stopOpacity={0}/>
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
                  <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={range==='30d'?5:0}/>
                  <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} tickFormatter={v => v>=1000?(v/1000).toFixed(0)+'k':v}/>
                  <Tooltip content={<ChartTip/>}/>
                  <Area type="monotone" dataKey="sent"      name="Sent"      stroke="#374151" strokeWidth={2}   fill="url(#tSent)" dot={false}/>
                  <Area type="monotone" dataKey="delivered" name="Delivered" stroke="#6b7280" strokeWidth={1.5} fill="url(#tDlv)"  dot={false}/>
                  <Area type="monotone" dataKey="read"      name="Read"      stroke="#22C55E" strokeWidth={1.5} fill="url(#tRd)"   dot={false}/>
                  <Area type="monotone" dataKey="clicked"   name="Clicked"   stroke="#8B5CF6" strokeWidth={1.5} fill="url(#tClk)"  dot={false}/>
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>
          ) : (
            /* ── All-template category breakdown ── */
            <ChartCard
              className="flex-1"
              title="Conversation Insights"
              sub="By category over time"
              right={
                <div className="flex items-center gap-3 flex-wrap">
                  {AREA_LINES.map(l => (
                    <span key={l.key} className="flex items-center gap-1 text-[9px] text-slate-400">
                      <span className="w-2 h-2 rounded-sm" style={{ background: l.color }}/>{l.name}
                    </span>
                  ))}
                </div>
              }
            >
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={convData} margin={{ top:4, right:4, left:-10, bottom:0 }}>
                  <defs>
                    {AREA_LINES.map(l => (
                      <linearGradient key={l.key} id={`bc${l.key}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%"   stopColor={l.color} stopOpacity={0.15}/>
                        <stop offset="100%" stopColor={l.color} stopOpacity={0}/>
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
                  <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={range==='30d'?5:0}/>
                  <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} tickFormatter={v => v>=1000?(v/1000).toFixed(0)+'k':v}/>
                  <Tooltip content={<ChartTip/>}/>
                  {AREA_LINES.map(l => (
                    <Area key={l.key} type="monotone" dataKey={l.key} name={l.name}
                      stroke={l.color} strokeWidth={1.5} fill={`url(#bc${l.key})`} dot={false} stackId="conv"/>
                  ))}
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>
          )}
        </div>

        <ChartCard title="Paid Conversations" sub="By category + charges">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <ResponsiveContainer width={110} height={110}>
                <PieChart>
                  <Pie data={CATS.filter(c=>c.paid>0)} cx="50%" cy="50%"
                    innerRadius={32} outerRadius={52} dataKey="paid" strokeWidth={2} stroke="#fff">
                    {CATS.filter(c=>c.paid>0).map((_, i) => (
                      <Cell key={i} fill={['#1e293b','#475569','#94a3b8'][i % 3]}/>
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-[13px] font-bold text-slate-800">{(totalPaid/1000).toFixed(0)}k</p>
                <p className="text-[8px] text-slate-400">total</p>
              </div>
            </div>
          </div>
          <div className="space-y-1.5">
            {CATS.map((c, i) => (
              <div key={c.cat} className="flex items-center justify-between py-1.5 border-b border-slate-50 last:border-0">
                <span className="flex items-center gap-2 text-[10px] text-slate-500 min-w-0">
                  <span className="w-2 h-2 rounded-sm flex-shrink-0"
                    style={{ background: ['#1e293b','#475569','#94a3b8','#cbd5e1','#e2e8f0'][i] }}/>
                  <span className="truncate">{c.cat}</span>
                </span>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="text-[10px] font-semibold text-slate-700">{c.paid.toLocaleString()}</span>
                  <span className="text-[9px] text-slate-400 w-14 text-right">₹{c.charges.toLocaleString()}</span>
                </div>
              </div>
            ))}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-[10px] font-bold text-slate-600">Total</span>
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-bold text-slate-800">{totalPaid.toLocaleString()}</span>
                <span className="text-[9px] font-bold text-slate-600 w-14 text-right">₹{totalCharges.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* ── Approximate Charges + Template Errors ── */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-stretch">
        <div className="lg:col-span-3 flex flex-col">
          <ChartCard
            className="flex-1"
            title="Approximate Charges"
            sub="₹ spend trend by conversation type"
            right={
              <div className="flex items-center gap-2">
                <button className="btn-secondary">Conversations <ChevronDown size={9}/></button>
                <button className="btn-secondary">Customise <ChevronDown size={9}/></button>
              </div>
            }
          >
            <ResponsiveContainer width="100%" height={190}>
              <AreaChart data={chargesData} margin={{ top:4, right:4, left:-4, bottom:0 }}>
                <defs>
                  {AREA_LINES.map(l => (
                    <linearGradient key={`ch${l.key}`} id={`ch${l.key}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%"   stopColor={l.color} stopOpacity={0.18}/>
                      <stop offset="100%" stopColor={l.color} stopOpacity={0}/>
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
                <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={range==='30d'?5:0}/>
                <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} tickFormatter={v => '₹'+(v/1000).toFixed(0)+'k'}/>
                <Tooltip content={<ChartTip/>}/>
                {AREA_LINES.map(l => (
                  <Area key={l.key} type="monotone" dataKey={l.key} name={l.name}
                    stroke={l.color} strokeWidth={1.5} fill={`url(#ch${l.key})`} dot={false} stackId="charges"/>
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <div className="lg:col-span-2 flex flex-col">
          <ChartCard
            className="flex-1"
            title="Template Errors"
            sub={`${totalErrors.toLocaleString()} total`}
            right={
              <span className="text-[9px] font-bold text-red-500 bg-red-50 border border-red-100 px-2 py-0.5 rounded-full">
                {WA_ERRORS.length} types
              </span>
            }
            noPad
          >
            <div className="divide-y divide-surface-border">
              {WA_ERRORS.map((e, i) => {
                const pct = Math.round((e.count / totalErrors) * 100)
                return (
                  <div key={i} className="px-4 py-2.5 hover:bg-slate-50/60 transition-colors">
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="text-[10px] text-slate-500 leading-snug flex-1">{e.type}</span>
                      <span className="text-[11px] font-bold text-slate-700 flex-shrink-0">{e.count.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-slate-400 font-mono">{e.code}</span>
                      <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full bg-red-300" style={{ width:`${pct}%` }}/>
                      </div>
                      <span className="text-[9px] text-slate-400">{pct}%</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </ChartCard>
        </div>
      </div>

      {/* ── Campaign Performance ── */}
      <ChartCard
        title="Campaign Performance"
        sub={selTpl
          ? `Campaigns using "${selTpl.name}"`
          : `${BC_CAMPAIGNS.length} campaigns`}
        noPad
      >
        <div className="divide-y divide-surface-border">
          {BC_CAMPAIGNS.filter(c => !selTpl || selTpl.campaigns.includes(c.name)).length === 0 ? (
            <div className="py-10 text-center">
              <Megaphone size={24} className="text-slate-200 mx-auto mb-2" />
              <p className="text-xs text-slate-400">This template hasn't been used in any campaign yet</p>
            </div>
          ) : BC_CAMPAIGNS
            .filter(c => !selTpl || selTpl.campaigns.includes(c.name))
            .map(c => {
            const dlvPct = Math.round((c.delivered / c.sent) * 100)
            return (
              <div key={c.name} className="px-4 py-3 hover:bg-slate-50/40 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[12px] font-semibold text-slate-700">{c.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-[10px] text-slate-400">{c.sent.toLocaleString()} sent</span>
                    <span className={clsx('text-[11px] font-bold', c.readRate > 50 ? 'text-emerald-600' : 'text-amber-500')}>
                      {c.readRate}% read
                    </span>
                    <span className={clsx('text-[11px] font-bold', c.clickRate > 8 ? 'text-emerald-600' : 'text-slate-500')}>
                      {c.clickRate}% click
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: 'Delivered', value: dlvPct },
                    { label: 'Read',      value: c.readRate },
                    { label: 'Clicked',   value: c.clickRate },
                    { label: 'Replied',   value: Math.round(c.clickRate * 0.7) },
                  ].map(bar => (
                    <div key={bar.label}>
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-[8px] text-slate-400">{bar.label}</span>
                        <span className="text-[8px] font-bold text-slate-600">{bar.value}%</span>
                      </div>
                      <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full bg-slate-700" style={{ width:`${Math.min(bar.value,100)}%` }}/>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      </ChartCard>

    </div>
  )
}

/* ════════════════════════════════════════════════════════════════
   AI USAGE TAB
════════════════════════════════════════════════════════════════ */
function AITab({ range }) {
  const data       = range === 'today' ? AI_1 : range === '7d' ? AI_7 : AI_30
  const sum        = (k) => data.reduce((a,d) => a + d[k], 0)
  const tokens     = sum('tokens'), sessions = sum('sessions'), suggested = sum('suggested'), accepted = sum('accepted')
  const acceptRate = Math.round((accepted / suggested) * 100)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <MetricCard icon={Zap}          label="Tokens Used"          value={(tokens/1000).toFixed(0)+'K'} trend={22} color="#8B5CF6"/>
        <MetricCard icon={Bot}          label="AI Sessions"          value={sessions.toLocaleString()}    trend={18} color="#0066ff"/>
        <MetricCard icon={CheckCircle2} label="Suggestions Accepted" value={`${acceptRate}%`}             trend={4}  color="#22C55E"/>
        <MetricCard icon={TrendingUp}   label="Automation Rate"      value="71%"                          trend={6}  color="#F59E0B"/>
      </div>

      <ChartCard title="Token Usage Over Time" sub="AI tokens consumed per day">
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={data} margin={{ top:4, right:4, left:-10, bottom:0 }}>
            <defs>
              <linearGradient id="gTok" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#374151" stopOpacity={0.15}/><stop offset="100%" stopColor="#374151" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
            <XAxis dataKey="date" tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={range==='30d'?5:0}/>
            <YAxis tick={{ fontSize:9, fill:'#94a3b8' }} tickLine={false} axisLine={false} tickFormatter={v=>(v/1000).toFixed(0)+'K'}/>
            <Tooltip content={<ChartTip/>}/>
            <Area type="monotone" dataKey="tokens" name="Tokens" stroke="#374151" strokeWidth={2} fill="url(#gTok)" dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Suggestions vs Accepted" sub="Last 7 days">
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={data.slice(-7)} margin={{ top:4, right:4, left:-20, bottom:0 }} barSize={16} barGap={3}>
              <CartesianGrid strokeDasharray="2 4" stroke="#f1f5f9" vertical={false}/>
              <XAxis dataKey="date" tick={{ fontSize:8, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
              <YAxis tick={{ fontSize:8, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
              <Tooltip content={<ChartTip/>}/>
              <Bar dataKey="suggested" name="Suggested" fill="#d1d5db" radius={[3,3,0,0]}/>
              <Bar dataKey="accepted"  name="Accepted"  fill="#374151" radius={[3,3,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
          <Legend items={[{color:'#d1d5db',label:'Suggested'},{color:'#374151',label:'Accepted'}]}/>
        </ChartCard>

        <ChartCard title="Feature Acceptance">
          <div className="space-y-4">
            {AI_FEATURES.map(f => (
              <div key={f.name}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background: '#f5f5f5' }}>
                      <Zap size={10} style={{ color: '#374151' }}/>
                    </div>
                    <span className="text-[11px] font-medium text-slate-600">{f.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-400">{f.uses.toLocaleString()}</span>
                    <span className="text-[11px] font-bold w-8 text-right text-slate-700">{f.rate}%</span>
                  </div>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width:`${f.rate}%`, background: f.color }}/>
                </div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>
    </div>
  )
}

/* ════════════════════════════════════════════════════════════════
   ROOT
════════════════════════════════════════════════════════════════ */
export default function Analytics() {
  const [tab,           setTab]           = useState('chat')
  const [range,         setRange]         = useState('30d')
  const [showPicker,    setShowPicker]    = useState(false)
  const [fromDate,      setFromDate]      = useState('')
  const [toDate,        setToDate]        = useState('')
  const [selTemplateId, setSelTemplateId] = useState('all')
  const pickerRef = useRef(null)

  /* close picker on outside click */
  useEffect(() => {
    function handle(e) {
      if (pickerRef.current && !pickerRef.current.contains(e.target)) setShowPicker(false)
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [])

  function applyCustom() {
    if (!fromDate || !toDate) return
    setRange('custom')
    setShowPicker(false)
  }

  /* label shown on the custom button */
  const customLabel = range === 'custom' && fromDate && toDate
    ? `${fromDate} – ${toDate}`
    : 'Custom'

  return (
    <div className="space-y-4 animate-fade-in">

      {/* ── toolbar ── */}
      <div className="flex items-center gap-2 flex-wrap">
        {/* tabs */}
        <div className="flex items-center gap-1 bg-slate-100 rounded-xl p-1">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={clsx(
                'px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap',
                tab === t.id ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              )}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1"/>

        {/* template filter — only visible on Broadcasts tab */}
        {tab === 'broadcast' && (
          <NativeSelect value={selTemplateId} onChange={e => setSelTemplateId(e.target.value)} sm className="font-semibold">
            <option value="all">All Templates</option>
            {BC_TEMPLATES.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </NativeSelect>
        )}

        {/* date range presets */}
        <div className="flex items-center gap-1 bg-slate-100 rounded-xl p-1">
          {PRESETS.map(p => (
            <button key={p.id} onClick={() => { setRange(p.id); setShowPicker(false) }}
              className={clsx(
                'px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all whitespace-nowrap',
                range === p.id ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              )}>
              {p.label}
            </button>
          ))}

          {/* custom date button */}
          <div className="relative" ref={pickerRef}>
            <button
              onClick={() => setShowPicker(p => !p)}
              className={clsx(
                'flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all whitespace-nowrap',
                range === 'custom' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              )}>
              <Calendar size={10}/>
              {customLabel}
            </button>

            {/* date picker dropdown */}
            {showPicker && (
              <div className="absolute right-0 top-full mt-2 z-50 bg-white border border-surface-border rounded-xl shadow-modal p-4 w-64 animate-fade-in">
                <p className="text-[11px] font-semibold text-slate-700 mb-3">Custom Date Range</p>
                <div className="space-y-2.5">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-500 mb-1">From</label>
                    <input
                      type="date"
                      value={fromDate}
                      max={toDate || undefined}
                      onChange={e => setFromDate(e.target.value)}
                      className="w-full border border-surface-border rounded-lg px-2.5 py-1.5 text-[11px] text-slate-700 focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-500 mb-1">To</label>
                    <input
                      type="date"
                      value={toDate}
                      min={fromDate || undefined}
                      onChange={e => setToDate(e.target.value)}
                      className="w-full border border-surface-border rounded-lg px-2.5 py-1.5 text-[11px] text-slate-700 focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => { setShowPicker(false) }}
                    className="btn-secondary flex-1 justify-center">
                    Cancel
                  </button>
                  <button
                    onClick={applyCustom}
                    disabled={!fromDate || !toDate}
                    className="btn-primary flex-1 justify-center disabled:opacity-40 disabled:cursor-not-allowed">
                    Apply
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <button className="btn-secondary">
          <Download size={11}/> Export
        </button>
      </div>

      {/* ── content ── */}
      {tab === 'chat'      && <ChatTab range={range}/>}
      {tab === 'appt'      && <AppointmentsTab range={range}/>}
      {tab === 'broadcast' && <BroadcastsTab range={range} selTemplateId={selTemplateId} setSelTemplateId={setSelTemplateId}/>}
      {tab === 'ai'        && <AITab range={range}/>}

    </div>
  )
}
