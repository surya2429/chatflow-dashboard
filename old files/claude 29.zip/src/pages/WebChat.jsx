import { useState } from 'react'
import {
  Globe, MessageCircle, Users, Clock, CheckCircle2,
  Copy, Check, Settings, Palette, Code2, BarChart2,
  AlignLeft, AlignRight, ArrowUpRight, RefreshCw,
  Shield, Info, ExternalLink, Zap, Monitor, Smartphone,
  Tablet, ChevronDown, ChevronUp, MessageSquare, HelpCircle,
  Volume2, Star, Smile, Paperclip, Bell, Eye, EyeOff,
  Hash, Link2, Type, Image,
} from 'lucide-react'
import clsx from 'clsx'
import WebChatWidget from '../components/WebChatWidget'

/* ─── Tabs ──────────────────────────────────────── */
const TABS = [
  { id:'overview', label:'Overview',       icon: BarChart2      },
  { id:'builder',  label:'Widget Builder', icon: Palette        },
  { id:'embed',    label:'Embed Code',     icon: Code2          },
  { id:'settings', label:'Settings',       icon: Settings       },
]

/* ─── Overview data ─────────────────────────────── */
const STATS = [
  { label:'Total Conversations', value:'1,247', change:'+12%', icon: MessageCircle, color:'blue'   },
  { label:'Leads Captured',      value:'342',   change:'+8%',  icon: Users,         color:'purple' },
  { label:'Avg Response Time',   value:'18s',   change:'-22%', icon: Clock,         color:'green'  },
  { label:'Bot Resolution Rate', value:'73%',   change:'+5%',  icon: CheckCircle2,  color:'amber'  },
]
const SC = {
  blue:   { bg:'bg-blue-50',    ic:'text-blue-500',    badge:'bg-blue-100 text-blue-700'    },
  purple: { bg:'bg-purple-50',  ic:'text-purple-500',  badge:'bg-purple-100 text-purple-700'},
  green:  { bg:'bg-emerald-50', ic:'text-emerald-500', badge:'bg-emerald-100 text-emerald-700'},
  amber:  { bg:'bg-amber-50',   ic:'text-amber-500',   badge:'bg-amber-100 text-amber-700'  },
}
const RECENT = [
  { id:1, name:'Arjun Sharma',  page:'Pricing',      msgs:7,  status:'resolved',  time:'2m ago',  lead:true  },
  { id:2, name:'Neha Patel',    page:'Home',         msgs:3,  status:'active',    time:'5m ago',  lead:false },
  { id:3, name:'Rahul Singh',   page:'Product Demo', msgs:12, status:'resolved',  time:'18m ago', lead:true  },
  { id:4, name:'Visitor #4821', page:'Blog',         msgs:2,  status:'abandoned', time:'34m ago', lead:false },
  { id:5, name:'Priya Verma',   page:'Contact Us',   msgs:5,  status:'resolved',  time:'1h ago',  lead:true  },
]
const SS = { active:'bg-emerald-100 text-emerald-700', resolved:'bg-blue-100 text-blue-700', abandoned:'bg-slate-100 text-slate-500' }

const COLORS = ['#0066ff','#8B5CF6','#10B981','#F59E0B','#EF4444','#EC4899','#06B6D4','#64748B','#1D4ED8','#7C3AED','#059669','#DC2626']
const FW = ['HTML','React / Next.js','WordPress','Webflow']
const BOT_ID = 'cf_bot_a8x2k9p1'

/* ─── Helpers ───────────────────────────────────── */
function useCopy() {
  const [copied, setCopied] = useState(null)
  function copy(text, key) {
    navigator.clipboard.writeText(text).catch(()=>{})
    setCopied(key)
    setTimeout(()=>setCopied(null), 2000)
  }
  return { copied, copy }
}

function Toggle({ checked, onChange, size='md' }) {
  const h = size==='sm' ? 'h-4 w-7' : 'h-5 w-9'
  const dot = size==='sm' ? 'w-3 h-3' : 'w-4 h-4'
  const tx  = size==='sm' ? 'translate-x-3' : 'translate-x-4'
  return (
    <button onClick={()=>onChange(!checked)}
      className={clsx('relative rounded-full transition-colors flex-shrink-0', h, checked ? 'bg-primary' : 'bg-slate-200')}>
      <span className={clsx('absolute top-0.5 bg-white rounded-full shadow transition-transform', dot, checked ? tx : 'translate-x-0.5')} />
    </button>
  )
}

function Section({ title, icon: Icon, children, defaultOpen=true }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border border-surface-border rounded-xl overflow-hidden">
      <button onClick={()=>setOpen(p=>!p)}
        className="w-full flex items-center gap-2.5 px-4 py-3 bg-white hover:bg-slate-50 transition-colors text-left">
        {Icon && <Icon size={13} className="text-slate-400 flex-shrink-0" />}
        <span className="flex-1 text-xs font-bold text-slate-800">{title}</span>
        {open ? <ChevronUp size={13} className="text-slate-400"/> : <ChevronDown size={13} className="text-slate-400"/>}
      </button>
      {open && <div className="border-t border-surface-border p-4 space-y-3.5 bg-white">{children}</div>}
    </div>
  )
}

function FL({ label, hint, children }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1.5">
        <span className="text-[11px] font-semibold text-slate-700">{label}</span>
        {hint && <span className="text-[10px] text-slate-400">{hint}</span>}
      </div>
      {children}
    </div>
  )
}

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-[11px] text-slate-700 leading-tight">{label}</span>
      {children}
    </div>
  )
}

function ColorDot({ color, selected, onClick }) {
  return (
    <button onClick={onClick} style={{ background:color, boxShadow: selected ? `0 0 0 2px white, 0 0 0 4px ${color}` : 'none' }}
      className="w-7 h-7 rounded-full transition-transform hover:scale-110 flex-shrink-0"
      style={{ background:color, outline: selected ? `3px solid ${color}` : 'none', outlineOffset:2 }}
    />
  )
}

/* ─── Tab: Overview ─────────────────────────────── */
function OverviewTab() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {STATS.map(s => {
          const c = SC[s.color]
          return (
            <div key={s.label} className="bg-white border border-surface-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={clsx('w-9 h-9 rounded-xl flex items-center justify-center', c.bg)}>
                  <s.icon size={17} className={c.ic}/>
                </div>
                <span className={clsx('text-[10px] font-bold px-2 py-0.5 rounded-full', c.badge)}>{s.change} ↑</span>
              </div>
              <p className="text-2xl font-bold text-slate-900">{s.value}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">{s.label}</p>
            </div>
          )
        })}
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-semibold text-slate-800">Widget Active</span>
        </div>
        <span className="text-[11px] text-slate-400">·</span>
        <span className="text-[11px] text-slate-500">Installed on <strong className="text-slate-700">yourwebsite.com</strong></span>
        <span className="text-[11px] text-slate-400">·</span>
        <span className="text-[11px] text-slate-500">Last visitor: <strong className="text-slate-700">2 min ago</strong></span>
        <div className="ml-auto">
          <button className="btn-secondary text-[11px] flex items-center gap-1.5"><ExternalLink size={11}/>View site</button>
        </div>
      </div>

      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-surface-border">
          <h3 className="text-sm font-bold text-slate-800">Recent Conversations</h3>
          <button className="text-[11px] text-primary font-semibold hover:underline flex items-center gap-1">View all<ArrowUpRight size={11}/></button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full" style={{minWidth:480}}>
            <thead>
              <tr className="border-b border-surface-border bg-slate-50">
                {['Visitor','Page','Messages','Status','Lead','Time'].map(h=>(
                  <th key={h} className="text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider px-4 py-2.5">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {RECENT.map(c=>(
                <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary-50 flex items-center justify-center text-primary text-[9px] font-bold flex-shrink-0">{c.name[0]}</div>
                      <span className="text-xs font-semibold text-slate-800">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-[11px] text-slate-500">{c.page}</td>
                  <td className="px-4 py-3 text-[11px] text-slate-600 font-semibold">{c.msgs}</td>
                  <td className="px-4 py-3"><span className={clsx('text-[10px] px-2 py-0.5 rounded-full font-semibold capitalize', SS[c.status])}>{c.status}</span></td>
                  <td className="px-4 py-3">{c.lead ? <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-emerald-100 text-emerald-700">✓ Yes</span> : <span className="text-[10px] text-slate-400">—</span>}</td>
                  <td className="px-4 py-3 text-[11px] text-slate-400">{c.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4">
        <h3 className="text-sm font-bold text-slate-800 mb-3">Top Pages by Conversations</h3>
        <div className="space-y-2.5">
          {[{page:'/pricing',pct:34,n:423},{page:'/home',pct:22,n:274},{page:'/product',pct:18,n:224},{page:'/blog',pct:15,n:187},{page:'/contact',pct:11,n:139}].map(p=>(
            <div key={p.page} className="flex items-center gap-3">
              <span className="text-[11px] text-slate-600 font-mono w-28 flex-shrink-0 truncate">{p.page}</span>
              <div className="flex-1 bg-slate-100 rounded-full h-1.5">
                <div className="h-1.5 rounded-full bg-primary transition-all" style={{width:`${p.pct}%`}} />
              </div>
              <span className="text-[11px] text-slate-500 w-8 text-right flex-shrink-0">{p.n}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ─── Tab: Widget Builder ───────────────────────── */
function BuilderTab() {
  const [cfg, setCfg] = useState({
    primaryColor:   '#0066ff',
    botName:        'ChatFlow Bot',
    tagline:        'Typically replies instantly',
    greeting:       'Hi there 👋',
    greetingSub:    'How can we help you today?',
    welcomeMessage: 'Hi! 👋 How can I help you today?',
    launcherText:   'Need help? Chat with us!',
    avatarInitial:  'C',
    position:       'right',
    size:           'medium',
    showBranding:   true,
    gradient:       true,
    showArticles:   true,
    showRating:     true,
    soundEnabled:   false,
    emojiEnabled:   true,
    attachEnabled:  true,
    leadCapture:    false,
    showDelay:      3,
    launcherIcon:   'chat',
  })
  const [device,  setDevice]  = useState('desktop')
  const [preview, setPreview] = useState('home') // home | chat | articles
  const set = (k,v) => setCfg(p=>({...p,[k]:v}))

  const deviceDims = {
    desktop: { w:380, h:560 },
    tablet:  { w:340, h:520 },
    mobile:  { w:300, h:500 },
  }
  const { w, h } = deviceDims[device]

  return (
    <div className="flex flex-col xl:flex-row gap-5 min-h-0">

      {/* ── Config panel ── */}
      <div className="xl:w-[360px] flex-shrink-0 space-y-2.5 xl:overflow-y-auto xl:max-h-[calc(100vh-200px)]">

        <Section title="Identity & Branding" icon={Type} defaultOpen>
          <FL label="Bot Name">
            <input value={cfg.botName} onChange={e=>set('botName',e.target.value)} className="input-field w-full text-sm" placeholder="ChatFlow Bot"/>
          </FL>
          <FL label="Avatar Letter">
            <div className="flex items-center gap-2">
              <input value={cfg.avatarInitial} onChange={e=>set('avatarInitial',(e.target.value.slice(-1).toUpperCase()||'B'))} className="input-field w-14 text-sm text-center font-bold" maxLength={1}/>
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0" style={{background:cfg.primaryColor}}>{cfg.avatarInitial}</div>
            </div>
          </FL>
          <FL label="Status Tagline">
            <input value={cfg.tagline} onChange={e=>set('tagline',e.target.value)} className="input-field w-full text-sm" placeholder="Typically replies instantly"/>
          </FL>
        </Section>

        <Section title="Colors & Theme" icon={Palette} defaultOpen>
          <FL label="Primary Color">
            <div className="flex flex-wrap gap-2 items-center">
              {COLORS.map(c=>(
                <button key={c} onClick={()=>set('primaryColor',c)}
                  className="w-7 h-7 rounded-full transition-transform hover:scale-110 flex-shrink-0"
                  style={{background:c, outline:cfg.primaryColor===c?`3px solid ${c}`:'none', outlineOffset:2}}
                />
              ))}
              <input type="color" value={cfg.primaryColor} onChange={e=>set('primaryColor',e.target.value)}
                className="w-7 h-7 rounded-full border-2 border-slate-200 cursor-pointer overflow-hidden p-0 flex-shrink-0"/>
            </div>
          </FL>
          <Row label="Gradient header">
            <Toggle checked={cfg.gradient} onChange={v=>set('gradient',v)}/>
          </Row>
        </Section>

        <Section title="Welcome Screen" icon={MessageSquare}>
          <FL label="Greeting Headline">
            <input value={cfg.greeting} onChange={e=>set('greeting',e.target.value)} className="input-field w-full text-sm" placeholder="Hi there 👋"/>
          </FL>
          <FL label="Greeting Subtext">
            <input value={cfg.greetingSub} onChange={e=>set('greetingSub',e.target.value)} className="input-field w-full text-sm" placeholder="How can we help you today?"/>
          </FL>
          <Row label="Show help articles">
            <Toggle checked={cfg.showArticles} onChange={v=>set('showArticles',v)}/>
          </Row>
        </Section>

        <Section title="Conversation" icon={MessageCircle}>
          <FL label="Welcome Message" hint="(first bot message)">
            <textarea value={cfg.welcomeMessage} onChange={e=>set('welcomeMessage',e.target.value)} rows={2} className="input-field w-full text-sm resize-none" placeholder="Hi! 👋 How can I help?"/>
          </FL>
          <Row label="Satisfaction rating">
            <Toggle checked={cfg.showRating} onChange={v=>set('showRating',v)}/>
          </Row>
          <Row label="Sound notifications">
            <Toggle checked={cfg.soundEnabled} onChange={v=>set('soundEnabled',v)}/>
          </Row>
          <Row label="Emoji picker">
            <Toggle checked={cfg.emojiEnabled} onChange={v=>set('emojiEnabled',v)}/>
          </Row>
          <Row label="File attachments">
            <Toggle checked={cfg.attachEnabled} onChange={v=>set('attachEnabled',v)}/>
          </Row>
        </Section>

        <Section title="Launcher" icon={Zap}>
          <FL label="Launcher Tooltip Text" hint="(optional)">
            <input value={cfg.launcherText} onChange={e=>set('launcherText',e.target.value)} className="input-field w-full text-sm" placeholder="Need help? Chat with us!"/>
          </FL>
          <FL label={`Show Delay — ${cfg.showDelay}s`}>
            <input type="range" min={0} max={30} value={cfg.showDelay} onChange={e=>set('showDelay',Number(e.target.value))} className="w-full accent-primary"/>
            <div className="flex justify-between text-[9px] text-slate-400 mt-0.5"><span>Immediately</span><span>30 seconds</span></div>
          </FL>
          <FL label="Position">
            <div className="grid grid-cols-2 gap-2">
              {[{val:'left',label:'Bottom Left',icon:AlignLeft},{val:'right',label:'Bottom Right',icon:AlignRight}].map(({val,label,icon:Icon})=>(
                <button key={val} onClick={()=>set('position',val)}
                  className={clsx('flex flex-col items-center gap-1.5 py-3 rounded-xl border-2 transition-all text-[11px] font-medium',
                    cfg.position===val ? 'border-primary bg-primary-50 text-primary' : 'border-surface-border bg-white text-slate-500 hover:border-slate-300')}>
                  <Icon size={15}/>{label}
                </button>
              ))}
            </div>
          </FL>
          <FL label="Size">
            <div className="grid grid-cols-3 gap-2">
              {['small','medium','large'].map(s=>(
                <button key={s} onClick={()=>set('size',s)}
                  className={clsx('py-2 rounded-xl border-2 transition-all text-[11px] font-medium capitalize',
                    cfg.size===s ? 'border-primary bg-primary-50 text-primary' : 'border-surface-border bg-white text-slate-500 hover:border-slate-300')}>
                  {s}
                </button>
              ))}
            </div>
          </FL>
        </Section>

        <Section title="Lead Capture" icon={Users}>
          <Row label="Enable pre-chat form">
            <Toggle checked={cfg.leadCapture} onChange={v=>set('leadCapture',v)}/>
          </Row>
          {cfg.leadCapture && (
            <div className="space-y-2 pt-1 border-t border-surface-border">
              {['Full Name','Email Address','Phone Number'].map(f=>(
                <Row key={f} label={f}><Toggle size="sm" checked={true} onChange={()=>{}}/></Row>
              ))}
            </div>
          )}
        </Section>

        <Section title="Branding" icon={Star}>
          <Row label={<span>"Powered by ChatFlow" badge</span>}>
            <Toggle checked={cfg.showBranding} onChange={v=>set('showBranding',v)}/>
          </Row>
        </Section>

        <button className="btn-primary w-full text-sm flex items-center justify-center gap-2">
          <Check size={14}/> Save Widget Settings
        </button>
      </div>

      {/* ── Preview panel ── */}
      <div className="flex-1 bg-slate-100 border border-surface-border rounded-2xl p-5 flex flex-col gap-4 min-h-0">

        {/* Preview toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 flex-shrink-0">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Live Preview</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Interact with the widget — changes reflect instantly</p>
          </div>
          <div className="flex items-center gap-2">
            {/* Screen tabs */}
            <div className="flex items-center gap-1 bg-white border border-surface-border rounded-lg p-1">
              {[{id:'home',label:'Home'},{id:'chat',label:'Chat'},{id:'articles',label:'Articles'}].map(s=>(
                <button key={s.id} onClick={()=>setPreview(s.id)}
                  className={clsx('text-[10px] font-semibold px-2.5 py-1 rounded-md transition-colors',
                    preview===s.id ? 'bg-primary text-white' : 'text-slate-500 hover:text-slate-700')}>
                  {s.label}
                </button>
              ))}
            </div>
            {/* Device tabs */}
            <div className="flex items-center gap-1 bg-white border border-surface-border rounded-lg p-1">
              {[{id:'desktop',icon:Monitor},{id:'tablet',icon:Tablet},{id:'mobile',icon:Smartphone}].map(({id,icon:Icon})=>(
                <button key={id} onClick={()=>setDevice(id)}
                  className={clsx('p-1.5 rounded-md transition-colors', device===id ? 'bg-primary text-white' : 'text-slate-400 hover:text-slate-600')}>
                  <Icon size={13}/>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Browser mockup + widget */}
        <div className="flex-1 flex items-start justify-center overflow-auto">
          <div className="flex flex-col items-center gap-3">
            {/* Browser frame */}
            <div className="rounded-xl overflow-hidden border border-slate-300 shadow-2xl bg-white flex flex-col transition-all duration-300" style={{width:w+2}}>
              {/* Browser bar */}
              <div className="flex items-center gap-2 px-3 py-2 bg-slate-200 border-b border-slate-300 flex-shrink-0">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400"/>
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400"/>
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400"/>
                </div>
                <div className="flex-1 mx-2 bg-white rounded-md px-2 py-0.5 text-[9px] text-slate-400 border border-slate-300 flex items-center gap-1">
                  <Shield size={7} className="text-slate-300"/>yourwebsite.com/pricing
                </div>
                <RefreshCw size={10} className="text-slate-400"/>
              </div>

              {/* Page + widget */}
              <div className="relative bg-white overflow-hidden" style={{height:h}}>
                {/* Mock page */}
                <div className="p-5 space-y-3 opacity-40 pointer-events-none select-none">
                  <div className="h-5 w-36 bg-slate-200 rounded"/>
                  <div className="h-2 w-full bg-slate-100 rounded"/>
                  <div className="h-2 w-5/6 bg-slate-100 rounded"/>
                  <div className="h-2 w-4/5 bg-slate-100 rounded"/>
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    {[1,2,3].map(i=>(
                      <div key={i} className="h-20 rounded-lg bg-slate-100 p-2 space-y-1">
                        <div className="h-2 w-2/3 bg-slate-200 rounded"/>
                        <div className="h-1.5 w-full bg-slate-50 rounded"/>
                        <div className="h-5 w-1/2 bg-slate-200 rounded mt-2"/>
                      </div>
                    ))}
                  </div>
                  <div className="h-2 w-3/4 bg-slate-100 rounded"/>
                  <div className="h-2 w-full bg-slate-100 rounded"/>
                </div>

                {/* Widget — absolutely positioned in corner */}
                <div className="absolute inset-0 pointer-events-auto" style={{overflow:'hidden'}}>
                  <div style={{
                    position:'absolute', bottom:0,
                    [cfg.position==='right'?'right':'left']: 0,
                    width:'100%', height:'100%',
                    display:'flex',
                    flexDirection:'column',
                    alignItems: cfg.position==='right' ? 'flex-end' : 'flex-start',
                    justifyContent:'flex-end',
                    padding:12,
                  }}>
                    <div style={{
                      width: Math.min(w - 24, 360),
                      height: Math.min(h - 24, 560),
                      borderRadius:20,
                      overflow:'hidden',
                      boxShadow:'0 24px 60px rgba(0,0,0,.2)',
                      border:'1px solid rgba(0,0,0,.07)',
                    }}>
                      <WebChatWidget
                        key={preview}
                        config={cfg}
                        previewOpen
                        previewScreen={preview}
                        embed
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-[10px] text-slate-400">Interact freely — state persists as you tweak settings</p>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Tab: Embed Code ───────────────────────────── */
function EmbedTab() {
  const { copied, copy } = useCopy()
  const [fw, setFw] = useState('HTML')

  const HTML = `<!-- ChatFlow Widget -->
<script>
  window.ChatFlowConfig = {
    botId: "${BOT_ID}",
    primaryColor: "#0066ff",
    position: "bottom-right",
    botName: "ChatFlow Bot",
    welcomeMessage: "Hi there! 👋 How can I help?",
    showRating: true,
    showArticles: true,
  };
</script>
<script src="https://cdn.chatflow.io/widget.js" async defer></script>`

  const REACT = `// components/ChatFlowWidget.jsx
import { useEffect } from 'react';

export default function ChatFlowWidget() {
  useEffect(() => {
    window.ChatFlowConfig = {
      botId: '${BOT_ID}',
      primaryColor: '#0066ff',
      position: 'bottom-right',
      botName: 'ChatFlow Bot',
    };
    const s = document.createElement('script');
    s.src = 'https://cdn.chatflow.io/widget.js';
    s.async = true;
    document.head.appendChild(s);
    return () => {
      document.head.removeChild(s);
      delete window.ChatFlowConfig;
    };
  }, []);
  return null;
}

// In your layout or _app.jsx:
// <ChatFlowWidget />`

  const WP = `// Add to your theme's functions.php
function chatflow_widget() {
  ?>
  <script>
    window.ChatFlowConfig = {
      botId: '${BOT_ID}',
      primaryColor: '#0066ff',
      position: 'bottom-right',
    };
  </script>
  <script src="https://cdn.chatflow.io/widget.js" async defer></script>
  <?php
}
add_action('wp_footer', 'chatflow_widget');`

  const WF = `<!-- Webflow: Project Settings → Custom Code → Footer Code -->
<script>
  window.ChatFlowConfig = {
    botId: "${BOT_ID}",
    primaryColor: "#0066ff",
    position: "bottom-right",
  };
</script>
<script src="https://cdn.chatflow.io/widget.js" async defer></script>`

  const MAP = { 'HTML':HTML, 'React / Next.js':REACT, 'WordPress':WP, 'Webflow':WF }
  const HINTS = {
    'HTML': 'Paste just before the closing </body> tag on every page where you want the widget.',
    'React / Next.js': 'Import and render <ChatFlowWidget /> once in your root layout for sitewide coverage.',
    'WordPress': "Add to your active theme's functions.php. The widget will appear on every page.",
    'Webflow': 'Go to Project Settings → Custom Code → Footer Code. Publish your site after saving.',
  }

  return (
    <div className="space-y-5">
      <div className="bg-white border border-surface-border rounded-xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold text-slate-800">Your Bot ID</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Identifies your widget in the embed code</p>
          </div>
          <div className="flex items-center gap-2 bg-slate-50 border border-surface-border rounded-lg px-3 py-2">
            <code className="text-xs font-mono text-slate-700">{BOT_ID}</code>
            <button onClick={()=>copy(BOT_ID,'botid')} className="p-1 rounded text-slate-400 hover:text-slate-600 transition-colors">
              {copied==='botid' ? <Check size={12} className="text-emerald-500"/> : <Copy size={12}/>}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="flex items-center gap-1 p-3 border-b border-surface-border overflow-x-auto">
          {FW.map(f=>(
            <button key={f} onClick={()=>setFw(f)}
              className={clsx('text-[11px] font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors',
                fw===f ? 'bg-primary text-white' : 'text-slate-500 hover:bg-surface-hover')}>
              {f}
            </button>
          ))}
        </div>
        <div className="relative">
          <pre className="text-[11px] font-mono p-5 overflow-x-auto leading-relaxed bg-slate-950 text-slate-100 m-0">
            <code>{MAP[fw]}</code>
          </pre>
          <button onClick={()=>copy(MAP[fw],fw)}
            className={clsx('absolute top-3 right-3 flex items-center gap-1.5 text-[10px] px-2.5 py-1.5 rounded-lg font-semibold transition-colors',
              copied===fw ? 'bg-emerald-500 text-white' : 'bg-white/10 text-slate-300 hover:bg-white/20')}>
            {copied===fw ? <><Check size={10}/>Copied!</> : <><Copy size={10}/>Copy</>}
          </button>
        </div>
        <div className="p-4 border-t border-surface-border bg-blue-50">
          <div className="flex gap-2">
            <Info size={13} className="text-blue-500 flex-shrink-0 mt-0.5"/>
            <p className="text-[11px] text-blue-700 leading-relaxed">{HINTS[fw]}</p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <div>
          <h3 className="text-sm font-bold text-slate-800">Domain Allowlist</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Widget loads only on these domains</p>
        </div>
        {['yourwebsite.com','staging.yourwebsite.com'].map((d,i)=>(
          <div key={i} className="flex items-center justify-between gap-3 py-2 border-b border-surface-border last:border-0">
            <div className="flex items-center gap-2">
              <Shield size={12} className="text-emerald-500"/>
              <code className="text-[11px] font-mono text-slate-700">{d}</code>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-semibold">Active</span>
              <button className="text-[11px] text-red-400 hover:text-red-600 font-medium">Remove</button>
            </div>
          </div>
        ))}
        <button className="btn-secondary text-xs flex items-center gap-1.5">+ Add Domain</button>
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-slate-800">Installation Status</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Detected on yourwebsite.com 2 minutes ago</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"/>
          <span className="text-xs font-semibold text-emerald-600">Verified</span>
          <button className="btn-ghost text-[11px] flex items-center gap-1.5 ml-2"><RefreshCw size={11}/>Re-check</button>
        </div>
      </div>
    </div>
  )
}

/* ─── Tab: Settings ─────────────────────────────── */
function SettingsTab() {
  const [routing, setRouting] = useState('flow')
  const [lead, setLead] = useState({enabled:true,name:true,email:true,phone:false})
  const [offline, setOffline] = useState('message')
  const [gdpr, setGdpr] = useState(false)
  const [notifs, setNotifs] = useState({newChat:true,idle:false,lead:true,abandoned:false})

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <div>
          <h3 className="text-sm font-bold text-slate-800">Chat Routing</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">How incoming web chats are handled</p>
        </div>
        {[
          {val:'flow', label:'Bot-first (Recommended)', desc:'Chatbot handles conversations using your Automation Flows. Escalates to live agents when needed.', icon:Zap},
          {val:'agent',label:'Direct to Agent',         desc:'Skip the bot. All web chats go directly to available live agents.',                             icon:Users},
        ].map(({val,label,desc,icon:Icon})=>(
          <button key={val} onClick={()=>setRouting(val)}
            className={clsx('w-full text-left flex gap-3 p-3 rounded-xl border-2 transition-all',
              routing===val ? 'border-primary bg-primary-50' : 'border-surface-border hover:border-slate-300')}>
            <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5',
              routing===val ? 'bg-primary text-white' : 'bg-slate-100 text-slate-500')}>
              <Icon size={15}/>
            </div>
            <div>
              <p className={clsx('text-xs font-bold', routing===val ? 'text-primary' : 'text-slate-800')}>{label}</p>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">{desc}</p>
            </div>
            <div className="ml-auto flex-shrink-0 mt-1">
              <div className={clsx('w-4 h-4 rounded-full border-2 flex items-center justify-center', routing===val ? 'border-primary' : 'border-slate-300')}>
                {routing===val && <div className="w-2 h-2 rounded-full bg-primary"/>}
              </div>
            </div>
          </button>
        ))}
        {routing==='flow' && (
          <div className="flex items-center gap-2 text-[11px] text-primary bg-primary-50 rounded-lg px-3 py-2">
            <Info size={12}/> Using your Automation Flows. <button className="underline font-semibold">Configure flows →</button>
          </div>
        )}
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Lead Capture</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Collect visitor info before chat starts</p>
          </div>
          <Toggle checked={lead.enabled} onChange={v=>setLead(p=>({...p,enabled:v}))}/>
        </div>
        {lead.enabled && (
          <div className="space-y-2 pt-2 border-t border-surface-border">
            {[{k:'name',l:'Full Name'},{k:'email',l:'Email Address'},{k:'phone',l:'Phone Number'}].map(({k,l})=>(
              <div key={k} className="flex items-center justify-between">
                <span className="text-[11px] text-slate-700">{l}</span>
                <Toggle size="sm" checked={lead[k]} onChange={v=>setLead(p=>({...p,[k]:v}))}/>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <div>
          <h3 className="text-sm font-bold text-slate-800">Offline Behavior</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">What visitors see when all agents are offline</p>
        </div>
        {[
          {val:'message',label:"Show offline message", desc:"Display a custom \"We're away\" message in the chat"},
          {val:'hide',   label:'Hide widget',          desc:'The launcher is hidden when your team is offline'},
          {val:'email',  label:'Collect email only',   desc:'Show a simple form to capture the visitor\'s email'},
        ].map(({val,label,desc})=>(
          <label key={val} className="flex items-start gap-3 cursor-pointer">
            <input type="radio" name="offline" value={val} checked={offline===val} onChange={()=>setOffline(val)} className="mt-0.5 accent-primary flex-shrink-0"/>
            <div>
              <p className="text-xs font-semibold text-slate-800">{label}</p>
              <p className="text-[10px] text-slate-400">{desc}</p>
            </div>
          </label>
        ))}
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800">GDPR Consent Notice</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Show consent message before the first chat</p>
          </div>
          <Toggle checked={gdpr} onChange={setGdpr}/>
        </div>
        {gdpr && (
          <div className="space-y-2 pt-2 border-t border-surface-border">
            <div>
              <p className="text-[11px] font-semibold text-slate-700 mb-1.5">Privacy Policy URL</p>
              <input className="input-field w-full text-sm" placeholder="https://yourwebsite.com/privacy"/>
            </div>
            <div>
              <p className="text-[11px] font-semibold text-slate-700 mb-1.5">Consent Message</p>
              <textarea rows={2} className="input-field w-full text-sm resize-none"
                defaultValue="By chatting with us, you agree to our Privacy Policy and the use of cookies."/>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white border border-surface-border rounded-xl p-4 space-y-3">
        <h3 className="text-sm font-bold text-slate-800">Agent Notifications</h3>
        {[
          {k:'newChat',   l:'New web chat started'},
          {k:'idle',      l:'Visitor idle for 2 minutes'},
          {k:'lead',      l:'Lead captured'},
          {k:'abandoned', l:'Conversation abandoned'},
        ].map(({k,l})=>(
          <div key={k} className="flex items-center justify-between">
            <span className="text-[11px] text-slate-700">{l}</span>
            <Toggle size="sm" checked={notifs[k]} onChange={v=>setNotifs(p=>({...p,[k]:v}))}/>
          </div>
        ))}
      </div>

      <button className="btn-primary text-sm flex items-center gap-2"><Check size={14}/>Save Settings</button>
    </div>
  )
}

/* ─── Main Page ─────────────────────────────────── */
export default function WebChat() {
  const [tab, setTab] = useState('overview')
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex-shrink-0 bg-white border-b border-surface-border px-5 pt-5 pb-0">
        <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
              <Globe size={20} className="text-blue-500"/>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Website Chatbot</h1>
              <p className="text-xs text-slate-500">Engage website visitors with an AI-powered chat widget</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"/>Widget Live
            </div>
            <button className="btn-secondary text-xs flex items-center gap-1.5"><ExternalLink size={12}/>Preview on site</button>
          </div>
        </div>
        <div className="flex gap-0.5 overflow-x-auto">
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              className={clsx('flex items-center gap-1.5 px-4 py-2.5 text-[12px] font-semibold whitespace-nowrap border-b-2 transition-colors',
                tab===t.id ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-800')}>
              <t.icon size={13}/>{t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 min-h-0">
        {tab==='overview' && <OverviewTab/>}
        {tab==='builder'  && <BuilderTab/>}
        {tab==='embed'    && <EmbedTab/>}
        {tab==='settings' && <SettingsTab/>}
      </div>
    </div>
  )
}
