import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, MessageSquare, Users, Radio, Workflow,
  FileText, ShoppingBag, BarChart2, Puzzle, PhoneCall, Settings,
  ChevronLeft, ChevronRight, Zap, Bell,
} from 'lucide-react'
import { NAV_ITEMS } from '../constants/navigation'
import { useApp } from '../context/AppContext'
import clsx from 'clsx'

const ICON_MAP = {
  LayoutDashboard, MessageSquare, Users, Radio, Workflow,
  FileText, ShoppingBag, BarChart2, Puzzle, PhoneCall, Settings,
}

const BADGE_COLORS = {
  blue:   'bg-primary-50 text-primary',
  green:  'bg-emerald-50 text-emerald-600',
  purple: 'bg-purple-50 text-purple-600',
  amber:  'bg-amber-50 text-amber-600',
}

export default function Sidebar() {
  const { sidebarCollapsed, toggleSidebar, user } = useApp()

  return (
    <aside className={clsx(
      'flex flex-col h-screen bg-white border-r border-surface-border transition-all duration-300 flex-shrink-0 z-20',
      sidebarCollapsed ? 'w-[60px]' : 'w-[220px]'
    )}>
      {/* Logo */}
      <div className={clsx(
        'flex items-center h-[60px] border-b border-surface-border px-4 flex-shrink-0',
        sidebarCollapsed ? 'justify-center' : 'justify-between'
      )}>
        {!sidebarCollapsed ? (
          <>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-btn">
                <Zap size={16} className="text-white" />
              </div>
              <div>
                <span className="font-bold text-slate-900 text-sm leading-none">ChatFlow</span>
                <p className="text-[10px] text-slate-400 leading-none mt-0.5">WhatsApp Platform</p>
              </div>
            </div>
            <button onClick={toggleSidebar} className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-surface-hover">
              <ChevronLeft size={15} />
            </button>
          </>
        ) : (
          <button onClick={toggleSidebar} className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-surface-hover">
            <div className="w-7 h-7 bg-primary rounded-md flex items-center justify-center">
              <Zap size={14} className="text-white" />
            </div>
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {NAV_ITEMS.map(item => {
          const Icon = ICON_MAP[item.icon]
          return (
            <div key={item.id}>
              {item.dividerBefore && <div className="my-2 border-t border-surface-border mx-1" />}
              <NavLink
                to={item.path}
                end={item.path === '/'}
                title={sidebarCollapsed ? item.label : undefined}
                className={({ isActive }) =>
                  clsx('nav-item', isActive && 'active', sidebarCollapsed && 'justify-center px-2')
                }
              >
                {Icon && <Icon size={17} className="flex-shrink-0" />}
                {!sidebarCollapsed && (
                  <>
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.badge && (
                      <span className={clsx('text-[10px] px-1.5 py-0.5 rounded-full font-semibold', BADGE_COLORS[item.badgeColor] || 'bg-slate-100 text-slate-500')}>
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            </div>
          )
        })}
      </nav>

      {/* User profile */}
      <div className="border-t border-surface-border p-3">
        {!sidebarCollapsed ? (
          <div className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface-hover cursor-pointer transition-colors">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {user.initials}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-800 truncate">{user.name}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.workspace.plan} Plan</p>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" title="Online" />
          </div>
        ) : (
          <div className="flex justify-center">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold cursor-pointer">
              {user.initials}
            </div>
          </div>
        )}
      </div>
    </aside>
  )
}
