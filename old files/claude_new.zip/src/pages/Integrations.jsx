import { useState } from 'react'
import { Search, CheckCircle2, Plus, X, Zap, Settings, ExternalLink } from 'lucide-react'
import { INTEGRATIONS, INTEGRATION_CATEGORIES } from '../constants/integrations'
import clsx from 'clsx'

function IntegrationModal({ integration, onClose }) {
  const [apiKey, setApiKey] = useState('')
  const [connecting, setConnecting] = useState(false)
  const [connected, setConnected] = useState(integration.status === 'connected')

  function handleConnect() {
    setConnecting(true)
    setTimeout(() => { setConnecting(false); setConnected(true) }, 1500)
  }

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white border border-surface-border rounded-2xl w-full max-w-md shadow-modal">
        <div className="flex items-center justify-between p-5 border-b border-surface-border">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
              style={{ background: `${integration.color}18` }}
            >
              {integration.icon}
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">{integration.name}</h3>
              <span className="text-xs text-slate-500">{integration.category}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-surface-hover transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-sm text-slate-600">{integration.description}</p>

          {connected ? (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200">
              <CheckCircle2 size={16} className="text-emerald-600 flex-shrink-0" />
              <span className="text-sm text-emerald-700 font-medium">Connected & Active</span>
            </div>
          ) : (
            <>
              <div className="form-group">
                <label className="label">API Key</label>
                <input
                  type="password"
                  className="input"
                  placeholder={`Enter your ${integration.name} API key`}
                  value={apiKey}
                  onChange={e => setApiKey(e.target.value)}
                />
              </div>
              {integration.category === 'Google' && (
                <button className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-white text-slate-800 text-sm font-medium border border-surface-border hover:bg-surface-hover transition-colors">
                  <span>🔵</span> Connect with Google OAuth
                </button>
              )}
            </>
          )}

          <div className="flex flex-wrap gap-2">
            {['Read', 'Write', 'Webhooks'].map(p => (
              <span key={p} className="badge badge-blue text-xs">
                ✓ {p}
              </span>
            ))}
          </div>
        </div>

        <div className="flex gap-2 p-5 border-t border-surface-border">
          {connected ? (
            <>
              <button className="btn-secondary flex-1 justify-center">
                <Settings size={14} /> Configure
              </button>
              <button className="btn-secondary flex-1 justify-center text-red-400 hover:text-red-500">
                Disconnect
              </button>
            </>
          ) : (
            <>
              <button onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
              <button onClick={handleConnect} disabled={connecting} className="btn-primary flex-1 justify-center">
                {connecting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Connecting...
                  </span>
                ) : (
                  <><Zap size={14} /> Connect</>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function IntegrationCard({ integration, onSelect }) {
  return (
    <div
      className="card p-4 hover:border-primary/30 transition-all cursor-pointer group relative overflow-hidden"
      onClick={() => onSelect(integration)}
    >
      {integration.status === 'connected' && (
        <div className="absolute top-2 right-2">
          <span className="badge badge-green text-[10px]">
            <CheckCircle2 size={9} /> Active
          </span>
        </div>
      )}
      {integration.tier === 'enterprise' && (
        <div className="absolute top-2 right-2">
          <span className="badge badge-purple text-[10px]">Enterprise</span>
        </div>
      )}

      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl mb-3"
        style={{ background: `${integration.color}18` }}
      >
        {integration.icon}
      </div>

      <h3 className="font-semibold text-slate-900 text-sm group-hover:text-primary transition-colors">
        {integration.name}
      </h3>
      <span className="text-xs text-slate-400 font-medium">{integration.category}</span>
      <p className="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-2">{integration.description}</p>

      <button className={clsx(
        'mt-3 w-full py-1.5 rounded-lg text-xs font-medium transition-colors border',
        integration.status === 'connected'
          ? 'bg-surface border-surface-border text-slate-600 hover:bg-surface-hover'
          : 'bg-primary-50 border-primary/20 text-primary hover:bg-primary-100'
      )}>
        {integration.status === 'connected' ? 'Manage' : 'Connect'}
      </button>
    </div>
  )
}

export default function Integrations() {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [selected, setSelected] = useState(null)

  const filtered = INTEGRATIONS.filter(i => {
    const matchCat = category === 'All' || i.category === category
    const matchSearch = i.name.toLowerCase().includes(search.toLowerCase()) ||
                        i.description.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const connected = filtered.filter(i => i.status === 'connected')
  const available = filtered.filter(i => i.status !== 'connected')

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Integrations</h1>
          <p className="text-xs text-slate-500 mt-0.5">Connect your favourite tools — plug and play, no code required.</p>
        </div>
        <button className="btn-secondary">
          <Plus size={14} /> Request Integration
        </button>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Integrations', value: INTEGRATIONS.length + '+', color: 'text-primary' },
          { label: 'Connected',          value: INTEGRATIONS.filter(i => i.status === 'connected').length, color: 'text-emerald-600' },
          { label: 'Categories',         value: INTEGRATION_CATEGORIES.length - 1, color: 'text-purple-600' },
        ].map(s => (
          <div key={s.label} className="stat-card text-center">
            <p className={clsx('text-2xl font-bold', s.color)}>{s.value}</p>
            <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Search + Filters */}
      <div className="card p-4">
        <div className="relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            className="input pl-9"
            placeholder="Search integrations..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {INTEGRATION_CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={clsx(
                'px-3 py-1 rounded-full text-xs font-medium transition-colors border',
                category === cat
                  ? 'bg-primary text-white border-primary'
                  : 'bg-white text-slate-600 border-surface-border hover:border-primary/40'
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Connected */}
      {connected.length > 0 && (
        <div>
          <h3 className="section-title mb-3">Connected ({connected.length})</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {connected.map(i => (
              <IntegrationCard key={i.id} integration={i} onSelect={setSelected} />
            ))}
          </div>
        </div>
      )}

      {/* Available */}
      {available.length > 0 && (
        <div>
          <h3 className="section-title mb-3">Available ({available.length})</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {available.map(i => (
              <IntegrationCard key={i.id} integration={i} onSelect={setSelected} />
            ))}
          </div>
        </div>
      )}

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <div className="text-4xl mb-3">🔍</div>
          <p className="text-slate-500 font-medium">No integrations found</p>
          <p className="text-slate-400 text-sm mt-1">Try a different search or category</p>
        </div>
      )}

      {selected && (
        <IntegrationModal integration={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  )
}
