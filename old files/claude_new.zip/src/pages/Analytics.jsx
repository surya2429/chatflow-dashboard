import { useState, useMemo } from 'react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, RadialBarChart, RadialBar,
} from 'recharts'
import {
  MessageSquare, TrendingUp, TrendingDown, Clock, CheckCircle2, Users, Bot,
  IndianRupee, CalendarCheck, Download, Send, AlertCircle, ThumbsUp,
  PhoneCall, Star, Zap, ShieldAlert, BarChart2, RefreshCw, ArrowUpRight, ArrowDownRight,
  UserPlus, Globe, Smartphone, MousePointer2, Activity, GitBranch, XCircle, Layers,
  ChevronDown, ChevronUp, User, LayoutDashboard,
} from 'lucide-react'
import clsx from 'clsx'
import { subDays, format } from 'date-fns'

/* ─── MOCK DATA ───────────────────────────────────────────────────────────── */
const today = new Date()
const makeDays = (n) => Array.from({ length: n }, (_, i) => format(subDays(today, n - 1 - i), 'MMM d'))

const DAYS_30 = makeDays(30)
const DAYS_7  = makeDays(7)

const rand = (min, max) => Math.floor(min + Math.random() * (max - min))

const DAILY_30 = DAYS_30.map(date => ({
  date,
  incoming:      rand(200, 600),
  outgoing:      rand(300, 700),
  resolved:      rand(80,  200),
  botHandled:    rand(150, 400),
  escalated:     rand(10,  60),
  leads:         rand(5,   30),
  appointments:  rand(2,   10),
  sent:          rand(400, 900),
  delivered:     rand(380, 870),
  read:          rand(200, 500),
  failed:        rand(2,   20),
}))

const DAILY_7 = DAYS_7.map(date => ({
  date,
  incoming:      rand(200, 600),
  outgoing:      rand(300, 700),
  resolved:      rand(80,  200),
  botHandled:    rand(150, 400),
  escalated:     rand(10,  60),
  sent:          rand(400, 900),
  delivered:     rand(380, 870),
  read:          rand(200, 500),
  failed:        rand(2,   20),
}))

const HOURLY = Array.from({ length: 24 }, (_, i) => ({
  hour: `${String(i).padStart(2, '0')}:00`,
  messages: rand(10, i >= 8 && i <= 20 ? 280 : 40),
}))

const TEMPLATE_STATS = [
  { name: 'order_confirmation',    category: 'Utility',    sent: 8241, delivered: 98.1, read: 81.4, clicked: 42.3, replied: 12.1, failed: 1.9, blocked: 0.4 },
  { name: 'flash_sale_oct',        category: 'Marketing',  sent: 5120, delivered: 95.3, read: 74.2, clicked: 31.8, replied: 8.4,  failed: 4.7, blocked: 1.2 },
  { name: 'welcome_new_user',      category: 'Marketing',  sent: 3890, delivered: 97.6, read: 68.9, clicked: 28.1, replied: 6.2,  failed: 2.4, blocked: 0.7 },
  { name: 'appointment_reminder',  category: 'Utility',    sent: 2104, delivered: 99.2, read: 88.7, clicked: 61.4, replied: 31.2, failed: 0.8, blocked: 0.1 },
  { name: 'otp_verification',      category: 'Auth',       sent: 1840, delivered: 99.7, read: 96.1, clicked: 0,    replied: 0,    failed: 0.3, blocked: 0.0 },
  { name: 'cart_abandonment',      category: 'Marketing',  sent: 1540, delivered: 94.8, read: 61.2, clicked: 38.7, replied: 9.1,  failed: 5.2, blocked: 2.1 },
]

const AGENT_STATS = [
  { name: 'Rahul Mehta',  avatar: 'RM', color: '#8B5CF6', handled: 124, resolved: 111, avgFirst: '1m 48s', avgResolution: '14m 22s', csat: 4.8, online: true  },
  { name: 'Priya Das',    avatar: 'PD', color: '#EC4899', handled: 98,  resolved: 87,  avgFirst: '2m 12s', avgResolution: '18m 05s', csat: 4.6, online: true  },
  { name: 'Aryan Kapoor', avatar: 'AK', color: '#F59E0B', handled: 76,  resolved: 68,  avgFirst: '3m 44s', avgResolution: '22m 31s', csat: 4.3, online: true  },
  { name: 'Sunita Rao',   avatar: 'SR', color: '#14B8A6', handled: 61,  resolved: 54,  avgFirst: '2m 01s', avgResolution: '16m 48s', csat: 4.7, online: false },
]

const RESOLUTION_PIE = [
  { name: 'Bot Resolved',   value: 62, color: '#0066ff' },
  { name: 'Agent Resolved', value: 28, color: '#8B5CF6' },
  { name: 'Open',           value: 6,  color: '#F59E0B' },
  { name: 'Abandoned',      value: 4,  color: '#F87171' },
]

const CSAT_DIST = [
  { rating: '⭐⭐⭐⭐⭐ 5 stars', value: 58, color: '#22C55E' },
  { rating: '⭐⭐⭐⭐  4 stars', value: 24, color: '#86EFAC' },
  { rating: '⭐⭐⭐   3 stars', value: 11, color: '#FCD34D' },
  { rating: '⭐⭐    2 stars', value: 4,  color: '#FB923C' },
  { rating: '⭐     1 star',  value: 3,  color: '#F87171' },
]

const BROADCAST_CAMPAIGNS = [
  { name: 'Flash Sale — Apr',    sent: 5120, delivered: 4881, read: 3611, clicked: 1547, replied: 430, failed: 239, date: 'Apr 15' },
  { name: 'Diwali Offer',        sent: 4200, delivered: 3990, read: 2772, clicked: 1050, replied: 294, failed: 210, date: 'Mar 28' },
  { name: 'New Product Launch',  sent: 3100, delivered: 2945, read: 1913, clicked: 744,  replied: 186, failed: 155, date: 'Mar 14' },
  { name: 'Reengagement Blast',  sent: 2800, delivered: 2660, read: 1596, clicked: 504,  replied: 112, failed: 140, date: 'Feb 28' },
  { name: 'Weekly Newsletter',   sent: 1900, delivered: 1843, read: 1290, clicked: 386,  replied: 95,  failed: 57,  date: 'Feb 14' },
]

const AI_DAILY = makeDays(14).map(date => ({
  date,
  tokens:   rand(30000, 90000),
  requests: rand(200,   600),
  cost:     parseFloat((rand(8, 25) * 0.1).toFixed(2)),
}))

// ── Summary / Dashboard mock data ──────────────────────────────────────────────
const CONV_TREND = makeDays(14).map(date => ({
  date,
  open:       rand(80,  220),
  resolved:   rand(120, 340),
  botSession: rand(60,  180),
}))

const AGENT_CONV_DATA = [
  { name: 'Rahul Mehta',  conversations: 124, color: '#8B5CF6' },
  { name: 'Priya Das',    conversations: 98,  color: '#EC4899' },
  { name: 'Aryan Kapoor', conversations: 76,  color: '#F59E0B' },
  { name: 'Sunita Rao',   conversations: 61,  color: '#14B8A6' },
  { name: 'Vikram Singh', conversations: 44,  color: '#3B82F6' },
]

const ASSIGNED_PIE = [
  { name: 'Assigned',   value: 68, color: '#6366f1' },
  { name: 'Unassigned', value: 32, color: '#e5e7eb' },
]

const BOT_FLOW_DATA = [
  { node: 'Welcome',         sessions: 1842 },
  { node: 'Main Menu',       sessions: 1726 },
  { node: 'Product Inquiry', sessions: 984  },
  { node: 'Support',         sessions: 712  },
  { node: 'Order Track',     sessions: 538  },
  { node: 'Payment',         sessions: 291  },
]

const TOP_DROP_CARDS = [
  { node: 'Ask Phone Number', drops: 284, pct: 15.4, color: '#ef4444' },
  { node: 'Payment Step',     drops: 196, pct: 10.6, color: '#f97316' },
  { node: 'Form — Address',   drops: 143, pct:  7.8, color: '#f59e0b' },
  { node: 'Schedule Picker',  drops: 88,  pct:  4.8, color: '#eab308' },
  { node: 'File Upload',      drops: 61,  pct:  3.3, color: '#84cc16' },
]

/* ─── HELPERS ─────────────────────────────────────────────────────────────── */
const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white border border-surface-border rounded-lg p-3 shadow-modal text-xs">
      <p className="font-semibold text-slate-700 mb-1.5">{label}</p>
      {payload.map(p => (
        <div key={p.name} className="flex items-center gap-2 mt-0.5">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-slate-500">{p.name}:</span>
          <span className="font-bold text-slate-800">{typeof p.value === 'number' ? p.value.toLocaleString() : p.value}</span>
        </div>
      ))}
    </div>
  )
}

function Trend({ value, suffix = '%', invert = false }) {
  const up = invert ? value < 0 : value >= 0
  return (
    <span className={clsx('inline-flex items-center gap-0.5 text-xs font-semibold', up ? 'text-emerald-600' : 'text-red-500')}>
      {up ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
      {Math.abs(value)}{suffix}
    </span>
  )
}

function StatCard({ label, value, icon: Icon, color, iconBg, trend, trendLabel, invert = false }) {
  return (
    <div className="card p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <div className={clsx('w-9 h-9 rounded-xl flex items-center justify-center', iconBg || 'bg-primary-50')}>
          <Icon size={16} className={color || 'text-primary'} />
        </div>
        {trend !== undefined && <Trend value={trend} invert={invert} />}
      </div>
      <div>
        <p className="text-2xl font-bold text-slate-900 leading-tight">{value}</p>
        <p className="text-xs text-slate-500 mt-0.5">{label}</p>
        {trendLabel && <p className="text-xs text-slate-400 mt-1">{trendLabel}</p>}
      </div>
    </div>
  )
}

function SectionCard({ title, action, children }) {
  return (
    <div className="card overflow-hidden">
      <div className="px-5 py-4 border-b border-surface-border flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-800">{title}</h3>
        {action}
      </div>
      <div className="p-5">{children}</div>
    </div>
  )
}

function PctBar({ value, color = 'bg-primary', total = 100 }) {
  return (
    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
      <div className={clsx('h-full rounded-full', color)} style={{ width: `${(value / total) * 100}%` }} />
    </div>
  )
}

/* ─── SUMMARY TAB (Gallabox Dashboard) ───────────────────────────────────── */
function SummaryTab() {
  // ── KPI values ──────────────────────────────────────────────────────────────
  const kpiCards = [
    // Row 1 — Conversations
    { label: 'Open Conversations',           value: '1,284',  icon: MessageSquare, iconBg: 'bg-blue-50',    color: 'text-blue-600',    trend: 8.4,  trendLabel: 'active right now' },
    { label: 'Resolved Conversations',       value: '3,921',  icon: CheckCircle2,  iconBg: 'bg-emerald-50', color: 'text-emerald-600', trend: 14.2, trendLabel: 'this period' },
    { label: 'New Contacts',                 value: '642',    icon: UserPlus,      iconBg: 'bg-purple-50',  color: 'text-purple-600',  trend: 22.1, trendLabel: 'added this period' },
    { label: 'Active Conversations',         value: '387',    icon: Activity,      iconBg: 'bg-cyan-50',    color: 'text-cyan-600',    trend: 5.3,  trendLabel: 'currently active' },
    // Row 2 — WhatsApp breakdown
    { label: 'WhatsApp Business Initiated',  value: '2,104',  icon: Smartphone,    iconBg: 'bg-green-50',   color: 'text-green-600',   trend: 11.6, trendLabel: 'sent by your business' },
    { label: 'WhatsApp User Initiated',      value: '1,817',  icon: Users,         iconBg: 'bg-indigo-50',  color: 'text-indigo-600',  trend: 7.9,  trendLabel: 'started by users' },
    { label: 'WhatsApp Free Entry Points',   value: '312',    icon: MousePointer2, iconBg: 'bg-amber-50',   color: 'text-amber-600',   trend: 18.4, trendLabel: 'click-to-WhatsApp' },
    { label: 'WhatsApp Session Messages',    value: '18,420', icon: MessageSquare, iconBg: 'bg-sky-50',     color: 'text-sky-600',     trend: 9.2,  trendLabel: 'exchanged this period' },
    { label: 'WhatsApp Template Messages',   value: '5,290',  icon: Send,          iconBg: 'bg-violet-50',  color: 'text-violet-600',  trend: 6.1,  trendLabel: 'sent via templates' },
    { label: 'Web Conversations',            value: '198',    icon: Globe,         iconBg: 'bg-rose-50',    color: 'text-rose-600',    trend: 3.8,  trendLabel: 'from web channel' },
  ]

  return (
    <div className="space-y-6">

      {/* ── SECTION 1: Summary KPIs ─────────────────────────────────────────── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 bg-indigo-500 rounded-full"/>
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Summary</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {kpiCards.map(k => (
            <StatCard key={k.label} label={k.label} value={k.value}
              icon={k.icon} iconBg={k.iconBg} color={k.color}
              trend={k.trend} trendLabel={k.trendLabel}/>
          ))}
        </div>
      </div>

      {/* ── SECTION 2: Conversation Analytics ──────────────────────────────── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 bg-blue-500 rounded-full"/>
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Conversation Analytics</h2>
        </div>

        {/* FRT + TAT summary row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          <StatCard label="Total Conversations" value="5,205"   icon={MessageSquare} iconBg="bg-blue-50"    color="text-blue-600"    trend={12.4} trendLabel="open + resolved"/>
          <StatCard label="First Response Time (FRT)" value="1h 52m"  icon={Zap}          iconBg="bg-purple-50"  color="text-purple-600"  trend={-8.1} trendLabel="avg time to first reply"/>
          <StatCard label="Turnaround Time (TAT)"     value="4h 18m"  icon={Clock}        iconBg="bg-cyan-50"    color="text-cyan-600"    trend={-5.3} trendLabel="avg full resolution time"/>
          <StatCard label="CSAT Score"                value="4.6 / 5" icon={Star}         iconBg="bg-emerald-50" color="text-emerald-600" trend={0.2}  trendLabel="91% positive"/>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Conversation Trend */}
          <div className="md:col-span-2">
            <SectionCard title="Conversations Over Time">
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={CONV_TREND} margin={{ top:5, right:5, left:-20, bottom:0 }}>
                  <defs>
                    <linearGradient id="gOpen" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#3B82F6" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="gRes" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#10b981" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false}/>
                  <XAxis dataKey="date" tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={2}/>
                  <YAxis tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
                  <Tooltip content={<CustomTooltip/>}/>
                  <Legend wrapperStyle={{ fontSize:'11px', paddingTop:'10px' }}/>
                  <Area type="monotone" dataKey="open"     name="Open"     stroke="#3B82F6" strokeWidth={2} fill="url(#gOpen)" dot={false}/>
                  <Area type="monotone" dataKey="resolved" name="Resolved" stroke="#10b981" strokeWidth={2} fill="url(#gRes)"  dot={false}/>
                </AreaChart>
              </ResponsiveContainer>
            </SectionCard>
          </div>

          {/* Active by Status — Donut */}
          <SectionCard title="Active Conversations by Status">
            <div className="flex flex-col items-center">
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie data={ASSIGNED_PIE} cx="50%" cy="50%" innerRadius={46} outerRadius={68}
                    dataKey="value" paddingAngle={3}>
                    {ASSIGNED_PIE.map((e,i) => <Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip formatter={v=>`${v}%`} contentStyle={{ background:'#fff', border:'1px solid #e2e8f0', borderRadius:'8px', fontSize:'12px' }}/>
                </PieChart>
              </ResponsiveContainer>
              <div className="w-full space-y-2 mt-1">
                {ASSIGNED_PIE.map(d=>(
                  <div key={d.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background:d.color }}/>
                    <span className="text-xs text-slate-500 flex-1">{d.name}</span>
                    <span className="text-xs font-semibold text-slate-800">{d.value}%</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 w-full text-center">
                <div className="text-2xl font-bold text-slate-800">387</div>
                <div className="text-xs text-slate-400">total active</div>
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Active Conversations by Agent — Bar */}
        <SectionCard title="Active Conversations by Agents">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={AGENT_CONV_DATA} layout="vertical" margin={{ top:0, right:20, left:90, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false}/>
              <XAxis type="number" tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
              <YAxis type="category" dataKey="name" tick={{ fontSize:11, fill:'#64748b' }} tickLine={false} axisLine={false} width={90}/>
              <Tooltip content={<CustomTooltip/>}/>
              <Bar dataKey="conversations" name="Conversations" radius={[0,5,5,0]}>
                {AGENT_CONV_DATA.map((e,i) => <Cell key={i} fill={e.color}/>)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      {/* ── SECTION 3: Bot Analytics ────────────────────────────────────────── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 bg-violet-500 rounded-full"/>
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Bot Analytics</h2>
        </div>

        {/* Bot KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
          <StatCard label="Bot Sessions"          value="1,842"   icon={Bot}         iconBg="bg-violet-50"  color="text-violet-600"  trend={18.3} trendLabel="total interactions"/>
          <StatCard label="Completed Sessions"     value="1,284"   icon={CheckCircle2}iconBg="bg-emerald-50" color="text-emerald-600" trend={9.1}  trendLabel="69.7% completion rate"/>
          <StatCard label="Dropped Sessions"       value="312"     icon={XCircle}     iconBg="bg-red-50"     color="text-red-500"     trend={-4.2} trendLabel="users who left early" invert/>
          <StatCard label="Flow Sessions"          value="1,726"   icon={GitBranch}   iconBg="bg-blue-50"    color="text-blue-600"    trend={14.8} trendLabel="passed through a flow node"/>
          <StatCard label="Avg Session Length"     value="3m 24s"  icon={Clock}       iconBg="bg-amber-50"   color="text-amber-600"   trend={2.1}  trendLabel="per interaction"/>
          <StatCard label="Containment Rate"       value="69.7%"   icon={Layers}      iconBg="bg-cyan-50"    color="text-cyan-600"    trend={3.4}  trendLabel="resolved without agent"/>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Bot Flow Node Activity */}
          <SectionCard title="Flow Sessions by Node">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={BOT_FLOW_DATA} layout="vertical" margin={{ top:0, right:20, left:100, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false}/>
                <XAxis type="number" tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
                <YAxis type="category" dataKey="node" tick={{ fontSize:11, fill:'#64748b' }} tickLine={false} axisLine={false} width={100}/>
                <Tooltip content={<CustomTooltip/>}/>
                <Bar dataKey="sessions" name="Sessions" fill="#8b5cf6" radius={[0,5,5,0]}/>
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>

          {/* Top Drop Cards */}
          <SectionCard title="Top Drop Cards">
            <div className="space-y-3">
              {TOP_DROP_CARDS.map((d,i) => (
                <div key={d.node}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 w-4">#{i+1}</span>
                      <span className="text-xs font-medium text-slate-700">{d.node}</span>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs font-semibold text-slate-600">{d.drops} drops</span>
                      <span className="text-xs font-bold" style={{ color: d.color }}>{d.pct}%</span>
                    </div>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width:`${d.pct * 4}%`, background: d.color }}/>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-100">
              <div className="flex items-start gap-2">
                <AlertCircle size={13} className="text-red-500 flex-shrink-0 mt-0.5"/>
                <p className="text-xs text-red-600">
                  <span className="font-semibold">312 sessions dropped</span> — "Ask Phone Number" has the highest abandonment. Consider making it optional.
                </p>
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Bot Session trend */}
        <SectionCard title="Bot Sessions Over Time">
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={CONV_TREND} margin={{ top:5, right:5, left:-20, bottom:0 }}>
              <defs>
                <linearGradient id="gBot2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#8b5cf6" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false}/>
              <XAxis dataKey="date" tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false} interval={2}/>
              <YAxis tick={{ fontSize:10, fill:'#94a3b8' }} tickLine={false} axisLine={false}/>
              <Tooltip content={<CustomTooltip/>}/>
              <Legend wrapperStyle={{ fontSize:'11px', paddingTop:'10px' }}/>
              <Area type="monotone" dataKey="botSession" name="Bot Sessions" stroke="#8b5cf6" strokeWidth={2} fill="url(#gBot2)" dot={false}/>
            </AreaChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>
    </div>
  )
}

/* ─── CONVERSATIONS TAB ───────────────────────────────────────────────────── */
function ConversationsTab({ data }) {
  const totalConvs    = 4291
  const botHandled    = 2661
  const agentHandled  = 1202
  const containment   = Math.round((botHandled / totalConvs) * 100)
  const escalation    = Math.round((agentHandled / totalConvs) * 100)

  return (
    <div className="space-y-5">
      {/* KPI Row 1 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Total Conversations" value="4,291"  icon={MessageSquare} iconBg="bg-blue-50"    color="text-blue-600"    trend={12.4}  trendLabel="vs last period" />
        <StatCard label="Bot Containment"     value={containment + '%'}  icon={Bot}          iconBg="bg-primary-50" color="text-primary"     trend={3.2}   trendLabel={botHandled.toLocaleString() + ' handled by bot'} />
        <StatCard label="Escalation Rate"     value={escalation + '%'}   icon={AlertCircle}  iconBg="bg-amber-50"   color="text-amber-600"   trend={-1.8}  invert trendLabel={agentHandled.toLocaleString() + ' to live agent'} />
        <StatCard label="Avg First Response"  value="1m 52s" icon={Zap}          iconBg="bg-purple-50"  color="text-purple-600"  trend={-8.1}  trendLabel="faster than last period" />
        <StatCard label="Avg Resolution Time" value="18m 4s" icon={Clock}        iconBg="bg-cyan-50"    color="text-cyan-600"    trend={-5.3}  trendLabel="vs 19m 8s last period" />
        <StatCard label="CSAT Score"          value="4.6 / 5" icon={Star}         iconBg="bg-emerald-50" color="text-emerald-600" trend={0.2}   trendLabel="91% positive ratings" />
      </div>

      {/* Message Volume Chart */}
      <SectionCard title="Message Volume">
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="gIn" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gOut" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0066ff" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#0066ff" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gBot" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={Math.floor(data.length / 6)} />
            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
            <Area type="monotone" dataKey="incoming"   name="Incoming"    stroke="#3B82F6" strokeWidth={2} fill="url(#gIn)"  dot={false} />
            <Area type="monotone" dataKey="outgoing"   name="Outgoing"    stroke="#0066ff" strokeWidth={2} fill="url(#gOut)" dot={false} />
            <Area type="monotone" dataKey="botHandled" name="Bot Handled" stroke="#8B5CF6" strokeWidth={2} fill="url(#gBot)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </SectionCard>

      {/* Resolution + CSAT + Hourly */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Resolution Breakdown */}
        <SectionCard title="Resolution Breakdown">
          <div className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={150}>
              <PieChart>
                <Pie data={RESOLUTION_PIE} cx="50%" cy="50%" innerRadius={45} outerRadius={68} dataKey="value" paddingAngle={2}>
                  {RESOLUTION_PIE.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip formatter={(v) => `${v}%`} contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="w-full space-y-2 mt-1">
              {RESOLUTION_PIE.map(d => (
                <div key={d.name} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  <span className="text-xs text-slate-500 flex-1">{d.name}</span>
                  <span className="text-xs font-semibold text-slate-800">{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </SectionCard>

        {/* CSAT Distribution */}
        <SectionCard title="CSAT Distribution">
          <div className="space-y-3">
            {CSAT_DIST.map(d => (
              <div key={d.rating}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600">{d.rating}</span>
                  <span className="font-semibold text-slate-800">{d.value}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${d.value}%`, background: d.color }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* Hourly Activity */}
        <SectionCard title="Messages by Hour (Today)">
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={HOURLY} margin={{ top: 5, right: 0, left: -28, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="hour" tick={{ fontSize: 8, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={3} />
              <YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="messages" name="Messages" fill="#0066ff" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      {/* Agent Performance Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-800">Agent Performance</h3>
          <button className="btn-ghost text-xs gap-1"><Download size={12} /> Export</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                {['Agent', 'Status', 'Handled', 'Resolved', 'Res. Rate', 'Avg First Reply', 'Avg Resolution', 'CSAT'].map(h => (
                  <th key={h} className="table-header text-left">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {AGENT_STATS.map(a => (
                <tr key={a.name} className="table-row">
                  <td className="table-cell">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ background: a.color }}>{a.avatar}</div>
                      <span className="font-medium text-slate-800 text-sm">{a.name}</span>
                    </div>
                  </td>
                  <td className="table-cell">
                    <span className={clsx('inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium', a.online ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500')}>
                      <span className={clsx('w-1.5 h-1.5 rounded-full', a.online ? 'bg-emerald-500' : 'bg-slate-400')} />
                      {a.online ? 'Online' : 'Offline'}
                    </span>
                  </td>
                  <td className="table-cell font-medium">{a.handled}</td>
                  <td className="table-cell">{a.resolved}</td>
                  <td className="table-cell">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-700">{Math.round((a.resolved / a.handled) * 100)}%</span>
                      <div className="flex-1 min-w-[40px]"><PctBar value={a.resolved} total={a.handled} color="bg-emerald-400" /></div>
                    </div>
                  </td>
                  <td className="table-cell text-slate-600">{a.avgFirst}</td>
                  <td className="table-cell text-slate-600">{a.avgResolution}</td>
                  <td className="table-cell">
                    <div className="flex items-center gap-1">
                      <Star size={11} className="text-amber-400 fill-amber-400" />
                      <span className="font-semibold text-slate-800">{a.csat}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

/* ─── BROADCASTS TAB ──────────────────────────────────────────────────────── */
function BroadcastsTab({ data }) {
  const totals = BROADCAST_CAMPAIGNS.reduce((acc, c) => ({
    sent: acc.sent + c.sent,
    delivered: acc.delivered + c.delivered,
    read: acc.read + c.read,
    clicked: acc.clicked + c.clicked,
    replied: acc.replied + c.replied,
    failed: acc.failed + c.failed,
  }), { sent: 0, delivered: 0, read: 0, clicked: 0, replied: 0, failed: 0 })

  const deliveryRate = ((totals.delivered / totals.sent) * 100).toFixed(1)
  const readRate     = ((totals.read / totals.delivered) * 100).toFixed(1)
  const ctr          = ((totals.clicked / totals.delivered) * 100).toFixed(1)
  const replyRate    = ((totals.replied / totals.delivered) * 100).toFixed(1)
  const failRate     = ((totals.failed / totals.sent) * 100).toFixed(1)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Total Sent"     value={totals.sent.toLocaleString()}      icon={Send}          iconBg="bg-blue-50"    color="text-blue-600"    trend={18.2} trendLabel="messages sent" />
        <StatCard label="Delivered"      value={deliveryRate + '%'}                 icon={CheckCircle2}  iconBg="bg-emerald-50" color="text-emerald-600" trend={0.4}  trendLabel={totals.delivered.toLocaleString() + ' delivered'} />
        <StatCard label="Read Rate"      value={readRate + '%'}                     icon={MessageSquare} iconBg="bg-primary-50" color="text-primary"     trend={2.1}  trendLabel={totals.read.toLocaleString() + ' read'} />
        <StatCard label="Click-Through"  value={ctr + '%'}                          icon={TrendingUp}    iconBg="bg-purple-50"  color="text-purple-600"  trend={1.3}  trendLabel={totals.clicked.toLocaleString() + ' clicked'} />
        <StatCard label="Reply Rate"     value={replyRate + '%'}                    icon={RefreshCw}     iconBg="bg-cyan-50"    color="text-cyan-600"    trend={0.8}  trendLabel={totals.replied.toLocaleString() + ' replied'} />
        <StatCard label="Failed"         value={failRate + '%'}                     icon={ShieldAlert}   iconBg="bg-red-50"     color="text-red-500"     trend={-0.3} invert trendLabel={totals.failed.toLocaleString() + ' undelivered'} />
      </div>

      {/* Delivery funnel */}
      <SectionCard title="Broadcast Delivery Funnel">
        <div className="grid grid-cols-5 gap-2 text-center">
          {[
            { label: 'Sent',      value: totals.sent,      pct: 100,  color: 'bg-blue-500' },
            { label: 'Delivered', value: totals.delivered, pct: parseFloat(deliveryRate), color: 'bg-emerald-500' },
            { label: 'Read',      value: totals.read,      pct: parseFloat(readRate),     color: 'bg-primary' },
            { label: 'Clicked',   value: totals.clicked,   pct: parseFloat(ctr),          color: 'bg-purple-500' },
            { label: 'Replied',   value: totals.replied,   pct: parseFloat(replyRate),    color: 'bg-cyan-500' },
          ].map((f, i, arr) => (
            <div key={f.label} className="flex flex-col items-center gap-2">
              <div className={clsx('w-full rounded-xl flex items-end justify-center text-white text-xs font-bold', f.color)}
                style={{ height: 100, paddingBottom: 8, opacity: 0.85 + i * 0.03 }}>
                {f.pct}%
              </div>
              <div className="text-sm font-bold text-slate-800">{f.value.toLocaleString()}</div>
              <div className="text-xs text-slate-500">{f.label}</div>
              {i < arr.length - 1 && (
                <div className="absolute hidden" />
              )}
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Trend chart */}
      <SectionCard title="Broadcast Performance Trend">
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={Math.floor(data.length / 6)} />
            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
            <Line type="monotone" dataKey="sent"      name="Sent"      stroke="#3B82F6" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="delivered" name="Delivered" stroke="#22C55E" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="read"      name="Read"      stroke="#0066ff" strokeWidth={2} dot={false} strokeDasharray="4 2" />
          </LineChart>
        </ResponsiveContainer>
      </SectionCard>

      {/* Campaign Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-800">Campaign Performance</h3>
          <button className="btn-ghost text-xs gap-1"><Download size={12} /> Export</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                {['Campaign', 'Date', 'Sent', 'Delivered', 'Read', 'Clicked', 'Replied', 'Failed'].map(h => (
                  <th key={h} className="table-header text-left">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {BROADCAST_CAMPAIGNS.map(c => (
                <tr key={c.name} className="table-row">
                  <td className="table-cell font-medium text-slate-800">{c.name}</td>
                  <td className="table-cell text-slate-500 text-xs">{c.date}</td>
                  <td className="table-cell">{c.sent.toLocaleString()}</td>
                  <td className="table-cell">
                    <span className="text-emerald-600 font-medium">{((c.delivered / c.sent) * 100).toFixed(1)}%</span>
                    <span className="text-slate-400 text-xs ml-1">({c.delivered.toLocaleString()})</span>
                  </td>
                  <td className="table-cell">
                    <span className="text-primary font-medium">{((c.read / c.delivered) * 100).toFixed(1)}%</span>
                  </td>
                  <td className="table-cell">
                    <span className="text-purple-600 font-medium">{((c.clicked / c.delivered) * 100).toFixed(1)}%</span>
                  </td>
                  <td className="table-cell">
                    <span className="text-cyan-600 font-medium">{((c.replied / c.delivered) * 100).toFixed(1)}%</span>
                  </td>
                  <td className="table-cell">
                    <span className={clsx('font-medium', c.failed > 200 ? 'text-red-500' : 'text-slate-500')}>
                      {((c.failed / c.sent) * 100).toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

/* ─── TEMPLATES TAB ───────────────────────────────────────────────────────── */
function TemplatesTab() {
  const totalSent = TEMPLATE_STATS.reduce((a, t) => a + t.sent, 0)
  const avgRead   = (TEMPLATE_STATS.reduce((a, t) => a + t.read, 0) / TEMPLATE_STATS.length).toFixed(1)
  const avgCTR    = (TEMPLATE_STATS.filter(t => t.clicked > 0).reduce((a, t) => a + t.clicked, 0) / TEMPLATE_STATS.filter(t => t.clicked > 0).length).toFixed(1)
  const avgFail   = (TEMPLATE_STATS.reduce((a, t) => a + t.failed, 0) / TEMPLATE_STATS.length).toFixed(1)

  const barData = TEMPLATE_STATS.map(t => ({ name: t.name.replace(/_/g, ' '), sent: t.sent, read: Math.round(t.sent * t.read / 100) }))

  const categoryColor = {
    Marketing: 'badge-green',
    Utility:   'badge-blue',
    Auth:      'badge-amber',
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Sent"     value={totalSent.toLocaleString()} icon={Send}          iconBg="bg-blue-50"    color="text-blue-600"    trend={14.2} trendLabel="across all templates" />
        <StatCard label="Avg Read Rate"  value={avgRead + '%'}               icon={CheckCircle2}  iconBg="bg-emerald-50" color="text-emerald-600" trend={2.8}  trendLabel="messages opened" />
        <StatCard label="Avg CTR"        value={avgCTR + '%'}                icon={TrendingUp}    iconBg="bg-purple-50"  color="text-purple-600"  trend={1.1}  trendLabel="button clicks / delivered" />
        <StatCard label="Avg Fail Rate"  value={avgFail + '%'}               icon={ShieldAlert}   iconBg="bg-red-50"     color="text-red-500"     trend={-0.5} invert trendLabel="undelivered messages" />
      </div>

      {/* Bar chart — sent vs read */}
      <SectionCard title="Template Reach & Read Comparison">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={barData} layout="vertical" margin={{ top: 0, right: 20, left: 90, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false} width={90} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
            <Bar dataKey="sent" name="Sent"      fill="#DBEAFE" radius={[0, 4, 4, 0]} />
            <Bar dataKey="read" name="Read"      fill="#0066ff" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </SectionCard>

      {/* Template Performance Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-800">Per-Template Performance</h3>
          <button className="btn-ghost text-xs gap-1"><Download size={12} /> Export</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                {['Template Name', 'Category', 'Sent', 'Delivered', 'Read Rate', 'CTR', 'Reply Rate', 'Failed', 'Blocked'].map(h => (
                  <th key={h} className="table-header text-left">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {TEMPLATE_STATS.map(t => (
                <tr key={t.name} className="table-row">
                  <td className="table-cell font-medium text-slate-800 font-mono text-xs">{t.name}</td>
                  <td className="table-cell"><span className={clsx('badge', categoryColor[t.category] || 'badge-blue')}>{t.category}</span></td>
                  <td className="table-cell font-medium">{t.sent.toLocaleString()}</td>
                  <td className="table-cell">
                    <div className="flex items-center gap-2 min-w-[80px]">
                      <PctBar value={t.delivered} color="bg-emerald-400" />
                      <span className="text-xs font-medium text-emerald-600 whitespace-nowrap">{t.delivered}%</span>
                    </div>
                  </td>
                  <td className="table-cell">
                    <div className="flex items-center gap-2 min-w-[80px]">
                      <PctBar value={t.read} color="bg-blue-400" />
                      <span className="text-xs font-medium text-primary whitespace-nowrap">{t.read}%</span>
                    </div>
                  </td>
                  <td className="table-cell font-semibold text-purple-600">{t.clicked > 0 ? t.clicked + '%' : '—'}</td>
                  <td className="table-cell text-cyan-600">{t.replied > 0 ? t.replied + '%' : '—'}</td>
                  <td className="table-cell">
                    <span className={clsx('font-medium text-xs', t.failed > 3 ? 'text-red-500' : 'text-slate-400')}>{t.failed}%</span>
                  </td>
                  <td className="table-cell">
                    <span className={clsx('font-medium text-xs', t.blocked > 1 ? 'text-red-600 font-bold' : 'text-slate-400')}>{t.blocked}%</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

/* ─── APPOINTMENTS TAB ────────────────────────────────────────────────────── */
function AppointmentsTab({ data }) {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Bookings"    value="127"  icon={CalendarCheck} iconBg="bg-cyan-50"    color="text-cyan-600"    trend={31.4} trendLabel="this period" />
        <StatCard label="Completed"         value="98"   icon={CheckCircle2}  iconBg="bg-emerald-50" color="text-emerald-600" trend={2.1}  trendLabel="77.2% completion rate" />
        <StatCard label="No-Show Rate"      value="9.4%" icon={AlertCircle}   iconBg="bg-red-50"     color="text-red-500"     trend={-1.2} invert trendLabel="12 missed" />
        <StatCard label="Rescheduled"       value="17"   icon={RefreshCw}     iconBg="bg-amber-50"   color="text-amber-600"   trend={3.1}  trendLabel="13.4% of bookings" />
      </div>

      <SectionCard title="Daily Bookings Trend">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={Math.floor(data.length / 6)} />
            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="appointments" name="Bookings" fill="#06B6D4" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </SectionCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SectionCard title="Booking Sources">
          <div className="space-y-4">
            {[
              { label: 'WhatsApp Bot',   value: 89,  pct: 70, color: 'bg-primary' },
              { label: 'Voice Bot',      value: 24,  pct: 19, color: 'bg-purple-500' },
              { label: 'Live Agent',     value: 14,  pct: 11, color: 'bg-blue-400' },
            ].map(s => (
              <div key={s.label}>
                <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                  <span>{s.label}</span>
                  <span className="font-semibold text-slate-700">{s.value} <span className="text-slate-400">({s.pct}%)</span></span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={clsx('h-full rounded-full', s.color)} style={{ width: `${s.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Appointment Outcomes">
          <div className="space-y-4">
            {[
              { label: 'Completed on time', value: 83, total: 127, color: 'bg-emerald-500' },
              { label: 'Completed (late)',   value: 15, total: 127, color: 'bg-emerald-300' },
              { label: 'Rescheduled',        value: 17, total: 127, color: 'bg-amber-400'   },
              { label: 'No-show',            value: 12, total: 127, color: 'bg-red-400'     },
            ].map(o => (
              <div key={o.label}>
                <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                  <span>{o.label}</span>
                  <span className="font-semibold text-slate-700">{o.value} <span className="text-slate-400">({Math.round(o.value / o.total * 100)}%)</span></span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={clsx('h-full rounded-full', o.color)} style={{ width: `${(o.value / o.total) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

/* ─── AI USAGE TAB ────────────────────────────────────────────────────────── */
function AIUsageTab() {
  const totalTokens = AI_DAILY.reduce((a, b) => a + b.tokens, 0)
  const totalCost   = AI_DAILY.reduce((a, b) => a + b.cost, 0)
  const totalReqs   = AI_DAILY.reduce((a, b) => a + b.requests, 0)
  const avgTok      = Math.round(totalTokens / totalReqs)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Tokens"     value={(totalTokens / 1000).toFixed(0) + 'K'} icon={Bot}        iconBg="bg-primary-50" color="text-primary"     trend={8.4}  trendLabel="last 14 days" />
        <StatCard label="API Requests"     value={totalReqs.toLocaleString()}              icon={Zap}        iconBg="bg-blue-50"    color="text-blue-600"    trend={11.2} trendLabel="total calls" />
        <StatCard label="Total Cost"       value={'$' + totalCost.toFixed(2)}              icon={TrendingUp} iconBg="bg-purple-50"  color="text-purple-600"  trend={6.9}  trendLabel="AI inference cost" />
        <StatCard label="Avg Tokens / Req" value={avgTok + ' tok'}                         icon={Clock}      iconBg="bg-amber-50"   color="text-amber-600"   trend={-2.1} invert trendLabel="more efficient" />
      </div>

      <SectionCard title="Daily Token & Cost Trend">
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={AI_DAILY} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="gTok" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={2} />
            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
            <Area type="monotone" dataKey="tokens" name="Tokens" stroke="#8B5CF6" strokeWidth={2} fill="url(#gTok)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </SectionCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SectionCard title="Model Usage Breakdown">
          <div className="space-y-4">
            {[
              { label: 'OpenAI GPT-4o',  pct: 52, tokens: '364K', cost: '$18.20', color: 'bg-emerald-500' },
              { label: 'Claude Sonnet',  pct: 31, tokens: '217K', cost: '$10.85', color: 'bg-amber-500'   },
              { label: 'Google Gemini',  pct: 17, tokens: '119K', cost: '$5.95',  color: 'bg-blue-500'    },
            ].map(m => (
              <div key={m.label}>
                <div className="flex justify-between text-xs text-slate-600 mb-1.5">
                  <span className="font-medium">{m.label}</span>
                  <span>{m.tokens} · <span className="text-slate-500">{m.cost}</span> <span className="text-slate-400">({m.pct}%)</span></span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={clsx('h-full rounded-full', m.color)} style={{ width: `${m.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="AI Feature Usage">
          <div className="space-y-4">
            {[
              { label: 'Bot Auto-replies',    calls: 4821, pct: 68, color: 'bg-primary'      },
              { label: 'Lead Qualification',  calls: 1204, pct: 17, color: 'bg-purple-500'   },
              { label: 'Sentiment Analysis',  calls: 741,  pct: 10, color: 'bg-amber-400'    },
              { label: 'Smart Suggestions',   calls: 354,  pct: 5,  color: 'bg-emerald-400'  },
            ].map(f => (
              <div key={f.label}>
                <div className="flex justify-between text-xs text-slate-600 mb-1.5">
                  <span className="font-medium">{f.label}</span>
                  <span>{f.calls.toLocaleString()} calls <span className="text-slate-400">({f.pct}%)</span></span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={clsx('h-full rounded-full', f.color)} style={{ width: `${f.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

/* ─── MAIN COMPONENT ──────────────────────────────────────────────────────── */
const TABS = [
  { label: 'Summary',       icon: LayoutDashboard },
  { label: 'Conversations', icon: MessageSquare   },
  { label: 'Broadcasts',    icon: Send            },
  { label: 'Templates',     icon: BarChart2       },
  { label: 'Appointments',  icon: CalendarCheck   },
  { label: 'AI Usage',      icon: Bot             },
]

const PRESETS = ['Today', '7 Days', '30 Days', 'Custom']

export default function Analytics() {
  const [activeTab,   setActiveTab]   = useState(0)
  const [preset,      setPreset]      = useState('30 Days')
  const [dateFrom,    setDateFrom]    = useState(format(subDays(today, 29), 'yyyy-MM-dd'))
  const [dateTo,      setDateTo]      = useState(format(today, 'yyyy-MM-dd'))

  const chartData = useMemo(() => preset === '7 Days' ? DAILY_7 : DAILY_30, [preset])

  function applyPreset(p) {
    setPreset(p)
    if (p === 'Today')   { setDateFrom(format(today, 'yyyy-MM-dd')); setDateTo(format(today, 'yyyy-MM-dd')) }
    if (p === '7 Days')  { setDateFrom(format(subDays(today, 6), 'yyyy-MM-dd')); setDateTo(format(today, 'yyyy-MM-dd')) }
    if (p === '30 Days') { setDateFrom(format(subDays(today, 29), 'yyyy-MM-dd')); setDateTo(format(today, 'yyyy-MM-dd')) }
  }

  const TAB_CONTENT = [
    <SummaryTab />,
    <ConversationsTab data={chartData} />,
    <BroadcastsTab    data={chartData} />,
    <TemplatesTab />,
    <AppointmentsTab  data={chartData} />,
    <AIUsageTab />,
  ]

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Analytics</h1>
          <p className="text-xs text-slate-500 mt-0.5">Track performance across conversations, broadcasts, templates and AI</p>
        </div>
        <button className="btn-secondary gap-1.5">
          <Download size={14} /> Export Report
        </button>
      </div>

      {/* Date Range Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex bg-slate-100 rounded-lg p-0.5 gap-0.5">
          {PRESETS.map(p => (
            <button
              key={p}
              onClick={() => applyPreset(p)}
              className={clsx(
                'px-3 py-1.5 rounded-md text-xs font-medium transition-colors',
                preset === p ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              )}
            >
              {p}
            </button>
          ))}
        </div>
        {preset === 'Custom' && (
          <div className="flex items-center gap-2">
            <input type="date" className="input w-auto text-xs" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
            <span className="text-slate-400 text-sm">→</span>
            <input type="date" className="input w-auto text-xs" value={dateTo}   onChange={e => setDateTo(e.target.value)} />
          </div>
        )}
        {preset !== 'Custom' && (
          <span className="text-xs text-slate-400">
            {format(new Date(dateFrom), 'MMM d, yyyy')} — {format(new Date(dateTo), 'MMM d, yyyy')}
          </span>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit flex-wrap">
        {TABS.map(({ label, icon: Icon }, i) => (
          <button
            key={label}
            onClick={() => setActiveTab(i)}
            className={clsx(
              'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors',
              activeTab === i ? 'bg-white text-slate-900 shadow-card' : 'text-slate-500 hover:text-slate-700'
            )}
          >
            <Icon size={13} />
            {label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {TAB_CONTENT[activeTab]}
    </div>
  )
}
