// FlowSetup.jsx — 100% Gallabox Flow Builder replica
import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import {
  Plus, X, ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  Save, Trash2, Copy, Edit3, Check, Search,
  MessageSquare, Hash, Phone, Mail, Calendar, MapPin, Paperclip,
  Image, FileText, Clock, GitFork, List, Globe, UserCheck, User, Tag,
  MousePointer2, Zap, Database, Variable, Mic, Star,
  ZoomIn, ZoomOut, Send, RefreshCw, CornerDownRight,
  Cpu, Lock, Unlock, CheckCircle, Package, Layout,
  Bold, Italic, Strikethrough,
  ShoppingCart, Users, Building, Repeat, SlidersHorizontal,
  BookOpen, HelpCircle, AlertCircle, CreditCard, BarChart2, Briefcase,
  Video, Maximize2, Sparkles, Play, Eye, Rocket, AlertTriangle,
  ChevronRight as CRIcon, Regex,
} from 'lucide-react'

// ─── Node Definitions ─────────────────────────────────────────────────────────

const DEFS = {
  // SYSTEM
  start:          { label: 'Start',                  icon: Zap,              color: '#6366f1', cat: 'system'    },
  end:            { label: 'End Flow',               icon: X,                color: '#64748b', cat: 'system'    },
  // SEND TEXT
  text:           { label: 'Send Text',              icon: MessageSquare,    color: '#10b981', cat: 'send'      },
  media:          { label: 'Send Media',             icon: Image,            color: '#10b981', cat: 'send'      },
  send_buttons:   { label: 'Send Buttons',           icon: MousePointer2,    color: '#10b981', cat: 'send'      },
  send_list:      { label: 'Send List',              icon: List,             color: '#10b981', cat: 'send'      },
  template:       { label: 'Send Template',          icon: Layout,           color: '#10b981', cat: 'send'      },
  send_voice:     { label: 'Send Voice',             icon: Mic,              color: '#10b981', cat: 'send'      },
  catalog:        { label: 'Send Catalog',           icon: Package,          color: '#10b981', cat: 'send'      },
  // ASK QUESTIONS
  ask_text:       { label: 'Ask Text',               icon: MessageSquare,    color: '#f59e0b', cat: 'ask'       },
  ask_number:     { label: 'Ask Number',             icon: Hash,             color: '#f59e0b', cat: 'ask'       },
  ask_phone:      { label: 'Ask Phone',              icon: Phone,            color: '#f59e0b', cat: 'ask'       },
  ask_email:      { label: 'Ask Email',              icon: Mail,             color: '#f59e0b', cat: 'ask'       },
  ask_date:       { label: 'Ask Date',               icon: Calendar,         color: '#f59e0b', cat: 'ask'       },
  ask_location:   { label: 'Ask Location',           icon: MapPin,           color: '#f59e0b', cat: 'ask'       },
  ask_url:        { label: 'Ask URL',                icon: Globe,            color: '#f59e0b', cat: 'ask'       },
  ask_file:       { label: 'Ask File',               icon: Paperclip,        color: '#f59e0b', cat: 'ask'       },
  ask_button:     { label: 'Ask with Buttons',       icon: MousePointer2,    color: '#f59e0b', cat: 'ask'       },
  ask_list:       { label: 'Ask with List',          icon: List,             color: '#f59e0b', cat: 'ask'       },
  ask_keyword:    { label: 'Ask with Keywords',      icon: Tag,              color: '#f59e0b', cat: 'ask'       },
  ask_collection: { label: 'Ask Collection',         icon: Package,          color: '#f59e0b', cat: 'ask'       },
  ask_form:       { label: 'Ask Form',               icon: FileText,         color: '#f59e0b', cat: 'ask'       },
  ask_payment:    { label: 'Ask Payment',            icon: CreditCard,       color: '#f59e0b', cat: 'ask'       },
  // ACTIONS
  assign:         { label: 'Assign Conversation',   icon: User,             color: '#3b82f6', cat: 'action'    },
  unassign:       { label: 'Unassign Conversation', icon: UserCheck,        color: '#3b82f6', cat: 'action'    },
  resolve:        { label: 'Resolve Conversation',  icon: CheckCircle,      color: '#3b82f6', cat: 'action'    },
  update_conv:    { label: 'Update Conversation',   icon: Edit3,            color: '#3b82f6', cat: 'action'    },
  update_contact: { label: 'Update Contact',        icon: UserCheck,        color: '#3b82f6', cat: 'action'    },
  update_company: { label: 'Update Company',        icon: Building,         color: '#3b82f6', cat: 'action'    },
  push_seq:       { label: 'Push to Sequence',      icon: Repeat,           color: '#3b82f6', cat: 'action'    },
  add_note:       { label: 'Add Note',              icon: FileText,         color: '#3b82f6', cat: 'action'    },
  // UTILITIES
  delay:          { label: 'Delay',                 icon: Clock,            color: '#8b5cf6', cat: 'utility'   },
  condition:      { label: 'Condition',             icon: GitFork,          color: '#8b5cf6', cat: 'utility'   },
  set_var:        { label: 'Set Variable',          icon: Variable,         color: '#8b5cf6', cat: 'utility'   },
  jump:           { label: 'Jump to Step',          icon: CornerDownRight,  color: '#8b5cf6', cat: 'utility'   },
  switch_node:    { label: 'Switch',                icon: SlidersHorizontal,color: '#8b5cf6', cat: 'utility'   },
  gpt_dialog:     { label: 'GPT Dialog',            icon: Cpu,              color: '#8b5cf6', cat: 'utility'   },
  gpt_kb:         { label: 'GPT Knowledge Base',   icon: BookOpen,         color: '#8b5cf6', cat: 'utility'   },
  working_hours:  { label: 'Working Hours',         icon: Clock,            color: '#8b5cf6', cat: 'utility'   },
  hint:           { label: 'Hint',                  icon: HelpCircle,       color: '#8b5cf6', cat: 'utility'   },
  wait_order:     { label: 'Wait for Order',        icon: ShoppingCart,     color: '#8b5cf6', cat: 'utility'   },
  // CONNECTORS
  sheets:         { label: 'Google Sheets',         icon: Database,         color: '#06b6d4', cat: 'connector' },
  api:            { label: 'API Request',           icon: Globe,            color: '#06b6d4', cat: 'connector' },
  razorpay:       { label: 'Razorpay',              icon: CreditCard,       color: '#06b6d4', cat: 'connector' },
  zoho_crm:       { label: 'Zoho CRM',              icon: Briefcase,        color: '#06b6d4', cat: 'connector' },
  shopify:        { label: 'Shopify',               icon: ShoppingCart,     color: '#06b6d4', cat: 'connector' },
  hubspot:        { label: 'HubSpot',               icon: BarChart2,        color: '#06b6d4', cat: 'connector' },
  zoho_bigin:     { label: 'Zoho Bigin',            icon: Briefcase,        color: '#06b6d4', cat: 'connector' },
  leadsquared:    { label: 'LeadSquared',           icon: Users,            color: '#06b6d4', cat: 'connector' },
  woocommerce:    { label: 'WooCommerce',           icon: ShoppingCart,     color: '#06b6d4', cat: 'connector' },
  openai_conn:    { label: 'OpenAI',                icon: Cpu,              color: '#06b6d4', cat: 'connector' },
  zoom_conn:      { label: 'Zoom',                  icon: Video,            color: '#06b6d4', cat: 'connector' },
  sangam:         { label: 'Sangam CRM',            icon: Briefcase,        color: '#06b6d4', cat: 'connector' },
}

const CAT_ORDER  = ['system','send','ask','action','utility','connector']
const CAT_LABELS = { system:'Trigger & End', send:'Send Text', ask:'Ask Questions', action:'Actions', utility:'Utilities', connector:'Connectors' }
const CAT_BG     = {
  system:'linear-gradient(135deg,#6366f1,#818cf8)', send:'linear-gradient(135deg,#10b981,#34d399)',
  ask:'linear-gradient(135deg,#f59e0b,#fbbf24)',    action:'linear-gradient(135deg,#3b82f6,#60a5fa)',
  utility:'linear-gradient(135deg,#8b5cf6,#a78bfa)',connector:'linear-gradient(135deg,#06b6d4,#22d3ee)',
}
const CAT_COLOR  = { system:'#6366f1', send:'#10b981', ask:'#f59e0b', action:'#3b82f6', utility:'#8b5cf6', connector:'#06b6d4' }

// System / built-in variables grouped
const VAR_GROUPS = [
  { group: 'Intent', vars: [
    { v:'{{intent.text}}',       l:'User Message Text' },
    { v:'{{intent.payload}}',    l:'User Message Payload' },
  ]},
  { group: 'Recipient', vars: [
    { v:'{{recipient.name}}',          l:'Contact Name' },
    { v:'{{recipient.phone}}',         l:'Contact Phone' },
    { v:'{{recipient.country_code}}',  l:'Country Code' },
    { v:'{{recipient.email}}',         l:'Contact Email' },
  ]},
  { group: 'Contact', vars: [
    { v:'{{contact.name}}',       l:'Name' },
    { v:'{{contact.email}}',      l:'Email' },
    { v:'{{contact.phone}}',      l:'Phone' },
    { v:'{{contact.tags}}',       l:'Tags' },
    { v:'{{contact.owner}}',      l:'Owner' },
    { v:'{{contact.opt_in}}',     l:'Message Opt-In' },
  ]},
  { group: 'Session', vars: [
    { v:'{{session.trigger_type}}', l:'Trigger Type' },
    { v:'{{session.cart_items}}',   l:'Cart Items' },
    { v:'{{session.cart_amount}}',  l:'Cart Amount' },
  ]},
  { group: 'Custom Variables', vars: [
    { v:'{{user_reply}}',     l:'User Reply' },
    { v:'{{user_choice}}',    l:'User Choice' },
    { v:'{{order_id}}',       l:'Order ID' },
    { v:'{{payment_id}}',     l:'Payment ID' },
    { v:'{{ai_response}}',    l:'AI Response' },
    { v:'{{api_response}}',   l:'API Response' },
  ]},
]
const ALL_VARS = VAR_GROUPS.flatMap(g => g.vars)

const DAYS = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
const DAY_LABELS = { monday:'Mon',tuesday:'Tue',wednesday:'Wed',thursday:'Thu',friday:'Fri',saturday:'Sat',sunday:'Sun' }
const TIMEZONES = ['Asia/Kolkata','Asia/Dubai','Asia/Singapore','Asia/Tokyo','Europe/London','Europe/Paris','America/New_York','America/Los_Angeles','Australia/Sydney']

const MAX_CARDS = 100

// ─── makeDefaults ──────────────────────────────────────────────────────────────
function makeDefaults(type) {
  const base = { name: DEFS[type]?.label || type }
  const inv = { invalidMsg:'', retryCount:2, onInvalid:'retry' }
  switch (type) {
    case 'start':         return { ...base, trigger:'any', keywords:'', matchType:'contains', optIn:false }
    case 'end':           return { ...base, endMessage:'', action:'none' }
    case 'text':          return { ...base, message:'' }
    case 'media':         return { ...base, mediaType:'image', url:'', caption:'', fileName:'' }
    case 'send_buttons':  return { ...base, headerText:'', bodyText:'', footerText:'', buttons:[{id:'1',label:'',value:''}] }
    case 'send_list':     return { ...base, headerText:'', bodyText:'', footerText:'', buttonLabel:'View Options', sections:[{title:'Section 1',items:[{id:'1',title:'',description:'',value:''}]}] }
    case 'template':      return { ...base, templateName:'', language:'en', headerVar:'', bodyVars:[], ctaUrl:'' }
    case 'send_voice':    return { ...base, audioUrl:'' }
    case 'catalog':       return { ...base, catalogId:'', productSetId:'', bodyText:'', footerText:'' }
    case 'ask_text':      return { ...base, question:'', saveAs:'', regex:'', ...inv }
    case 'ask_number':    return { ...base, question:'', saveAs:'', min:'', max:'', regex:'', ...inv }
    case 'ask_phone':     return { ...base, question:'', saveAs:'', countryCode:'+91', ...inv }
    case 'ask_email':     return { ...base, question:'', saveAs:'', ...inv }
    case 'ask_date':      return { ...base, question:'', saveAs:'', dateFormat:'DD/MM/YYYY', minDate:'', maxDate:'', ...inv }
    case 'ask_location':  return { ...base, question:'', saveAs:'', ...inv }
    case 'ask_url':       return { ...base, question:'', saveAs:'', ...inv }
    case 'ask_file':      return { ...base, question:'', saveAs:'', allowedTypes:['image','document','video'], maxSizeMB:10, ...inv }
    case 'ask_button':    return { ...base, question:'', saveAs:'', footerText:'', buttons:[{id:'1',label:'',value:''}], ...inv }
    case 'ask_list':      return { ...base, headerType:'text', headerText:'', question:'', footerText:'', buttonLabel:'Choose Option', optionsType:'static', sections:[{title:'Options',items:[{id:'1',title:'',description:'',value:''}]}], dynamicVar:'', dynamicPathId:'', dynamicPathTitle:'', dynamicPathSectionTitle:'', saveAs:'', ...inv }
    case 'ask_keyword':   return { ...base, question:'', keywords:[{id:'1',label:'',value:''}], caseSensitive:false, saveAs:'', ...inv }
    case 'ask_collection':return { ...base, question:'', saveAs:'', catalogId:'', productSetId:'' }
    case 'ask_form':      return { ...base, title:'', fields:[{id:'1',label:'',type:'text',required:true,saveAs:''}], submitLabel:'Submit' }
    case 'ask_payment':   return { ...base, gateway:'razorpay', amount:'', currency:'INR', description:'', saveAs:'', askName:false, askPhone:false, askEmail:false }
    case 'assign':        return { ...base, assignTo:'agent', agentId:'', teamId:'', handoffMsg:'' }
    case 'unassign':      return { ...base, handoffMsg:'' }
    case 'resolve':       return { ...base, resolveMsg:'', sendMsg:false }
    case 'update_conv':   return { ...base, fields:[{id:'1',key:'',value:''}] }
    case 'update_contact':return { ...base, fields:[{id:'1',key:'',value:''}] }
    case 'update_company':return { ...base, fields:[{id:'1',key:'',value:''}] }
    case 'push_seq':      return { ...base, sequenceId:'', delayMinutes:0 }
    case 'add_note':      return { ...base, noteText:'' }
    case 'delay':         return { ...base, duration:5, unit:'seconds' }
    case 'condition':     return { ...base, variable:'', operator:'equals', value:'', trueLabel:'Yes', falseLabel:'No' }
    case 'set_var':       return { ...base, variable:'', value:'', valueType:'static' }
    case 'jump':          return { ...base, targetNodeId:'' }
    case 'switch_node':   return { ...base, variable:'', cases:[{id:'1',value:'',label:'Case 1'}], defaultLabel:'Default' }
    case 'gpt_dialog':    return { ...base, prompt:'', userMessage:'{{intent.text}}', maxTokens:500, temperature:0.7, saveAs:'{{ai_response}}', functions:[] }
    case 'gpt_kb':        return { ...base, knowledgeBaseId:'', userMessage:'{{intent.text}}', inputVars:'', saveAs:'{{ai_response}}', maxTokens:500, fallbackMessage:'' }
    case 'working_hours': {
      const schedule = {}
      DAYS.forEach(d => { schedule[d] = { enabled: !['saturday','sunday'].includes(d), open:'09:00', close:'18:00' } })
      return { ...base, timezone:'Asia/Kolkata', schedule, insideLabel:'Open', outsideLabel:'Closed' }
    }
    case 'hint':          return { ...base, hintText:'', visibleTo:'all' }
    case 'wait_order':    return { ...base, timeoutDuration:24, timeoutUnit:'hours', saveAs:'{{order_id}}' }
    case 'sheets':        return { ...base, spreadsheetId:'', sheetName:'', operation:'append', fields:[{id:'1',key:'',value:''}] }
    case 'api':           return { ...base, method:'POST', url:'', headers:[{id:'1',key:'',value:''}], bodyType:'json', body:'', saveAs:'{{api_response}}', saveFields:[{id:'1',key:'',value:''}] }
    case 'razorpay':      return { ...base, amount:'', currency:'INR', description:'', expiry:15, customerName:'{{recipient.name}}', customerPhone:'{{recipient.phone}}', customerEmail:'{{recipient.email}}', saveAs:'{{payment_id}}' }
    case 'zoho_crm':      return { ...base, operation:'create', module:'Leads', fields:[{id:'1',key:'',value:''}], saveAs:'' }
    case 'shopify':       return { ...base, operation:'get_order', orderId:'', productId:'', customerEmail:'', saveAs:'' }
    case 'hubspot':       return { ...base, operation:'create_contact', fields:[{id:'1',key:'',value:''}], saveAs:'' }
    case 'zoho_bigin':    return { ...base, operation:'create', module:'Contacts', fields:[{id:'1',key:'',value:''}], saveAs:'' }
    case 'leadsquared':   return { ...base, activityEvent:'', fields:[{id:'1',key:'',value:''}], saveAs:'' }
    case 'woocommerce':   return { ...base, operation:'get_order', orderId:'', productId:'', orderStatus:'', saveAs:'' }
    case 'openai_conn':   return { ...base, prompt:'', model:'gpt-4o-mini', saveAs:'{{ai_response}}', maxTokens:500, temperature:0.7 }
    case 'zoom_conn':     return { ...base, topic:'', startTime:'', duration:60, saveAs:'' }
    case 'sangam':        return { ...base, operation:'create_lead', fields:[{id:'1',key:'',value:''}], saveAs:'' }
    default:              return base
  }
}

// ─── getOutputPorts ────────────────────────────────────────────────────────────
function getOutputPorts(node) {
  const d = node.data || {}
  switch (node.type) {
    case 'end':           return []
    case 'condition':     return [{ label:d.trueLabel||'Yes',idx:0 },{ label:d.falseLabel||'No',idx:1 }]
    case 'ask_button':    return (d.buttons||[]).map((b,i)=>({ label:b.label||`Option ${i+1}`,idx:i }))
    case 'send_buttons':  return (d.buttons||[]).map((b,i)=>({ label:b.label||`Button ${i+1}`,idx:i }))
    case 'ask_list':      return (d.sections||[]).flatMap(s=>s.items||[]).slice(0,10).map((it,i)=>({ label:it.title||`Item ${i+1}`,idx:i }))
    case 'send_list':     return (d.sections||[]).flatMap(s=>s.items||[]).slice(0,10).map((it,i)=>({ label:it.title||`Item ${i+1}`,idx:i }))
    case 'ask_keyword':   return (d.keywords||[]).map((k,i)=>({ label:k.label||k.value||`KW ${i+1}`,idx:i }))
    case 'switch_node':   return [...(d.cases||[]).map((c,i)=>({ label:c.label||c.value||`Case ${i+1}`,idx:i })),{ label:d.defaultLabel||'Default',idx:(d.cases||[]).length }]
    case 'working_hours': return [{ label:d.insideLabel||'Open',idx:0 },{ label:d.outsideLabel||'Closed',idx:1 }]
    case 'wait_order':    return [{ label:'Order Received',idx:0 },{ label:'Timeout',idx:1 }]
    case 'api':           return [{ label:'Success',idx:0 },{ label:'Error',idx:1 }]
    default:              return [{ label:'→',idx:0 }]
  }
}

// ─── Demo nodes ────────────────────────────────────────────────────────────────
const DEMO_NODES = [
  { id:'n1', type:'start',      x:60,  y:180, data:{ name:'Start', trigger:'keyword', keywords:'hello, hi', matchType:'contains' } },
  { id:'n2', type:'text',       x:300, y:180, data:{ name:'Welcome', message:'Hello {{recipient.name}}! Welcome 👋' } },
  { id:'n3', type:'ask_button', x:560, y:180, data:{ name:'Main Menu', question:'How can I help you today?', saveAs:'{{user_choice}}', buttons:[{id:'1',label:'Support',value:'support'},{id:'2',label:'Sales',value:'sales'},{id:'3',label:'Other',value:'other'}] } },
  { id:'n4', type:'text',       x:820, y:40,  data:{ name:'Support', message:'Connecting you to our support team...' } },
  { id:'n5', type:'text',       x:820, y:200, data:{ name:'Sales', message:'Our sales team will assist you!' } },
  { id:'n6', type:'text',       x:820, y:360, data:{ name:'Other', message:'Please describe your issue.' } },
  { id:'n7', type:'end',        x:1060,y:200, data:{ name:'End', endMessage:'Thank you! Have a great day 👋', action:'none' } },
]
const DEMO_EDGES = [
  { id:'e1', fromId:'n1', fromPort:0, toId:'n2' },
  { id:'e2', fromId:'n2', fromPort:0, toId:'n3' },
  { id:'e3', fromId:'n3', fromPort:0, toId:'n4' },
  { id:'e4', fromId:'n3', fromPort:1, toId:'n5' },
  { id:'e5', fromId:'n3', fromPort:2, toId:'n6' },
  { id:'e6', fromId:'n5', fromPort:0, toId:'n7' },
]

// ─── Utilities ─────────────────────────────────────────────────────────────────
let _uid = 100
const uid = () => `n${++_uid}`
const eid = () => `e${++_uid}`

function bezier(x1,y1,x2,y2) {
  const dx = Math.abs(x2-x1)*0.5
  return `M${x1},${y1} C${x1+dx},${y1} ${x2-dx},${y2} ${x2},${y2}`
}

const NODE_W = 210
const NODE_H = 66
const PORT_R = 7

// ─── Form helpers ──────────────────────────────────────────────────────────────

function FLabel({ label, children, hint }) {
  return (
    <div style={{ marginBottom:12 }}>
      <div style={{ fontSize:11, fontWeight:700, color:'#374151', marginBottom:4, display:'flex', alignItems:'center', gap:4, textTransform:'uppercase', letterSpacing:'0.04em' }}>
        {label}
        {hint && <span title={hint} style={{ cursor:'help', color:'#9ca3af', fontWeight:400, textTransform:'none', letterSpacing:0 }}><HelpCircle size={11}/></span>}
      </div>
      {children}
    </div>
  )
}

const inputStyle = { width:'100%', border:'1px solid #d1d5db', borderRadius:6, padding:'7px 10px', fontSize:13, outline:'none', background:'#fff', color:'#111827', boxSizing:'border-box', fontFamily:'inherit' }
const disabledInputStyle = { ...inputStyle, background:'#f9fafb', color:'#9ca3af' }

function FInput({ value='', onChange, placeholder='', type='text', disabled=false, style={}, maxLength }) {
  return <input type={type} value={value} disabled={disabled} maxLength={maxLength}
    onChange={e=>onChange&&onChange(e.target.value)} placeholder={placeholder}
    style={{ ...(disabled?disabledInputStyle:inputStyle), ...style }}/>
}

function FTextarea({ value='', onChange, placeholder='', rows=3 }) {
  return <textarea value={value} rows={rows}
    onChange={e=>onChange&&onChange(e.target.value)} placeholder={placeholder}
    style={{ ...inputStyle, resize:'vertical', lineHeight:1.5 }}/>
}

function FSelect({ value='', onChange, options=[] }) {
  return (
    <select value={value} onChange={e=>onChange&&onChange(e.target.value)}
      style={{ ...inputStyle, cursor:'pointer' }}>
      {options.map(o => typeof o==='string'
        ? <option key={o} value={o}>{o}</option>
        : <option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  )
}

function FToggle({ value=false, onChange, label }) {
  return (
    <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', userSelect:'none', marginBottom:6 }}>
      <div onClick={()=>onChange&&onChange(!value)}
        style={{ width:36, height:20, borderRadius:10, background:value?'#6366f1':'#d1d5db', position:'relative', transition:'background 0.2s', flexShrink:0 }}>
        <div style={{ position:'absolute', top:2, left:value?16:2, width:16, height:16, borderRadius:'50%', background:'#fff', transition:'left 0.2s' }}/>
      </div>
      {label && <span style={{ fontSize:13, color:'#374151' }}>{label}</span>}
    </label>
  )
}

// Variable picker with groups
function FVarSelect({ value='', onChange }) {
  return (
    <select value={value} onChange={e=>onChange&&onChange(e.target.value)} style={{ ...inputStyle, cursor:'pointer' }}>
      <option value=''>Select variable...</option>
      {VAR_GROUPS.map(g=>(
        <optgroup key={g.group} label={g.group}>
          {g.vars.map(v=><option key={v.v} value={v.v}>{v.l} — {v.v}</option>)}
        </optgroup>
      ))}
    </select>
  )
}

// Rich text toolbar (Bold / Italic / Strikethrough) for message/question fields
function FRichTextarea({ value='', onChange, placeholder='', rows=3 }) {
  const taRef = useRef(null)

  const wrap = (tag) => {
    const ta = taRef.current
    if (!ta) return
    const { selectionStart: s, selectionEnd: e } = ta
    const sel = value.slice(s, e)
    const markers = { bold:'*', italic:'_', strike:'~' }
    const m = markers[tag]
    const newVal = value.slice(0,s) + m + sel + m + value.slice(e)
    onChange(newVal)
    setTimeout(() => { ta.focus(); ta.setSelectionRange(s+1, e+1) }, 0)
  }

  return (
    <div style={{ border:'1px solid #d1d5db', borderRadius:6, overflow:'hidden' }}>
      <div style={{ display:'flex', gap:2, padding:'4px 6px', background:'#f9fafb', borderBottom:'1px solid #e5e7eb' }}>
        {[['bold','B','bold'],['italic','I','italic'],['strike','S','strikethrough']].map(([tag,label,title])=>(
          <button key={tag} onClick={()=>wrap(tag)} title={title}
            style={{ border:'none', background:'none', cursor:'pointer', padding:'2px 6px', borderRadius:4, fontSize:12,
              fontWeight:tag==='bold'?'bold':'normal', fontStyle:tag==='italic'?'italic':'normal',
              textDecoration:tag==='strike'?'line-through':'none', color:'#374151' }}
            onMouseEnter={e=>e.currentTarget.style.background='#e5e7eb'}
            onMouseLeave={e=>e.currentTarget.style.background='none'}>
            {label}
          </button>
        ))}
        <div style={{ flex:1 }}/>
        <span style={{ fontSize:10, color:'#9ca3af', alignSelf:'center' }}>*bold* _italic_ ~strike~</span>
      </div>
      <textarea ref={taRef} value={value} rows={rows} placeholder={placeholder}
        onChange={e=>onChange&&onChange(e.target.value)}
        style={{ width:'100%', border:'none', padding:'7px 10px', fontSize:13, outline:'none', resize:'vertical', fontFamily:'inherit', lineHeight:1.5, boxSizing:'border-box' }}/>
    </div>
  )
}

// Key-value list
function FKVList({ items=[], onChange, keyPlaceholder='Key', valPlaceholder='Value', addLabel='Add Field', max=20 }) {
  const add = () => { if (items.length<max) onChange([...items,{id:String(Date.now()),key:'',value:''}]) }
  const remove = id => onChange(items.filter(i=>i.id!==id))
  const upd = (id,field,val) => onChange(items.map(i=>i.id===id?{...i,[field]:val}:i))
  return (
    <div>
      {items.map(item=>(
        <div key={item.id} style={{ display:'flex', gap:5, marginBottom:5, alignItems:'center' }}>
          <input value={item.key} onChange={e=>upd(item.id,'key',e.target.value)} placeholder={keyPlaceholder}
            style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
          <input value={item.value} onChange={e=>upd(item.id,'value',e.target.value)} placeholder={valPlaceholder}
            style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
          <button onClick={()=>remove(item.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:3 }}><X size={12}/></button>
        </div>
      ))}
      <button onClick={add} disabled={items.length>=max}
        style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
        + {addLabel}
      </button>
    </div>
  )
}

// Button list
function FButtonList({ buttons=[], onChange, max=3 }) {
  const add = () => { if (buttons.length<max) onChange([...buttons,{id:String(Date.now()),label:'',value:''}]) }
  const remove = id => onChange(buttons.filter(b=>b.id!==id))
  const upd = (id,field,val) => onChange(buttons.map(b=>b.id===id?{...b,[field]:val}:b))
  return (
    <div>
      {buttons.map((btn,i)=>(
        <div key={btn.id} style={{ border:'1px solid #e5e7eb', borderRadius:6, padding:8, marginBottom:6 }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
            <span style={{ fontSize:10, fontWeight:700, color:'#9ca3af' }}>BUTTON {i+1}</span>
            <button onClick={()=>remove(btn.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={11}/></button>
          </div>
          <input value={btn.label} onChange={e=>upd(btn.id,'label',e.target.value)} placeholder='Button label'
            style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12, marginBottom:4, boxSizing:'border-box' }}/>
          <input value={btn.value} onChange={e=>upd(btn.id,'value',e.target.value)} placeholder='Value (optional)'
            style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12, boxSizing:'border-box' }}/>
        </div>
      ))}
      {buttons.length<max && (
        <button onClick={add} style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
          + Add Button
        </button>
      )}
    </div>
  )
}

// Sections + items
function FSectionList({ sections=[], onChange }) {
  const addSec = () => onChange([...sections,{title:`Section ${sections.length+1}`,items:[{id:String(Date.now()),title:'',description:'',value:''}]}])
  const removeSec = i => onChange(sections.filter((_,idx)=>idx!==i))
  const updSec = (i,title) => onChange(sections.map((s,idx)=>idx===i?{...s,title}:s))
  const addItem = i => {
    const ns = sections.map((s,idx)=>idx===i?{...s,items:[...s.items,{id:String(Date.now()),title:'',description:'',value:''}]}:s)
    onChange(ns)
  }
  const removeItem = (si,id) => onChange(sections.map((s,idx)=>idx===si?{...s,items:s.items.filter(it=>it.id!==id)}:s))
  const updItem = (si,id,field,val) => onChange(sections.map((s,idx)=>idx===si?{...s,items:s.items.map(it=>it.id===id?{...it,[field]:val}:it)}:s))
  return (
    <div>
      {sections.map((sec,si)=>(
        <div key={si} style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:9, marginBottom:7 }}>
          <div style={{ display:'flex', gap:5, alignItems:'center', marginBottom:7 }}>
            <input value={sec.title} onChange={e=>updSec(si,e.target.value)} placeholder='Section title'
              style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
            <button onClick={()=>removeSec(si)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={11}/></button>
          </div>
          {(sec.items||[]).map(item=>(
            <div key={item.id} style={{ border:'1px solid #f3f4f6', borderRadius:5, padding:7, marginBottom:5, background:'#fafafa' }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                <span style={{ fontSize:9, color:'#9ca3af', fontWeight:700 }}>ITEM</span>
                <button onClick={()=>removeItem(si,item.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={9}/></button>
              </div>
              <input value={item.title} onChange={e=>updItem(si,item.id,'title',e.target.value)} placeholder='Title'
                style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 7px', fontSize:11, marginBottom:3, boxSizing:'border-box' }}/>
              <input value={item.description} onChange={e=>updItem(si,item.id,'description',e.target.value)} placeholder='Description (optional)'
                style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 7px', fontSize:11, marginBottom:3, boxSizing:'border-box' }}/>
              <input value={item.value} onChange={e=>updItem(si,item.id,'value',e.target.value)} placeholder='Value'
                style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 7px', fontSize:11, boxSizing:'border-box' }}/>
            </div>
          ))}
          <button onClick={()=>addItem(si)} style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:4, padding:'3px 7px', cursor:'pointer', width:'100%' }}>
            + Add Item
          </button>
        </div>
      ))}
      {sections.length<10 && (
        <button onClick={addSec} style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
          + Add Section
        </button>
      )}
    </div>
  )
}

// Shared validation block
function InvalidFields({ d, set }) {
  return (
    <div style={{ borderTop:'1px solid #f3f4f6', paddingTop:12, marginTop:4 }}>
      <div style={{ fontSize:10, fontWeight:700, color:'#9ca3af', letterSpacing:1, marginBottom:9 }}>VALIDATION</div>
      <FLabel label="Validation Error Message">
        <FTextarea value={d.invalidMsg||''} onChange={v=>set('invalidMsg',v)} placeholder='Message on invalid input' rows={2}/>
      </FLabel>
      <div style={{ display:'flex', gap:8 }}>
        <div style={{ flex:1 }}>
          <FLabel label="Retry Attempts">
            <FInput type='number' value={d.retryCount??2} onChange={v=>set('retryCount',+v)}/>
          </FLabel>
        </div>
        <div style={{ flex:2 }}>
          <FLabel label="On Invalid Response">
            <FSelect value={d.onInvalid||'retry'} onChange={v=>set('onInvalid',v)}
              options={[{v:'retry',l:'Retry'},{v:'skip',l:'Skip Step'},{v:'end_flow',l:'End Flow'},{v:'fallback',l:'Go to Fallback'}]}/>
          </FLabel>
        </div>
      </div>
    </div>
  )
}

// ─── EditForm ──────────────────────────────────────────────────────────────────
function EditForm({ node, onChange }) {
  const d = node.data || {}
  const set = (k,v) => onChange({ ...node, data:{ ...d,[k]:v } })

  switch (node.type) {

    // ── SYSTEM ────────────────────────────────────────────────────────────────
    case 'start': return (
      <>
        <FLabel label="Trigger Type">
          <FSelect value={d.trigger||'any'} onChange={v=>set('trigger',v)}
            options={[{v:'any',l:'Any Message'},{v:'keyword',l:'Keyword'},{v:'button',l:'Button Reply'},{v:'opt_in',l:'Contact Opt-In'},{v:'first_message',l:'First Message'}]}/>
        </FLabel>
        {d.trigger==='keyword' && <>
          <FLabel label="Keywords (comma-separated)">
            <FInput value={d.keywords||''} onChange={v=>set('keywords',v)} placeholder='hello, hi, hey'/>
          </FLabel>
          <FLabel label="Match Type">
            <FSelect value={d.matchType||'contains'} onChange={v=>set('matchType',v)}
              options={[{v:'contains',l:'Contains'},{v:'exact',l:'Exact Match'},{v:'starts_with',l:'Starts With'},{v:'ends_with',l:'Ends With'}]}/>
          </FLabel>
        </>}
        <FToggle value={d.optIn||false} onChange={v=>set('optIn',v)} label='Only opted-in contacts'/>
      </>
    )

    case 'end': return (
      <>
        <FLabel label="Action on End">
          <FSelect value={d.action||'none'} onChange={v=>set('action',v)}
            options={[{v:'none',l:'None'},{v:'resolve',l:'Resolve Conversation'},{v:'unassign',l:'Unassign Agent'},{v:'opt_out',l:'Opt-Out Contact'}]}/>
        </FLabel>
        <FLabel label="End Message (optional)">
          <FTextarea value={d.endMessage||''} onChange={v=>set('endMessage',v)} placeholder='Goodbye message...' rows={2}/>
        </FLabel>
      </>
    )

    // ── SEND TEXT ─────────────────────────────────────────────────────────────
    case 'text': return (
      <>
        <FLabel label="Message" hint="Supports *bold*, _italic_, ~strikethrough~, {{variables}}">
          <FRichTextarea value={d.message||''} onChange={v=>set('message',v)} placeholder='Type your message here...' rows={4}/>
        </FLabel>
        <FLabel label="Insert Variable">
          <FVarSelect onChange={v=>set('message',(d.message||'')+v)}/>
        </FLabel>
      </>
    )

    case 'media': return (
      <>
        <FLabel label="Media Type">
          <FSelect value={d.mediaType||'image'} onChange={v=>set('mediaType',v)}
            options={[{v:'image',l:'Image'},{v:'video',l:'Video'},{v:'document',l:'Document'},{v:'audio',l:'Audio'}]}/>
        </FLabel>
        <FLabel label="Media URL"><FInput value={d.url||''} onChange={v=>set('url',v)} placeholder='https://...'/></FLabel>
        {d.mediaType!=='audio' && <FLabel label="Caption"><FTextarea value={d.caption||''} onChange={v=>set('caption',v)} rows={2}/></FLabel>}
        {d.mediaType==='document' && <FLabel label="File Name"><FInput value={d.fileName||''} onChange={v=>set('fileName',v)} placeholder='document.pdf'/></FLabel>}
      </>
    )

    case 'send_buttons': return (
      <>
        <FLabel label="Header Text (optional)"><FInput value={d.headerText||''} onChange={v=>set('headerText',v)}/></FLabel>
        <FLabel label="Body Text" hint="Supports *bold*, _italic_, ~strike~"><FRichTextarea value={d.bodyText||''} onChange={v=>set('bodyText',v)} rows={3}/></FLabel>
        <FLabel label="Footer (optional)"><FInput value={d.footerText||''} onChange={v=>set('footerText',v)}/></FLabel>
        <FLabel label="Buttons (max 3)"><FButtonList buttons={d.buttons||[]} onChange={v=>set('buttons',v)} max={3}/></FLabel>
      </>
    )

    case 'send_list': return (
      <>
        <FLabel label="Header Text"><FInput value={d.headerText||''} onChange={v=>set('headerText',v)}/></FLabel>
        <FLabel label="Body Text"><FRichTextarea value={d.bodyText||''} onChange={v=>set('bodyText',v)} rows={3}/></FLabel>
        <FLabel label="Footer (optional)"><FInput value={d.footerText||''} onChange={v=>set('footerText',v)}/></FLabel>
        <FLabel label="Button Label"><FInput value={d.buttonLabel||'View Options'} onChange={v=>set('buttonLabel',v)}/></FLabel>
        <FLabel label="Sections"><FSectionList sections={d.sections||[]} onChange={v=>set('sections',v)}/></FLabel>
      </>
    )

    case 'template': return (
      <>
        <FLabel label="Template Name"><FInput value={d.templateName||''} onChange={v=>set('templateName',v)} placeholder='my_template_name'/></FLabel>
        <FLabel label="Language">
          <FSelect value={d.language||'en'} onChange={v=>set('language',v)}
            options={[{v:'en',l:'English'},{v:'hi',l:'Hindi'},{v:'ta',l:'Tamil'},{v:'te',l:'Telugu'},{v:'kn',l:'Kannada'},{v:'mr',l:'Marathi'},{v:'ar',l:'Arabic'},{v:'es',l:'Spanish'},{v:'pt_BR',l:'Portuguese (BR)'}]}/>
        </FLabel>
        <FLabel label="Header Variable"><FInput value={d.headerVar||''} onChange={v=>set('headerVar',v)} placeholder='{{variable}}'/></FLabel>
        <FLabel label="Body Variables"><FKVList items={d.bodyVars||[]} onChange={v=>set('bodyVars',v)} keyPlaceholder='Param ({{1}})' valPlaceholder='Value'/></FLabel>
        <FLabel label="CTA URL (optional)"><FInput value={d.ctaUrl||''} onChange={v=>set('ctaUrl',v)} placeholder='https://'/></FLabel>
      </>
    )

    case 'send_voice': return (
      <FLabel label="Audio URL"><FInput value={d.audioUrl||''} onChange={v=>set('audioUrl',v)} placeholder='https://...mp3'/></FLabel>
    )

    case 'catalog': return (
      <>
        <FLabel label="Catalog ID"><FInput value={d.catalogId||''} onChange={v=>set('catalogId',v)}/></FLabel>
        <FLabel label="Product Set ID"><FInput value={d.productSetId||''} onChange={v=>set('productSetId',v)}/></FLabel>
        <FLabel label="Body Text"><FTextarea value={d.bodyText||''} onChange={v=>set('bodyText',v)} rows={2}/></FLabel>
        <FLabel label="Footer"><FInput value={d.footerText||''} onChange={v=>set('footerText',v)}/></FLabel>
      </>
    )

    // ── ASK QUESTIONS ─────────────────────────────────────────────────────────
    case 'ask_text': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} placeholder='What is your name?' rows={3}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <FLabel label="Regex Validation (optional)" hint="Leave empty to skip regex check">
          <FInput value={d.regex||''} onChange={v=>set('regex',v)} placeholder='^[a-zA-Z ]+$'/>
        </FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_number': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} placeholder='Enter a number' rows={3}/></FLabel>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Min Value"><FInput type='number' value={d.min||''} onChange={v=>set('min',v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Max Value"><FInput type='number' value={d.max||''} onChange={v=>set('max',v)}/></FLabel></div>
        </div>
        <FLabel label="Regex (optional)"><FInput value={d.regex||''} onChange={v=>set('regex',v)} placeholder='^\d+$'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_phone': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Country Code">
          <FSelect value={d.countryCode||'+91'} onChange={v=>set('countryCode',v)}
            options={[{v:'+91',l:'+91 India'},{v:'+1',l:'+1 USA'},{v:'+44',l:'+44 UK'},{v:'+971',l:'+971 UAE'},{v:'+65',l:'+65 Singapore'},{v:'+60',l:'+60 Malaysia'}]}/>
        </FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_email': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_date': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Date Format">
          <FSelect value={d.dateFormat||'DD/MM/YYYY'} onChange={v=>set('dateFormat',v)}
            options={[{v:'DD/MM/YYYY',l:'DD/MM/YYYY'},{v:'MM/DD/YYYY',l:'MM/DD/YYYY'},{v:'YYYY-MM-DD',l:'YYYY-MM-DD'}]}/>
        </FLabel>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Min Date"><FInput value={d.minDate||''} onChange={v=>set('minDate',v)} placeholder='YYYY-MM-DD'/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Max Date"><FInput value={d.maxDate||''} onChange={v=>set('maxDate',v)} placeholder='YYYY-MM-DD'/></FLabel></div>
        </div>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_location': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_url': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_file': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Allowed File Types">
          {['image','video','document','audio'].map(t=>(
            <label key={t} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4, cursor:'pointer', fontSize:13 }}>
              <input type='checkbox' checked={(d.allowedTypes||[]).includes(t)}
                onChange={e=>{
                  const cur = d.allowedTypes||[]
                  set('allowedTypes', e.target.checked?[...cur,t]:cur.filter(x=>x!==t))
                }}/>
              {t.charAt(0).toUpperCase()+t.slice(1)}
            </label>
          ))}
        </FLabel>
        <FLabel label="Max File Size (MB)"><FInput type='number' value={d.maxSizeMB||10} onChange={v=>set('maxSizeMB',+v)}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_button': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} placeholder='Choose an option:' rows={3}/></FLabel>
        <FLabel label="Footer (optional)"><FInput value={d.footerText||''} onChange={v=>set('footerText',v)}/></FLabel>
        <FLabel label="Buttons (max 3)"><FButtonList buttons={d.buttons||[]} onChange={v=>set('buttons',v)} max={3}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_list': return (
      <>
        <FLabel label="Header Type">
          <FSelect value={d.headerType||'text'} onChange={v=>set('headerType',v)}
            options={[{v:'text',l:'Text'},{v:'image',l:'Image'},{v:'video',l:'Video'},{v:'document',l:'Document'}]}/>
        </FLabel>
        {(d.headerType||'text')==='text'
          ? <FLabel label="Header Text"><FInput value={d.headerText||''} onChange={v=>set('headerText',v)}/></FLabel>
          : <FLabel label="Header Media URL"><FInput value={d.headerUrl||''} onChange={v=>set('headerUrl',v)} placeholder='https://'/></FLabel>}
        <FLabel label="Question / Body"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} placeholder='Choose from the list:' rows={3}/></FLabel>
        <FLabel label="Footer (optional)"><FInput value={d.footerText||''} onChange={v=>set('footerText',v)}/></FLabel>
        <FLabel label="Button Label"><FInput value={d.buttonLabel||'Choose Option'} onChange={v=>set('buttonLabel',v)}/></FLabel>
        <FLabel label="Options Type">
          <FSelect value={d.optionsType||'static'} onChange={v=>set('optionsType',v)}
            options={[{v:'static',l:'Static Options'},{v:'dynamic',l:'Dynamic (from Variable)'},{v:'dynamic_sections',l:'Dynamic with Sections'}]}/>
        </FLabel>
        {(d.optionsType||'static')==='static' && (
          <FLabel label="Sections & Items"><FSectionList sections={d.sections||[]} onChange={v=>set('sections',v)}/></FLabel>
        )}
        {d.optionsType==='dynamic' && (
          <>
            <FLabel label="Variable to Iterate"><FVarSelect value={d.dynamicVar||''} onChange={v=>set('dynamicVar',v)}/></FLabel>
            <FLabel label="Path to ID"><FInput value={d.dynamicPathId||''} onChange={v=>set('dynamicPathId',v)} placeholder='e.g. id'/></FLabel>
            <FLabel label="Path to Title"><FInput value={d.dynamicPathTitle||''} onChange={v=>set('dynamicPathTitle',v)} placeholder='e.g. name'/></FLabel>
          </>
        )}
        {d.optionsType==='dynamic_sections' && (
          <>
            <FLabel label="Variable to Iterate"><FVarSelect value={d.dynamicVar||''} onChange={v=>set('dynamicVar',v)}/></FLabel>
            <FLabel label="Path to Section Title"><FInput value={d.dynamicPathSectionTitle||''} onChange={v=>set('dynamicPathSectionTitle',v)} placeholder='e.g. category'/></FLabel>
            <FLabel label="Path to ID"><FInput value={d.dynamicPathId||''} onChange={v=>set('dynamicPathId',v)} placeholder='e.g. id'/></FLabel>
            <FLabel label="Path to Title"><FInput value={d.dynamicPathTitle||''} onChange={v=>set('dynamicPathTitle',v)} placeholder='e.g. name'/></FLabel>
            <FLabel label="Path to Description"><FInput value={d.dynamicPathDesc||''} onChange={v=>set('dynamicPathDesc',v)} placeholder='e.g. description'/></FLabel>
          </>
        )}
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_keyword': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} placeholder='Type a keyword to continue' rows={3}/></FLabel>
        <FLabel label="Keywords">
          {(d.keywords||[]).map((kw,i)=>(
            <div key={kw.id} style={{ display:'flex', gap:5, marginBottom:5, alignItems:'center' }}>
              <input value={kw.label} onChange={e=>{const kws=[...(d.keywords||[])];kws[i]={...kws[i],label:e.target.value};set('keywords',kws)}}
                placeholder='Display label' style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
              <input value={kw.value} onChange={e=>{const kws=[...(d.keywords||[])];kws[i]={...kws[i],value:e.target.value};set('keywords',kws)}}
                placeholder='Keyword value' style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
              <button onClick={()=>set('keywords',(d.keywords||[]).filter(k=>k.id!==kw.id))}
                style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={11}/></button>
            </div>
          ))}
          <button onClick={()=>set('keywords',[...(d.keywords||[]),{id:String(Date.now()),label:'',value:''}])}
            style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
            + Add Keyword
          </button>
        </FLabel>
        <FToggle value={d.caseSensitive||false} onChange={v=>set('caseSensitive',v)} label='Case Sensitive'/>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <InvalidFields d={d} set={set}/>
      </>
    )

    case 'ask_collection': return (
      <>
        <FLabel label="Question"><FRichTextarea value={d.question||''} onChange={v=>set('question',v)} rows={3}/></FLabel>
        <FLabel label="Catalog ID"><FInput value={d.catalogId||''} onChange={v=>set('catalogId',v)}/></FLabel>
        <FLabel label="Product Set ID"><FInput value={d.productSetId||''} onChange={v=>set('productSetId',v)}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'ask_form': return (
      <>
        <FLabel label="Form Title"><FInput value={d.title||''} onChange={v=>set('title',v)} placeholder='Please fill this form'/></FLabel>
        <FLabel label="Form Fields">
          {(d.fields||[]).map((f,i)=>(
            <div key={f.id} style={{ border:'1px solid #e5e7eb', borderRadius:6, padding:8, marginBottom:7 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                <span style={{ fontSize:10, fontWeight:700, color:'#9ca3af' }}>FIELD {i+1}</span>
                <button onClick={()=>set('fields',(d.fields||[]).filter(x=>x.id!==f.id))} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={11}/></button>
              </div>
              <input value={f.label} onChange={e=>{const fs=[...(d.fields||[])];fs[i]={...fs[i],label:e.target.value};set('fields',fs)}}
                placeholder='Label' style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'4px 7px', fontSize:12, marginBottom:3, boxSizing:'border-box' }}/>
              <select value={f.type} onChange={e=>{const fs=[...(d.fields||[])];fs[i]={...fs[i],type:e.target.value};set('fields',fs)}}
                style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'4px 7px', fontSize:12, marginBottom:3 }}>
                {['text','number','email','phone','date','select'].map(t=><option key={t} value={t}>{t}</option>)}
              </select>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <label style={{ display:'flex', alignItems:'center', gap:4, fontSize:12 }}>
                  <input type='checkbox' checked={f.required||false} onChange={e=>{const fs=[...(d.fields||[])];fs[i]={...fs[i],required:e.target.checked};set('fields',fs)}}/>
                  Required
                </label>
                <input value={f.saveAs||''} onChange={e=>{const fs=[...(d.fields||[])];fs[i]={...fs[i],saveAs:e.target.value};set('fields',fs)}}
                  placeholder='Save As {{variable}}'
                  style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'4px 7px', fontSize:12 }}/>
              </div>
            </div>
          ))}
          <button onClick={()=>set('fields',[...(d.fields||[]),{id:String(Date.now()),label:'',type:'text',required:true,saveAs:''}])}
            style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
            + Add Field
          </button>
        </FLabel>
        <FLabel label="Submit Button Label"><FInput value={d.submitLabel||'Submit'} onChange={v=>set('submitLabel',v)}/></FLabel>
      </>
    )

    case 'ask_payment': return (
      <>
        <FLabel label="Payment Gateway">
          <FSelect value={d.gateway||'razorpay'} onChange={v=>set('gateway',v)}
            options={[{v:'razorpay',l:'Razorpay'},{v:'stripe',l:'Stripe'},{v:'payu',l:'PayU'}]}/>
        </FLabel>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Amount"><FInput value={d.amount||''} onChange={v=>set('amount',v)} placeholder='0.00'/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Currency">
            <FSelect value={d.currency||'INR'} onChange={v=>set('currency',v)} options={[{v:'INR',l:'INR'},{v:'USD',l:'USD'},{v:'EUR',l:'EUR'},{v:'GBP',l:'GBP'},{v:'AED',l:'AED'}]}/>
          </FLabel></div>
        </div>
        <FLabel label="Description"><FInput value={d.description||''} onChange={v=>set('description',v)}/></FLabel>
        <div style={{ fontSize:12, fontWeight:600, marginBottom:6 }}>Collect from Customer</div>
        <FToggle value={d.askName||false} onChange={v=>set('askName',v)} label='Name'/>
        <FToggle value={d.askPhone||false} onChange={v=>set('askPhone',v)} label='Phone'/>
        <FToggle value={d.askEmail||false} onChange={v=>set('askEmail',v)} label='Email'/>
        <FLabel label="Save Payment ID As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    // ── ACTIONS ───────────────────────────────────────────────────────────────
    case 'assign': return (
      <>
        <FLabel label="Assign To">
          <FSelect value={d.assignTo||'agent'} onChange={v=>set('assignTo',v)}
            options={[{v:'agent',l:'Specific Agent'},{v:'team',l:'Team'},{v:'bot',l:'Bot Only'},{v:'round_robin',l:'Round Robin'}]}/>
        </FLabel>
        {d.assignTo==='agent' && <FLabel label="Agent ID"><FInput value={d.agentId||''} onChange={v=>set('agentId',v)}/></FLabel>}
        {d.assignTo==='team'  && <FLabel label="Team ID"><FInput value={d.teamId||''} onChange={v=>set('teamId',v)}/></FLabel>}
        <FLabel label="Handoff Message (optional)"><FTextarea value={d.handoffMsg||''} onChange={v=>set('handoffMsg',v)} rows={2}/></FLabel>
      </>
    )

    case 'unassign': return (
      <FLabel label="Handoff Message (optional)"><FTextarea value={d.handoffMsg||''} onChange={v=>set('handoffMsg',v)} rows={2}/></FLabel>
    )

    case 'resolve': return (
      <>
        <FToggle value={d.sendMsg||false} onChange={v=>set('sendMsg',v)} label='Send message before resolving'/>
        {d.sendMsg && <FLabel label="Resolve Message"><FTextarea value={d.resolveMsg||''} onChange={v=>set('resolveMsg',v)} rows={2}/></FLabel>}
      </>
    )

    case 'update_conv':    return <FLabel label="Conversation Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Field' valPlaceholder='Value'/></FLabel>
    case 'update_contact': return <FLabel label="Contact Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Field' valPlaceholder='Value'/></FLabel>
    case 'update_company': return <FLabel label="Company Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Field' valPlaceholder='Value'/></FLabel>

    case 'push_seq': return (
      <>
        <FLabel label="Sequence ID"><FInput value={d.sequenceId||''} onChange={v=>set('sequenceId',v)}/></FLabel>
        <FLabel label="Delay (minutes)"><FInput type='number' value={d.delayMinutes||0} onChange={v=>set('delayMinutes',+v)}/></FLabel>
      </>
    )

    case 'add_note': return (
      <FLabel label="Note Text"><FTextarea value={d.noteText||''} onChange={v=>set('noteText',v)} placeholder='Internal note...' rows={4}/></FLabel>
    )

    // ── UTILITIES ─────────────────────────────────────────────────────────────
    case 'delay': return (
      <>
        <FLabel label="Duration"><FInput type='number' value={d.duration||5} onChange={v=>set('duration',+v)}/></FLabel>
        <FLabel label="Unit">
          <FSelect value={d.unit||'seconds'} onChange={v=>set('unit',v)}
            options={[{v:'seconds',l:'Seconds'},{v:'minutes',l:'Minutes'},{v:'hours',l:'Hours'},{v:'days',l:'Days'}]}/>
        </FLabel>
      </>
    )

    case 'condition': return (
      <>
        <FLabel label="Variable"><FVarSelect value={d.variable||''} onChange={v=>set('variable',v)}/></FLabel>
        <FLabel label="Operator">
          <FSelect value={d.operator||'equals'} onChange={v=>set('operator',v)}
            options={[{v:'equals',l:'Equals'},{v:'not_equals',l:'Not Equals'},{v:'contains',l:'Contains'},{v:'not_contains',l:'Does Not Contain'},{v:'starts_with',l:'Starts With'},{v:'ends_with',l:'Ends With'},{v:'greater_than',l:'Greater Than'},{v:'less_than',l:'Less Than'},{v:'is_empty',l:'Is Empty'},{v:'is_not_empty',l:'Is Not Empty'}]}/>
        </FLabel>
        {!['is_empty','is_not_empty'].includes(d.operator) && <FLabel label="Value"><FInput value={d.value||''} onChange={v=>set('value',v)} placeholder='Compare value'/></FLabel>}
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="True Label"><FInput value={d.trueLabel||'Yes'} onChange={v=>set('trueLabel',v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="False Label"><FInput value={d.falseLabel||'No'} onChange={v=>set('falseLabel',v)}/></FLabel></div>
        </div>
      </>
    )

    case 'set_var': return (
      <>
        <FLabel label="Variable"><FVarSelect value={d.variable||''} onChange={v=>set('variable',v)}/></FLabel>
        <FLabel label="Value Type">
          <FSelect value={d.valueType||'static'} onChange={v=>set('valueType',v)}
            options={[{v:'static',l:'Static Value'},{v:'variable',l:'From Variable'},{v:'expression',l:'Expression'}]}/>
        </FLabel>
        <FLabel label="Value">
          {d.valueType==='variable'
            ? <FVarSelect value={d.value||''} onChange={v=>set('value',v)}/>
            : <FInput value={d.value||''} onChange={v=>set('value',v)} placeholder='Value'/>}
        </FLabel>
      </>
    )

    case 'jump': return (
      <FLabel label="Jump to Step (Node ID)"><FInput value={d.targetNodeId||''} onChange={v=>set('targetNodeId',v)} placeholder='Node ID'/></FLabel>
    )

    case 'switch_node': return (
      <>
        <FLabel label="Variable"><FVarSelect value={d.variable||''} onChange={v=>set('variable',v)}/></FLabel>
        <FLabel label="Cases">
          {(d.cases||[]).map((c,i)=>(
            <div key={c.id} style={{ display:'flex', gap:5, marginBottom:5, alignItems:'center' }}>
              <input value={c.value} onChange={e=>{const cs=[...(d.cases||[])];cs[i]={...cs[i],value:e.target.value};set('cases',cs)}}
                placeholder='When equals...' style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
              <input value={c.label} onChange={e=>{const cs=[...(d.cases||[])];cs[i]={...cs[i],label:e.target.value};set('cases',cs)}}
                placeholder='Branch label' style={{ flex:1, border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12 }}/>
              <button onClick={()=>set('cases',(d.cases||[]).filter(x=>x.id!==c.id))} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={11}/></button>
            </div>
          ))}
          <button onClick={()=>set('cases',[...(d.cases||[]),{id:String(Date.now()),value:'',label:`Case ${(d.cases||[]).length+1}`}])}
            style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
            + Add Case
          </button>
        </FLabel>
        <FLabel label="Default Branch Label"><FInput value={d.defaultLabel||'Default'} onChange={v=>set('defaultLabel',v)}/></FLabel>
      </>
    )

    case 'gpt_dialog': return (
      <>
        <FLabel label="Prompt" hint="Instructions guiding AI behavior">
          <FTextarea value={d.prompt||''} onChange={v=>set('prompt',v)} placeholder='You are a helpful assistant that...' rows={4}/>
        </FLabel>
        <FLabel label="User Message">
          <FInput value={d.userMessage||'{{intent.text}}'} onChange={v=>set('userMessage',v)} placeholder='{{intent.text}}'/>
        </FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Max Tokens"><FInput type='number' value={d.maxTokens||500} onChange={v=>set('maxTokens',+v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Temperature"><FInput type='number' value={d.temperature||0.7} onChange={v=>set('temperature',+v)}/></FLabel></div>
        </div>
        {/* Functions */}
        <div style={{ borderTop:'1px solid #f3f4f6', paddingTop:12, marginTop:4 }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#9ca3af', letterSpacing:1, marginBottom:9 }}>FUNCTIONS (DATA COLLECTION)</div>
          {(d.functions||[]).map((fn,fi)=>(
            <div key={fi} style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:9, marginBottom:8 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:7 }}>
                <span style={{ fontSize:11, fontWeight:700, color:'#6366f1' }}>Function {fi+1}</span>
                <button onClick={()=>set('functions',(d.functions||[]).filter((_,idx)=>idx!==fi))} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444' }}><X size={12}/></button>
              </div>
              <input value={fn.name||''} onChange={e=>{const fns=[...(d.functions||[])];fns[fi]={...fns[fi],name:e.target.value};set('functions',fns)}}
                placeholder='Function name' style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12, marginBottom:4, boxSizing:'border-box' }}/>
              <input value={fn.description||''} onChange={e=>{const fns=[...(d.functions||[])];fns[fi]={...fns[fi],description:e.target.value};set('functions',fns)}}
                placeholder='Function description' style={{ width:'100%', border:'1px solid #d1d5db', borderRadius:5, padding:'5px 7px', fontSize:12, marginBottom:6, boxSizing:'border-box' }}/>
              <div style={{ fontSize:10, fontWeight:700, color:'#9ca3af', marginBottom:5 }}>PARAMETERS</div>
              {(fn.params||[]).map((p,pi)=>(
                <div key={pi} style={{ display:'flex', gap:4, marginBottom:4, alignItems:'center' }}>
                  <input value={p.name||''} onChange={e=>{const fns=[...(d.functions||[])];fns[fi].params[pi]={...p,name:e.target.value};set('functions',fns)}}
                    placeholder='Name' style={{ flex:2, border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 6px', fontSize:11 }}/>
                  <select value={p.type||'string'} onChange={e=>{const fns=[...(d.functions||[])];fns[fi].params[pi]={...p,type:e.target.value};set('functions',fns)}}
                    style={{ flex:1, border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 6px', fontSize:11 }}>
                    <option value='string'>string</option>
                    <option value='number'>number</option>
                    <option value='boolean'>boolean</option>
                  </select>
                  <input value={p.storeAs||''} onChange={e=>{const fns=[...(d.functions||[])];fns[fi].params[pi]={...p,storeAs:e.target.value};set('functions',fns)}}
                    placeholder='Store in {{var}}' style={{ flex:2, border:'1px solid #e5e7eb', borderRadius:4, padding:'4px 6px', fontSize:11 }}/>
                  <button onClick={()=>{const fns=[...(d.functions||[])];fns[fi].params=fns[fi].params.filter((_,idx)=>idx!==pi);set('functions',fns)}}
                    style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:2 }}><X size={10}/></button>
                </div>
              ))}
              <button onClick={()=>{const fns=[...(d.functions||[])];if(!fns[fi].params)fns[fi].params=[];fns[fi].params.push({name:'',type:'string',storeAs:''});set('functions',fns)}}
                style={{ fontSize:10, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:4, padding:'3px 7px', cursor:'pointer', width:'100%' }}>
                + Add Parameter
              </button>
            </div>
          ))}
          <button onClick={()=>set('functions',[...(d.functions||[]),{name:'',description:'',params:[]}])}
            style={{ fontSize:11, color:'#6366f1', background:'none', border:'1px dashed #c7d2fe', borderRadius:5, padding:'4px 10px', cursor:'pointer', width:'100%' }}>
            + Add Function
          </button>
        </div>
      </>
    )

    case 'gpt_kb': return (
      <>
        <FLabel label="Knowledge Base ID"><FInput value={d.knowledgeBaseId||''} onChange={v=>set('knowledgeBaseId',v)}/></FLabel>
        <FLabel label="User Message"><FInput value={d.userMessage||'{{intent.text}}'} onChange={v=>set('userMessage',v)}/></FLabel>
        <FLabel label="Input Variables"><FInput value={d.inputVars||''} onChange={v=>set('inputVars',v)} placeholder='{{var1}}, {{var2}}'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <FLabel label="Max Tokens"><FInput type='number' value={d.maxTokens||500} onChange={v=>set('maxTokens',+v)}/></FLabel>
        <FLabel label="Fallback Message (when no answer)"><FTextarea value={d.fallbackMessage||''} onChange={v=>set('fallbackMessage',v)} rows={2}/></FLabel>
      </>
    )

    case 'working_hours': {
      const schedule = d.schedule || {}
      const updDay = (day,field,val) => set('schedule', { ...schedule, [day]:{ ...(schedule[day]||{}), [field]:val } })
      return (
        <>
          <FLabel label="Timezone">
            <FSelect value={d.timezone||'Asia/Kolkata'} onChange={v=>set('timezone',v)} options={TIMEZONES}/>
          </FLabel>
          <FLabel label="Schedule">
            <div style={{ border:'1px solid #e5e7eb', borderRadius:7, overflow:'hidden' }}>
              {DAYS.map(day=>{
                const ds = schedule[day] || { enabled:false, open:'09:00', close:'18:00' }
                return (
                  <div key={day} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderBottom:'1px solid #f3f4f6', background:ds.enabled?'#fff':'#fafafa' }}>
                    <FToggle value={ds.enabled} onChange={v=>updDay(day,'enabled',v)}/>
                    <span style={{ fontSize:12, fontWeight:600, width:36, color:ds.enabled?'#111827':'#9ca3af' }}>{DAY_LABELS[day]}</span>
                    {ds.enabled ? <>
                      <input type='time' value={ds.open||'09:00'} onChange={e=>updDay(day,'open',e.target.value)}
                        style={{ border:'1px solid #d1d5db', borderRadius:4, padding:'3px 5px', fontSize:12 }}/>
                      <span style={{ fontSize:12, color:'#6b7280' }}>–</span>
                      <input type='time' value={ds.close||'18:00'} onChange={e=>updDay(day,'close',e.target.value)}
                        style={{ border:'1px solid #d1d5db', borderRadius:4, padding:'3px 5px', fontSize:12 }}/>
                    </> : <span style={{ fontSize:11, color:'#9ca3af' }}>Closed</span>}
                  </div>
                )
              })}
            </div>
          </FLabel>
          <div style={{ display:'flex', gap:8 }}>
            <div style={{ flex:1 }}><FLabel label="Inside Hours Label"><FInput value={d.insideLabel||'Open'} onChange={v=>set('insideLabel',v)}/></FLabel></div>
            <div style={{ flex:1 }}><FLabel label="Outside Hours Label"><FInput value={d.outsideLabel||'Closed'} onChange={v=>set('outsideLabel',v)}/></FLabel></div>
          </div>
        </>
      )
    }

    case 'hint': return (
      <>
        <FLabel label="Hint Text"><FTextarea value={d.hintText||''} onChange={v=>set('hintText',v)} rows={3}/></FLabel>
        <FLabel label="Visible To">
          <FSelect value={d.visibleTo||'all'} onChange={v=>set('visibleTo',v)}
            options={[{v:'all',l:'All Agents'},{v:'assigned',l:'Assigned Agent Only'},{v:'admin',l:'Admin Only'}]}/>
        </FLabel>
      </>
    )

    case 'wait_order': return (
      <>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Timeout"><FInput type='number' value={d.timeoutDuration||24} onChange={v=>set('timeoutDuration',+v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Unit">
            <FSelect value={d.timeoutUnit||'hours'} onChange={v=>set('timeoutUnit',v)} options={[{v:'minutes',l:'Minutes'},{v:'hours',l:'Hours'},{v:'days',l:'Days'}]}/>
          </FLabel></div>
        </div>
        <FLabel label="Save Order ID As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    // ── CONNECTORS ────────────────────────────────────────────────────────────
    case 'sheets': return (
      <>
        <FLabel label="Spreadsheet ID"><FInput value={d.spreadsheetId||''} onChange={v=>set('spreadsheetId',v)}/></FLabel>
        <FLabel label="Sheet Name"><FInput value={d.sheetName||''} onChange={v=>set('sheetName',v)} placeholder='Sheet1'/></FLabel>
        <FLabel label="Operation">
          <FSelect value={d.operation||'append'} onChange={v=>set('operation',v)}
            options={[{v:'append',l:'Append Row'},{v:'update',l:'Update Row'},{v:'read',l:'Read Row'},{v:'delete',l:'Delete Row'}]}/>
        </FLabel>
        <FLabel label="Field Mapping"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Column' valPlaceholder='Value'/></FLabel>
      </>
    )

    case 'api': return (
      <>
        <FLabel label="Method">
          <FSelect value={d.method||'POST'} onChange={v=>set('method',v)} options={[{v:'GET',l:'GET'},{v:'POST',l:'POST'},{v:'PUT',l:'PUT'},{v:'PATCH',l:'PATCH'},{v:'DELETE',l:'DELETE'}]}/>
        </FLabel>
        <FLabel label="URL"><FInput value={d.url||''} onChange={v=>set('url',v)} placeholder='https://api.example.com/'/></FLabel>
        <FLabel label="Headers"><FKVList items={d.headers||[]} onChange={v=>set('headers',v)} keyPlaceholder='Header' valPlaceholder='Value' addLabel='Add Header'/></FLabel>
        <FLabel label="Body Type">
          <FSelect value={d.bodyType||'json'} onChange={v=>set('bodyType',v)} options={[{v:'json',l:'JSON'},{v:'form',l:'Form Data'},{v:'raw',l:'Raw'},{v:'none',l:'None'}]}/>
        </FLabel>
        {d.bodyType!=='none' && <FLabel label="Body"><FTextarea value={d.body||''} onChange={v=>set('body',v)} placeholder='{"key":"{{variable}}"}' rows={4}/></FLabel>}
        <FLabel label="Save Response Fields"><FKVList items={d.saveFields||[]} onChange={v=>set('saveFields',v)} keyPlaceholder='Variable' valPlaceholder='JSON path (data.id)' addLabel='Add Field'/></FLabel>
        <FLabel label="Save Full Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'razorpay': return (
      <>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Amount"><FInput value={d.amount||''} onChange={v=>set('amount',v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Currency"><FSelect value={d.currency||'INR'} onChange={v=>set('currency',v)} options={[{v:'INR',l:'INR'},{v:'USD',l:'USD'}]}/></FLabel></div>
        </div>
        <FLabel label="Description"><FInput value={d.description||''} onChange={v=>set('description',v)}/></FLabel>
        <FLabel label="Link Expiry (minutes)"><FInput type='number' value={d.expiry||15} onChange={v=>set('expiry',+v)}/></FLabel>
        <FLabel label="Customer Name"><FInput value={d.customerName||''} onChange={v=>set('customerName',v)} placeholder='{{recipient.name}}'/></FLabel>
        <FLabel label="Customer Phone"><FInput value={d.customerPhone||''} onChange={v=>set('customerPhone',v)} placeholder='{{recipient.phone}}'/></FLabel>
        <FLabel label="Customer Email"><FInput value={d.customerEmail||''} onChange={v=>set('customerEmail',v)} placeholder='{{recipient.email}}'/></FLabel>
        <FLabel label="Save Payment ID As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'zoho_crm': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'create'} onChange={v=>set('operation',v)} options={[{v:'create',l:'Create Record'},{v:'update',l:'Update Record'},{v:'search',l:'Search Records'},{v:'get',l:'Get Record'}]}/></FLabel>
        <FLabel label="Module"><FSelect value={d.module||'Leads'} onChange={v=>set('module',v)} options={[{v:'Leads',l:'Leads'},{v:'Contacts',l:'Contacts'},{v:'Deals',l:'Deals'},{v:'Accounts',l:'Accounts'}]}/></FLabel>
        <FLabel label="Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='CRM Field' valPlaceholder='Value'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'shopify': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'get_order'} onChange={v=>set('operation',v)} options={[{v:'get_order',l:'Get Order'},{v:'get_product',l:'Get Product'},{v:'get_customer',l:'Get Customer'},{v:'update_order',l:'Update Order'}]}/></FLabel>
        {['get_order','update_order'].includes(d.operation) && <FLabel label="Order ID"><FInput value={d.orderId||''} onChange={v=>set('orderId',v)} placeholder='{{order_id}}'/></FLabel>}
        {d.operation==='get_product' && <FLabel label="Product ID"><FInput value={d.productId||''} onChange={v=>set('productId',v)}/></FLabel>}
        {d.operation==='get_customer' && <FLabel label="Customer Email"><FInput value={d.customerEmail||''} onChange={v=>set('customerEmail',v)}/></FLabel>}
        {d.operation==='update_order' && <FLabel label="New Status"><FInput value={d.orderStatus||''} onChange={v=>set('orderStatus',v)}/></FLabel>}
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'hubspot': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'create_contact'} onChange={v=>set('operation',v)} options={[{v:'create_contact',l:'Create Contact'},{v:'update_contact',l:'Update Contact'},{v:'create_deal',l:'Create Deal'},{v:'get_contact',l:'Get Contact'}]}/></FLabel>
        <FLabel label="Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='HubSpot Property' valPlaceholder='Value'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'zoho_bigin': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'create'} onChange={v=>set('operation',v)} options={[{v:'create',l:'Create'},{v:'update',l:'Update'},{v:'get',l:'Get'}]}/></FLabel>
        <FLabel label="Module"><FSelect value={d.module||'Contacts'} onChange={v=>set('module',v)} options={[{v:'Contacts',l:'Contacts'},{v:'Pipelines',l:'Pipelines'},{v:'Companies',l:'Companies'}]}/></FLabel>
        <FLabel label="Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Field' valPlaceholder='Value'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'leadsquared': return (
      <>
        <FLabel label="Activity Event"><FInput value={d.activityEvent||''} onChange={v=>set('activityEvent',v)} placeholder='Activity event code'/></FLabel>
        <FLabel label="Lead Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='Schema Name' valPlaceholder='Value'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'woocommerce': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'get_order'} onChange={v=>set('operation',v)} options={[{v:'get_order',l:'Get Order'},{v:'get_product',l:'Get Product'},{v:'update_order_status',l:'Update Order Status'}]}/></FLabel>
        {['get_order','update_order_status'].includes(d.operation) && <FLabel label="Order ID"><FInput value={d.orderId||''} onChange={v=>set('orderId',v)} placeholder='{{order_id}}'/></FLabel>}
        {d.operation==='get_product' && <FLabel label="Product ID"><FInput value={d.productId||''} onChange={v=>set('productId',v)}/></FLabel>}
        {d.operation==='update_order_status' && <FLabel label="New Status"><FInput value={d.orderStatus||''} onChange={v=>set('orderStatus',v)}/></FLabel>}
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'openai_conn': return (
      <>
        <FLabel label="Prompt"><FTextarea value={d.prompt||''} onChange={v=>set('prompt',v)} rows={4}/></FLabel>
        <FLabel label="Model"><FSelect value={d.model||'gpt-4o-mini'} onChange={v=>set('model',v)} options={[{v:'gpt-4o-mini',l:'GPT-4o Mini'},{v:'gpt-4o',l:'GPT-4o'},{v:'gpt-4-turbo',l:'GPT-4 Turbo'},{v:'gpt-3.5-turbo',l:'GPT-3.5 Turbo'}]}/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ flex:1 }}><FLabel label="Max Tokens"><FInput type='number' value={d.maxTokens||500} onChange={v=>set('maxTokens',+v)}/></FLabel></div>
          <div style={{ flex:1 }}><FLabel label="Temperature"><FInput type='number' value={d.temperature||0.7} onChange={v=>set('temperature',+v)}/></FLabel></div>
        </div>
      </>
    )

    case 'zoom_conn': return (
      <>
        <FLabel label="Meeting Topic"><FInput value={d.topic||''} onChange={v=>set('topic',v)}/></FLabel>
        <FLabel label="Start Time"><FInput value={d.startTime||''} onChange={v=>set('startTime',v)} placeholder='{{user_date}} or ISO string'/></FLabel>
        <FLabel label="Duration (minutes)"><FInput type='number' value={d.duration||60} onChange={v=>set('duration',+v)}/></FLabel>
        <FLabel label="Save Join URL As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    case 'sangam': return (
      <>
        <FLabel label="Operation"><FSelect value={d.operation||'create_lead'} onChange={v=>set('operation',v)} options={[{v:'create_lead',l:'Create Lead'},{v:'update_lead',l:'Update Lead'},{v:'create_contact',l:'Create Contact'}]}/></FLabel>
        <FLabel label="Fields"><FKVList items={d.fields||[]} onChange={v=>set('fields',v)} keyPlaceholder='CRM Field' valPlaceholder='Value'/></FLabel>
        <FLabel label="Save Response As"><FVarSelect value={d.saveAs||''} onChange={v=>set('saveAs',v)}/></FLabel>
      </>
    )

    default: return <div style={{ color:'#9ca3af', fontSize:13 }}>No settings available.</div>
  }
}

// ─── NodeCard (canvas) ────────────────────────────────────────────────────────
function NodeCard({ node, selected, onSelect, onDragStart }) {
  const def = DEFS[node.type] || { label:node.type, icon:Zap, color:'#6366f1', cat:'system' }
  const Icon = def.icon
  const ports = getOutputPorts(node)

  return (
    <g transform={`translate(${node.x},${node.y})`} style={{ cursor:'grab', userSelect:'none' }}
      onMouseDown={e=>{ e.stopPropagation(); onDragStart(e, node.id) }}
      onClick={e=>{ e.stopPropagation(); onSelect(node.id) }}>

      {/* Drop shadow */}
      <rect x={2} y={4} width={NODE_W} height={NODE_H} rx={10} fill='rgba(0,0,0,0.07)'/>
      {/* Card bg */}
      <rect x={0} y={0} width={NODE_W} height={NODE_H} rx={10} fill='#fff'
        stroke={selected?'#6366f1':'#e5e7eb'} strokeWidth={selected?2:1}/>
      {/* Left color bar */}
      <rect x={0} y={0} width={5} height={NODE_H} rx={4} fill={def.color}/>
      <rect x={3} y={0} width={2} height={NODE_H} fill={def.color}/>
      {/* Icon */}
      <circle cx={30} cy={NODE_H/2} r={16} fill={def.color+'1a'}/>
      <foreignObject x={22} y={NODE_H/2-9} width={18} height={18}>
        <Icon size={16} color={def.color}/>
      </foreignObject>
      {/* Name */}
      <text x={55} y={NODE_H/2-7} fontSize={12} fontWeight={700} fill='#111827' dominantBaseline='middle'>
        {(node.data?.name||def.label).slice(0,20)}
      </text>
      <text x={55} y={NODE_H/2+9} fontSize={10} fill='#9ca3af' dominantBaseline='middle'>
        {def.label}
      </text>

      {/* Input port */}
      <circle cx={0} cy={NODE_H/2} r={PORT_R} fill='#fff' stroke='#d1d5db' strokeWidth={1.5}/>
      <circle cx={0} cy={NODE_H/2} r={3} fill='#9ca3af'/>

      {/* Output ports */}
      {ports.map((p,i)=>{
        const py = ports.length===1 ? NODE_H/2 : (NODE_H/(ports.length+1))*(i+1)
        return (
          <g key={i}>
            <circle cx={NODE_W} cy={py} r={PORT_R} fill={def.color} stroke='#fff' strokeWidth={1.5} style={{ cursor:'crosshair' }}/>
            <circle cx={NODE_W} cy={py} r={3} fill='#fff'/>
            {ports.length>1 && (
              <text x={NODE_W-10} y={py} fontSize={9} fill='#6b7280' textAnchor='end' dominantBaseline='middle'>
                {p.label.slice(0,14)}
              </text>
            )}
          </g>
        )
      })}
    </g>
  )
}

// ─── Node Picker ───────────────────────────────────────────────────────────────
function NodePicker({ onAdd, onClose, cardCount }) {
  const [q, setQ] = useState('')
  const [openCat, setOpenCat] = useState('send')

  const filtered = q ? Object.entries(DEFS).filter(([,d])=>d.label.toLowerCase().includes(q.toLowerCase())) : null
  const remaining = MAX_CARDS - cardCount

  return (
    <div style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', background:'rgba(0,0,0,0.35)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100 }}
      onClick={onClose}>
      <div style={{ background:'#fff', borderRadius:16, width:500, maxHeight:'82vh', display:'flex', flexDirection:'column', boxShadow:'0 24px 64px rgba(0,0,0,0.22)', overflow:'hidden' }}
        onClick={e=>e.stopPropagation()}>

        {/* Header */}
        <div style={{ padding:'14px 18px', borderBottom:'1px solid #f3f4f6', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ flex:1, position:'relative' }}>
            <Search size={14} style={{ position:'absolute', left:10, top:10, color:'#9ca3af' }}/>
            <input value={q} onChange={e=>setQ(e.target.value)} autoFocus placeholder='Search node types...'
              style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px 8px 32px', fontSize:13, outline:'none', boxSizing:'border-box' }}/>
          </div>
          {/* Card counter */}
          <div style={{ display:'flex', alignItems:'center', gap:5, fontSize:12, color: remaining<10?'#ef4444':'#6b7280', fontWeight:600, flexShrink:0 }}>
            <AlertCircle size={13} color={remaining<20?'#f59e0b':'#9ca3af'}/>
            {cardCount}/{MAX_CARDS}
          </div>
          <button onClick={onClose} style={{ border:'none', background:'#f3f4f6', borderRadius:7, padding:7, cursor:'pointer', display:'flex' }}><X size={14}/></button>
        </div>

        {/* List */}
        <div style={{ overflowY:'auto', flex:1 }}>
          {filtered ? (
            <div style={{ padding:'8px 12px' }}>
              {filtered.map(([type,def])=>{
                const Icon = def.icon
                return (
                  <div key={type} onClick={()=>{ if(cardCount<MAX_CARDS){onAdd(type);onClose()} }}
                    style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 10px', borderRadius:8, cursor: cardCount>=MAX_CARDS?'not-allowed':'pointer', marginBottom:2, opacity:cardCount>=MAX_CARDS?0.5:1 }}
                    onMouseEnter={e=>e.currentTarget.style.background='#f3f4f6'}
                    onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                    <div style={{ width:32, height:32, borderRadius:8, background:def.color+'1a', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                      <Icon size={15} color={def.color}/>
                    </div>
                    <div>
                      <div style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{def.label}</div>
                      <div style={{ fontSize:11, color:'#9ca3af' }}>{CAT_LABELS[def.cat]}</div>
                    </div>
                  </div>
                )
              })}
              {filtered.length===0 && <div style={{ padding:24, textAlign:'center', color:'#9ca3af', fontSize:13 }}>No nodes found</div>}
            </div>
          ) : (
            CAT_ORDER.map(cat=>{
              const nodes = Object.entries(DEFS).filter(([,d])=>d.cat===cat)
              const isOpen = openCat===cat
              return (
                <div key={cat}>
                  <div onClick={()=>setOpenCat(isOpen?null:cat)}
                    style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 16px', cursor:'pointer', borderBottom:'1px solid #f3f4f6' }}
                    onMouseEnter={e=>e.currentTarget.style.background='#f9fafb'}
                    onMouseLeave={e=>e.currentTarget.style.background=''}>
                    <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                      <div style={{ width:9, height:9, borderRadius:'50%', background:CAT_COLOR[cat]||'#6366f1' }}/>
                      <span style={{ fontSize:13, fontWeight:700, color:'#374151' }}>{CAT_LABELS[cat]}</span>
                      <span style={{ fontSize:11, color:'#9ca3af', background:'#f3f4f6', borderRadius:10, padding:'1px 7px' }}>{nodes.length}</span>
                    </div>
                    {isOpen ? <ChevronUp size={13} color='#6b7280'/> : <ChevronDown size={13} color='#6b7280'/>}
                  </div>
                  {isOpen && (
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:5, padding:'8px 12px', background:'#fafafa' }}>
                      {nodes.map(([type,def])=>{
                        const Icon = def.icon
                        return (
                          <div key={type} onClick={()=>{ if(cardCount<MAX_CARDS){onAdd(type);onClose()} }}
                            style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 10px', borderRadius:8, cursor:cardCount>=MAX_CARDS?'not-allowed':'pointer', background:'#fff', border:'1px solid #e5e7eb', opacity:cardCount>=MAX_CARDS?0.5:1 }}
                            onMouseEnter={e=>{ if(cardCount<MAX_CARDS) e.currentTarget.style.background='#f0f9ff' }}
                            onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                            <div style={{ width:28, height:28, borderRadius:7, background:def.color+'1a', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                              <Icon size={13} color={def.color}/>
                            </div>
                            <div style={{ fontSize:12, fontWeight:600, color:'#374151', lineHeight:1.3 }}>{def.label}</div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })
          )}
        </div>

        {/* Footer: card limit warning */}
        {cardCount >= MAX_CARDS && (
          <div style={{ padding:'10px 16px', background:'#fef2f2', borderTop:'1px solid #fecaca', display:'flex', alignItems:'center', gap:8 }}>
            <AlertTriangle size={14} color='#ef4444'/>
            <span style={{ fontSize:12, color:'#dc2626', fontWeight:600 }}>Card limit reached (100/100). Delete a card first.</span>
          </div>
        )}
        {cardCount >= 80 && cardCount < MAX_CARDS && (
          <div style={{ padding:'8px 16px', background:'#fffbeb', borderTop:'1px solid #fde68a', display:'flex', alignItems:'center', gap:8 }}>
            <AlertTriangle size={13} color='#f59e0b'/>
            <span style={{ fontSize:11, color:'#b45309' }}>{remaining} cards remaining before limit</span>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Node Editor Panel ────────────────────────────────────────────────────────
function NodeEditorPanel({ node, nodes, edges, onChange, onDelete, onDuplicate, onClose }) {
  const def = DEFS[node.type] || { label:node.type, icon:Zap, color:'#6366f1', cat:'system' }
  const Icon = def.icon
  const [tab, setTab] = useState('settings')
  const nameLen = (node.data?.name||'').length
  const NAME_MAX = 32

  return (
    <div style={{ width:340, height:'100%', background:'#fff', borderLeft:'1px solid #e5e7eb', display:'flex', flexDirection:'column', flexShrink:0, overflow:'hidden' }}>

      {/* Header with gradient */}
      <div style={{ background:CAT_BG[def.cat]||CAT_BG.system, padding:'14px 16px', color:'#fff' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ background:'rgba(255,255,255,0.2)', borderRadius:8, padding:6, display:'flex' }}>
              <Icon size={15} color='#fff'/>
            </div>
            <div>
              <div style={{ fontSize:13, fontWeight:700 }}>{def.label}</div>
              <div style={{ fontSize:10, opacity:0.75 }}>{CAT_LABELS[def.cat]}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ border:'none', background:'rgba(255,255,255,0.2)', color:'#fff', borderRadius:6, padding:5, cursor:'pointer', display:'flex' }}>
            <X size={13}/>
          </button>
        </div>
        {/* Node name — 32 char limit */}
        <div style={{ position:'relative' }}>
          <input value={node.data?.name||''} maxLength={NAME_MAX}
            onChange={e=>onChange({ ...node, data:{ ...node.data, name:e.target.value } })}
            placeholder='Step name...'
            style={{ width:'100%', border:'none', background:'rgba(255,255,255,0.18)', color:'#fff', borderRadius:8, padding:'7px 36px 7px 10px', fontSize:13, outline:'none', boxSizing:'border-box' }}/>
          <span style={{ position:'absolute', right:8, top:8, fontSize:10, color: nameLen>=NAME_MAX?'#fca5a5':'rgba(255,255,255,0.6)' }}>
            {nameLen}/{NAME_MAX}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', borderBottom:'1px solid #e5e7eb' }}>
        {['settings','connections'].map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{ flex:1, border:'none', background:'none', padding:'9px 0', fontSize:12, fontWeight:600,
              color:tab===t?'#6366f1':'#6b7280', borderBottom:tab===t?'2px solid #6366f1':'2px solid transparent', cursor:'pointer' }}>
            {t.charAt(0).toUpperCase()+t.slice(1)}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{ flex:1, overflowY:'auto', padding:14 }}>
        {tab==='settings' && <EditForm node={node} onChange={onChange}/>}
        {tab==='connections' && (
          <div>
            <div style={{ fontSize:11, fontWeight:700, color:'#374151', marginBottom:8 }}>INCOMING</div>
            {edges.filter(e=>e.toId===node.id).length===0
              ? <div style={{ color:'#9ca3af', fontSize:12, marginBottom:16 }}>None</div>
              : edges.filter(e=>e.toId===node.id).map(e=>{
                  const src=nodes.find(n=>n.id===e.fromId)
                  return <div key={e.id} style={{ padding:'6px 10px', background:'#f9fafb', borderRadius:7, marginBottom:5, fontSize:12 }}>← {src?.data?.name||src?.type||e.fromId}</div>
                })}
            <div style={{ fontSize:11, fontWeight:700, color:'#374151', marginBottom:8, marginTop:14 }}>OUTGOING</div>
            {edges.filter(e=>e.fromId===node.id).length===0
              ? <div style={{ color:'#9ca3af', fontSize:12 }}>None</div>
              : edges.filter(e=>e.fromId===node.id).map(e=>{
                  const tgt=nodes.find(n=>n.id===e.toId)
                  return <div key={e.id} style={{ padding:'6px 10px', background:'#f9fafb', borderRadius:7, marginBottom:5, fontSize:12 }}>→ {tgt?.data?.name||tgt?.type||e.toId}</div>
                })}
          </div>
        )}
      </div>

      {/* Actions */}
      <div style={{ borderTop:'1px solid #f3f4f6', padding:'10px 14px', display:'flex', gap:8 }}>
        <button onClick={onDuplicate}
          style={{ flex:1, border:'1px solid #e5e7eb', background:'#fff', borderRadius:8, padding:'7px 0', fontSize:12, fontWeight:600, color:'#374151', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:5 }}>
          <Copy size={12}/> Duplicate
        </button>
        <button onClick={onDelete}
          style={{ flex:1, border:'1px solid #fee2e2', background:'#fff', borderRadius:8, padding:'7px 0', fontSize:12, fontWeight:600, color:'#ef4444', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:5 }}>
          <Trash2 size={12}/> Delete
        </button>
      </div>
    </div>
  )
}

// ─── Minimap ──────────────────────────────────────────────────────────────────
function Minimap({ nodes, edges, viewBox }) {
  const W=160, H=100, pad=50
  const allX=nodes.map(n=>n.x), allY=nodes.map(n=>n.y)
  const minX=Math.min(...allX,0)-pad, maxX=Math.max(...allX,800)+pad+NODE_W
  const minY=Math.min(...allY,0)-pad, maxY=Math.max(...allY,600)+pad+NODE_H
  const scale=Math.min(W/(maxX-minX), H/(maxY-minY))
  return (
    <div style={{ position:'absolute', bottom:20, right:20, background:'rgba(255,255,255,0.96)', borderRadius:10, boxShadow:'0 2px 12px rgba(0,0,0,0.12)', border:'1px solid #e5e7eb', overflow:'hidden' }}>
      <svg width={W} height={H}>
        {edges.map(e=>{
          const from=nodes.find(n=>n.id===e.fromId), to=nodes.find(n=>n.id===e.toId)
          if(!from||!to) return null
          return <path key={e.id} d={bezier((from.x+NODE_W-minX)*scale,(from.y+NODE_H/2-minY)*scale,(to.x-minX)*scale,(to.y+NODE_H/2-minY)*scale)} stroke='#cbd5e1' strokeWidth={1} fill='none'/>
        })}
        {nodes.map(n=>{
          const def=DEFS[n.type]||{}
          return <rect key={n.id} x={(n.x-minX)*scale} y={(n.y-minY)*scale} width={NODE_W*scale} height={NODE_H*scale} rx={2} fill={def.color||'#6366f1'} opacity={0.7}/>
        })}
        {viewBox && <rect x={(viewBox.x-minX)*scale} y={(viewBox.y-minY)*scale} width={viewBox.w*scale} height={viewBox.h*scale} rx={2} fill='none' stroke='#6366f1' strokeWidth={1.5}/>}
      </svg>
    </div>
  )
}

// ─── WhatsApp Test Preview ────────────────────────────────────────────────────
function WaPreview({ nodes, edges, onClose }) {
  const [step, setStep] = useState(0)
  const start = nodes.find(n=>n.type==='start')
  const flow = []
  if (start) {
    let cur=start, seen=new Set()
    while(cur&&!seen.has(cur.id)&&flow.length<15){
      seen.add(cur.id); flow.push(cur)
      const edge=edges.find(e=>e.fromId===cur.id&&e.fromPort===0)
      if(!edge) break
      cur=nodes.find(n=>n.id===edge.toId)
    }
  }
  const cur = flow[Math.min(step, flow.length-1)]

  const renderMsg = (node) => {
    if (!node) return null
    const d=node.data||{}
    const bubble = (txt, btns=null) => (
      <div>
        <div style={{ background:'#dcf8c6', borderRadius:'8px 8px 8px 2px', padding:'8px 12px', fontSize:13, maxWidth:220, wordBreak:'break-word', marginBottom:btns?4:0 }}>
          {txt||'...'}
        </div>
        {btns && btns.map((b,i)=>(
          <div key={i} style={{ background:'#fff', border:'1px solid #25d366', borderRadius:8, padding:'6px 12px', fontSize:13, textAlign:'center', marginBottom:3, color:'#075e54', fontWeight:600, cursor:'pointer' }}>
            {b.label||`Option ${i+1}`}
          </div>
        ))}
      </div>
    )
    switch(node.type){
      case 'text':       return bubble(d.message)
      case 'media':      return bubble(`📎 ${d.mediaType||'media'}${d.caption?' — '+d.caption:''}`)
      case 'ask_text':   return bubble(d.question)
      case 'ask_number': return bubble(d.question)
      case 'ask_phone':  return bubble(d.question)
      case 'ask_email':  return bubble(d.question)
      case 'ask_date':   return bubble(d.question)
      case 'ask_location':return bubble(d.question)
      case 'ask_url':    return bubble(d.question)
      case 'ask_file':   return bubble(d.question)
      case 'ask_button': return bubble(d.question, d.buttons)
      case 'send_buttons':return bubble(d.bodyText, d.buttons)
      case 'ask_list':
      case 'send_list':
        return (
          <div>
            <div style={{ background:'#dcf8c6', borderRadius:'8px 8px 8px 2px', padding:'8px 12px', fontSize:13, marginBottom:4 }}>{d.question||d.bodyText||'...'}</div>
            <div style={{ background:'#fff', border:'1px solid #25d366', borderRadius:8, padding:'6px 12px', fontSize:13, textAlign:'center', color:'#075e54', fontWeight:600 }}>☰ {d.buttonLabel||'View Options'}</div>
          </div>
        )
      case 'template':   return bubble(`📋 Template: ${d.templateName||'(none)'}`)
      case 'end':        return <div style={{ background:'#f3f4f6', borderRadius:8, padding:'8px 12px', fontSize:12, color:'#6b7280', textAlign:'center' }}>⏹ Flow ended{d.endMessage&&': '+d.endMessage}</div>
      default:           return <div style={{ background:'#f3f4f6', borderRadius:8, padding:'8px 12px', fontSize:11, color:'#9ca3af' }}>[{node.type}]</div>
    }
  }

  return (
    <div style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', background:'rgba(0,0,0,0.4)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100 }}
      onClick={onClose}>
      <div style={{ background:'#fff', borderRadius:20, width:320, overflow:'hidden', boxShadow:'0 24px 64px rgba(0,0,0,0.25)' }}
        onClick={e=>e.stopPropagation()}>
        {/* WA header */}
        <div style={{ background:'#075e54', padding:'12px 16px', color:'#fff', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontWeight:700, fontSize:14 }}>Test Bot Preview</div>
            <div style={{ fontSize:11, opacity:0.75 }}>WhatsApp Simulator</div>
          </div>
          <button onClick={onClose} style={{ border:'none', background:'rgba(255,255,255,0.15)', borderRadius:6, padding:5, cursor:'pointer', color:'#fff', display:'flex' }}><X size={14}/></button>
        </div>
        {/* Chat area */}
        <div style={{ background:'#e5ddd5', minHeight:320, padding:16, maxHeight:420, overflowY:'auto', backgroundImage:"url(\"data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40' fill='%23d4c9b0' fill-opacity='0.1'/%3E%3C/svg%3E\")" }}>
          {flow.map((node,i)=>(
            <div key={node.id} style={{ marginBottom:12, opacity:i<=step?1:0.2, transition:'opacity 0.3s' }}>
              <div style={{ fontSize:9, color:'#6b7280', marginBottom:3, textAlign:'right' }}>{node.data?.name||node.type}</div>
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                {renderMsg(node)}
              </div>
            </div>
          ))}
        </div>
        {/* Nav */}
        <div style={{ background:'#fff', padding:'10px 16px', display:'flex', alignItems:'center', gap:8, borderTop:'1px solid #e5e7eb' }}>
          <button onClick={()=>setStep(s=>Math.max(0,s-1))} disabled={step===0}
            style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'6px 10px', cursor:'pointer', opacity:step===0?0.4:1, display:'flex' }}>
            <ChevronLeft size={14}/>
          </button>
          <div style={{ flex:1, textAlign:'center', fontSize:12, color:'#6b7280' }}>
            Step {step+1} / {flow.length||1}
          </div>
          <button onClick={()=>setStep(s=>Math.min((flow.length||1)-1,s+1))} disabled={step>=(flow.length||1)-1}
            style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'6px 10px', cursor:'pointer', opacity:step>=(flow.length||1)-1?0.4:1, display:'flex' }}>
            <ChevronRight size={14}/>
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Publish Modal ────────────────────────────────────────────────────────────
function PublishModal({ nodes, edges, onConfirm, onClose }) {
  const errors = []
  const startNodes = nodes.filter(n=>n.type==='start')
  if (startNodes.length===0) errors.push('No Start node found')
  if (startNodes.length>1)  errors.push('Multiple Start nodes — only one allowed')
  nodes.forEach(n=>{
    if (n.type==='end') return
    const out=edges.filter(e=>e.fromId===n.id)
    if(out.length===0&&n.type!=='end') errors.push(`"${n.data?.name||n.type}" has no outgoing connection`)
  })

  return (
    <div style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', background:'rgba(0,0,0,0.4)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 }}
      onClick={onClose}>
      <div style={{ background:'#fff', borderRadius:16, width:440, padding:24, boxShadow:'0 24px 64px rgba(0,0,0,0.2)' }}
        onClick={e=>e.stopPropagation()}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
          <div style={{ width:40, height:40, background:errors.length?'#fee2e2':'#dcfce7', borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center' }}>
            {errors.length ? <AlertTriangle size={20} color='#dc2626'/> : <Check size={20} color='#16a34a'/>}
          </div>
          <div>
            <div style={{ fontSize:16, fontWeight:700, color:'#111827' }}>{errors.length?'Validation Errors':'Ready to Publish'}</div>
            <div style={{ fontSize:12, color:'#6b7280' }}>{errors.length?'Fix errors before publishing':'Your flow looks good!'}</div>
          </div>
        </div>
        {errors.length>0 && (
          <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:8, padding:12, marginBottom:16 }}>
            {errors.map((e,i)=>(
              <div key={i} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:i<errors.length-1?6:0 }}>
                <AlertCircle size={12} color='#ef4444'/>
                <span style={{ fontSize:12, color:'#dc2626' }}>{e}</span>
              </div>
            ))}
          </div>
        )}
        <div style={{ fontSize:12, color:'#6b7280', marginBottom:18 }}>
          {nodes.length} cards · {edges.length} connections
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <button onClick={onClose} style={{ flex:1, border:'1px solid #e5e7eb', background:'#fff', borderRadius:9, padding:'10px 0', fontSize:14, fontWeight:600, color:'#374151', cursor:'pointer' }}>
            Cancel
          </button>
          <button onClick={errors.length?undefined:onConfirm} disabled={errors.length>0}
            style={{ flex:2, border:'none', background:errors.length?'#d1d5db':'#6366f1', color:'#fff', borderRadius:9, padding:'10px 0', fontSize:14, fontWeight:700, cursor:errors.length?'not-allowed':'pointer' }}>
            {errors.length ? 'Fix Errors First' : '🚀 Publish Flow'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main FlowSetup ───────────────────────────────────────────────────────────
export default function FlowSetup() {
  const [nodes,      setNodes]      = useState(DEMO_NODES)
  const [edges,      setEdges]      = useState(DEMO_EDGES)
  const [selectedId, setSelectedId] = useState(null)
  const [showPicker, setShowPicker] = useState(false)
  const [showTestBot,setShowTestBot]= useState(false)
  const [showPublish,setShowPublish]= useState(false)
  const [published,  setPublished]  = useState(false)
  const [locked,     setLocked]     = useState(false)
  const [flowName,   setFlowName]   = useState('New Flow')
  const [editName,   setEditName]   = useState(false)
  const [zoom,       setZoom]       = useState(1)
  const [pan,        setPan]        = useState({ x:60, y:60 })
  const [dragging,   setDragging]   = useState(null)
  const [panning,    setPanning]    = useState(false)
  const [panStart,   setPanStart]   = useState({ x:0, y:0 })
  const [mousePos,   setMousePos]   = useState({ x:0, y:0 })
  const [history,    setHistory]    = useState([{ nodes:DEMO_NODES, edges:DEMO_EDGES }])
  const [histIdx,    setHistIdx]    = useState(0)
  const svgRef = useRef(null)
  const svgWrapRef = useRef(null)

  const selectedNode = nodes.find(n=>n.id===selectedId)

  // ── History ──────────────────────────────────────────────────────────────────
  const pushHistory = useCallback((nn, ne) => {
    setHistory(h => [...h.slice(0,histIdx+1), { nodes:nn, edges:ne }].slice(-30))
    setHistIdx(i => Math.min(i+1, 29))
  }, [histIdx])

  const applyHistory = useCallback((newNodes, newEdges) => {
    setNodes(newNodes); setEdges(newEdges); pushHistory(newNodes, newEdges)
  }, [pushHistory])

  const undo = useCallback(() => {
    if (histIdx<=0) return
    const idx=histIdx-1; setHistIdx(idx); setNodes(history[idx].nodes); setEdges(history[idx].edges)
  }, [history, histIdx])

  const redo = useCallback(() => {
    if (histIdx>=history.length-1) return
    const idx=histIdx+1; setHistIdx(idx); setNodes(history[idx].nodes); setEdges(history[idx].edges)
  }, [history, histIdx])

  // ── Keyboard ─────────────────────────────────────────────────────────────────
  useEffect(() => {
    const h = e => {
      if ((e.metaKey||e.ctrlKey)&&e.key==='z'&&!e.shiftKey) { e.preventDefault(); undo() }
      if ((e.metaKey||e.ctrlKey)&&(e.key==='y'||(e.key==='z'&&e.shiftKey))) { e.preventDefault(); redo() }
      if ((e.key==='Delete'||e.key==='Backspace')&&selectedId) {
        if(document.activeElement.tagName==='INPUT'||document.activeElement.tagName==='TEXTAREA') return
        if (!locked) {
          const nn=nodes.filter(n=>n.id!==selectedId)
          const ne=edges.filter(e=>e.fromId!==selectedId&&e.toId!==selectedId)
          applyHistory(nn,ne); setSelectedId(null)
        }
      }
      if (e.key==='Escape') { setSelectedId(null); setShowPicker(false) }
    }
    window.addEventListener('keydown',h)
    return ()=>window.removeEventListener('keydown',h)
  }, [undo, redo, selectedId, nodes, edges, applyHistory, locked])

  // ── SVG coords ───────────────────────────────────────────────────────────────
  const toCanvas = useCallback((cx,cy) => {
    const rect=svgRef.current?.getBoundingClientRect()
    if(!rect) return {x:0,y:0}
    return { x:(cx-rect.left-pan.x)/zoom, y:(cy-rect.top-pan.y)/zoom }
  }, [pan, zoom])

  // ── Drag node ────────────────────────────────────────────────────────────────
  const startDrag = useCallback((e,nodeId) => {
    if (locked) return
    const pt=toCanvas(e.clientX,e.clientY)
    const node=nodes.find(n=>n.id===nodeId)
    setDragging({ nodeId, ox:pt.x-node.x, oy:pt.y-node.y })
  }, [nodes, toCanvas, locked])

  // ── Mouse move ───────────────────────────────────────────────────────────────
  const onSvgMouseMove = useCallback((e) => {
    const pt=toCanvas(e.clientX,e.clientY)
    setMousePos(pt)
    if (dragging) {
      setNodes(ns=>ns.map(n=>n.id===dragging.nodeId?{...n,x:pt.x-dragging.ox,y:pt.y-dragging.oy}:n))
    }
    if (panning) {
      setPan({ x:e.clientX-panStart.x, y:e.clientY-panStart.y })
    }
  }, [dragging, panning, panStart, toCanvas])

  const onSvgMouseDown = useCallback((e) => {
    if (e.target===svgRef.current||e.target.tagName==='svg') {
      setPanning(true)
      setPanStart({ x:e.clientX-pan.x, y:e.clientY-pan.y })
      setSelectedId(null)
    }
  }, [pan])

  const onSvgMouseUp = useCallback(() => {
    if (dragging) { pushHistory(nodes,edges); setDragging(null) }
    setPanning(false)
  }, [dragging, nodes, edges, pushHistory])

  // ── Wheel zoom ───────────────────────────────────────────────────────────────
  const onWheel = useCallback((e) => {
    e.preventDefault()
    setZoom(z=>Math.min(2.5,Math.max(0.25,z*(e.deltaY<0?1.1:0.9))))
  }, [])

  useEffect(() => {
    const el=svgRef.current; if(!el) return
    el.addEventListener('wheel',onWheel,{passive:false})
    return ()=>el.removeEventListener('wheel',onWheel)
  }, [onWheel])

  // ── Add node ─────────────────────────────────────────────────────────────────
  const addNode = useCallback((type) => {
    if (nodes.length>=MAX_CARDS) return
    const n={ id:uid(), type, x:(-pan.x+400)/zoom, y:(-pan.y+250)/zoom, data:makeDefaults(type) }
    const nn=[...nodes,n]
    applyHistory(nn,edges); setSelectedId(n.id)
  }, [nodes, edges, pan, zoom, applyHistory])

  // ── Update node ──────────────────────────────────────────────────────────────
  const updateNode = useCallback((updated) => {
    const nn=nodes.map(n=>n.id===updated.id?updated:n)
    setNodes(nn); pushHistory(nn,edges)
  }, [nodes, edges, pushHistory])

  // ── Delete / Duplicate ───────────────────────────────────────────────────────
  const deleteNode = useCallback((id) => {
    if (locked) return
    const nn=nodes.filter(n=>n.id!==id)
    const ne=edges.filter(e=>e.fromId!==id&&e.toId!==id)
    applyHistory(nn,ne); setSelectedId(null)
  }, [nodes, edges, applyHistory, locked])

  const duplicateNode = useCallback((id) => {
    if (nodes.length>=MAX_CARDS) return
    const src=nodes.find(n=>n.id===id); if(!src) return
    const n={...src,id:uid(),x:src.x+40,y:src.y+40,data:{...src.data,name:(src.data?.name||'')+' Copy'}}
    const nn=[...nodes,n]; applyHistory(nn,edges); setSelectedId(n.id)
  }, [nodes, edges, applyHistory])

  // ── Beautify Flow ─────────────────────────────────────────────────────────────
  const beautifyFlow = useCallback(() => {
    if (locked) return
    const COL_GAP=280, ROW_GAP=120
    const start=nodes.find(n=>n.type==='start')
    if(!start) return
    const positioned={}, levels={}
    const queue=[{id:start.id,col:0,row:0}]
    const colRows={}
    while(queue.length>0){
      const {id,col,row}=queue.shift()
      if(positioned[id]) continue
      positioned[id]={col,row}
      if(!colRows[col]) colRows[col]=[]
      colRows[col].push(id)
      const outEdges=edges.filter(e=>e.fromId===id)
      outEdges.forEach((e,i)=>{ if(!positioned[e.toId]) queue.push({id:e.toId,col:col+1,row:i}) })
    }
    // position remaining unconnected nodes
    let col=0
    nodes.forEach(n=>{ if(!positioned[n.id]){ positioned[n.id]={col:col++,row:0} } })
    const nn=nodes.map(n=>{
      const pos=positioned[n.id]||{col:0,row:0}
      return {...n, x:60+pos.col*COL_GAP, y:60+pos.row*ROW_GAP}
    })
    applyHistory(nn,edges)
  }, [nodes, edges, applyHistory, locked])

  // ── Fit to screen ────────────────────────────────────────────────────────────
  const fitScreen = useCallback(() => {
    if (!svgRef.current||nodes.length===0) return
    const rect=svgRef.current.getBoundingClientRect()
    const minX=Math.min(...nodes.map(n=>n.x))-40
    const minY=Math.min(...nodes.map(n=>n.y))-40
    const maxX=Math.max(...nodes.map(n=>n.x+NODE_W))+40
    const maxY=Math.max(...nodes.map(n=>n.y+NODE_H))+40
    const scaleX=rect.width/(maxX-minX)
    const scaleY=rect.height/(maxY-minY)
    const newZoom=Math.min(scaleX,scaleY,2)
    setZoom(newZoom)
    setPan({ x:-minX*newZoom+20, y:-minY*newZoom+20 })
  }, [nodes])

  // ── Publish ───────────────────────────────────────────────────────────────────
  const handlePublish = () => {
    setPublished(true)
    setShowPublish(false)
    setTimeout(()=>setPublished(false), 3000)
  }

  // ── Edge paths ────────────────────────────────────────────────────────────────
  const edgePaths = useMemo(()=>edges.map(e=>{
    const from=nodes.find(n=>n.id===e.fromId), to=nodes.find(n=>n.id===e.toId)
    if(!from||!to) return null
    const ports=getOutputPorts(from)
    const pi=e.fromPort||0
    const py=ports.length<=1?NODE_H/2:(NODE_H/(ports.length+1))*(pi+1)
    return {...e, path:bezier(from.x+NODE_W,from.y+py,to.x,to.y+NODE_H/2)}
  }).filter(Boolean), [nodes,edges])

  const cardCount=nodes.length
  const cardPct=cardCount/MAX_CARDS
  const cardColor=cardPct>=1?'#ef4444':cardPct>=0.8?'#f59e0b':'#10b981'

  return (
    <div style={{ height:'100vh', display:'flex', flexDirection:'column', background:'#f8fafc', fontFamily:'Inter,system-ui,sans-serif' }}>

      {/* ── TOP BAR ── */}
      <div style={{ height:54, background:'#fff', borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', padding:'0 14px', gap:8, flexShrink:0, zIndex:10 }}>

        {/* Flow name */}
        {editName
          ? <input autoFocus value={flowName} onChange={e=>setFlowName(e.target.value)}
              onBlur={()=>setEditName(false)} onKeyDown={e=>e.key==='Enter'&&setEditName(false)}
              style={{ fontSize:14, fontWeight:700, border:'1px solid #6366f1', borderRadius:6, padding:'4px 10px', outline:'none', maxWidth:180 }}/>
          : <div onClick={()=>setEditName(true)} style={{ display:'flex', alignItems:'center', gap:5, cursor:'pointer', fontSize:14, fontWeight:700, color:'#111827' }}>
              {flowName} <Edit3 size={11} color='#9ca3af'/>
            </div>}

        <div style={{ flex:1 }}/>

        {/* Card counter */}
        <div style={{ display:'flex', alignItems:'center', gap:6, border:'1px solid #e5e7eb', borderRadius:7, padding:'4px 10px' }}>
          <div style={{ width:40, height:5, background:'#e5e7eb', borderRadius:3, overflow:'hidden' }}>
            <div style={{ width:`${cardPct*100}%`, height:'100%', background:cardColor, transition:'width 0.3s' }}/>
          </div>
          <span style={{ fontSize:11, fontWeight:700, color:cardColor }}>{cardCount}/{MAX_CARDS}</span>
        </div>

        {/* Undo / Redo */}
        <button onClick={undo} disabled={histIdx<=0} title='Undo (⌘Z)'
          style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'5px 9px', cursor:'pointer', opacity:histIdx<=0?0.4:1, display:'flex', alignItems:'center', gap:4, fontSize:12, color:'#374151' }}>
          ↩ Undo
        </button>
        <button onClick={redo} disabled={histIdx>=history.length-1} title='Redo (⌘Y)'
          style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'5px 9px', cursor:'pointer', opacity:histIdx>=history.length-1?0.4:1, display:'flex', alignItems:'center', gap:4, fontSize:12, color:'#374151' }}>
          ↪ Redo
        </button>

        {/* Zoom */}
        <div style={{ display:'flex', alignItems:'center', border:'1px solid #e5e7eb', borderRadius:7, overflow:'hidden' }}>
          <button onClick={()=>setZoom(z=>Math.max(0.25,z-0.1))} style={{ border:'none', background:'#fff', padding:'5px 9px', cursor:'pointer', display:'flex' }}><ZoomOut size={13}/></button>
          <span style={{ fontSize:11, fontWeight:700, color:'#374151', minWidth:38, textAlign:'center' }}>{Math.round(zoom*100)}%</span>
          <button onClick={()=>setZoom(z=>Math.min(2.5,z+0.1))} style={{ border:'none', background:'#fff', padding:'5px 9px', cursor:'pointer', display:'flex' }}><ZoomIn size={13}/></button>
        </div>

        {/* Fit Screen */}
        <button onClick={fitScreen} title='Fit to Screen'
          style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'5px 9px', cursor:'pointer', display:'flex', alignItems:'center', gap:4, fontSize:12, color:'#374151' }}>
          <Maximize2 size={13}/> Fit
        </button>

        {/* Beautify */}
        <button onClick={beautifyFlow} title='Auto-arrange cards'
          style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'5px 9px', cursor:'pointer', display:'flex', alignItems:'center', gap:4, fontSize:12, color:'#374151' }}>
          <Sparkles size={13}/> Beautify
        </button>

        {/* Lock */}
        <button onClick={()=>setLocked(l=>!l)} title={locked?'Unlock canvas':'Lock canvas'}
          style={{ border:'1px solid #e5e7eb', background:locked?'#fef3c7':'#fff', borderRadius:7, padding:'5px 9px', cursor:'pointer', display:'flex', alignItems:'center', gap:4, fontSize:12, color:locked?'#b45309':'#374151' }}>
          {locked ? <Lock size={13}/> : <Unlock size={13}/>}
          {locked ? 'Locked' : 'Lock'}
        </button>

        {/* Test Bot */}
        <button onClick={()=>setShowTestBot(true)}
          style={{ border:'1px solid #10b981', background:'#f0fdf4', borderRadius:7, padding:'5px 12px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:12, fontWeight:600, color:'#065f46' }}>
          <Play size={13}/> Test Bot
        </button>

        {/* Add Node */}
        <button onClick={()=>setShowPicker(true)}
          style={{ border:'none', background:'#6366f1', color:'#fff', borderRadius:7, padding:'6px 13px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600 }}>
          <Plus size={14}/> Add Node
        </button>

        {/* Publish */}
        <button onClick={()=>setShowPublish(true)}
          style={{ border:'none', background:published?'#10b981':'#111827', color:'#fff', borderRadius:7, padding:'6px 15px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:13, fontWeight:700, transition:'background 0.3s' }}>
          {published ? <><Check size={14}/> Published</> : <><Rocket size={14}/> Publish</>}
        </button>
      </div>

      {/* ── CANVAS AREA ── */}
      <div style={{ flex:1, display:'flex', overflow:'hidden' }}>

        {/* SVG Canvas */}
        <div ref={svgWrapRef} style={{ flex:1, position:'relative', overflow:'hidden' }}>
          {/* Dot grid */}
          <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }}>
            <defs>
              <pattern id='dots' x={pan.x%24} y={pan.y%24} width={24*zoom} height={24*zoom} patternUnits='userSpaceOnUse'>
                <circle cx={0} cy={0} r={1} fill='#d1d5db' opacity={0.5}/>
              </pattern>
            </defs>
            <rect width='100%' height='100%' fill='url(#dots)'/>
          </svg>

          {/* Locked banner */}
          {locked && (
            <div style={{ position:'absolute', top:10, left:'50%', transform:'translateX(-50%)', background:'#fffbeb', border:'1px solid #fde68a', borderRadius:8, padding:'6px 14px', fontSize:12, fontWeight:600, color:'#92400e', zIndex:10, display:'flex', alignItems:'center', gap:6 }}>
              <Lock size={12}/> View-Only Mode — Canvas is locked
            </div>
          )}

          {/* Main SVG */}
          <svg ref={svgRef} style={{ position:'absolute', inset:0, width:'100%', height:'100%', cursor:panning?'grabbing':locked?'default':'default' }}
            onMouseDown={onSvgMouseDown} onMouseMove={onSvgMouseMove}
            onMouseUp={onSvgMouseUp} onMouseLeave={onSvgMouseUp}>
            <defs>
              <marker id='arr' markerWidth={10} markerHeight={7} refX={8} refY={3.5} orient='auto'>
                <polygon points='0 0,10 3.5,0 7' fill='#94a3b8'/>
              </marker>
              <marker id='arr-sel' markerWidth={10} markerHeight={7} refX={8} refY={3.5} orient='auto'>
                <polygon points='0 0,10 3.5,0 7' fill='#6366f1'/>
              </marker>
            </defs>
            <g transform={`translate(${pan.x},${pan.y}) scale(${zoom})`}>
              {/* Edges */}
              {edgePaths.map(e=>{
                const hl=e.fromId===selectedId||e.toId===selectedId
                return <path key={e.id} d={e.path} stroke={hl?'#6366f1':'#94a3b8'} strokeWidth={(hl?2:1.5)/zoom} fill='none' markerEnd={hl?'url(#arr-sel)':'url(#arr)'}/>
              })}
              {/* Nodes */}
              {nodes.map(n=>(
                <NodeCard key={n.id} node={n} selected={n.id===selectedId}
                  onSelect={setSelectedId} onDragStart={startDrag}/>
              ))}
            </g>
          </svg>

          {/* Minimap */}
          <Minimap nodes={nodes} edges={edges} viewBox={{ x:-pan.x/zoom, y:-pan.y/zoom, w:1200/zoom, h:800/zoom }}/>

          {/* Empty state */}
          {nodes.length===0 && (
            <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', pointerEvents:'none' }}>
              <div style={{ fontSize:52, marginBottom:14 }}>🔗</div>
              <div style={{ fontSize:18, fontWeight:700, color:'#374151' }}>Start building your flow</div>
              <div style={{ fontSize:14, color:'#9ca3af', marginTop:6 }}>Click "Add Node" to add your first card</div>
            </div>
          )}

          {/* Node Picker */}
          {showPicker && <NodePicker onAdd={addNode} onClose={()=>setShowPicker(false)} cardCount={cardCount}/>}

          {/* Test Bot Modal */}
          {showTestBot && <WaPreview nodes={nodes} edges={edges} onClose={()=>setShowTestBot(false)}/>}

          {/* Publish Modal */}
          {showPublish && <PublishModal nodes={nodes} edges={edges} onConfirm={handlePublish} onClose={()=>setShowPublish(false)}/>}
        </div>

        {/* Node Editor Panel */}
        {selectedNode && (
          <NodeEditorPanel
            node={selectedNode} nodes={nodes} edges={edges}
            onChange={updateNode}
            onDelete={()=>deleteNode(selectedId)}
            onDuplicate={()=>duplicateNode(selectedId)}
            onClose={()=>setSelectedId(null)}/>
        )}
      </div>
    </div>
  )
}
