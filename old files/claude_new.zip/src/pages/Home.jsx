import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar,
} from 'recharts'
import {
  MessageSquare, Users, CheckCircle2, Clock, TrendingUp, TrendingDown,
  ArrowRight, Bot, UserCheck, Radio, GitBranch,
  CalendarCheck, IndianRupee, MoreHorizontal, Zap,
  Activity, RefreshCw, Send, PhoneCall, AlertCircle,
  ChevronRight, Eye,
} from 'lucide-react'
import { STATS, MESSAGE_VOLUME, TOP_FLOWS, RECENT_ACTIVITY } from '../constants/mockData'
import { useApp } from '../context/AppContext'
import clsx from 'clsx'

const ICON_MAP = {
  MessageSquare, Users, CheckCircle2, Clock, IndianRupee, CalendarCheck, PhoneCall,
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white border border-surface-border rounded-lg p-3 shadow-modal text-xs">
      <p className="font-medium text-slate-600 mb-1.5">{label}</p>
      {payload.map(p => (
        <div key={p.name} className="flex items-center gap-2 mt-0.5">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-slate-500">{p.name}:</span>
          <span className="font-semibold text-slate-800">{p.value.toLocaleString()}</span>
        </div>
      ))}
    </div>
  )
}

// Open / pending conversation statuses
const CONVO_STATUS = [
  { label: 'Open',       value: 43,  color: 'bg-primary',     text: 'text-primary',     bg: 'bg-primary-50',   icon: MessageSquare },
  { label: 'Bot Active', value: 18,  color: 'bg-purple-500',  text: 'text-purple-600',  bg: 'bg-purple-50',    icon: Bot },
  { label: 'Waiting',    value: 11,  color: 'bg-amber-400',   text: 'text-amber-600',   bg: 'bg-amber-50',     icon: Clock },
  { label: 'Resolved Today', value: 218, color: 'bg-emerald-500', text: 'text-emerald-600', bg: 'bg-emerald-50', icon: CheckCircle2 },
]

const TEAM = [
  { name: 'Rahul Mehta',   avatar: 'RM', role: 'Senior Agent', assigned: 14, resolved: 11, avgReply: '2.1m', status: 'online'  },
  { name: 'Priya Das',     avatar: 'PD', role: 'Agent',        assigned: 9,  resolved: 8,  avgReply: '3.4m', status: 'online'  },
  { name: 'Aryan Kapoor',  avatar: 'AK', role: 'Agent',        assigned: 7,  resolved: 5,  avgReply: '5.2m', status: 'busy'   },
  { name: 'Sunita Rao',    avatar: 'SR', role: 'Agent',        assigned: 6,  resolved: 6,  avgReply: '1.8m', status: 'offline' },
]

const BROADCASTS = [
  { name: 'Flash Sale — April',   sent: 3204, delivered: 96, read: 74, replied: 12, date: 'Apr 15' },
  { name: 'Welcome Series D1',    sent: 1102, delivered: 98, read: 81, replied: 9,  date: 'Apr 14' },
  { name: 'Order Confirmation',   sent: 892,  delivered: 99, read: 91, replied: 4,  date: 'Apr 13' },
  { name: 'Re-engagement Drip',   sent: 2100, delivered: 89, read: 52, replied: 7,  date: 'Apr 12' },
]

const STATUS_DOT = {
  online:  'bg-emerald-400',
  busy:    'bg-amber-400',
  offline: 'bg-slate-300',
}

export default function Home() {
  const navigate = useNavigate()
  const { user } = useApp()
  const [dateRange, setDateRange] = useState('30d')

  const statRows = [
    { label: 'Messages Sent',  value: '24,821', trend: '+12.4%', up: true,  icon: 'MessageSquare', color: 'blue'    },
    { label: 'Total Contacts', value: '1,204',  trend: '+8.1%',  up: true,  icon: 'Users',         color: 'green'   },
    { label: 'Delivery Rate',  value: '98.2%',  trend: '-0.3%',  up: false, icon: 'CheckCircle2',  color: 'emerald' },
    { label: 'Avg Response',   value: '3.2 min',trend: '▲ 0.8m', up: false, icon: 'Clock',         color: 'amber'   },
    { label: 'Revenue',        value: '₹12,430',trend: '+22.1%', up: true,  icon: 'IndianRupee',   color: 'purple'  },
    { label: 'Appointments',   value: '127',    trend: '+31%',   up: true,  icon: 'CalendarCheck', color: 'cyan'    },
  ]

  const colorMap = {
    blue:    'bg-primary-50 text-primary',
    green:   'bg-emerald-50 text-emerald-600',
    amber:   'bg-amber-50 text-amber-600',
    purple:  'bg-purple-50 text-purple-600',
    cyan:    'bg-cyan-50 text-cyan-600',
    emerald: 'bg-emerald-50 text-emerald-600',
  }

  return (
    <div className="space-y-5 animate-fade-in">

      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-primary to-blue-700 rounded-xl p-5 flex items-center justify-between text-white overflow-hidden relative">
        <div className="relative z-10">
          <h2 className="text-lg font-bold">Good morning, {user.name.split(' ')[0]}! 👋</h2>
          <p className="text-blue-100 text-sm mt-0.5">Here's your WhatsApp business overview for today.</p>
          <div className="flex items-center gap-3 mt-3">
            <button onClick={() => navigate('/broadcasting')} className="bg-white text-primary text-xs font-semibold px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors flex items-center gap-1.5">
              <Radio size={13} /> Send Broadcast
            </button>
            <button onClick={() => navigate('/flows')} className="bg-white/20 text-white text-xs font-medium px-4 py-2 rounded-lg hover:bg-white/30 transition-colors flex items-center gap-1.5">
              <GitBranch size={13} /> Create Flow
            </button>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-6 relative z-10">
          <div className="text-center">
            <p className="text-3xl font-bold">{user.creditBalance.toLocaleString()}</p>
            <p className="text-blue-200 text-xs mt-0.5">Credits Remaining</p>
          </div>
          <div className="w-px h-12 bg-white/20" />
          <div className="text-center">
            <p className="text-3xl font-bold">3</p>
            <p className="text-blue-200 text-xs mt-0.5">Agents Online</p>
          </div>
          <div className="w-px h-12 bg-white/20" />
          <div className="text-center">
            <p className="text-3xl font-bold">43</p>
            <p className="text-blue-200 text-xs mt-0.5">Open Chats</p>
          </div>
        </div>
        <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-white/5" />
        <div className="absolute -right-4 -bottom-8 w-28 h-28 rounded-full bg-white/5" />
      </div>

      {/* Conversation Status Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {CONVO_STATUS.map(s => {
          const Icon = s.icon
          return (
            <button
              key={s.label}
              onClick={() => navigate('/conversations')}
              className="card p-4 flex items-center gap-3 hover:border-primary/30 hover:shadow-md transition-all text-left"
            >
              <div className={clsx('w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0', s.bg)}>
                <Icon size={18} className={s.text} />
              </div>
              <div>
                <p className={clsx('text-2xl font-bold', s.text)}>{s.value}</p>
                <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
              </div>
            </button>
          )
        })}
      </div>

      {/* KPI stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {statRows.map(stat => {
          const Icon = ICON_MAP[stat.icon]
          return (
            <div key={stat.label} className="stat-card hover:border-primary/20 transition-all">
              <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center mb-3', colorMap[stat.color])}>
                {Icon && <Icon size={15} />}
              </div>
              <p className="text-xl font-bold text-slate-900">{stat.value}</p>
              <p className="text-xs text-slate-500 mt-0.5">{stat.label}</p>
              <div className={clsx('flex items-center gap-1 mt-2 text-xs font-medium', stat.up ? 'text-emerald-600' : 'text-red-500')}>
                {stat.up ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                <span>{stat.trend}</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Chart + Resolution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="section-title">Conversation Volume</h3>
              <p className="section-sub">Incoming vs outgoing messages</p>
            </div>
            <select
              value={dateRange}
              onChange={e => setDateRange(e.target.value)}
              className="input-sm w-auto border border-surface-border rounded-lg px-2 py-1 text-xs"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={MESSAGE_VOLUME} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gOut" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0066ff" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#0066ff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gIn" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.12} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} interval={6} />
              <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="outgoing" name="Outgoing" stroke="#0066ff" strokeWidth={2} fill="url(#gOut)" dot={false} />
              <Area type="monotone" dataKey="incoming" name="Incoming" stroke="#10b981" strokeWidth={2} fill="url(#gIn)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card p-5">
          <div className="mb-3">
            <h3 className="section-title">Resolution Breakdown</h3>
            <p className="section-sub">How conversations are resolved</p>
          </div>
          <div className="space-y-3 mt-4">
            {[
              { label: 'Bot Resolved',   value: 72, color: 'bg-primary',      text: 'text-primary',      icon: Bot },
              { label: 'Agent Resolved', value: 21, color: 'bg-emerald-500',  text: 'text-emerald-600',  icon: UserCheck },
              { label: 'Pending',        value: 7,  color: 'bg-amber-400',    text: 'text-amber-600',    icon: Clock },
            ].map(item => {
              const Icon = item.icon
              return (
                <div key={item.label}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <Icon size={12} className={item.text} />
                      <span className="text-slate-600 font-medium">{item.label}</span>
                    </div>
                    <span className={clsx('font-bold', item.text)}>{item.value}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className={clsx('h-full rounded-full', item.color)} style={{ width: `${item.value}%` }} />
                  </div>
                </div>
              )
            })}
          </div>
          <div className="mt-4 pt-4 border-t border-surface-border grid grid-cols-2 gap-2">
            {[
              { label: 'Open',         value: '43',    color: 'text-primary' },
              { label: 'Resolved',     value: '218',   color: 'text-emerald-600' },
              { label: 'Bot Rate',     value: '72%',   color: 'text-purple-600' },
              { label: 'CSAT',         value: '4.6/5', color: 'text-amber-600' },
            ].map(s => (
              <div key={s.label} className="text-center py-2 bg-surface rounded-lg">
                <p className={clsx('text-base font-bold', s.color)}>{s.value}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team Performance + Recent Broadcasts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Team Performance */}
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
            <div>
              <h3 className="section-title">Team Performance</h3>
              <p className="section-sub">Agent activity today</p>
            </div>
            <button onClick={() => navigate('/analytics')} className="btn-ghost text-xs text-primary">
              View All <ArrowRight size={12} />
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr>
                {['Agent', 'Assigned', 'Resolved', 'Avg Reply', 'Status'].map(h => (
                  <th key={h} className="table-header">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {TEAM.map(agent => (
                <tr key={agent.name} className="table-row">
                  <td className="table-cell">
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <div className="w-7 h-7 rounded-full bg-primary-50 flex items-center justify-center text-xs font-bold text-primary">
                          {agent.avatar}
                        </div>
                        <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', STATUS_DOT[agent.status])} />
                      </div>
                      <div>
                        <p className="text-xs font-medium text-slate-800">{agent.name}</p>
                        <p className="text-[10px] text-slate-400">{agent.role}</p>
                      </div>
                    </div>
                  </td>
                  <td className="table-cell text-center font-semibold text-slate-700">{agent.assigned}</td>
                  <td className="table-cell text-center font-semibold text-emerald-600">{agent.resolved}</td>
                  <td className="table-cell text-center text-slate-500 text-xs">{agent.avgReply}</td>
                  <td className="table-cell">
                    <span className={clsx('badge text-[10px]', {
                      'badge-green': agent.status === 'online',
                      'badge-amber': agent.status === 'busy',
                      'badge-gray':  agent.status === 'offline',
                    })}>
                      {agent.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Recent Broadcasts */}
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
            <div>
              <h3 className="section-title">Recent Broadcasts</h3>
              <p className="section-sub">Latest campaign performance</p>
            </div>
            <button onClick={() => navigate('/broadcasting')} className="btn-ghost text-xs text-primary">
              View All <ArrowRight size={12} />
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr>
                {['Campaign', 'Sent', 'Delivered', 'Read', 'Date'].map(h => (
                  <th key={h} className="table-header">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {BROADCASTS.map(b => (
                <tr key={b.name} className="table-row">
                  <td className="table-cell">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-primary-50 flex items-center justify-center flex-shrink-0">
                        <Radio size={13} className="text-primary" />
                      </div>
                      <p className="text-xs font-medium text-slate-800 truncate max-w-[130px]">{b.name}</p>
                    </div>
                  </td>
                  <td className="table-cell text-slate-700 font-medium">{b.sent.toLocaleString()}</td>
                  <td className="table-cell">
                    <div className="flex items-center gap-1.5">
                      <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${b.delivered}%` }} />
                      </div>
                      <span className="text-xs text-slate-600">{b.delivered}%</span>
                    </div>
                  </td>
                  <td className="table-cell">
                    <div className="flex items-center gap-1.5">
                      <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${b.read}%` }} />
                      </div>
                      <span className="text-xs text-slate-600">{b.read}%</span>
                    </div>
                  </td>
                  <td className="table-cell text-slate-400 text-xs">{b.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

      {/* Recent Activity + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Recent Conversations */}
        <div className="lg:col-span-2 card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
            <div>
              <h3 className="section-title">Recent Conversations</h3>
              <p className="section-sub">Latest open chats needing attention</p>
            </div>
            <button onClick={() => navigate('/conversations')} className="btn-ghost text-xs text-primary">
              Open Inbox <ArrowRight size={12} />
            </button>
          </div>
          <div className="divide-y divide-surface-border">
            {[
              { name: 'Priya Sharma',  phone: '+91 98765 43210', msg: 'Hello! I need help with my order #3821', time: '2 min ago',  status: 'bot',    tags: ['vip', 'order-issue'], unread: 3 },
              { name: 'Rahul Mehta',   phone: '+91 82341 09876', msg: 'What are your pricing plans?',           time: '1 hr ago',   status: 'agent',  tags: ['lead'],              unread: 1 },
              { name: 'Anita Kapoor',  phone: '+91 91234 56789', msg: 'My appointment is confirmed. Thanks!',   time: '3 hrs ago',  status: 'resolved',tags: ['appointment'],      unread: 0 },
              { name: 'Vikram Singh',  phone: '+91 77890 12345', msg: 'Can I get a refund?',                    time: '5 hrs ago',  status: 'agent',  tags: ['refund'],            unread: 0 },
            ].map(c => (
              <div key={c.name} onClick={() => navigate('/conversations')} className="flex items-center gap-3 px-5 py-3.5 hover:bg-surface-hover transition-colors cursor-pointer">
                <div className="w-9 h-9 rounded-full bg-primary-50 flex items-center justify-center text-sm font-bold text-primary flex-shrink-0">
                  {c.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-900 truncate">{c.name}</p>
                    {c.tags.map(t => (
                      <span key={t} className="badge badge-blue text-[10px] hidden sm:inline-flex">#{t}</span>
                    ))}
                  </div>
                  <p className="text-xs text-slate-500 truncate mt-0.5">{c.msg}</p>
                </div>
                <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                  <p className="text-[10px] text-slate-400">{c.time}</p>
                  <span className={clsx('badge text-[10px]', {
                    'badge-blue':  c.status === 'bot',
                    'badge-green': c.status === 'agent',
                    'badge-gray':  c.status === 'resolved',
                  })}>
                    {c.status}
                  </span>
                </div>
                {c.unread > 0 && (
                  <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
                    {c.unread}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-3">
          <div className="card p-5">
            <h3 className="section-title mb-3">Quick Actions</h3>
            <div className="space-y-2">
              {[
                { label: 'New Broadcast',    icon: Radio,      path: '/broadcasting', color: 'bg-primary-50 text-primary',       desc: 'Send to contacts' },
                { label: 'Create Flow',      icon: GitBranch,  path: '/flows',        color: 'bg-purple-50 text-purple-600',     desc: 'Automate responses' },
                { label: 'Add Contact',      icon: Users,      path: '/contacts',     color: 'bg-emerald-50 text-emerald-600',   desc: 'Import or add' },
                { label: 'New Template',     icon: MessageSquare, path: '/templates', color: 'bg-amber-50 text-amber-600',      desc: 'Create template' },
              ].map(a => {
                const Icon = a.icon
                return (
                  <button
                    key={a.label}
                    onClick={() => navigate(a.path)}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-surface-border hover:border-primary/30 hover:bg-surface-hover transition-all text-left"
                  >
                    <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0', a.color)}>
                      <Icon size={15} />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-800">{a.label}</p>
                      <p className="text-[10px] text-slate-400">{a.desc}</p>
                    </div>
                    <ChevronRight size={14} className="ml-auto text-slate-300" />
                  </button>
                )
              })}
            </div>
          </div>

          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="section-title">Recent Activity</h3>
              <Activity size={13} className="text-slate-400" />
            </div>
            <div className="space-y-2.5">
              {RECENT_ACTIVITY.slice(0, 4).map(a => (
                <div key={a.id} className="flex items-start gap-2.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-slate-700 leading-relaxed">{a.text}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{a.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
