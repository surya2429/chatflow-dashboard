import { useState } from 'react'
import {
  Search, Plus, Upload, Download, Filter, MoreVertical,
  Mail, Phone, Tag, Trash2, Edit3, User, ChevronDown,
  CheckSquare, Square, Users, X, Check,
} from 'lucide-react'
import clsx from 'clsx'

const SAMPLE_CONTACTS = [
  { id: '1', name: 'Priya Sharma',  phone: '+91 98765 43210', email: 'priya@example.com', tags: ['vip', 'order-issue'], status: 'active', source: 'WhatsApp', lastContact: 'Apr 15', optIn: true },
  { id: '2', name: 'Rahul Mehta',   phone: '+91 82341 09876', email: 'rahul@example.com', tags: ['lead'],              status: 'active', source: 'Import',   lastContact: 'Apr 14', optIn: true },
  { id: '3', name: 'Anita Kapoor',  phone: '+91 91234 56789', email: 'anita@example.com', tags: ['appointment'],       status: 'active', source: 'WhatsApp', lastContact: 'Apr 13', optIn: true },
  { id: '4', name: 'Vikram Singh',  phone: '+91 77890 12345', email: 'vikram@example.com',tags: ['refund'],            status: 'blocked',source: 'WhatsApp', lastContact: 'Apr 12', optIn: false },
  { id: '5', name: 'Meera Joshi',   phone: '+91 88001 23456', email: 'meera@example.com', tags: ['satisfied'],         status: 'active', source: 'CSV',      lastContact: 'Apr 10', optIn: true },
  { id: '6', name: 'Arjun Nair',    phone: '+91 99100 23456', email: 'arjun@example.com', tags: ['lead','vip'],        status: 'active', source: 'API',      lastContact: 'Apr 9',  optIn: true },
  { id: '7', name: 'Kavya Reddy',   phone: '+91 87654 32109', email: 'kavya@example.com', tags: ['customer'],          status: 'active', source: 'WhatsApp', lastContact: 'Apr 8',  optIn: true },
  { id: '8', name: 'Suresh Babu',   phone: '+91 76543 21098', email: 'suresh@example.com',tags: ['lead'],              status: 'active', source: 'Import',   lastContact: 'Apr 7',  optIn: true },
]

const ALL_TAGS = ['vip', 'lead', 'customer', 'refund', 'appointment', 'satisfied', 'order-issue']

function ImportModal({ onClose }) {
  const [step, setStep] = useState(1)
  const [dragging, setDragging] = useState(false)
  const [file, setFile] = useState(null)

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-modal animate-fade-in">
        <div className="flex items-center justify-between p-5 border-b border-surface-border">
          <h3 className="font-semibold text-slate-900">Import Contacts</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        <div className="p-5">
          {/* Steps */}
          <div className="flex items-center gap-2 mb-5">
            {['Upload File', 'Map Fields', 'Import'].map((s, i) => (
              <div key={s} className="flex items-center gap-2 flex-1">
                <div className={clsx(
                  'w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                  step > i + 1 ? 'bg-emerald-500 text-white' : step === i + 1 ? 'bg-primary text-white' : 'bg-slate-100 text-slate-400'
                )}>
                  {step > i + 1 ? <Check size={12} /> : i + 1}
                </div>
                <span className={clsx('text-xs font-medium', step === i + 1 ? 'text-slate-800' : 'text-slate-400')}>{s}</span>
                {i < 2 && <div className="flex-1 h-0.5 bg-slate-100 ml-2" />}
              </div>
            ))}
          </div>

          {step === 1 && (
            <div>
              <div
                onDragOver={e => { e.preventDefault(); setDragging(true) }}
                onDragLeave={() => setDragging(false)}
                onDrop={e => { e.preventDefault(); setDragging(false); setFile(e.dataTransfer.files[0]) }}
                className={clsx(
                  'border-2 border-dashed rounded-xl p-8 text-center transition-colors',
                  dragging ? 'border-primary bg-primary-50' : file ? 'border-emerald-400 bg-emerald-50' : 'border-slate-200 hover:border-primary/40'
                )}
              >
                {file ? (
                  <>
                    <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3">
                      <Check size={22} className="text-emerald-600" />
                    </div>
                    <p className="font-medium text-emerald-700 text-sm">{file.name}</p>
                    <p className="text-xs text-emerald-500 mt-0.5">Ready to import</p>
                  </>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
                      <Upload size={22} className="text-slate-400" />
                    </div>
                    <p className="font-medium text-slate-700 text-sm">Drop your CSV file here</p>
                    <p className="text-xs text-slate-400 mt-1">or click to browse</p>
                    <input type="file" accept=".csv,.xlsx" className="hidden" onChange={e => setFile(e.target.files[0])} id="file-upload" />
                    <label htmlFor="file-upload" className="inline-block mt-3 btn-primary text-xs cursor-pointer">Browse File</label>
                  </>
                )}
              </div>
              <div className="mt-3 p-3 rounded-lg bg-slate-50 border border-surface-border">
                <p className="text-xs font-medium text-slate-700 mb-1">Required columns:</p>
                <p className="text-xs text-slate-500">name, phone (with country code), email (optional), tags (optional)</p>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500">Map your CSV columns to contact fields</p>
              {[
                { csv: 'Full Name',    field: 'name' },
                { csv: 'Mobile No',   field: 'phone' },
                { csv: 'Email ID',    field: 'email' },
                { csv: 'Category',    field: 'tags' },
              ].map(m => (
                <div key={m.csv} className="flex items-center gap-3">
                  <div className="flex-1 p-2.5 rounded-lg bg-slate-50 border border-surface-border text-xs text-slate-600 font-mono">{m.csv}</div>
                  <span className="text-slate-400 text-xs">→</span>
                  <select className="flex-1 input text-xs">
                    <option value={m.field}>{m.field}</option>
                    <option>name</option>
                    <option>phone</option>
                    <option>email</option>
                    <option>tags</option>
                    <option>— Skip —</option>
                  </select>
                </div>
              ))}
            </div>
          )}

          {step === 3 && (
            <div className="text-center py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                <Check size={28} className="text-emerald-600" />
              </div>
              <p className="font-bold text-slate-900 text-lg">Import Successful!</p>
              <p className="text-sm text-slate-500 mt-1">247 contacts imported, 3 skipped (duplicates)</p>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[['247', 'Imported'], ['3', 'Skipped'], ['0', 'Failed']].map(([val, lbl]) => (
                  <div key={lbl} className="p-3 rounded-lg bg-slate-50 border border-surface-border">
                    <p className="text-xl font-bold text-slate-900">{val}</p>
                    <p className="text-xs text-slate-500">{lbl}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-2 p-5 border-t border-surface-border">
          {step > 1 && step < 3 && (
            <button onClick={() => setStep(s => s - 1)} className="btn-secondary flex-1 justify-center">Back</button>
          )}
          {step < 3 ? (
            <button
              onClick={() => setStep(s => s + 1)}
              disabled={step === 1 && !file}
              className="btn-primary flex-1 justify-center"
            >
              {step === 2 ? 'Import Contacts' : 'Continue'}
            </button>
          ) : (
            <button onClick={onClose} className="btn-primary flex-1 justify-center">Done</button>
          )}
        </div>
      </div>
    </div>
  )
}

function AddContactModal({ onClose }) {
  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-modal animate-fade-in">
        <div className="flex items-center justify-between p-5 border-b border-surface-border">
          <h3 className="font-semibold text-slate-900">Add Contact</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-3">
          <div className="form-group">
            <label className="label">Full Name *</label>
            <input className="input" placeholder="Enter full name" />
          </div>
          <div className="form-group">
            <label className="label">WhatsApp Number *</label>
            <div className="flex gap-2">
              <select className="input w-24 flex-shrink-0"><option>+91</option><option>+1</option><option>+44</option></select>
              <input className="input" placeholder="98765 43210" />
            </div>
          </div>
          <div className="form-group">
            <label className="label">Email</label>
            <input type="email" className="input" placeholder="email@example.com" />
          </div>
          <div className="form-group">
            <label className="label">Labels</label>
            <div className="flex flex-wrap gap-1.5 p-2 rounded-lg border border-surface-border bg-white min-h-[36px]">
              {['vip', 'lead', 'customer'].map(t => (
                <span key={t} className="badge badge-blue cursor-pointer"># {t} <X size={9} className="ml-0.5" /></span>
              ))}
              <input className="text-xs outline-none flex-1 min-w-[60px] placeholder-slate-400" placeholder="Add label..." />
            </div>
          </div>
          <div className="form-group">
            <label className="label">Opt-in Status</label>
            <div className="flex gap-2">
              {['Opted In', 'Opted Out'].map(s => (
                <label key={s} className="flex items-center gap-2 flex-1 p-2.5 rounded-lg border border-surface-border cursor-pointer hover:bg-surface-hover text-xs">
                  <input type="radio" name="optin" className="accent-primary" defaultChecked={s === 'Opted In'} />
                  {s}
                </label>
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-2 p-5 border-t border-surface-border">
          <button onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
          <button className="btn-primary flex-1 justify-center"><Plus size={14} /> Add Contact</button>
        </div>
      </div>
    </div>
  )
}

export default function Contacts() {
  const [search, setSearch] = useState('')
  const [selectedTag, setSelectedTag] = useState('all')
  const [selected, setSelected] = useState([])
  const [showImport, setShowImport] = useState(false)
  const [showAdd, setShowAdd] = useState(false)

  const filtered = SAMPLE_CONTACTS.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.phone.includes(search)
    const matchTag = selectedTag === 'all' || c.tags.includes(selectedTag)
    return matchSearch && matchTag
  })

  function toggleSelect(id) {
    setSelected(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id])
  }

  function toggleAll() {
    setSelected(prev => prev.length === filtered.length ? [] : filtered.map(c => c.id))
  }

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Contacts</h1>
          <p className="text-xs text-slate-500 mt-0.5">{SAMPLE_CONTACTS.length} total contacts · {SAMPLE_CONTACTS.filter(c => c.optIn).length} opted in</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowImport(true)} className="btn-secondary">
            <Upload size={14} /> Import CSV
          </button>
          <button className="btn-secondary">
            <Download size={14} /> Export
          </button>
          <button onClick={() => setShowAdd(true)} className="btn-primary">
            <Plus size={14} /> Add Contact
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total', value: SAMPLE_CONTACTS.length, color: 'text-primary', bg: 'bg-primary-50' },
          { label: 'Opted In', value: SAMPLE_CONTACTS.filter(c => c.optIn).length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'New This Month', value: 84, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Blocked', value: SAMPLE_CONTACTS.filter(c => c.status === 'blocked').length, color: 'text-red-500', bg: 'bg-red-50' },
        ].map(s => (
          <div key={s.label} className={clsx('card p-4 flex items-center gap-3')}>
            <div className={clsx('w-10 h-10 rounded-lg flex items-center justify-center', s.bg)}>
              <Users size={18} className={s.color} />
            </div>
            <div>
              <p className={clsx('text-xl font-bold', s.color)}>{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters + Search */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input pl-9" placeholder="Search by name or phone..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedTag('all')}
            className={clsx('px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border', selectedTag === 'all' ? 'bg-primary text-white border-primary' : 'bg-white text-slate-600 border-surface-border hover:border-primary/40')}
          >
            All
          </button>
          {ALL_TAGS.map(tag => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag === selectedTag ? 'all' : tag)}
              className={clsx('px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border', selectedTag === tag ? 'bg-primary text-white border-primary' : 'bg-white text-slate-600 border-surface-border hover:border-primary/40')}
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>

      {/* Bulk actions */}
      {selected.length > 0 && (
        <div className="flex items-center gap-3 p-3 rounded-xl bg-primary-50 border border-primary/20">
          <span className="text-xs font-semibold text-primary">{selected.length} selected</span>
          <button className="btn-secondary text-xs py-1.5">
            <Radio size={12} /> Send Broadcast
          </button>
          <button className="btn-secondary text-xs py-1.5">
            <Tag size={12} /> Add Label
          </button>
          <button className="btn-danger text-xs py-1.5 ml-auto">
            <Trash2 size={12} /> Delete
          </button>
          <button onClick={() => setSelected([])} className="p-1 rounded hover:bg-primary/10 text-primary">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Table */}
      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="table-header w-10">
                <button onClick={toggleAll} className="text-slate-400 hover:text-slate-600">
                  {selected.length === filtered.length && filtered.length > 0
                    ? <CheckSquare size={15} className="text-primary" />
                    : <Square size={15} />}
                </button>
              </th>
              {['Name', 'Phone', 'Labels', 'Source', 'Opt-in', 'Last Contact', 'Status', ''].map(h => (
                <th key={h} className="table-header">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {filtered.map(c => (
              <tr key={c.id} className={clsx('table-row', selected.includes(c.id) && 'bg-primary-50/30')}>
                <td className="table-cell">
                  <button onClick={() => toggleSelect(c.id)} className="text-slate-400 hover:text-primary">
                    {selected.includes(c.id)
                      ? <CheckSquare size={15} className="text-primary" />
                      : <Square size={15} />}
                  </button>
                </td>
                <td className="table-cell">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {c.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 text-sm">{c.name}</p>
                      <p className="text-xs text-slate-400">{c.email}</p>
                    </div>
                  </div>
                </td>
                <td className="table-cell text-slate-600">{c.phone}</td>
                <td className="table-cell">
                  <div className="flex flex-wrap gap-1">
                    {c.tags.map(t => <span key={t} className="badge badge-blue text-[10px]">#{t}</span>)}
                  </div>
                </td>
                <td className="table-cell">
                  <span className="badge badge-gray text-[10px]">{c.source}</span>
                </td>
                <td className="table-cell">
                  {c.optIn
                    ? <span className="badge badge-green text-[10px]">Opted In</span>
                    : <span className="badge badge-red text-[10px]">Opted Out</span>}
                </td>
                <td className="table-cell text-slate-500 text-xs">{c.lastContact}</td>
                <td className="table-cell">
                  <span className={clsx('badge text-[10px]', c.status === 'active' ? 'badge-green' : 'badge-red')}>
                    {c.status}
                  </span>
                </td>
                <td className="table-cell">
                  <div className="flex items-center gap-1">
                    <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-primary transition-colors">
                      <Edit3 size={13} />
                    </button>
                    <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-red-500 transition-colors">
                      <Trash2 size={13} />
                    </button>
                    <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors">
                      <MoreVertical size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showImport && <ImportModal onClose={() => setShowImport(false)} />}
      {showAdd && <AddContactModal onClose={() => setShowAdd(false)} />}
    </div>
  )
}

// eslint-disable-next-line no-unused-vars
const Radio = ({ size, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}>
    <circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/>
  </svg>
)
