import { useState } from 'react'
import {
  CheckCircle2, Circle, Copy, ExternalLink, Check,
  ChevronRight, Globe, Phone, Webhook, FileText, TestTube,
  ArrowLeft, ArrowRight,
} from 'lucide-react'
import clsx from 'clsx'

const STEPS = [
  { id: 1, title: 'Meta Business',   icon: Globe,    subtitle: 'Create & configure your Meta App' },
  { id: 2, title: 'Phone Number',    icon: Phone,    subtitle: 'Verify your WhatsApp business number' },
  { id: 3, title: 'Webhook Setup',   icon: Webhook,  subtitle: 'Configure webhook for incoming messages' },
  { id: 4, title: 'Templates',       icon: FileText, subtitle: 'Create approved message templates' },
  { id: 5, title: 'Test Connection', icon: TestTube, subtitle: 'Send a test message to verify setup' },
]

function CopyBlock({ code }) {
  const [copied, setCopied] = useState(false)

  function copy() {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className="relative group">
      <pre className="bg-slate-50 border border-surface-border rounded-lg px-4 py-3 text-xs text-primary font-mono overflow-x-auto">
        {code}
      </pre>
      <button
        onClick={copy}
        className="absolute top-2 right-2 p-1.5 rounded-md bg-white border border-surface-border hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors opacity-0 group-hover:opacity-100"
      >
        {copied ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
      </button>
    </div>
  )
}

function Step1() {
  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3 p-4 rounded-xl bg-primary-50 border border-primary/20">
        <span className="text-2xl">ℹ️</span>
        <p className="text-sm text-slate-700">
          You'll need a <strong className="text-slate-900">Meta Business Account</strong> and a verified phone number.
          This process takes about 5-10 minutes.
        </p>
      </div>

      <div className="space-y-4">
        {[
          {
            step: 1,
            title: 'Go to Meta for Developers',
            desc: 'Visit developers.facebook.com and log in with your business account.',
            action: <a href="#" className="inline-flex items-center gap-1 text-xs text-primary hover:underline">Open Meta Developers <ExternalLink size={11} /></a>,
          },
          {
            step: 2,
            title: 'Create a New App',
            desc: 'Click "Create App" → Select "Business" type → Enter your app name.',
          },
          {
            step: 3,
            title: 'Add WhatsApp Product',
            desc: 'In your app dashboard, click "+ Add Product" and select WhatsApp.',
          },
          {
            step: 4,
            title: 'Enter Your Credentials',
            desc: 'Copy your App ID, App Secret, and Phone Number ID from the API Setup page.',
          },
        ].map(item => (
          <div key={item.step} className="flex gap-4">
            <div className="w-7 h-7 rounded-full bg-primary-50 border border-primary/20 flex items-center justify-center text-primary text-xs font-bold flex-shrink-0 mt-0.5">
              {item.step}
            </div>
            <div className="flex-1">
              <p className="font-medium text-slate-900 text-sm">{item.title}</p>
              <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
              {item.action && <div className="mt-1">{item.action}</div>}
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <div className="form-group">
          <label className="label">App ID</label>
          <input className="input" placeholder="Enter your Meta App ID" />
        </div>
        <div className="form-group">
          <label className="label">App Secret</label>
          <input type="password" className="input" placeholder="Enter your App Secret" />
        </div>
        <div className="form-group">
          <label className="label">Phone Number ID</label>
          <input className="input" placeholder="Enter your Phone Number ID" />
        </div>
        <div className="form-group">
          <label className="label">Access Token</label>
          <input type="password" className="input" placeholder="Enter your Permanent Access Token" />
        </div>
      </div>
    </div>
  )
}

function Step2() {
  const [verified, setVerified] = useState(false)

  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <div className="form-group">
          <label className="label">WhatsApp Business Phone Number</label>
          <div className="flex gap-2">
            <select className="select w-24 flex-shrink-0">
              <option>+91</option>
              <option>+1</option>
              <option>+44</option>
            </select>
            <input className="input" placeholder="98765 43210" />
          </div>
        </div>
        <div className="form-group">
          <label className="label">Display Name</label>
          <input className="input" placeholder="Your Business Name" defaultValue="Acme Corp" />
        </div>
      </div>

      {verified ? (
        <div className="flex items-center gap-2 p-4 rounded-xl bg-emerald-50 border border-emerald-200">
          <CheckCircle2 size={20} className="text-emerald-600 flex-shrink-0" />
          <div>
            <p className="font-medium text-emerald-800">Number Verified!</p>
            <p className="text-xs text-emerald-600 mt-0.5">+91 98765 43210 is ready to use with WhatsApp Business API.</p>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-slate-500">We'll send a 6-digit OTP to verify your number.</p>
          <button onClick={() => setVerified(true)} className="btn-primary">
            Send Verification Code
          </button>
        </div>
      )}

      <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
        <p className="text-xs text-amber-700 font-medium mb-1">⚠️ Important</p>
        <p className="text-xs text-amber-600">
          The phone number must NOT have an existing WhatsApp account. If it does, you'll need to delete it first or use a new number.
        </p>
      </div>
    </div>
  )
}

function Step3() {
  const webhookUrl = 'https://api.chatflow.io/webhook/YOUR_WORKSPACE_ID'
  const verifyToken = 'cf_verify_a8b3c91d2e4f5678'

  return (
    <div className="space-y-5">
      <p className="text-sm text-slate-600">
        Configure this webhook URL in your Meta App to receive incoming WhatsApp messages.
      </p>

      <div className="space-y-3">
        <div className="form-group">
          <label className="label">Your Webhook URL</label>
          <CopyBlock code={webhookUrl} />
        </div>
        <div className="form-group">
          <label className="label">Verify Token</label>
          <CopyBlock code={verifyToken} />
        </div>
      </div>

      <div className="space-y-3">
        {[
          { step: 1, text: 'In your Meta App, go to WhatsApp → Configuration' },
          { step: 2, text: 'Click "Edit" next to Webhook and paste the URL and token above' },
          { step: 3, text: 'Click "Verify and Save" — you should see a green checkmark' },
          { step: 4, text: 'Under "Webhook Fields", subscribe to: messages, message_deliveries, message_reads' },
        ].map(item => (
          <div key={item.step} className="flex gap-3">
            <div className="w-6 h-6 rounded-full bg-primary-50 border border-primary/20 flex items-center justify-center text-primary text-xs font-bold flex-shrink-0">
              {item.step}
            </div>
            <p className="text-sm text-slate-600">{item.text}</p>
          </div>
        ))}
      </div>

      <div className="p-4 rounded-xl bg-slate-50 border border-surface-border">
        <p className="text-xs text-slate-500 font-medium mb-2">Webhook Events to Subscribe:</p>
        <div className="flex flex-wrap gap-2">
          {['messages', 'message_deliveries', 'message_reads', 'message_reactions'].map(e => (
            <span key={e} className="text-xs px-2 py-0.5 rounded bg-primary-50 text-primary font-mono border border-primary/20">{e}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

function Step4() {
  return (
    <div className="space-y-5">
      <p className="text-sm text-slate-600">
        Create message templates in Meta Business Manager. All marketing templates require approval (usually 24 hours).
      </p>

      <div className="space-y-3">
        {[
          { name: 'welcome_message',   category: 'MARKETING',     status: 'APPROVED' },
          { name: 'order_confirmation',category: 'TRANSACTIONAL', status: 'APPROVED' },
          { name: 'flash_sale_promo',  category: 'MARKETING',     status: 'PENDING'  },
        ].map(t => (
          <div key={t.name} className="flex items-center justify-between p-3 rounded-lg bg-white border border-surface-border">
            <div>
              <p className="text-sm font-medium text-slate-900 font-mono">{t.name}</p>
              <span className="text-xs text-slate-500">{t.category}</span>
            </div>
            <span className={clsx('badge', {
              'badge-green': t.status === 'APPROVED',
              'badge-amber': t.status === 'PENDING',
            })}>
              {t.status}
            </span>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Quick tips</p>
        {[
          'Use {{1}}, {{2}} for dynamic variables in templates',
          'Transactional templates (order updates, OTPs) get approved faster',
          'Marketing templates need opt-in from users first',
          'You can create up to 250 templates per number',
        ].map(tip => (
          <div key={tip} className="flex items-start gap-2">
            <CheckCircle2 size={13} className="text-emerald-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slate-600">{tip}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

function Step5() {
  const [testing, setTesting] = useState(false)
  const [result, setResult] = useState(null)

  function runTest() {
    setTesting(true)
    setResult(null)
    setTimeout(() => { setTesting(false); setResult('success') }, 2500)
  }

  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <div className="form-group">
          <label className="label">Test Phone Number</label>
          <input className="input" placeholder="+91 98765 43210" />
        </div>
        <div className="form-group">
          <label className="label">Test Template</label>
          <select className="select">
            <option>welcome_message</option>
            <option>order_confirmation</option>
          </select>
        </div>
      </div>

      <button onClick={runTest} disabled={testing} className="btn-primary w-full justify-center">
        {testing ? (
          <><span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Sending test message...</>
        ) : (
          <><TestTube size={14} /> Send Test Message</>
        )}
      </button>

      {result === 'success' && (
        <div className="space-y-3">
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 size={18} className="text-emerald-600" />
              <p className="font-semibold text-emerald-800">Setup Complete!</p>
            </div>
            <p className="text-xs text-emerald-600">
              A test message was sent successfully. Your WhatsApp Business API is connected and ready.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { check: 'API Connected',    ok: true },
              { check: 'Webhook Active',   ok: true },
              { check: 'Templates Loaded', ok: true },
              { check: 'Phone Verified',   ok: true },
            ].map(c => (
              <div key={c.check} className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-surface-border">
                <CheckCircle2 size={13} className="text-emerald-500" />
                <span className="text-xs text-slate-700">{c.check}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

const STEP_COMPONENTS = [Step1, Step2, Step3, Step4, Step5]

export default function Installation() {
  const [currentStep, setCurrentStep] = useState(0)
  const [completed, setCompleted] = useState([])

  function goNext() {
    if (!completed.includes(currentStep)) {
      setCompleted(prev => [...prev, currentStep])
    }
    if (currentStep < STEPS.length - 1) setCurrentStep(s => s + 1)
  }

  function goPrev() {
    if (currentStep > 0) setCurrentStep(s => s - 1)
  }

  const StepComponent = STEP_COMPONENTS[currentStep]

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div className="text-center">
        <h1 className="page-title text-xl">WhatsApp Business API Setup</h1>
        <p className="text-slate-500 mt-1 text-sm">Follow these 5 steps to connect your WhatsApp Business account</p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center justify-between">
        {STEPS.map((step, i) => {
          const Icon = step.icon
          const isActive = i === currentStep
          const isDone = completed.includes(i)
          return (
            <div key={step.id} className="flex items-center flex-1">
              <button onClick={() => setCurrentStep(i)} className="flex flex-col items-center gap-1 group">
                <div className={clsx(
                  'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all',
                  isActive ? 'border-primary bg-primary text-white scale-110' :
                  isDone  ? 'border-primary bg-primary-50 text-primary' :
                  'border-surface-border bg-white text-slate-400'
                )}>
                  {isDone && !isActive ? <CheckCircle2 size={18} /> : <Icon size={16} />}
                </div>
                <span className={clsx('text-xs font-medium hidden sm:block', isActive ? 'text-primary' : isDone ? 'text-primary' : 'text-slate-400')}>
                  {step.title}
                </span>
              </button>
              {i < STEPS.length - 1 && (
                <div className={clsx('flex-1 h-0.5 mx-2', i < currentStep ? 'bg-primary' : 'bg-surface-border')} />
              )}
            </div>
          )
        })}
      </div>

      {/* Step Content */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center">
            {(() => { const Icon = STEPS[currentStep].icon; return <Icon size={18} className="text-primary" /> })()}
          </div>
          <div>
            <h3 className="font-semibold text-slate-900">Step {currentStep + 1}: {STEPS[currentStep].title}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{STEPS[currentStep].subtitle}</p>
          </div>
        </div>

        <StepComponent />

        <div className="flex justify-between mt-8 pt-5 border-t border-surface-border">
          <button
            onClick={goPrev}
            disabled={currentStep === 0}
            className={clsx('btn-secondary', currentStep === 0 && 'opacity-40 cursor-not-allowed')}
          >
            <ArrowLeft size={14} /> Previous
          </button>
          <button onClick={goNext} className="btn-primary">
            {currentStep === STEPS.length - 1 ? (
              <><CheckCircle2 size={14} /> Complete Setup</>
            ) : (
              <>Next Step <ArrowRight size={14} /></>
            )}
          </button>
        </div>
      </div>

      {/* Help links */}
      <div className="card p-4">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Documentation & Resources</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            'WhatsApp Business API Docs',
            'Meta App Setup Guide',
            'Template Guidelines',
            'Webhook Configuration',
          ].map(link => (
            <a key={link} href="#" className="flex items-center gap-2 text-xs text-slate-500 hover:text-primary transition-colors">
              <ExternalLink size={11} className="flex-shrink-0" />
              {link}
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}
