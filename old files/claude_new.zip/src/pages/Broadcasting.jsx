import { useState, useMemo } from 'react'
import {
  Plus, Search, ChevronLeft, ChevronRight, X, Send, Users, FileText,
  Upload, Calendar, BarChart2, Download, CheckCircle2, AlertCircle,
  Clock, Zap, Check, Info, Target, Inbox, Eye, Shield, Activity,
  CornerUpLeft, Layers, RefreshCw, MessageSquare, MousePointerClick,
  ArrowUpRight, TrendingUp,
} from 'lucide-react'
import { TEMPLATES } from '../constants/mockData'
import clsx from 'clsx'

/* ─────────────────────────── MOCK DATA ─────────────────────────── */
const CAMPAIGNS = [
  {
    id: 'c1', name: 'Exclusive Festival Offer for Our Valued Members',
    date: '2025-05-14 18:52', channel: 'Default',
    recipients: 230, successful: 221, read: 215, replied: 103,
    failed: 9, ignored: 6, sending: 0, clicks: 110, status: 'Completed',
    template: {
      name: 'exclusive_festival_offer', category: 'MARKETING', header: 'IMAGE',
      bold: 'Exclusive Festival Offer!',
      body: 'Hi {{1}}, as a cherished member, we have a special festival surprise just for you! 🎁',
      footer: 'www.chatflow.io', buttons: ['Know more', 'Visit us'],
    },
  },
  {
    id: 'c2', name: 'Reminder: You Have Store Credits Waiting',
    date: '2025-05-05 07:27', channel: 'Default',
    recipients: 128, successful: 113, read: 103, replied: 31,
    failed: 15, ignored: 10, sending: 0, clicks: 97, status: 'Completed',
    template: {
      name: 'store_credits_reminder', category: 'MARKETING', header: 'TEXT',
      bold: '💰 You have store credits!',
      body: 'Hi {{1}}, you have ₹{{2}} in store credits. Use them before they expire on {{3}}.',
      footer: '', buttons: ['Use Credits Now', 'View Balance'],
    },
  },
  {
    id: 'c3', name: 'Your Opinion = A Special Discount Just for You',
    date: '2025-05-05 07:27', channel: 'Default',
    recipients: 300, successful: 265, read: 264, replied: 93,
    failed: 35, ignored: 1, sending: 0, clicks: 192, status: 'Completed',
    template: {
      name: 'feedback_special_discount', category: 'MARKETING', header: 'NONE',
      bold: '🌟 Share Your Feedback',
      body: 'Hi {{1}}, we value your opinion! Complete a quick survey and get {{2}}% off your next order.',
      footer: 'Reply STOP to opt out', buttons: ['Take Survey', 'Skip'],
    },
  },
  {
    id: 'c4', name: 'Spring Sale — Last 24 Hours',
    date: '2025-04-30 09:00', channel: 'Default',
    recipients: 1204, successful: 1165, read: 920, replied: 312,
    failed: 39, ignored: 245, sending: 0, clicks: 580, status: 'Completed',
    template: {
      name: 'spring_sale_final', category: 'MARKETING', header: 'IMAGE',
      bold: '⏰ Final Hours — Spring Sale!',
      body: "Hi {{1}}, up to 40% off ends at midnight. Don't miss out!",
      footer: '', buttons: ['Shop Now'],
    },
  },
  {
    id: 'c5', name: 'Order Confirmation — April Batch',
    date: '2025-04-28 11:00', channel: 'Default',
    recipients: 892, successful: 878, read: 791, replied: 44,
    failed: 14, ignored: 87, sending: 0, clicks: 412, status: 'Completed',
    template: {
      name: 'order_confirmation_v3', category: 'UTILITY', header: 'TEXT',
      bold: '✅ Order Confirmed',
      body: 'Hi {{1}}, your order #{{2}} is confirmed and will be delivered by {{3}}.',
      footer: '', buttons: ['Track Order', 'Contact Support'],
    },
  },
]

const CONTACT_GROUPS = [
  { id: 'g1', name: 'All Customers',  icon: '👥', count: 12480, desc: 'Every opted-in contact' },
  { id: 'g2', name: 'VIP Members',    icon: '⭐', count: 1204,  desc: 'High-value customers'   },
  { id: 'g3', name: 'Inactive (60d)', icon: '💤', count: 3201,  desc: 'No activity in 60 days' },
  { id: 'g4', name: 'New Signups',    icon: '🆕', count: 892,   desc: 'Joined in last 30 days'  },
  { id: 'g5', name: 'Abandoned Cart', icon: '🛒', count: 2108,  desc: 'Left without checkout'   },
  { id: 'g6', name: 'Post-purchase',  icon: '✅', count: 4321,  desc: 'Completed an order'      },
]

const APPROVED_TEMPLATES = (TEMPLATES || []).filter(t => t.status === 'APPROVED').concat([
  { id: 'at1', name: 'exclusive_festival_offer', category: 'MARKETING', status: 'APPROVED', body: 'Hi {{1}}, as a cherished member, we have a special festival surprise just for you! 🎁', buttons: ['Know more', 'Visit us'] },
  { id: 'at2', name: 'spring_sale_final',        category: 'MARKETING', status: 'APPROVED', body: "Hi {{1}}, up to 40% off ends at midnight. Don't miss out!", buttons: ['Shop Now'] },
  { id: 'at3', name: 'store_credits_reminder',   category: 'MARKETING', status: 'APPROVED', body: 'Hi {{1}}, you have ₹{{2}} in store credits expiring on {{3}}.', buttons: ['Use Credits Now'] },
  { id: 'at4', name: 'order_confirmation_v3',    category: 'UTILITY',   status: 'APPROVED', body: 'Hi {{1}}, your order #{{2}} is confirmed and arrives by {{3}}.', buttons: ['Track Order', 'Contact Support'] },
])

const WIZARD_STEPS = ['Template', 'Audience', 'Schedule', 'Review']
const STATUS_TABS   = ['All', 'Sending', 'Scheduled', 'Completed', 'Failed']

/* ─────────────────────────── UTILS ─────────────────────────── */
function pct(n, d) { return d > 0 ? Math.round((n / d) * 100) : 0 }

/* ─────────────────────────── STATUS PILL ─────────────────────────── */
function StatusPill({ status }) {
  const cfg = {
    Completed: { bg: 'bg-emerald-50', text: 'text-emerald-700', ring: 'ring-emerald-200', dot: 'bg-emerald-500' },
    Sending:   { bg: 'bg-blue-50',    text: 'text-blue-700',    ring: 'ring-blue-200',    dot: 'bg-blue-500'    },
    Scheduled: { bg: 'bg-amber-50',   text: 'text-amber-700',   ring: 'ring-amber-200',   dot: 'bg-amber-400'   },
    Failed:    { bg: 'bg-red-50',     text: 'text-red-700',     ring: 'ring-red-200',     dot: 'bg-red-500'     },
  }[status] || { bg: 'bg-slate-50', text: 'text-slate-600', ring: 'ring-slate-200', dot: 'bg-slate-400' }

  return (
    <span className={clsx('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ring-1', cfg.bg, cfg.text, cfg.ring)}>
      <span className={clsx('w-1.5 h-1.5 rounded-full flex-shrink-0', cfg.dot)} />
      {status}
    </span>
  )
}

/* ─────────────────────────── PHONE PREVIEW ─────────────────────────── */
function PhonePreview({ tpl }) {
  if (!tpl) return (
    <div className="flex flex-col items-center justify-center py-10 text-slate-300">
      <MessageSquare size={28} className="mb-2" />
      <p className="text-xs text-center text-slate-400">Select a template<br />to preview</p>
    </div>
  )
  const body = tpl.body?.replace(/\{\{1\}\}/g, 'Priya').replace(/\{\{2\}\}/g, '₹499').replace(/\{\{3\}\}/g, 'Apr 30')
  return (
    <div className="w-52 mx-auto">
      <div className="bg-slate-900 rounded-[2rem] border-[3px] border-slate-700 p-2.5 shadow-2xl">
        <div className="flex justify-between text-[9px] text-slate-500 px-1 mb-1.5"><span>9:41</span><span>●●●</span></div>
        <div className="bg-[#128C7E] px-3 py-2 flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">C</div>
          <div><p className="text-white text-[10px] font-semibold leading-none">ChatFlow</p><p className="text-gray-300 text-[9px] opacity-70">Business Account</p></div>
        </div>
        <div className="bg-[#ECE5DD] px-2 py-2 min-h-28 space-y-1">
          {tpl.header === 'IMAGE' && (
            <div className="rounded-lg overflow-hidden h-20 bg-gradient-to-br from-amber-200 to-orange-300 flex items-center justify-center">
              <span className="text-2xl">🎁</span>
            </div>
          )}
          <div className="bg-white rounded-xl p-2.5 shadow-sm">
            {tpl.bold && <p className="font-bold text-[11px] text-slate-800 mb-1">{tpl.bold}</p>}
            <p className="text-slate-700 text-[10px] leading-relaxed whitespace-pre-line">{body}</p>
            {tpl.footer && <p className="text-[9px] text-slate-400 mt-1">{tpl.footer}</p>}
            <p className="text-right text-[9px] text-slate-400 mt-1">10:42 ✓✓</p>
          </div>
          {tpl.buttons?.length > 0 && (
            <div className="space-y-0.5">
              {tpl.buttons.map((b, i) => (
                <div key={i} className="bg-white rounded-xl py-1.5 text-center text-[10px] text-[#128C7E] font-semibold shadow-sm">{b}</div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────────── RECIPIENT DATA ─────────────────────────── */
const PHONE_PREFIXES = ['6303','7013','7989','9966','9515','8009','6301','7623','8234','9345','6576','9876','7654','8765','9654']

function generateRecipients(c) {
  const seed  = parseInt(c.id.replace('c', '')) || 1
  const limit = Math.min(c.recipients, 50)

  // Build proportional statuses for the shown rows
  const failedN   = Math.round((c.failed  / c.recipients) * limit)
  const ignoredN  = Math.round((c.ignored / c.recipients) * limit)
  const repliedN  = Math.round((c.replied / c.recipients) * limit)
  const readN     = limit - failedN - ignoredN - repliedN

  const statusList = [
    ...Array(Math.max(failedN,  0)).fill('Failed'),
    ...Array(Math.max(ignoredN, 0)).fill('Delivered'),
    ...Array(Math.max(readN,    0)).fill('Read'),
    ...Array(Math.max(repliedN, 0)).fill('Replied'),
  ]

  // Deterministic shuffle using seed
  for (let i = statusList.length - 1; i > 0; i--) {
    const j = Math.abs((seed * 9301 + i * 49297) % (i + 1))
    ;[statusList[i], statusList[j]] = [statusList[j], statusList[i]]
  }

  return Array.from({ length: limit }, (_, i) => {
    const status  = statusList[i] || 'Delivered'
    const prefix  = PHONE_PREFIXES[i % PHONE_PREFIXES.length]
    const suffix  = String(Math.abs((seed * 9876 + i * 12345) % 999999)).padStart(6, '0')
    const phone   = `91${prefix}${suffix}`
    const hash    = Math.abs((seed * 777 + i * 333) % 9999999).toString(36).toUpperCase().padStart(7, 'A').slice(0, 7)
    const btnArr  = c.template.buttons || []
    const replied = status === 'Replied'
      ? (btnArr.length ? btnArr[i % btnArr.length] : 'Yes, interested.')
      : null
    return {
      id:        i + 1,
      phone,
      template:  c.template.name,
      messageId: `wamid.HBgM${hash}...`,
      status,
      clicked:   (status === 'Read' || status === 'Replied') && i % 3 === 0,
      replied,
      response:  status === 'Failed' ? 'Delivery failed' : 'Success',
      createdAt: c.date,
    }
  })
}

/* ─────────────────────────── CAMPAIGN INSIGHTS ─────────────────────────── */
function CampaignInsights({ campaign: c, onBack }) {
  const [insightView,     setInsightView]     = useState('overview')
  const [retargetFilter,  setRetargetFilter]  = useState('Replied with')
  const [retargetValue,   setRetargetValue]   = useState(c.template.buttons[0] || 'Any message')
  const [recipientTab,    setRecipientTab]    = useState('All')
  const [recipientSearch, setRecipientSearch] = useState('')
  const [currentPage,     setCurrentPage]     = useState(1)
  const ROWS_PER_PAGE = 10

  const allRecipients = useMemo(() => generateRecipients(c), [c.id])

  const filteredRecipients = useMemo(() => {
    return allRecipients.filter(r => {
      const matchTab =
        recipientTab === 'All'       ? true :
        recipientTab === 'Sent'      ? true :
        recipientTab === 'Delivered' ? r.status === 'Delivered' :
        recipientTab === 'Read'      ? r.status === 'Read'      :
        recipientTab === 'Failed'    ? r.status === 'Failed'    :
        recipientTab === 'Clicked'   ? r.clicked === true       :
        recipientTab === 'Replied'   ? !!r.replied              : true
      const q = recipientSearch.toLowerCase()
      const matchSearch = !q || r.phone.includes(q) || r.template.includes(q) || r.messageId.toLowerCase().includes(q)
      return matchTab && matchSearch
    })
  }, [allRecipients, recipientTab, recipientSearch])

  const totalPages = Math.ceil(filteredRecipients.length / ROWS_PER_PAGE)
  const pagedRows  = filteredRecipients.slice((currentPage - 1) * ROWS_PER_PAGE, currentPage * ROWS_PER_PAGE)

  const tabCounts = useMemo(() => ({
    All:       allRecipients.length,
    Sent:      allRecipients.length,
    Delivered: allRecipients.filter(r => r.status === 'Delivered').length,
    Read:      allRecipients.filter(r => r.status === 'Read').length,
    Failed:    allRecipients.filter(r => r.status === 'Failed').length,
    Clicked:   allRecipients.filter(r => r.clicked).length,
    Replied:   allRecipients.filter(r => !!r.replied).length,
  }), [allRecipients])

  const STATUS_PILL_CFG = {
    Failed:    { bg: 'bg-red-100',     text: 'text-red-700'     },
    Delivered: { bg: 'bg-lime-100',    text: 'text-lime-700'    },
    Read:      { bg: 'bg-emerald-100', text: 'text-emerald-700' },
    Replied:   { bg: 'bg-blue-100',    text: 'text-blue-700'    },
  }

  const delivPct   = pct(c.successful, c.recipients)
  const readPct    = pct(c.read, c.recipients)
  const repliedPct = pct(c.replied, c.recipients)
  const clicksPct  = pct(c.clicks, c.recipients)

  const readOfDeliv    = pct(c.read,    c.successful)
  const ignoredOfDeliv = pct(c.ignored, c.successful)

  const btnStats = c.template.buttons.map((btn, i) => ({
    label:   btn,
    replies: i === 0 ? Math.round(c.replied * 0.29) : Math.round(c.replied * 0.71),
    clicks:  i === 0 ? Math.round(c.clicks  * 0.29) : Math.round(c.clicks  * 0.71),
    total:   c.successful,
  }))

  const retargetAudience = retargetFilter === 'Replied with' ? Math.round(c.replied * 0.3)
    : retargetFilter === 'Did not reply'  ? c.successful - c.replied
    : retargetFilter === 'Clicked'        ? c.clicks
    : retargetFilter === 'Did not click'  ? c.successful - c.clicks
    : retargetFilter === 'Read but no reply' ? c.read - c.replied
    : c.failed

  return (
    <div className="animate-fade-in space-y-5">

      {/* ── Header ── */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <button onClick={onBack}
            className="mt-0.5 p-2 rounded-xl hover:bg-surface-hover text-slate-400 hover:text-slate-700 transition-colors border border-surface-border">
            <ChevronLeft size={16} />
          </button>
          <div>
            <p className="text-xs font-semibold text-slate-400 mb-1">Campaign Analytics</p>
            <h2 className="text-lg font-bold text-slate-900 max-w-xl leading-snug">{c.name}</h2>
            <p className="text-xs text-slate-400 mt-1">Sent {c.date} &nbsp;·&nbsp; via ChatFlow &nbsp;·&nbsp; {c.recipients.toLocaleString()} recipients</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <button className="btn-secondary text-xs gap-1.5"><Download size={13} /> Export</button>
          <button className="btn-secondary text-xs gap-1.5"><BarChart2 size={13} /> Delivery Report</button>
        </div>
      </div>

      {/* ── View Tabs ── */}
      <div className="flex items-center gap-0 border-b border-surface-border">
        {[
          { key: 'overview',   label: 'Overview'                                         },
          { key: 'recipients', label: `Recipients (${c.recipients.toLocaleString()})`    },
        ].map(({ key, label }) => (
          <button key={key} onClick={() => setInsightView(key)}
            className={clsx('px-4 py-3 text-sm font-semibold border-b-2 transition-colors',
              insightView === key
                ? 'border-primary text-primary'
                : 'border-transparent text-slate-500 hover:text-slate-700')}>
            {label}
          </button>
        ))}
      </div>

      {/* ══ OVERVIEW TAB ══ */}
      {insightView === 'overview' && <>

      {/* ── 4 KPI tiles ── */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { icon: CheckCircle2,    label: 'Delivered',       value: c.successful, p: delivPct,   color: 'bg-emerald-50 text-emerald-600', bar: 'bg-emerald-400' },
          { icon: Eye,             label: 'Read',            value: c.read,       p: readPct,    color: 'bg-teal-50 text-teal-600',       bar: 'bg-teal-400'    },
          { icon: CornerUpLeft,    label: 'Replied',         value: c.replied,    p: repliedPct, color: 'bg-violet-50 text-violet-600',   bar: 'bg-violet-400'  },
          { icon: MousePointerClick, label: 'Link Clicks',  value: c.clicks,     p: clicksPct,  color: 'bg-blue-50 text-blue-600',       bar: 'bg-blue-400'    },
        ].map(({ icon: Icon, label, value, p, color, bar }) => (
          <div key={label} className="card p-5">
            <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center mb-3 flex-shrink-0', color.split(' ')[0])}>
              <Icon size={15} className={color.split(' ')[1]} />
            </div>
            <p className="text-2xl font-bold text-slate-900">{value.toLocaleString()}</p>
            <p className="text-xs text-slate-500 mt-0.5 mb-2">{label}</p>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div className={clsx('h-full rounded-full', bar)} style={{ width: `${p}%` }} />
            </div>
            <p className="text-xs text-slate-400 mt-1.5">{p}% of recipients</p>
          </div>
        ))}
      </div>

      {/* ── Main content ── */}
      <div className="grid grid-cols-[1fr_232px] gap-5">

        {/* Left */}
        <div className="space-y-5">

          {/* Audience funnel */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-semibold text-slate-900">Audience Funnel</h3>
                <p className="text-xs text-slate-400 mt-0.5">How your message travelled through recipients</p>
              </div>
              <span className="text-[11px] text-amber-600 bg-amber-50 border border-amber-100 rounded-full px-3 py-1 flex items-center gap-1.5">
                <Info size={10} /> Approximate data
              </span>
            </div>

            {/* Big numbers */}
            <div className="flex items-center gap-8 mb-5">
              <div className="text-center">
                <p className="text-[11px] text-slate-400 mb-1">Total sent</p>
                <p className="text-3xl font-extrabold text-slate-900">{c.recipients.toLocaleString()}</p>
              </div>
              <div className="flex-1 flex items-center gap-2 text-slate-300">
                <div className="flex-1 border-t border-dashed border-slate-200" />
                <ArrowUpRight size={14} />
              </div>
              <div className="text-center">
                <p className="text-[11px] text-slate-400 mb-1">Delivered</p>
                <p className="text-3xl font-extrabold text-emerald-600">{c.successful.toLocaleString()}</p>
              </div>
              <div className="flex-1 flex items-center gap-2 text-slate-300">
                <div className="flex-1 border-t border-dashed border-slate-200" />
                <ArrowUpRight size={14} />
              </div>
              <div className="text-center">
                <p className="text-[11px] text-slate-400 mb-1">Read</p>
                <p className="text-3xl font-extrabold text-teal-600">{c.read.toLocaleString()}</p>
              </div>
            </div>

            {/* Stacked bar */}
            <div className="flex h-8 rounded-xl overflow-hidden mb-3 gap-0.5">
              <div className="h-full bg-teal-400 flex items-center justify-center text-white text-xs font-bold rounded-l-xl transition-all"
                style={{ width: `${readOfDeliv}%` }}>
                {readOfDeliv > 12 && `${readOfDeliv}%`}
              </div>
              <div className="h-full bg-slate-300 transition-all"
                style={{ width: `${ignoredOfDeliv}%` }} />
              <div className="h-full bg-red-300 transition-all rounded-r-xl"
                style={{ width: `${Math.max(0, 100 - readOfDeliv - ignoredOfDeliv)}%` }} />
            </div>

            <div className="flex items-center gap-5 text-xs text-slate-500">
              {[['bg-teal-400','Read'], ['bg-slate-300','Ignored / No action'], ['bg-red-300','Failed']].map(([dot, lbl]) => (
                <div key={lbl} className="flex items-center gap-1.5">
                  <span className={clsx('w-2 h-2 rounded-sm flex-shrink-0', dot)} /> {lbl}
                </div>
              ))}
            </div>
          </div>

          {/* Responses breakdown */}
          {c.template.buttons.length > 0 && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-1">Button Responses</h3>
              <p className="text-xs text-slate-400 mb-5">Replies and clicks per CTA button</p>

              <div className={clsx('grid gap-6', c.template.buttons.length > 1 ? 'grid-cols-2' : 'grid-cols-1 max-w-xs')}>
                {btnStats.map(({ label, replies, clicks, total }) => {
                  const rp = pct(replies, total)
                  const cp = pct(clicks,  total)
                  return (
                    <div key={label}>
                      <p className="text-sm font-semibold text-slate-700 mb-3 truncate">{label}</p>
                      <div className="space-y-2.5">
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-500 flex items-center gap-1"><CornerUpLeft size={10}/> Replies</span>
                            <span className="font-semibold text-slate-700">{replies} <span className="text-slate-400 font-normal">({rp}%)</span></span>
                          </div>
                          <div className="h-2 bg-amber-100 rounded-full overflow-hidden">
                            <div className="h-full bg-amber-400 rounded-full" style={{ width: `${rp}%` }} />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-500 flex items-center gap-1"><MousePointerClick size={10}/> Clicks</span>
                            <span className="font-semibold text-slate-700">{clicks} <span className="text-slate-400 font-normal">({cp}%)</span></span>
                          </div>
                          <div className="h-2 bg-blue-100 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${cp}%` }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className="flex items-center gap-5 mt-5 pt-4 border-t border-surface-border text-xs text-slate-400">
                {[['bg-amber-400','Replies'], ['bg-blue-500','Clicks']].map(([dot, lbl]) => (
                  <div key={lbl} className="flex items-center gap-1.5">
                    <span className={clsx('w-2 h-2 rounded-sm', dot)} /> {lbl}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Retarget */}
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
                <Target size={13} className="text-primary" />
              </div>
              <h3 className="font-semibold text-slate-900">Smart Retargeting</h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">Re-engage a specific segment from this campaign</p>

            <div className="bg-slate-50 border border-surface-border rounded-xl p-4 space-y-4">
              <p className="text-sm font-medium text-slate-700">Send a new campaign to contacts who:</p>

              <div className="flex items-center gap-2 flex-wrap">
                <select className="input text-sm" value={retargetFilter} onChange={e => setRetargetFilter(e.target.value)}>
                  <option>Replied with</option>
                  <option>Did not reply</option>
                  <option>Clicked</option>
                  <option>Did not click</option>
                  <option>Read but no reply</option>
                  <option>Not delivered</option>
                </select>
                <select className="input text-sm" value={retargetValue} onChange={e => setRetargetValue(e.target.value)}>
                  {c.template.buttons.map(b => <option key={b}>{b}</option>)}
                  <option>Any message</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5 px-4 py-2.5 bg-white rounded-xl border border-surface-border">
                  <Users size={14} className="text-slate-400" />
                  <span className="text-sm text-slate-500">Audience</span>
                  <span className="text-lg font-bold text-primary">{retargetAudience.toLocaleString()}</span>
                  <span className="text-xs text-slate-400">contacts</span>
                </div>
                <button className="btn-primary text-sm gap-1.5">
                  <Send size={13} /> Create Retarget Campaign
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right */}
        <div className="space-y-4">
          <div className="card p-4">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Template Used</p>
            <p className="text-xs text-primary font-medium mb-4 truncate">{c.template.name.replace(/_/g, ' ')}</p>
            <PhonePreview tpl={c.template} />
          </div>

          <div className="card p-4 space-y-2.5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider pb-2 border-b border-surface-border">At a Glance</p>
            {[
              { label: 'Delivery Rate', value: `${delivPct}%`,   color: 'text-emerald-600' },
              { label: 'Read Rate',     value: `${readPct}%`,    color: 'text-teal-600'    },
              { label: 'Reply Rate',    value: `${repliedPct}%`, color: 'text-violet-600'  },
              { label: 'Click Rate',    value: `${clicksPct}%`,  color: 'text-blue-600'    },
              { label: 'Failed',        value: c.failed,         color: 'text-red-500'     },
              { label: 'Ignored',       value: c.ignored,        color: 'text-slate-500'   },
            ].map(({ label, value, color }) => (
              <div key={label} className="flex items-center justify-between">
                <span className="text-xs text-slate-500">{label}</span>
                <span className={clsx('text-sm font-bold', color)}>{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      </>} {/* end overview tab */}

      {/* ══ RECIPIENTS TAB ══ */}
      {insightView === 'recipients' && (
        <div className="card p-0 overflow-hidden">

          {/* Header */}
          <div className="px-5 py-4 border-b border-surface-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-semibold text-slate-900 text-base">Template Response Insights</h3>
                <p className="text-sm text-slate-500 mt-0.5">
                  Message Sent to{' '}
                  <span className="font-bold text-slate-800">{c.recipients.toLocaleString()}</span> contacts
                  {c.recipients > 50 && <span className="text-slate-400 text-xs ml-1">(showing first 50)</span>}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input className="input-sm pl-8 text-xs w-56" placeholder="Search phone, template, message ID…"
                    value={recipientSearch}
                    onChange={e => { setRecipientSearch(e.target.value); setCurrentPage(1) }} />
                </div>
                <button className="p-2 rounded-lg border border-surface-border hover:bg-surface-hover text-slate-500 transition-colors" title="Refresh">
                  <RefreshCw size={13} />
                </button>
                <button className="btn-primary text-xs gap-1.5">
                  <Download size={13} /> Download
                </button>
              </div>
            </div>

            {/* Status filter tabs */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {['All','Sent','Delivered','Read','Failed','Clicked','Replied'].map(tab => (
                <button key={tab} onClick={() => { setRecipientTab(tab); setCurrentPage(1) }}
                  className={clsx(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all',
                    recipientTab === tab
                      ? 'bg-primary text-white shadow-sm'
                      : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                  )}>
                  {tab}
                  <span className={clsx('text-[10px]', recipientTab === tab ? 'text-white/70' : 'text-slate-400')}>
                    {tabCounts[tab]}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-border bg-slate-50/60">
                  {['S.No','Mobile No','Template','Message Id','Status','Clicked','Replied','Response','Created At','Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider whitespace-nowrap first:pl-5 last:pr-5">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border">
                {pagedRows.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-14 text-center">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center mx-auto mb-3">
                        <Inbox size={18} className="text-slate-300" />
                      </div>
                      <p className="text-sm text-slate-400">No recipients match this filter</p>
                    </td>
                  </tr>
                ) : pagedRows.map(r => {
                  const pill = STATUS_PILL_CFG[r.status] || { bg: 'bg-slate-100', text: 'text-slate-600' }
                  return (
                    <tr key={r.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="pl-5 pr-4 py-3.5 text-xs text-slate-400 tabular-nums">{r.id}</td>
                      <td className="px-4 py-3.5">
                        <span className="text-xs font-semibold text-primary hover:underline cursor-pointer">{r.phone}</span>
                      </td>
                      <td className="px-4 py-3.5 max-w-[140px]">
                        <span className="text-xs text-slate-600 font-medium truncate block" title={r.template}>
                          {r.template.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 max-w-[120px]">
                        <span className="text-xs text-slate-400 font-mono truncate block" title={r.messageId}>
                          {r.messageId}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className={clsx('inline-flex items-center text-[11px] font-bold px-2.5 py-1 rounded-full', pill.bg, pill.text)}>
                          {r.status}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        {r.clicked
                          ? <span className="text-xs font-semibold text-emerald-600">Yes</span>
                          : <span className="text-xs text-slate-300">—</span>}
                      </td>
                      <td className="px-4 py-3.5 max-w-[130px]">
                        {r.replied
                          ? <span className="text-xs text-blue-600 font-medium truncate block">{r.replied}</span>
                          : <span className="text-xs text-slate-300">—</span>}
                      </td>
                      <td className="px-4 py-3.5">
                        <span className={clsx('text-xs font-medium', r.status === 'Failed' ? 'text-red-500' : 'text-emerald-600')}>
                          {r.response}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span className="text-xs text-slate-500">{r.createdAt}</span>
                      </td>
                      <td className="px-4 pr-5 py-3.5 text-center">
                        <span className="text-xs text-slate-300">—</span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-5 py-3 border-t border-surface-border bg-slate-50/40">
            <p className="text-xs text-slate-400">
              Showing{' '}
              <span className="font-semibold text-slate-700">
                {filteredRecipients.length === 0 ? 0 : (currentPage - 1) * ROWS_PER_PAGE + 1}–{Math.min(currentPage * ROWS_PER_PAGE, filteredRecipients.length)}
              </span>{' '}
              of{' '}
              <span className="font-semibold text-slate-700">{filteredRecipients.length}</span> contacts
            </p>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}
                className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 disabled:opacity-30 transition-colors">
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setCurrentPage(p)}
                  className={clsx('w-7 h-7 rounded-lg text-xs font-semibold transition-colors',
                    currentPage === p ? 'bg-primary text-white' : 'text-slate-500 hover:bg-surface-hover')}>
                  {p}
                </button>
              ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages || totalPages === 0}
                className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 disabled:opacity-30 transition-colors">
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

/* ─────────────────────────── WIZARD ─────────────────────────── */
function NewCampaignWizard({ onClose, onCreated }) {
  const [step,       setStep]       = useState(0)
  const [selTpl,     setSelTpl]     = useState(null)
  const [selGroup,   setSelGroup]   = useState(null)
  const [csvFile,    setCsvFile]    = useState(null)
  const [mode,       setMode]       = useState('group')
  const [campName,   setCampName]   = useState('')
  const [sendNow,    setSendNow]    = useState(true)
  const [schedDate,  setSchedDate]  = useState('')
  const [schedTime,  setSchedTime]  = useState('09:00')
  const [tplSearch,  setTplSearch]  = useState('')
  const [launching,  setLaunching]  = useState(false)

  const audience = selGroup?.count || 0
  const canNext  = [!!selTpl, !!(selGroup || csvFile), true, true][step]

  function launch() {
    setLaunching(true)
    setTimeout(() => {
      onCreated({
        id: `c${Date.now()}`,
        name: campName || selTpl?.name?.replace(/_/g, ' ') || 'New Campaign',
        date: new Date().toISOString().slice(0, 16).replace('T', ' '),
        channel: 'Default',
        recipients: audience, successful: 0, read: 0, replied: 0,
        failed: 0, ignored: 0, sending: audience, clicks: 0,
        status: sendNow ? 'Sending' : 'Scheduled',
        template: selTpl || { name: '', category: 'MARKETING', header: 'NONE', body: '', buttons: [] },
      })
      setLaunching(false)
      onClose()
    }, 1800)
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-3xl flex flex-col shadow-modal" style={{ maxHeight: '92vh' }}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-surface-border flex-shrink-0">
          <div>
            <h2 className="font-bold text-slate-900 text-base">Create Campaign</h2>
            <p className="text-xs text-slate-400 mt-0.5">Step {step + 1} of {WIZARD_STEPS.length} — {WIZARD_STEPS[step]}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors">
            <X size={16} />
          </button>
        </div>

        {/* Step indicator */}
        <div className="px-6 pt-4 pb-3 border-b border-surface-border flex-shrink-0">
          <div className="flex items-center">
            {WIZARD_STEPS.map((s, i) => (
              <div key={i} className="flex items-center flex-1 last:flex-none">
                <div className="flex items-center gap-2">
                  <div className={clsx(
                    'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all',
                    i < step  ? 'bg-emerald-500 text-white' :
                    i === step ? 'bg-primary text-white ring-4 ring-primary/20' :
                                 'bg-slate-100 text-slate-400'
                  )}>
                    {i < step ? <Check size={13} /> : i + 1}
                  </div>
                  <span className={clsx('text-xs font-semibold hidden sm:block',
                    i === step ? 'text-primary' : i < step ? 'text-emerald-600' : 'text-slate-400')}>
                    {s}
                  </span>
                </div>
                {i < WIZARD_STEPS.length - 1 && (
                  <div className={clsx('flex-1 h-px mx-3', i < step ? 'bg-emerald-300' : 'bg-slate-200')} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">

          {/* Step 0 — Template */}
          {step === 0 && (
            <div className="flex" style={{ minHeight: 360 }}>
              <div className="flex-1 flex flex-col border-r border-surface-border">
                <div className="p-4 border-b border-surface-border">
                  <div className="relative">
                    <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input className="input pl-9 text-sm w-full" placeholder="Search approved templates…"
                      value={tplSearch} onChange={e => setTplSearch(e.target.value)} />
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto divide-y divide-surface-border">
                  {APPROVED_TEMPLATES.filter(t => t.name?.toLowerCase().includes(tplSearch.toLowerCase())).map(t => (
                    <div key={t.id} onClick={() => setSelTpl(t)}
                      className={clsx('flex items-start gap-3 px-4 py-3.5 cursor-pointer hover:bg-slate-50 transition-colors',
                        selTpl?.id === t.id && 'bg-primary-50 border-l-[3px] border-l-primary')}>
                      <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5',
                        t.category === 'MARKETING' ? 'bg-violet-50' : 'bg-blue-50')}>
                        <FileText size={14} className={t.category === 'MARKETING' ? 'text-violet-500' : 'text-blue-500'} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="text-sm font-semibold text-slate-800 truncate">{t.name?.replace(/_/g, ' ')}</p>
                          <span className={clsx('text-[9px] font-bold px-1.5 py-0.5 rounded flex-shrink-0',
                            t.category === 'MARKETING' ? 'bg-violet-100 text-violet-600' : 'bg-blue-100 text-blue-600')}>
                            {t.category?.charAt(0) + t.category?.slice(1).toLowerCase()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 truncate">{t.body}</p>
                      </div>
                      {selTpl?.id === t.id && <CheckCircle2 size={15} className="text-primary flex-shrink-0" />}
                    </div>
                  ))}
                </div>
              </div>
              <div className="w-56 p-4 bg-slate-50 flex flex-col">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Preview</p>
                <PhonePreview tpl={selTpl} />
              </div>
            </div>
          )}

          {/* Step 1 — Audience */}
          {step === 1 && (
            <div className="p-6 space-y-5">
              {/* Toggle */}
              <div className="flex rounded-xl border border-surface-border overflow-hidden bg-slate-50 p-1">
                {[['group', Users, 'Contact Group'], ['csv', Upload, 'Upload CSV']].map(([k, Icon, lbl]) => (
                  <button key={k} onClick={() => setMode(k)}
                    className={clsx('flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold rounded-lg transition-all',
                      mode === k ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700')}>
                    <Icon size={14} /> {lbl}
                  </button>
                ))}
              </div>

              {mode === 'group' && (
                <div className="grid grid-cols-2 gap-3">
                  {CONTACT_GROUPS.map(g => (
                    <div key={g.id} onClick={() => setSelGroup(g)}
                      className={clsx('rounded-xl border p-4 cursor-pointer transition-all hover:shadow-sm',
                        selGroup?.id === g.id
                          ? 'border-primary bg-primary-50 shadow-sm'
                          : 'border-surface-border hover:border-slate-300')}>
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{g.icon}</span>
                          <p className="font-semibold text-slate-800 text-sm">{g.name}</p>
                        </div>
                        {selGroup?.id === g.id && <CheckCircle2 size={15} className="text-primary flex-shrink-0" />}
                      </div>
                      <p className="text-xs text-slate-400 mb-2">{g.desc}</p>
                      <div className="flex items-center gap-1.5">
                        <Users size={11} className="text-slate-400" />
                        <span className="text-sm font-bold text-primary">{g.count.toLocaleString()}</span>
                        <span className="text-xs text-slate-400">contacts</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {mode === 'csv' && (
                <label className="border-2 border-dashed border-slate-200 rounded-xl p-12 text-center cursor-pointer hover:border-primary hover:bg-primary-50/30 transition-all block">
                  <Upload size={26} className="text-slate-300 mx-auto mb-3" />
                  {csvFile
                    ? <><p className="font-semibold text-primary">{csvFile.name}</p><p className="text-xs text-slate-400 mt-1">Click to replace file</p></>
                    : <><p className="font-semibold text-slate-600">Drop your CSV or Excel file here</p><p className="text-xs text-slate-400 mt-1">Columns: Name, Phone Number, Variables…</p></>
                  }
                  <input type="file" accept=".csv,.xlsx" hidden
                    onChange={e => { setCsvFile(e.target.files[0]); setSelGroup({ name: e.target.files[0].name, count: 0 }) }} />
                </label>
              )}

              {(selGroup || csvFile) && (
                <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                  <CheckCircle2 size={18} className="text-emerald-500 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-emerald-800 text-sm">{selGroup?.count?.toLocaleString() || 'Custom list'} recipients selected</p>
                    <p className="text-xs text-emerald-600 mt-0.5">{selGroup?.name}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 2 — Schedule */}
          {step === 2 && (
            <div className="p-6 space-y-5">
              <div className="form-group">
                <label className="label">Campaign Name</label>
                <input className="input" placeholder="e.g. May Festival Offer 2025"
                  value={campName} onChange={e => setCampName(e.target.value)} />
              </div>

              <div>
                <label className="label mb-3 block">When to send</label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { k: true,  Icon: Zap,      label: 'Send Immediately', desc: 'Launch as soon as you confirm' },
                    { k: false, Icon: Calendar, label: 'Schedule for Later', desc: 'Pick a specific date & time' },
                  ].map(({ k, Icon, label, desc }) => (
                    <div key={String(k)} onClick={() => setSendNow(k)}
                      className={clsx('rounded-xl border p-4 cursor-pointer transition-all',
                        sendNow === k ? 'border-primary bg-primary-50 shadow-sm' : 'border-surface-border hover:border-slate-300')}>
                      <div className="flex justify-between items-center mb-2.5">
                        <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center',
                          sendNow === k ? 'bg-primary/10' : 'bg-slate-100')}>
                          <Icon size={15} className={sendNow === k ? 'text-primary' : 'text-slate-400'} />
                        </div>
                        {sendNow === k && <CheckCircle2 size={15} className="text-primary" />}
                      </div>
                      <p className="font-semibold text-sm text-slate-800">{label}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {!sendNow && (
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2 form-group">
                    <label className="label">Date & Time</label>
                    <div className="flex gap-2">
                      <input type="date" className="input flex-1" value={schedDate} onChange={e => setSchedDate(e.target.value)} />
                      <input type="time" className="input w-28" value={schedTime} onChange={e => setSchedTime(e.target.value)} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="label">Timezone</label>
                    <select className="input">
                      <option>Asia/Kolkata</option>
                      <option>UTC</option>
                      <option>America/New_York</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Summary */}
              <div className="rounded-xl border border-surface-border bg-slate-50 p-4 space-y-2.5">
                {[
                  { label: 'Template',  value: selTpl?.name?.replace(/_/g, ' ') || '—' },
                  { label: 'Audience',  value: `${audience.toLocaleString()} contacts`   },
                  { label: 'Sending',   value: sendNow ? 'Immediately' : `${schedDate} at ${schedTime}` },
                  { label: 'Est. Cost', value: `₹${Math.ceil(audience * 0.05).toLocaleString()}` },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-slate-400">{label}</span>
                    <span className="font-semibold text-slate-800 text-right ml-4">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 3 — Review */}
          {step === 3 && (
            <div className="flex" style={{ minHeight: 360 }}>
              <div className="flex-1 p-6 space-y-4 border-r border-surface-border">
                <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-100 flex items-start gap-2.5">
                  <Info size={14} className="text-blue-500 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-700 leading-relaxed">
                    Review all details carefully. Once launched, the campaign will be queued for immediate delivery.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: FileText, label: 'Template',  val: selTpl?.name?.replace(/_/g, ' ') || '—' },
                    { icon: Users,    label: 'Audience',  val: `${audience.toLocaleString()} contacts`  },
                    { icon: Clock,    label: 'Sends',     val: sendNow ? 'Immediately' : schedDate       },
                    { icon: Zap,      label: 'Est. Cost', val: `₹${Math.ceil(audience * 0.05).toLocaleString()}` },
                  ].map(({ icon: Icon, label, val }) => (
                    <div key={label} className="flex items-center gap-3 p-3.5 rounded-xl border border-surface-border bg-slate-50/50">
                      <div className="w-8 h-8 rounded-lg bg-white border border-surface-border flex items-center justify-center flex-shrink-0">
                        <Icon size={14} className="text-slate-500" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[10px] text-slate-400 font-medium">{label}</p>
                        <p className="text-sm font-semibold text-slate-800 truncate">{val}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-amber-50 border border-amber-200">
                  <AlertCircle size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-800 leading-relaxed">
                    By launching, you confirm all recipients have opted in to receive WhatsApp marketing messages per Meta's Business Messaging Policy.
                  </p>
                </div>
              </div>

              <div className="w-56 p-5 bg-slate-50">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Message Preview</p>
                <PhonePreview tpl={selTpl} />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-surface-border flex-shrink-0 bg-slate-50/50 rounded-b-2xl">
          <div className="text-xs text-slate-400">
            {audience > 0 && (
              <span className="flex items-center gap-1.5 text-slate-500">
                <Users size={12} /> {audience.toLocaleString()} recipients
              </span>
            )}
          </div>
          <div className="flex gap-2.5">
            {step > 0 && (
              <button onClick={() => setStep(s => s - 1)} className="btn-secondary gap-1.5">
                <ChevronLeft size={14} /> Back
              </button>
            )}
            {step < WIZARD_STEPS.length - 1
              ? (
                <button onClick={() => setStep(s => s + 1)} disabled={!canNext}
                  className={clsx('btn-primary gap-1.5', !canNext && 'opacity-40 cursor-not-allowed')}>
                  Continue <ChevronRight size={14} />
                </button>
              )
              : (
                <button onClick={launch} disabled={launching}
                  className={clsx('btn-primary gap-1.5', launching && 'opacity-60 cursor-not-allowed')}>
                  {launching
                    ? <><span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> Launching…</>
                    : sendNow
                      ? <><Send size={13} /> Launch Campaign</>
                      : <><Calendar size={13} /> Schedule Campaign</>
                  }
                </button>
              )
            }
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────────── MAIN PAGE ─────────────────────────── */
export default function Broadcasting() {
  const [campaigns,      setCampaigns]      = useState(CAMPAIGNS)
  const [view,           setView]           = useState('list')
  const [activeCampaign, setActiveCampaign] = useState(null)
  const [showWizard,     setShowWizard]     = useState(false)
  const [search,         setSearch]         = useState('')
  const [activeTab,      setActiveTab]      = useState('All')
  const [dateRange,      setDateRange]      = useState('Last 30 days')

  const totals = campaigns.reduce((a, c) => ({
    sent:       a.sent       + c.successful + c.failed,
    delivered:  a.delivered  + c.successful,
    read:       a.read       + c.read,
    replied:    a.replied    + c.replied,
    sending:    a.sending    + c.sending,
    failed:     a.failed     + c.failed,
    processing: a.processing + (c.status === 'Sending'   ? 1 : 0),
    queued:     a.queued     + (c.status === 'Scheduled' ? 1 : 0),
  }), { sent: 0, delivered: 0, read: 0, replied: 0, sending: 0, failed: 0, processing: 0, queued: 0 })

  const tabCounts = STATUS_TABS.reduce((acc, t) => {
    acc[t] = t === 'All' ? campaigns.length : campaigns.filter(c => c.status === t).length
    return acc
  }, {})

  const filtered = campaigns.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase())
    const matchTab    = activeTab === 'All' || c.status === activeTab
    return matchSearch && matchTab
  })

  if (view === 'insights' && activeCampaign) {
    return (
      <div className="animate-fade-in">
        <CampaignInsights campaign={activeCampaign} onBack={() => setView('list')} />
      </div>
    )
  }

  return (
    <div className="space-y-5 animate-fade-in">

      {/* ── Header ── */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2.5 mb-0.5">
            <h1 className="text-xl font-bold text-slate-900">Broadcasts</h1>
            <span className="text-xs font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
              {campaigns.length} campaigns
            </span>
          </div>
          <p className="text-sm text-slate-400">Monitor and manage all your WhatsApp broadcast campaigns</p>
        </div>
        <div className="flex items-center gap-2">
          <select className="input text-sm w-36" value={dateRange} onChange={e => setDateRange(e.target.value)}>
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 90 days</option>
            <option>All time</option>
          </select>
          <button onClick={() => setShowWizard(true)} className="btn-primary gap-1.5">
            <Plus size={15} /> New Campaign
          </button>
        </div>
      </div>

      {/* ── Account Health ── */}
      <div className="grid grid-cols-3 gap-4">

        {/* Daily Limit */}
        <div className="card p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Daily Limit</p>
              <p className="text-sm font-semibold text-slate-900">Messaging Capacity</p>
            </div>
            <button className="text-slate-300 hover:text-slate-500 transition-colors">
              <Info size={14} />
            </button>
          </div>
          <div className="mb-3">
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-400">Used today</span>
              <span className="font-semibold text-slate-700">957 <span className="text-slate-400 font-normal">/ 2,000</span></span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full transition-all" style={{ width: '47.85%' }} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" />
            <p className="text-xs text-slate-500">1,043 contacts remaining today</p>
          </div>
        </div>

        {/* Messaging Quality */}
        <div className="card p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Quality Score</p>
              <p className="text-sm font-semibold text-slate-900">Messaging Quality</p>
            </div>
            <Shield size={15} className="text-emerald-500" />
          </div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-emerald-50 ring-2 ring-emerald-400 ring-offset-2 flex items-center justify-center flex-shrink-0">
              <div className="w-4 h-4 rounded-full bg-emerald-400" />
            </div>
            <div>
              <p className="text-lg font-bold text-emerald-600 leading-none">High</p>
              <p className="text-xs text-slate-400 mt-0.5">Your score is excellent</p>
            </div>
          </div>
          <div className="flex items-end gap-0.5 h-7">
            {[40, 55, 45, 65, 58, 72, 68].map((h, i) => (
              <div key={i} className={clsx('flex-1 rounded-sm transition-all', i >= 4 ? 'bg-emerald-400' : 'bg-emerald-100')}
                style={{ height: `${h}%` }} />
            ))}
          </div>
        </div>

        {/* Sending Streak */}
        <div className="card p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Streak</p>
              <p className="text-sm font-semibold text-slate-900">Consecutive Sending Days</p>
            </div>
            <Zap size={15} className="text-amber-400" />
          </div>
          <div className="flex items-center gap-2 mb-4">
            <p className="text-3xl font-bold text-slate-900">3</p>
            <p className="text-sm text-slate-400">days this week</p>
          </div>
          <div className="flex items-center gap-1.5">
            {['M','T','W','T','F','S','S'].map((day, i) => (
              <div key={i} className="flex flex-col items-center gap-1">
                <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center transition-all',
                  i < 3 ? 'bg-amber-400' : 'bg-slate-100')}>
                  {i < 3 ? <Check size={12} className="text-white" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />}
                </div>
                <span className="text-[9px] font-medium text-slate-400">{day}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Primary Metrics ── */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { icon: Send,         label: 'Total Sent',   value: totals.sent,      sub: `${pct(totals.delivered, totals.sent)}% delivery rate`,  iconBg: 'bg-blue-50',    iconColor: 'text-blue-500'    },
          { icon: CheckCircle2, label: 'Delivered',    value: totals.delivered, sub: `of ${totals.sent.toLocaleString()} sent`,                 iconBg: 'bg-emerald-50', iconColor: 'text-emerald-500' },
          { icon: Eye,          label: 'Read',         value: totals.read,      sub: `${pct(totals.read, totals.delivered)}% read rate`,        iconBg: 'bg-teal-50',    iconColor: 'text-teal-500'    },
          { icon: CornerUpLeft, label: 'Replied',      value: totals.replied,   sub: `${pct(totals.replied, totals.delivered)}% reply rate`,    iconBg: 'bg-violet-50',  iconColor: 'text-violet-500'  },
        ].map(({ icon: Icon, label, value, sub, iconBg, iconColor }) => (
          <div key={label} className="card p-5 hover:shadow-md transition-shadow">
            <div className={clsx('w-9 h-9 rounded-xl flex items-center justify-center mb-3', iconBg)}>
              <Icon size={17} className={iconColor} />
            </div>
            <p className="text-2xl font-bold text-slate-900">{value.toLocaleString()}</p>
            <p className="text-xs font-semibold text-slate-500 mt-0.5">{label}</p>
            <p className="text-xs text-slate-400 mt-1">{sub}</p>
          </div>
        ))}
      </div>

      {/* Secondary metrics */}
      <div className="card p-4">
        <div className="grid grid-cols-4 divide-x divide-surface-border">
          {[
            { label: 'Currently Sending', value: totals.sending,    color: 'text-blue-600',   badge: 'bg-blue-50'   },
            { label: 'Failed',            value: totals.failed,     color: 'text-red-600',    badge: 'bg-red-50'    },
            { label: 'Processing',        value: totals.processing, color: 'text-amber-600',  badge: 'bg-amber-50'  },
            { label: 'Queued',            value: totals.queued,     color: 'text-slate-600',  badge: 'bg-slate-50'  },
          ].map(({ label, value, color, badge }) => (
            <div key={label} className="px-5 first:pl-0 last:pr-0 flex items-center gap-3">
              <span className={clsx('text-xl font-bold tabular-nums', color)}>{value.toLocaleString()}</span>
              <span className="text-xs text-slate-400 leading-tight">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Campaigns ── */}
      <div className="card p-0 overflow-hidden">

        {/* Tabs + Search */}
        <div className="flex items-center justify-between px-5 border-b border-surface-border">
          <div className="flex items-center gap-0">
            {STATUS_TABS.map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={clsx('px-4 py-3.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap',
                  activeTab === tab
                    ? 'border-primary text-primary'
                    : 'border-transparent text-slate-500 hover:text-slate-700')}>
                {tab}
                {tabCounts[tab] > 0 && (
                  <span className={clsx('text-[10px] font-bold px-1.5 py-0.5 rounded-full',
                    activeTab === tab ? 'bg-primary/10 text-primary' : 'bg-slate-100 text-slate-400')}>
                    {tabCounts[tab]}
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="relative py-2">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input-sm pl-8 text-xs w-52" placeholder="Search campaigns…"
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-surface-border bg-slate-50/60">
                <th className="px-5 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Campaign</th>
                <th className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Audience</th>
                <th className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider min-w-[200px]">Performance</th>
                <th className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Sent</th>
                <th className="px-5 py-3 text-right text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {filtered.map(c => {
                const delivPct   = pct(c.successful, c.recipients)
                const readPct    = pct(c.read,       c.recipients)
                const repliedPct = pct(c.replied,    c.recipients)
                return (
                  <tr key={c.id} className="hover:bg-slate-50/50 transition-colors group">

                    {/* Campaign */}
                    <td className="px-5 py-4">
                      <div className="flex items-start gap-3">
                        <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5',
                          c.template.category === 'MARKETING' ? 'bg-violet-50' : 'bg-blue-50')}>
                          <FileText size={13} className={c.template.category === 'MARKETING' ? 'text-violet-500' : 'text-blue-500'} />
                        </div>
                        <div className="min-w-0">
                          <button onClick={() => { setActiveCampaign(c); setView('insights') }}
                            className="text-left group/name">
                            <p className="text-sm font-semibold text-slate-900 group-hover/name:text-primary transition-colors truncate max-w-[220px]">
                              {c.name}
                            </p>
                          </button>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className={clsx('text-[9px] font-bold px-1.5 py-0.5 rounded',
                              c.template.category === 'MARKETING' ? 'bg-violet-50 text-violet-500' : 'bg-blue-50 text-blue-500')}>
                              {c.template.category}
                            </span>
                            <span className="text-xs text-slate-400">{c.channel}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Audience */}
                    <td className="px-4 py-4">
                      <p className="text-sm font-semibold text-slate-800">{c.recipients.toLocaleString()}</p>
                      <p className="text-xs text-slate-400">contacts</p>
                    </td>

                    {/* Performance — inline funnel */}
                    <td className="px-4 py-4">
                      <div className="space-y-1.5">
                        {[
                          { label: 'Delivered', pctVal: delivPct,   bar: 'bg-emerald-400' },
                          { label: 'Read',      pctVal: readPct,    bar: 'bg-teal-400'    },
                          { label: 'Replied',   pctVal: repliedPct, bar: 'bg-violet-400'  },
                        ].map(({ label, pctVal, bar }) => (
                          <div key={label} className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-400 w-16 flex-shrink-0">{label}</span>
                            <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className={clsx('h-full rounded-full transition-all', bar)} style={{ width: `${pctVal}%` }} />
                            </div>
                            <span className="text-[10px] font-semibold text-slate-600 w-8 text-right tabular-nums">{pctVal}%</span>
                          </div>
                        ))}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="px-4 py-4">
                      <StatusPill status={c.status} />
                    </td>

                    {/* Date */}
                    <td className="px-4 py-4">
                      <p className="text-xs text-slate-500 whitespace-nowrap">{c.date}</p>
                    </td>

                    {/* Actions */}
                    <td className="px-5 py-4 text-right">
                      <button onClick={() => { setActiveCampaign(c); setView('insights') }}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:bg-primary-50 px-3 py-1.5 rounded-lg transition-colors">
                        <BarChart2 size={12} /> Analytics
                      </button>
                    </td>
                  </tr>
                )
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-16 text-center">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-3">
                      <Inbox size={20} className="text-slate-300" />
                    </div>
                    <p className="text-sm font-semibold text-slate-500">No campaigns found</p>
                    <p className="text-xs text-slate-400 mt-1">Try adjusting your search or filters</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-surface-border bg-slate-50/40">
          <p className="text-xs text-slate-400">Showing <span className="font-semibold text-slate-600">{filtered.length}</span> of <span className="font-semibold text-slate-600">{campaigns.length}</span> campaigns</p>
          <div className="flex items-center gap-1">
            <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 disabled:opacity-30 transition-colors" disabled><ChevronLeft size={14} /></button>
            <button className="px-3 py-1 rounded-lg bg-primary text-white text-xs font-semibold">1</button>
            <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 disabled:opacity-30 transition-colors" disabled><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {showWizard && <NewCampaignWizard onClose={() => setShowWizard(false)} onCreated={c => setCampaigns(prev => [c, ...prev])} />}
    </div>
  )
}
