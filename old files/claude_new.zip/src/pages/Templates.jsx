import { useState, useRef, useEffect, useMemo } from 'react'

/* ─── LANGUAGES ──────────────────────────────────────────────────────────── */
const LANGUAGES = [
  { value: 'af', label: 'Afrikaans' }, { value: 'sq', label: 'Albanian' },
  { value: 'ar', label: 'Arabic' }, { value: 'az', label: 'Azerbaijani' },
  { value: 'bn', label: 'Bengali' }, { value: 'bg', label: 'Bulgarian' },
  { value: 'ca', label: 'Catalan' }, { value: 'zh_CN', label: 'Chinese (Simplified)' },
  { value: 'zh_TW', label: 'Chinese (Traditional)' }, { value: 'hr', label: 'Croatian' },
  { value: 'cs', label: 'Czech' }, { value: 'da', label: 'Danish' },
  { value: 'nl', label: 'Dutch' }, { value: 'en', label: 'English' },
  { value: 'en_GB', label: 'English (UK)' }, { value: 'en_US', label: 'English (US)' },
  { value: 'et', label: 'Estonian' }, { value: 'fil', label: 'Filipino' },
  { value: 'fi', label: 'Finnish' }, { value: 'fr', label: 'French' },
  { value: 'de', label: 'German' }, { value: 'ka', label: 'Georgian' },
  { value: 'el', label: 'Greek' }, { value: 'gu', label: 'Gujarati' },
  { value: 'ha', label: 'Hausa' }, { value: 'he', label: 'Hebrew' },
  { value: 'hi', label: 'Hindi' }, { value: 'hu', label: 'Hungarian' },
  { value: 'id', label: 'Indonesian' }, { value: 'ga', label: 'Irish' },
  { value: 'it', label: 'Italian' }, { value: 'ja', label: 'Japanese' },
  { value: 'kn', label: 'Kannada' }, { value: 'kk', label: 'Kazakh' },
  { value: 'ko', label: 'Korean' }, { value: 'lo', label: 'Lao' },
  { value: 'lv', label: 'Latvian' }, { value: 'lt', label: 'Lithuanian' },
  { value: 'mk', label: 'Macedonian' }, { value: 'ms', label: 'Malay' },
  { value: 'ml', label: 'Malayalam' }, { value: 'mr', label: 'Marathi' },
  { value: 'nb', label: 'Norwegian' }, { value: 'fa', label: 'Persian' },
  { value: 'pl', label: 'Polish' }, { value: 'pt_BR', label: 'Portuguese (Brazil)' },
  { value: 'pt_PT', label: 'Portuguese (Portugal)' }, { value: 'pa', label: 'Punjabi' },
  { value: 'ro', label: 'Romanian' }, { value: 'ru', label: 'Russian' },
  { value: 'sr', label: 'Serbian' }, { value: 'sk', label: 'Slovak' },
  { value: 'sl', label: 'Slovenian' }, { value: 'es', label: 'Spanish' },
  { value: 'es_AR', label: 'Spanish (Argentina)' }, { value: 'es_ES', label: 'Spanish (Spain)' },
  { value: 'es_MX', label: 'Spanish (Mexico)' }, { value: 'sw', label: 'Swahili' },
  { value: 'sv', label: 'Swedish' }, { value: 'ta', label: 'Tamil' },
  { value: 'te', label: 'Telugu' }, { value: 'th', label: 'Thai' },
  { value: 'tr', label: 'Turkish' }, { value: 'uk', label: 'Ukrainian' },
  { value: 'ur', label: 'Urdu' }, { value: 'uz', label: 'Uzbek' },
  { value: 'vi', label: 'Vietnamese' }, { value: 'zu', label: 'Zulu' },
]

/* ─── CATEGORY DEFINITIONS ───────────────────────────────────────────────── */
const CATEGORY_DEFS = [
  {
    value: 'MARKETING', label: 'Marketing', tabIcon: '📣',
    goodFor: 'Welcome messages, promotions, offers, coupons, newsletters, announcements',
    areas: 'Media, header, body, footer, button',
    subTypes: [
      { value: 'default', label: 'Default', desc: 'Send messages with media and customised buttons to engage your customers.' },
      { value: 'catalog', label: 'Catalogue', desc: 'Send messages that drive sales by connecting your product catalogue.' },
      { value: 'flows', label: 'Flows', desc: 'Send a form to capture customer interests, appointment requests or run surveys.' },
      { value: 'order_details', label: 'Order details', desc: 'Send messages through which customers can pay you.' },
      { value: 'calling_permissions', label: 'Calling permissions request', desc: 'Ask customers if you can call them on WhatsApp.' },
    ],
  },
  {
    value: 'UTILITY', label: 'Utility', tabIcon: '🔔',
    goodFor: 'Order confirmations, account update, receipts, appointment reminders, billing',
    areas: 'Media, header, body, footer, button',
    subTypes: [
      { value: 'default', label: 'Default', desc: 'Send messages about an existing order or account.' },
      { value: 'flows', label: 'Flows', desc: 'Send a form to collect feedback, send reminders or manage orders.' },
      { value: 'order_status', label: 'Order status', desc: 'Send messages to tell customers about the progress of their orders.' },
      { value: 'order_details', label: 'Order details', desc: 'Send messages through which customers can pay you.' },
      { value: 'calling_permissions', label: 'Calling permissions request', desc: 'Ask customers if you can call them on WhatsApp.' },
    ],
  },
  {
    value: 'AUTHENTICATION', label: 'Authentication', tabIcon: '✏️',
    goodFor: 'One-time password, account recovery code, account verification, integrity challenges',
    areas: 'Code delivery method',
    subTypes: [
      { value: 'otp', label: 'One-time passcode', desc: 'Send codes to verify a transaction or login.' },
    ],
  },
]

const COUNTRY_CODES = [
  { value: 'US +1', label: 'United States (+1)' }, { value: 'UK +44', label: 'United Kingdom (+44)' },
  { value: 'IN +91', label: 'India (+91)' }, { value: 'AU +61', label: 'Australia (+61)' },
  { value: 'CA +1', label: 'Canada (+1)' }, { value: 'DE +49', label: 'Germany (+49)' },
  { value: 'FR +33', label: 'France (+33)' }, { value: 'BR +55', label: 'Brazil (+55)' },
  { value: 'MX +52', label: 'Mexico (+52)' }, { value: 'AE +971', label: 'UAE (+971)' },
  { value: 'SA +966', label: 'Saudi Arabia (+966)' }, { value: 'SG +65', label: 'Singapore (+65)' },
  { value: 'PK +92', label: 'Pakistan (+92)' }, { value: 'BD +880', label: 'Bangladesh (+880)' },
  { value: 'NG +234', label: 'Nigeria (+234)' }, { value: 'ID +62', label: 'Indonesia (+62)' },
]

const ACTIVE_FOR_OPTS = [
  { value: '1 day', label: '1 day' }, { value: '3 days', label: '3 days' },
  { value: '7 days', label: '7 days' }, { value: '14 days', label: '14 days' },
  { value: '30 days', label: '30 days' },
]

const TTL_OPTIONS = [
  { value: '5m', label: '5 minutes' }, { value: '10m', label: '10 minutes' },
  { value: '15m', label: '15 minutes' }, { value: '30m', label: '30 minutes' },
  { value: '1h', label: '1 hour' }, { value: '3h', label: '3 hours' },
  { value: '6h', label: '6 hours' }, { value: '12h', label: '12 hours' },
  { value: '24h', label: '24 hours' }, { value: '48h', label: '48 hours' },
  { value: '7d', label: '7 days' },
]

const FLOW_ICONS = [
  { value: 'DEFAULT', label: 'Default' }, { value: 'DOCUMENT', label: 'Document' },
  { value: 'PROMOTION', label: 'Promotion' }, { value: 'REVIEW', label: 'Review' },
]

const MEDIA_ICONS = { none: '', image: '🖼', video: '▶', document: '📄', location: '📍' }

/* ─── UTILITIES ──────────────────────────────────────────────────────────── */
function extractVariables(text) {
  if (!text) return []
  return [...new Set([...text.matchAll(/\{\{(\d+)\}\}/g)].map(m => parseInt(m[1])))].sort((a, b) => a - b)
}

function parseWAText(text, samples = {}) {
  if (!text) return null
  let s = text.replace(/\{\{(\d+)\}\}/g, (_, n) => samples[n] ? `\x00S:${samples[n]}\x00` : `{{${n}}}`)
  const parts = []
  s.split(/(\*[^*\n]+\*|_[^_\n]+_|~[^~\n]+~|`[^`\n]+`|\x00S:[^\x00]+\x00|\{\{\d+\}\})/g).forEach((t, i) => {
    if (!t) return
    if (t.startsWith('\x00S:')) parts.push(<span key={i} style={{ background: '#dbeafe', borderRadius: 3, padding: '0 3px', color: '#1d4ed8' }}>{t.slice(3, -1)}</span>)
    else if (/^\{\{\d+\}\}$/.test(t)) parts.push(<span key={i} style={{ background: '#fef3c7', borderRadius: 3, padding: '0 3px', color: '#92400e', fontFamily: 'monospace', fontSize: 11 }}>{t}</span>)
    else if (t.startsWith('*') && t.endsWith('*')) parts.push(<strong key={i}>{t.slice(1, -1)}</strong>)
    else if (t.startsWith('_') && t.endsWith('_')) parts.push(<em key={i}>{t.slice(1, -1)}</em>)
    else if (t.startsWith('~') && t.endsWith('~')) parts.push(<s key={i}>{t.slice(1, -1)}</s>)
    else if (t.startsWith('`') && t.endsWith('`')) parts.push(<code key={i} style={{ fontFamily: 'monospace', background: '#f3f4f6', borderRadius: 3, padding: '0 3px' }}>{t.slice(1, -1)}</code>)
    else parts.push(<span key={i}>{t}</span>)
  })
  return parts
}

function buildAPIPayload(form) {
  const components = []
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  if (hasMedia) {
    components.push({ type: 'HEADER', format: form.mediaSample.toUpperCase(), example: { header_handle: ['PLACEHOLDER'] } })
  } else if (form.headerText) {
    const vars = extractVariables(form.headerText)
    const comp = { type: 'HEADER', format: 'TEXT', text: form.headerText }
    if (vars.length) comp.example = { header_text: vars.map(n => form.samples?.[`h${n}`] || `val${n}`) }
    components.push(comp)
  }
  if (form.body) {
    const vars = extractVariables(form.body)
    const comp = { type: 'BODY', text: form.body }
    if (vars.length) comp.example = { body_text: [vars.map(n => form.samples?.[`b${n}`] || `val${n}`)] }
    components.push(comp)
  }
  if (form.footer) components.push({ type: 'FOOTER', text: form.footer })
  if (form.buttons?.length) {
    components.push({
      type: 'BUTTONS',
      buttons: form.buttons.map(b => {
        if (b.kind === 'custom') return { type: 'QUICK_REPLY', text: b.text }
        if (b.kind === 'url') return { type: 'URL', text: b.text, url: b.url || '', ...(b.urlType === 'dynamic' ? { example: [b.dynamicSample || '/example'] } : {}) }
        if (b.kind === 'phone') return { type: 'PHONE_NUMBER', text: b.text, phone_number: b.phone || '' }
        if (b.kind === 'wa_call') return { type: 'VOICE_CALL', text: b.text }
        if (b.kind === 'flow') return { type: 'FLOW', text: b.text, flow_id: b.flowId || '' }
        if (b.kind === 'copy_code') return { type: 'COPY_CODE', example: b.code || 'CODE10' }
        return { type: 'QUICK_REPLY', text: b.text }
      }),
    })
  }
  return { name: form.name, language: form.language, category: form.category, components }
}

/* ─── CLICK OUTSIDE HOOK ─────────────────────────────────────────────────── */
function useClickOutside(ref, callback) {
  const cbRef = useRef(callback)
  cbRef.current = callback
  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target)) cbRef.current()
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [ref])
}

/* ─── CUSTOM SELECT ──────────────────────────────────────────────────────── */
function CustomSelect({ value, options, onChange, placeholder = 'Select...', disabled = false, style = {} }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  useClickOutside(ref, () => setOpen(false))
  const selected = options.find(o => o.value === value)

  return (
    <div ref={ref} style={{ position: 'relative', ...style }}>
      <button
        type="button"
        onClick={() => !disabled && setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 10px', border: `1px solid ${open ? '#1877F2' : '#ccd0d5'}`,
          borderRadius: 6, background: disabled ? '#f0f2f5' : '#fff',
          color: selected ? (disabled ? '#9ca3af' : '#1c1e21') : '#9ca3af',
          fontSize: 13, cursor: disabled ? 'not-allowed' : 'pointer',
          outline: 'none', boxSizing: 'border-box', transition: 'border-color .15s',
        }}
      >
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'left' }}>
          {selected?.label || placeholder}
        </span>
        <svg width="10" height="6" viewBox="0 0 10 6" style={{ flexShrink: 0, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}>
          <path d="M1 1l4 4 4-4" stroke="#65676b" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {open && !disabled && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 3px)', left: 0, minWidth: '100%',
          background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8,
          boxShadow: '0 8px 24px rgba(0,0,0,0.14)', zIndex: 9999,
          maxHeight: 260, overflowY: 'auto',
        }}>
          {options.map(opt => (
            <button
              key={opt.value}
              type="button"
              onClick={() => { if (!opt.disabled) { onChange(opt.value); setOpen(false) } }}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                width: '100%', padding: '9px 12px', border: 'none',
                background: opt.value === value ? '#e7f3ff' : 'transparent',
                color: opt.disabled ? '#bcc0c4' : opt.value === value ? '#1877F2' : '#1c1e21',
                fontSize: 13, cursor: opt.disabled ? 'not-allowed' : 'pointer', textAlign: 'left',
              }}
              onMouseEnter={e => { if (!opt.disabled && opt.value !== value) e.currentTarget.style.background = '#f0f2f5' }}
              onMouseLeave={e => { if (opt.value !== value) e.currentTarget.style.background = 'transparent' }}
            >
              <span style={{ whiteSpace: 'nowrap' }}>{opt.label}</span>
              {opt.note && <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 12, flexShrink: 0 }}>{opt.note}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── SEARCHABLE SELECT ──────────────────────────────────────────────────── */
function SearchableSelect({ value, options, onChange, placeholder = 'Select...', disabled = false, style = {} }) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const ref = useRef(null)
  const searchRef = useRef(null)
  useClickOutside(ref, () => { setOpen(false); setSearch('') })
  const selected = options.find(o => o.value === value)
  const filtered = options.filter(o => o.label.toLowerCase().includes(search.toLowerCase()))

  function handleOpen() {
    if (disabled) return
    setOpen(o => !o)
    setTimeout(() => searchRef.current?.focus(), 50)
  }

  return (
    <div ref={ref} style={{ position: 'relative', ...style }}>
      <button
        type="button"
        onClick={handleOpen}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 10px', border: `1px solid ${open ? '#1877F2' : '#ccd0d5'}`,
          borderRadius: 6, background: disabled ? '#f0f2f5' : '#fff',
          color: selected ? (disabled ? '#9ca3af' : '#1c1e21') : '#9ca3af',
          fontSize: 13, cursor: disabled ? 'not-allowed' : 'pointer',
          outline: 'none', boxSizing: 'border-box', transition: 'border-color .15s',
        }}
      >
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'left' }}>
          {selected?.label || placeholder}
        </span>
        <svg width="10" height="6" viewBox="0 0 10 6" style={{ flexShrink: 0, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}>
          <path d="M1 1l4 4 4-4" stroke="#65676b" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {open && !disabled && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 3px)', left: 0, minWidth: '100%',
          background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8,
          boxShadow: '0 8px 24px rgba(0,0,0,0.14)', zIndex: 9999,
        }}>
          {/* Search box */}
          <div style={{ padding: '8px 8px 4px', borderBottom: '1px solid #f0f2f5' }}>
            <div style={{ position: 'relative' }}>
              <svg style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input
                ref={searchRef}
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search"
                style={{ width: '100%', padding: '6px 8px 6px 26px', border: '1px solid #e4e6eb', borderRadius: 5, fontSize: 13, outline: 'none', boxSizing: 'border-box', color: '#1c1e21' }}
              />
            </div>
          </div>
          {/* Options */}
          <div style={{ maxHeight: 220, overflowY: 'auto' }}>
            {filtered.length === 0 ? (
              <div style={{ padding: '12px', textAlign: 'center', fontSize: 12.5, color: '#9ca3af' }}>No results</div>
            ) : filtered.map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => { onChange(opt.value); setOpen(false); setSearch('') }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '9px 12px', border: 'none',
                  background: opt.value === value ? '#e7f3ff' : 'transparent',
                  color: opt.value === value ? '#1877F2' : '#1c1e21',
                  fontSize: 13, cursor: 'pointer', textAlign: 'left',
                }}
                onMouseEnter={e => { if (opt.value !== value) e.currentTarget.style.background = '#f0f2f5' }}
                onMouseLeave={e => { if (opt.value !== value) e.currentTarget.style.background = 'transparent' }}
              >
                {opt.value === value && (
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#1877F2', flexShrink: 0 }} />
                )}
                {opt.value !== value && <div style={{ width: 8, flexShrink: 0 }} />}
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

/* ─── STEP BAR ───────────────────────────────────────────────────────────── */
function StepBar({ step }) {
  const steps = ['Set up template', 'Edit template', 'Submit for Review']
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '0 24px', height: 46, background: '#fff', borderBottom: '1px solid #e4e6eb', flexShrink: 0 }}>
      {steps.map((s, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 20, height: 20, borderRadius: '50%', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 10, fontWeight: 700, flexShrink: 0,
              background: i <= step ? '#1877F2' : 'transparent',
              color: i <= step ? '#fff' : '#65676b',
              border: i <= step ? 'none' : '2px solid #bcc0c4',
            }}>
              {i < step ? '✓' : i + 1}
            </div>
            <span style={{ fontSize: 13, fontWeight: i === step ? 600 : 400, color: i === step ? '#1877F2' : i < step ? '#1877F2' : '#65676b' }}>{s}</span>
          </div>
          {i < steps.length - 1 && (
            <div style={{ width: 32, height: 1, background: i < step ? '#1877F2' : '#bcc0c4', margin: '0 12px' }} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ─── PHONE PREVIEW ──────────────────────────────────────────────────────── */
function PhonePreview({ form }) {
  const bSamples = useMemo(() => {
    const s = {}; extractVariables(form.body || '').forEach(n => { s[n] = form.samples?.[`b${n}`] || '' }); return s
  }, [form.body, form.samples])
  const hSamples = useMemo(() => {
    const s = {}; extractVariables(form.headerText || '').forEach(n => { s[n] = form.samples?.[`h${n}`] || '' }); return s
  }, [form.headerText, form.samples])
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const ctaBtns = (form.buttons || []).filter(b => b.kind !== 'custom')
  const qrBtns = (form.buttons || []).filter(b => b.kind === 'custom')
  const btnIco = { url: '🔗', phone: '📞', wa_call: '📲', flow: '▶', copy_code: '📋' }

  return (
    <div>
      <div style={{ width: 240, margin: '0 auto', background: '#111827', borderRadius: 28, padding: 6, boxShadow: '0 12px 36px rgba(0,0,0,0.3)' }}>
        <div style={{ borderRadius: 22, overflow: 'hidden', background: '#eae6df', minHeight: 380 }}>
          <div style={{ background: '#075e54', padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#128c7e', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11 }}>👤</div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#fff' }}>Business</div>
              <div style={{ fontSize: 9, color: '#b2dfdb' }}>via WhatsApp</div>
            </div>
          </div>
          <div style={{ padding: '10px 8px', minHeight: 220 }}>
            <div style={{ maxWidth: '90%', marginLeft: 'auto' }}>
              <div style={{ background: '#fff', borderRadius: '10px 2px 10px 10px', overflow: 'hidden', boxShadow: '0 1px 2px rgba(0,0,0,.08)' }}>
                {hasMedia && (
                  <div style={{ height: 90, background: form.mediaSample === 'image' ? 'linear-gradient(135deg,#e5e7eb,#d1d5db)' : form.mediaSample === 'video' ? 'linear-gradient(135deg,#1f2937,#374151)' : '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>
                    {MEDIA_ICONS[form.mediaSample]}
                  </div>
                )}
                {!hasMedia && form.headerText && (
                  <div style={{ padding: '8px 9px 3px', fontSize: 11.5, fontWeight: 700, color: '#111' }}>{parseWAText(form.headerText, hSamples)}</div>
                )}
                <div style={{ padding: '6px 9px', fontSize: 11, color: '#111', lineHeight: 1.55, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                  {form.body ? parseWAText(form.body, bSamples) : <span style={{ color: '#9ca3af', fontStyle: 'italic' }}>Message body…</span>}
                </div>
                {form.footer && <div style={{ padding: '0 9px 4px', fontSize: 9.5, color: '#6b7280' }}>{form.footer}</div>}
                <div style={{ padding: '1px 8px 4px', textAlign: 'right', fontSize: 8.5, color: '#9ca3af' }}>11:59 ✓✓</div>
                {ctaBtns.map(b => (
                  <div key={b.id} style={{ borderTop: '1px solid #f0f0f0', padding: '5px 9px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, fontSize: 10.5, color: '#128c7e', fontWeight: 600 }}>
                    <span>{btnIco[b.kind] || ''}</span>{b.text || <span style={{ color: '#9ca3af' }}>Button</span>}
                  </div>
                ))}
              </div>
              {qrBtns.length > 0 && (
                <div style={{ marginTop: 3, display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                  {qrBtns.map(b => (
                    <div key={b.id} style={{ background: '#fff', borderRadius: 6, padding: '4px 7px', fontSize: 10, color: '#128c7e', fontWeight: 600, boxShadow: '0 1px 2px rgba(0,0,0,.1)', flex: '1 1 auto', textAlign: 'center' }}>
                      {b.text || <span style={{ color: '#9ca3af' }}>Reply</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── VALIDATION PANEL ───────────────────────────────────────────────────── */
function ValidationPanel({ form }) {
  const bodyVars = extractVariables(form.body || '')
  const headerVars = extractVariables(form.headerText || '')
  const allSampleKeys = [...bodyVars.map(n => `b${n}`), ...headerVars.map(n => `h${n}`)]
  const missingSamples = allSampleKeys.filter(k => !form.samples?.[k]?.trim()).length
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const urlBtns = (form.buttons || []).filter(b => b.kind === 'url')
  const phoneBtns = (form.buttons || []).filter(b => b.kind === 'phone')
  const qrTexts = (form.buttons || []).filter(b => b.kind === 'custom').map(b => (b.text || '').trim().toLowerCase())
  const hasDupQr = new Set(qrTexts).size !== qrTexts.length

  const checks = [
    { label: 'Template name', ok: !!(form.name && /^[a-z0-9_]+$/.test(form.name) && form.name.length <= 512), detail: !form.name ? 'Required' : !/^[a-z0-9_]+$/.test(form.name) ? 'Lowercase & underscores only' : `${form.name.length}/512` },
    { label: 'Body content', ok: !!(form.body?.trim()), detail: form.body?.trim() ? `${form.body.length}/1024 chars` : 'Required' },
    { label: 'Sample values', ok: allSampleKeys.length === 0 || missingSamples === 0, detail: allSampleKeys.length === 0 ? 'No variables' : `${allSampleKeys.length - missingSamples}/${allSampleKeys.length} filled` },
    { label: 'Media upload', ok: !hasMedia || !!(form.mediaUrl), detail: !hasMedia ? 'Not required' : form.mediaUrl ? 'Uploaded ✓' : 'Upload required' },
    { label: 'Button limits', ok: (form.buttons || []).length <= 10 && urlBtns.length <= 2 && phoneBtns.length <= 1 && !hasDupQr, detail: `${(form.buttons || []).length}/10 buttons${hasDupQr ? ' · Duplicate QR' : ''}` },
    { label: 'Variable sequence', ok: bodyVars.every((v, i) => v === i + 1), detail: bodyVars.length === 0 ? 'No variables' : bodyVars.every((v, i) => v === i + 1) ? `${bodyVars.length} variable(s) ✓` : 'Non-sequential!' },
  ]
  const allOk = checks.every(c => c.ok)

  return (
    <div style={{ background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, overflow: 'hidden', marginTop: 12 }}>
      <div style={{ padding: '8px 12px', background: '#f0f2f5', borderBottom: '1px solid #e4e6eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#1c1e21' }}>Checklist</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: allOk ? '#42b72a' : '#f02849' }}>{allOk ? '✓ Ready' : `${checks.filter(c => !c.ok).length} issue(s)`}</span>
      </div>
      {checks.map((c, i) => (
        <div key={i} style={{ display: 'flex', gap: 8, padding: '6px 12px', borderBottom: i < checks.length - 1 ? '1px solid #f0f2f5' : 'none' }}>
          <div style={{ width: 14, height: 14, borderRadius: '50%', background: c.ok ? '#d1fae5' : '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2, fontSize: 7, color: c.ok ? '#059669' : '#dc2626', fontWeight: 900 }}>{c.ok ? '✓' : '✗'}</div>
          <div>
            <div style={{ fontSize: 11.5, color: '#1c1e21', fontWeight: 500 }}>{c.label}</div>
            <div style={{ fontSize: 10.5, color: c.ok ? '#65676b' : '#dc2626' }}>{c.detail}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

/* ─── SETUP RIGHT PANEL ──────────────────────────────────────────────────── */
function SetupRightPanel({ category }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === category)
  const previews = {
    MARKETING: { img: '🛒', body: 'Hey there! Check out our fresh groceries now!\n\nUse code HEALTH to get additional 10% off on your entire purchase.', time: '11:59', btns: ['🔗  Shop now', '📋  Copy code'] },
    UTILITY: { body: 'Good news! Your order 23KFEJJ2312 has shipped!\n\nHere\'s your tracking information, please check link below.', time: '11:59', btns: ['🔗  Track shipment'] },
    AUTHENTICATION: { body: '123456 is your verification code. For your security, do not share this code.', time: '11:59', btns: [] },
  }
  const p = previews[category] || previews.MARKETING
  return (
    <div style={{ padding: '20px 16px' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: '#1c1e21', marginBottom: 12 }}>Template preview</div>
      <div style={{ background: '#e9edef', borderRadius: 10, padding: 10, marginBottom: 16 }}>
        {p.img && (
          <div style={{ borderRadius: 7, overflow: 'hidden', marginBottom: 6, height: 80, background: 'linear-gradient(135deg,#4ade80,#22c55e)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28 }}>🥦🍅🍊</div>
        )}
        <div style={{ background: '#fff', borderRadius: 8, padding: '9px 9px 5px', boxShadow: '0 1px 2px rgba(0,0,0,.08)' }}>
          <div style={{ fontSize: 11, color: '#111', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>{p.body}</div>
          <div style={{ fontSize: 8.5, color: '#9ca3af', textAlign: 'right', marginTop: 4 }}>{p.time} ✓✓</div>
          {p.btns.map((b, i) => (
            <div key={i} style={{ borderTop: '1px solid #f0f0f0', padding: '5px 0', textAlign: 'center', fontSize: 10.5, color: '#128c7e', fontWeight: 600 }}>{b}</div>
          ))}
        </div>
      </div>
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#1c1e21', marginBottom: 4 }}>This template is good for</div>
        <div style={{ fontSize: 12.5, color: '#65676b', lineHeight: 1.5 }}>{catDef?.goodFor}</div>
      </div>
      <div>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#1c1e21', marginBottom: 4 }}>Template areas that you can customise</div>
        <div style={{ fontSize: 12.5, color: '#65676b' }}>{catDef?.areas}</div>
      </div>
    </div>
  )
}

/* ─── SETUP STEP ─────────────────────────────────────────────────────────── */
function SetupStep({ form, setForm }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)

  function setCategory(cat) {
    const def = CATEGORY_DEFS.find(c => c.value === cat)
    setForm(f => ({ ...f, category: cat, subType: def.subTypes[0].value }))
  }

  return (
    <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
      {/* Main */}
      <div style={{ flex: 1, overflowY: 'auto', background: '#f0f2f5', padding: '24px' }}>
        <div style={{ maxWidth: 700, margin: '0 auto' }}>
          <div style={{ background: '#fff', borderRadius: 8, border: '1px solid #e4e6eb' }}>
            <div style={{ padding: '20px 24px 16px' }}>
              <h2 style={{ fontSize: 17, fontWeight: 700, color: '#1c1e21', margin: '0 0 6px' }}>Set up your template</h2>
              <p style={{ fontSize: 13.5, color: '#65676b', margin: 0, lineHeight: 1.5 }}>
                Choose the category that best describes your message template. Then, select the type of message that you want to send.{' '}
                <span style={{ color: '#1877F2', cursor: 'pointer' }}>Learn more about categories.</span>
              </p>
            </div>

            {/* Category tabs */}
            <div style={{ display: 'flex', borderTop: '1px solid #e4e6eb', borderBottom: '1px solid #e4e6eb' }}>
              {CATEGORY_DEFS.map((cat, i) => {
                const isActive = form.category === cat.value
                return (
                  <button key={cat.value} type="button" onClick={() => setCategory(cat.value)} style={{
                    flex: 1, padding: '11px 16px', border: 'none',
                    borderRight: i < CATEGORY_DEFS.length - 1 ? '1px solid #e4e6eb' : 'none',
                    background: isActive ? '#1c1e21' : '#fff', color: isActive ? '#fff' : '#1c1e21',
                    fontSize: 14, fontWeight: isActive ? 600 : 400, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    transition: 'background .15s, color .15s',
                  }}>
                    <span>{cat.tabIcon}</span>{cat.label}
                  </button>
                )
              })}
            </div>

            {/* Sub-types */}
            <div style={{ padding: '4px 0 8px' }}>
              {catDef?.subTypes.map(st => {
                const isSelected = form.subType === st.value
                return (
                  <label key={st.value} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 12,
                    padding: '11px 24px', cursor: 'pointer',
                    background: isSelected ? '#e7f3ff' : 'transparent', transition: 'background .1s',
                  }}>
                    <div onClick={() => setForm(f => ({ ...f, subType: st.value }))} style={{
                      width: 16, height: 16, borderRadius: '50%', flexShrink: 0, marginTop: 3,
                      border: `2px solid ${isSelected ? '#1877F2' : '#bcc0c4'}`,
                      background: isSelected ? '#1877F2' : '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                    }}>
                      {isSelected && <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fff' }} />}
                    </div>
                    <div onClick={() => setForm(f => ({ ...f, subType: st.value }))}>
                      <div style={{ fontSize: 14, fontWeight: isSelected ? 600 : 400, color: '#1c1e21' }}>{st.label}</div>
                      <div style={{ fontSize: 12.5, color: '#65676b', marginTop: 2, lineHeight: 1.4 }}>{st.desc}</div>
                    </div>
                  </label>
                )
              })}
            </div>

            {/* Pre-approved templates banner */}
            {(form.category === 'UTILITY' || form.category === 'AUTHENTICATION') && (
              <div style={{ margin: '0 16px 16px', border: '1px solid #e4e6eb', borderRadius: 8, padding: '14px 16px', display: 'flex', gap: 14, alignItems: 'center' }}>
                <div style={{ width: 60, height: 60, borderRadius: 8, background: '#e7f3ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, flexShrink: 0 }}>📋</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: '#1c1e21', marginBottom: 4 }}>Start with pre-approved templates</div>
                  <div style={{ fontSize: 12.5, color: '#65676b', lineHeight: 1.5 }}>Save time and effort by using pre-approved templates from our template library. You can quickly build professional-looking templates without starting from scratch.</div>
                </div>
                <button type="button" style={{ padding: '8px 14px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0, fontWeight: 500 }}>Go to template library</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div style={{ width: 260, flexShrink: 0, borderLeft: '1px solid #e4e6eb', background: '#fff', overflowY: 'auto' }}>
        <SetupRightPanel category={form.category} />
      </div>
    </div>
  )
}

/* ─── TOOLBAR BUTTON ─────────────────────────────────────────────────────── */
function TBtn({ title, onClick, children }) {
  return (
    <button type="button" title={title} onClick={onClick}
      style={{ padding: '3px 6px', border: 'none', background: 'none', cursor: 'pointer', borderRadius: 4, fontSize: 13, color: '#444' }}
      onMouseEnter={e => e.currentTarget.style.background = '#e4e6eb'}
      onMouseLeave={e => e.currentTarget.style.background = 'none'}
    >{children}</button>
  )
}

/* ─── DRAG DROP UPLOAD ───────────────────────────────────────────────────── */
function DragDropUpload({ type, value, onChange }) {
  const [drag, setDrag] = useState(false)
  const ref = useRef(null)
  function handleFile(f) { if (f) onChange(URL.createObjectURL(f)) }
  return (
    <div
      onClick={() => ref.current?.click()}
      onDragOver={e => { e.preventDefault(); setDrag(true) }}
      onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]) }}
      style={{ border: `2px dashed ${drag ? '#1877F2' : value ? '#42b72a' : '#bcc0c4'}`, borderRadius: 8, padding: '20px 16px', textAlign: 'center', cursor: 'pointer', background: drag ? '#e7f3ff' : value ? '#f0fdf4' : '#fafafa', margin: '8px 0', transition: 'all .15s' }}
    >
      <input ref={ref} type="file" accept={type === 'image' ? 'image/*' : type === 'video' ? 'video/*' : '.pdf,.doc,.docx'} style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
      {value ? (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          <span style={{ fontSize: 16 }}>{MEDIA_ICONS[type]}</span>
          <span style={{ fontSize: 13, color: '#42b72a', fontWeight: 500 }}>File uploaded ✓</span>
          <button type="button" onClick={e => { e.stopPropagation(); onChange('') }} style={{ fontSize: 11, color: '#f02849', background: 'none', border: 'none', cursor: 'pointer' }}>Remove</button>
        </div>
      ) : (
        <div>
          <div style={{ fontSize: 13, color: '#1c1e21', marginBottom: 4 }}>Drag and drop to upload</div>
          <div style={{ fontSize: 12, color: '#1877F2', cursor: 'pointer' }}>Or choose files on your device</div>
        </div>
      )}
    </div>
  )
}

/* ─── SECTION ────────────────────────────────────────────────────────────── */
function Section({ title, subtitle, children }) {
  return (
    <div style={{ background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, marginBottom: 12 }}>
      <div style={{ padding: '14px 20px 12px', borderBottom: '1px solid #f0f2f5' }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#1c1e21' }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12.5, color: '#65676b', marginTop: 3, lineHeight: 1.5 }}>{subtitle}</div>}
      </div>
      <div style={{ padding: '16px 20px' }}>{children}</div>
    </div>
  )
}

/* ─── CONTENT SECTION ────────────────────────────────────────────────────── */
function ContentSection({ form, setForm }) {
  const taRef = useRef(null)
  const isCatalog = form.subType === 'catalog'
  const isCatMsg = form.catalogFormat === 'catalogue_message'
  const hasMedia = form.mediaSample && form.mediaSample !== 'none'
  const bodyVars = extractVariables(form.body || '')
  const headerVars = extractVariables(form.headerText || '')

  function wrapBody(pre, suf) {
    const ta = taRef.current; if (!ta) return
    const s = ta.selectionStart, e = ta.selectionEnd
    const next = (form.body || '').slice(0, s) + pre + (form.body || '').slice(s, e) + suf + (form.body || '').slice(e)
    setForm(f => ({ ...f, body: next }))
    setTimeout(() => { ta.focus(); ta.setSelectionRange(s + pre.length, e + pre.length) }, 0)
  }

  function addBodyVar() {
    const vars = extractVariables(form.body || '')
    const next = vars.length ? Math.max(...vars) + 1 : 1
    const ta = taRef.current
    const pos = ta ? ta.selectionStart : (form.body || '').length
    setForm(f => ({ ...f, body: (f.body || '').slice(0, pos) + `{{${next}}}` + (f.body || '').slice(pos) }))
    setTimeout(() => ta?.focus(), 0)
  }

  return (
    <Section
      title="Content"
      subtitle={<>Add a header, body and footer for your template. <span style={{ color: '#1877F2', cursor: 'pointer' }}>About templates</span></>}
    >
      {/* Type of variable */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 5 }}>
          Type of variable
          <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 15, height: 15, borderRadius: '50%', background: '#e4e6eb', fontSize: 9, color: '#65676b', cursor: 'help', fontWeight: 700 }} title="Choose how template variables are referenced in your message">i</span>
        </div>
        <CustomSelect
          value={form.varType || 'number'}
          onChange={v => setForm(f => ({ ...f, varType: v }))}
          options={[{ value: 'number', label: 'Number' }, { value: 'name', label: 'Name' }]}
          style={{ maxWidth: 260 }}
        />
      </div>

      {/* Media sample */}
      {!isCatalog && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21', marginBottom: 6 }}>
            Media sample <span style={{ fontWeight: 400, fontSize: 12.5, color: '#65676b' }}>· Optional</span>
          </div>
          <CustomSelect
            value={form.mediaSample || 'none'}
            onChange={v => setForm(f => ({ ...f, mediaSample: v, mediaUrl: '' }))}
            options={[
              { value: 'none', label: 'None' },
              { value: 'image', label: '🖼  Image' },
              { value: 'video', label: '▶  Video' },
              { value: 'document', label: '📄  Document' },
              { value: 'location', label: '📍  Location' },
            ]}
            style={{ maxWidth: 260 }}
          />
          {['image', 'video', 'document'].includes(form.mediaSample) && (
            <DragDropUpload type={form.mediaSample} value={form.mediaUrl} onChange={url => setForm(f => ({ ...f, mediaUrl: url }))} />
          )}
          {form.mediaSample === 'location' && (
            <div style={{ marginTop: 8, padding: '10px 12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 6, fontSize: 12.5, color: '#166534' }}>
              📍 The user's location pin will be shown. No additional configuration needed.
            </div>
          )}
        </div>
      )}

      {/* Header */}
      {!(isCatalog && isCatMsg) && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21' }}>
              Header <span style={{ fontWeight: 400, fontSize: 12.5, color: '#65676b' }}>· Optional</span>
            </div>
            {!hasMedia && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <span style={{ fontSize: 11, color: '#9ca3af' }}>{(form.headerText || '').length}/60</span>
                {headerVars.length === 0 && (
                  <>
                    <button type="button" onClick={() => setForm(f => ({ ...f, headerText: (f.headerText || '') + '{{1}}' }))}
                      style={{ fontSize: 12, color: '#1877F2', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500, padding: '0 0 0 6px' }}>
                      + Add variable
                    </button>
                    <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 14, height: 14, borderRadius: '50%', background: '#e4e6eb', fontSize: 9, color: '#65676b', cursor: 'help', fontWeight: 700 }} title="Add a placeholder variable that can be personalised for each recipient.">i</span>
                  </>
                )}
              </div>
            )}
          </div>
          <div style={{ position: 'relative' }}>
            <input
              value={form.headerText || ''}
              onChange={e => !hasMedia && setForm(f => ({ ...f, headerText: e.target.value.slice(0, 60) }))}
              placeholder={`Add a short line of text to the header of your message in ${LANGUAGES.find(l => l.value === form.language)?.label || 'English'}`}
              maxLength={60}
              disabled={hasMedia}
              style={{ width: '100%', padding: '9px 10px', border: '1px solid #ccd0d5', borderRadius: 6, fontSize: 13, outline: 'none', boxSizing: 'border-box', background: hasMedia ? '#f0f2f5' : '#fff', color: hasMedia ? '#9ca3af' : '#1c1e21', cursor: hasMedia ? 'not-allowed' : 'text' }}
            />
          </div>
          {headerVars.length > 0 && !hasMedia && (
            <div style={{ marginTop: 8, padding: '10px 12px', background: '#e7f3ff', border: '1px solid #bfdbfe', borderRadius: 6 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#1d4ed8', marginBottom: 6 }}>Header sample value</div>
              {headerVars.map(n => (
                <div key={n} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 11, fontFamily: 'monospace', background: '#dbeafe', color: '#1d4ed8', padding: '2px 6px', borderRadius: 4 }}>{`{{${n}}}`}</span>
                  <input value={form.samples?.[`h${n}`] || ''} onChange={e => setForm(f => ({ ...f, samples: { ...f.samples, [`h${n}`]: e.target.value } }))}
                    placeholder="Enter sample value"
                    style={{ flex: 1, padding: '5px 9px', border: '1px solid #bfdbfe', borderRadius: 5, fontSize: 12.5, outline: 'none' }} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Body */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21' }}>Body</div>
          <span style={{ fontSize: 11, color: (form.body || '').length > 900 ? '#f02849' : '#9ca3af' }}>{(form.body || '').length}/1024</span>
        </div>
        <div style={{ position: 'relative' }}>
          <textarea
            ref={taRef}
            value={form.body || ''}
            onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
            rows={5}
            maxLength={1024}
            placeholder={`Enter text in ${LANGUAGES.find(l => l.value === form.language)?.label || 'English'}`}
            style={{ width: '100%', padding: '9px 10px', border: '1px solid #ccd0d5', borderRadius: '6px 6px 0 0', fontSize: 13, resize: 'vertical', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', lineHeight: 1.55 }}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1, padding: '4px 6px', border: '1px solid #ccd0d5', borderTop: 'none', borderRadius: '0 0 6px 6px', background: '#f8f9fa', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <TBtn title="Emoji" onClick={() => {
              const ta = taRef.current; if (!ta) return
              const pos = ta.selectionStart
              setForm(f => ({ ...f, body: (f.body || '').slice(0, pos) + '😊' + (f.body || '').slice(pos) }))
              setTimeout(() => { ta.focus(); ta.setSelectionRange(pos + 2, pos + 2) }, 0)
            }}>😊</TBtn>
            <TBtn title="Bold" onClick={() => wrapBody('*', '*')}><strong style={{ fontSize: 12 }}>B</strong></TBtn>
            <TBtn title="Italic" onClick={() => wrapBody('_', '_')}><em style={{ fontSize: 12 }}>I</em></TBtn>
            <TBtn title="Strikethrough" onClick={() => wrapBody('~', '~')}><s style={{ fontSize: 12 }}>S</s></TBtn>
            <TBtn title="Monospace" onClick={() => wrapBody('`', '`')}><code style={{ fontSize: 10 }}>{'</>'}</code></TBtn>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <button type="button" onClick={addBodyVar} style={{ fontSize: 12, color: '#1877F2', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500, padding: '3px 4px' }}>+ Add variable</button>
            <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 15, height: 15, borderRadius: '50%', background: '#e4e6eb', fontSize: 9, color: '#65676b', cursor: 'help', fontWeight: 700, flexShrink: 0 }} title="Variables let you personalise messages. Use {{1}}, {{2}}, etc. and provide sample values before submitting.">i</span>
          </div>
        </div>
        {bodyVars.length > 0 && (
          <div style={{ marginTop: 10, padding: '10px 12px', background: '#e7f3ff', border: '1px solid #bfdbfe', borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#1d4ed8', marginBottom: 6 }}>Body sample values — required before submission</div>
            {bodyVars.map(n => (
              <div key={n} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontFamily: 'monospace', background: '#dbeafe', color: '#1d4ed8', padding: '2px 6px', borderRadius: 4, flexShrink: 0 }}>{`{{${n}}}`}</span>
                <input value={form.samples?.[`b${n}`] || ''} onChange={e => setForm(f => ({ ...f, samples: { ...f.samples, [`b${n}`]: e.target.value } }))}
                  placeholder={`Sample for {{${n}}}`}
                  style={{ flex: 1, padding: '5px 9px', border: '1px solid #bfdbfe', borderRadius: 5, fontSize: 12.5, outline: 'none' }} />
              </div>
            ))}
          </div>
        )}
        {bodyVars.length > 0 && !bodyVars.every((v, i) => v === i + 1) && (
          <div style={{ marginTop: 6, fontSize: 12, color: '#f02849' }}>{'⚠ Variables must be sequential starting from {{1}}'}</div>
        )}
      </div>

      {/* Footer */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21' }}>
            Footer <span style={{ fontWeight: 400, fontSize: 12.5, color: '#65676b' }}>· Optional</span>
          </div>
          <span style={{ fontSize: 11, color: '#9ca3af' }}>{(form.footer || '').length}/60</span>
        </div>
        <div style={{ position: 'relative' }}>
          <input
            value={form.footer || ''}
            onChange={e => setForm(f => ({ ...f, footer: e.target.value.slice(0, 60) }))}
            placeholder="Add a short line of text to the bottom of your message in English"
            maxLength={60}
            style={{ width: '100%', padding: '9px 10px', border: '1px solid #ccd0d5', borderRadius: 6, fontSize: 13, outline: 'none', boxSizing: 'border-box' }}
          />
        </div>
      </div>
    </Section>
  )
}

/* ─── BUTTON ROW ─────────────────────────────────────────────────────────── */
function ButtonRow({ btn, onUpdate, onRemove, allButtons, isQR }) {
  const isDupQR = isQR && allButtons.filter(b => b.kind === 'custom' && b.id !== btn.id && (b.text || '').trim().toLowerCase() === (btn.text || '').trim().toLowerCase()).length > 0
  const inp = { width: '100%', padding: '7px 9px', border: '1px solid #ccd0d5', borderRadius: 6, fontSize: 13, outline: 'none', boxSizing: 'border-box' }

  return (
    <div style={{ border: `1px solid ${isDupQR ? '#fca5a5' : '#e4e6eb'}`, borderRadius: 8, marginBottom: 8, background: '#fff' }}>

      {/* ── Main row ── */}
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, padding: '12px 12px 10px' }}>
        <span style={{ fontSize: 14, color: '#bcc0c4', cursor: 'grab', paddingBottom: 8, flexShrink: 0 }}>⠿</span>

        {isQR ? (
          <>
            <div style={{ width: 120, flexShrink: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>TYPE</div>
              <div style={{ padding: '7px 10px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#f0f2f5', color: '#65676b', fontSize: 13 }}>Custom</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>BUTTON TEXT</div>
              <div style={{ position: 'relative' }}>
                <input value={btn.text || ''} onChange={e => onUpdate({ text: e.target.value })} maxLength={25} placeholder="Enter text"
                  style={{ ...inp, paddingRight: 42, border: `1px solid ${isDupQR ? '#fca5a5' : '#ccd0d5'}` }} />
                <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 10.5, color: '#9ca3af' }}>{(btn.text || '').length}/25</span>
              </div>
              {isDupQR && <div style={{ fontSize: 11, color: '#f02849', marginTop: 3 }}>Duplicate button text</div>}
            </div>
          </>
        ) : (
          <>
            <div style={{ width: 165, flexShrink: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>TYPE OF ACTION</div>
              <CustomSelect
                value={btn.kind}
                onChange={v => onUpdate({ kind: v, text: v === 'wa_call' ? 'Call on WhatsApp' : v === 'copy_code' ? 'Copy offer code' : '' })}
                options={[
                  { value: 'url', label: 'Visit website' },
                  { value: 'wa_call', label: 'Call on WhatsApp' },
                  { value: 'phone', label: 'Call Phone Number' },
                  { value: 'flow', label: 'Complete flow' },
                  { value: 'copy_code', label: 'Copy offer code' },
                ]}
              />
            </div>

            {/* Button text for most types */}
            {btn.kind !== 'copy_code' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>BUTTON TEXT</div>
                <div style={{ position: 'relative' }}>
                  <input value={btn.text || ''} onChange={e => onUpdate({ text: e.target.value })} maxLength={25}
                    readOnly={btn.kind === 'wa_call'}
                    placeholder="Enter text"
                    style={{ ...inp, paddingRight: 42, background: btn.kind === 'wa_call' ? '#f0f2f5' : '#fff', color: btn.kind === 'wa_call' ? '#65676b' : '#1c1e21' }} />
                  <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 10.5, color: '#9ca3af' }}>{(btn.text || '').length}/25</span>
                </div>
              </div>
            )}

            {/* URL type */}
            {btn.kind === 'url' && (
              <div style={{ width: 120, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>URL TYPE</div>
                <CustomSelect value={btn.urlType || 'static'} onChange={v => onUpdate({ urlType: v })}
                  options={[{ value: 'static', label: 'Static' }, { value: 'dynamic', label: 'Dynamic' }]} />
              </div>
            )}

            {/* WA Call active for */}
            {btn.kind === 'wa_call' && (
              <div style={{ width: 130, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>ACTIVE FOR</div>
                <CustomSelect value={btn.activeFor || '7 days'} onChange={v => onUpdate({ activeFor: v })} options={ACTIVE_FOR_OPTS} />
              </div>
            )}

            {/* Phone country */}
            {btn.kind === 'phone' && (
              <div style={{ width: 180, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>COUNTRY</div>
                <CustomSelect value={btn.country || 'US +1'} onChange={v => onUpdate({ country: v })} options={COUNTRY_CODES} />
              </div>
            )}

            {/* Copy code - fixed label */}
            {btn.kind === 'copy_code' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>BUTTON TEXT</div>
                <div style={{ padding: '7px 9px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#f0f2f5', color: '#65676b', fontSize: 13 }}>Copy offer code</div>
              </div>
            )}

            {/* Flow icon */}
            {btn.kind === 'flow' && (
              <div style={{ width: 130, flexShrink: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>BUTTON ICON</div>
                <CustomSelect value={btn.icon || 'DEFAULT'} onChange={v => onUpdate({ icon: v })} options={FLOW_ICONS} />
              </div>
            )}
          </>
        )}

        <button type="button" onClick={onRemove}
          style={{ padding: '6px 8px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 15, color: '#9ca3af', flexShrink: 0, lineHeight: 1, alignSelf: 'flex-end', marginBottom: 2 }}
          onMouseEnter={e => e.currentTarget.style.color = '#f02849'}
          onMouseLeave={e => e.currentTarget.style.color = '#9ca3af'}
        >✕</button>
      </div>

      {/* ── URL expanded ── */}
      {btn.kind === 'url' && (
        <div style={{ padding: '0 12px 12px 36px', borderTop: '1px solid #f0f2f5' }}>
          <div style={{ paddingTop: 10 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>WEBSITE URL</div>
            <input value={btn.url || ''} onChange={e => onUpdate({ url: e.target.value })} maxLength={2000}
              placeholder={btn.urlType === 'dynamic' ? 'https://www.example.com/{{1}}' : 'https://www.example.com'}
              style={inp} />
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, color: '#1c1e21', cursor: 'pointer', marginTop: 10 }}>
            <input type="checkbox" checked={!!btn.trackConversions} onChange={e => onUpdate({ trackConversions: e.target.checked })} />
            Track app conversions <span style={{ color: '#65676b', fontSize: 12 }}>(Marketing Messages API for WhatsApp only)</span>
          </label>
          {btn.urlType === 'dynamic' && (
            <div style={{ marginTop: 10 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>SAMPLE DYNAMIC URL PATH</div>
              <input value={btn.dynamicSample || ''} onChange={e => onUpdate({ dynamicSample: e.target.value })}
                placeholder="/orders/12345"
                style={{ ...inp, background: '#f0f9ff', border: '1px solid #bfdbfe' }} />
            </div>
          )}
        </div>
      )}

      {/* ── Phone number row ── */}
      {btn.kind === 'phone' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: '1px solid #f0f2f5' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>PHONE NUMBER</div>
          <input value={btn.phone || ''} onChange={e => onUpdate({ phone: e.target.value })} maxLength={20}
            placeholder="Enter phone number"
            style={{ ...inp, border: `1px solid ${!btn.phone ? '#fca5a5' : '#ccd0d5'}` }} />
          {!btn.phone && <div style={{ fontSize: 11, color: '#f02849', marginTop: 4 }}>Phone number is required.</div>}
        </div>
      )}

      {/* ── WA Call info ── */}
      {btn.kind === 'wa_call' && (
        <div style={{ padding: '8px 12px 10px 36px', borderTop: '1px solid #f0f2f5', display: 'flex', gap: 6 }}>
          <span style={{ fontSize: 13, flexShrink: 0, marginTop: 1 }}>ℹ</span>
          <div style={{ fontSize: 12, color: '#65676b', lineHeight: 1.5 }}>
            Turn on calling in the <span style={{ color: '#1877F2', cursor: 'pointer' }}>WhatsApp Manager portal</span>. Alternatively, you can use the Phone Number Settings API.{' '}
            <span style={{ color: '#1877F2', cursor: 'pointer' }}>About calling on WhatsApp</span>
          </div>
        </div>
      )}

      {/* ── Flow options ── */}
      {btn.kind === 'flow' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: '1px solid #f0f2f5' }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10 }}>
            {btn.flowName ? (
              <>
                <span style={{ fontSize: 12.5, color: '#1877F2', fontWeight: 500 }}>{btn.flowName}</span>
                <button type="button" style={{ padding: '4px 10px', border: '1px solid #e4e6eb', borderRadius: 5, background: '#fff', fontSize: 12, cursor: 'pointer' }}>Preview</button>
                <button type="button" onClick={() => onUpdate({ flowName: '', flowId: '' })} style={{ padding: '4px 10px', border: '1px solid #e4e6eb', borderRadius: 5, background: '#fff', fontSize: 12, cursor: 'pointer' }}>Delete</button>
              </>
            ) : (
              <>
                <button type="button" onClick={() => onUpdate({ flowName: 'new_flow', flowId: `flow_${Date.now()}` })} style={{ padding: '5px 12px', border: '1px solid #ccd0d5', borderRadius: 5, background: '#fff', fontSize: 12.5, cursor: 'pointer' }}>+ Create new</button>
                <button type="button" onClick={() => onUpdate({ flowName: 'existing_flow', flowId: 'flow_001' })} style={{ padding: '5px 12px', border: '1px solid #ccd0d5', borderRadius: 5, background: '#fff', fontSize: 12.5, cursor: 'pointer' }}>⚙ Use existing</button>
              </>
            )}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>FLOW STARTS WITH</div>
              <CustomSelect value={btn.screenType || 'predefined'} onChange={v => onUpdate({ screenType: v })}
                options={[{ value: 'predefined', label: 'Pre-defined screen' }, { value: 'network', label: 'Network request' }]} />
            </div>
            {btn.screenType !== 'network' && (
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>SELECT PRE-DEFINED SCREEN</div>
                <CustomSelect value={btn.predefinedScreen || ''} onChange={v => onUpdate({ predefinedScreen: v })} placeholder="Select screen..."
                  options={[{ value: 'screen_1', label: 'Book a Demo' }, { value: 'screen_2', label: 'Get a Quote' }, { value: 'screen_3', label: 'Contact Us' }]} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Copy code offer input ── */}
      {btn.kind === 'copy_code' && (
        <div style={{ padding: '10px 12px 12px 36px', borderTop: '1px solid #f0f2f5' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>OFFER CODE SAMPLE</div>
          <input value={btn.code || ''} onChange={e => onUpdate({ code: e.target.value })} maxLength={20} placeholder="Enter sample code"
            style={{ ...inp, border: `1px solid ${!btn.code ? '#fca5a5' : '#ccd0d5'}`, fontFamily: btn.code ? 'monospace' : 'inherit' }} />
          {!btn.code && <div style={{ fontSize: 11, color: '#1877F2', marginTop: 4, cursor: 'pointer' }}>Add sample text</div>}
        </div>
      )}
    </div>
  )
}

/* ─── BUTTONS SECTION ────────────────────────────────────────────────────── */
function ButtonsSection({ form, setForm }) {
  const [showMenu, setShowMenu] = useState(false)
  const menuRef = useRef(null)
  useClickOutside(menuRef, () => setShowMenu(false))
  const { subType, buttons = [] } = form

  function addBtn(kind) {
    const id = `btn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    const defaults = {
      custom: { text: '' },
      url: { text: '', urlType: 'static', url: '', trackConversions: false },
      wa_call: { text: 'Call on WhatsApp', activeFor: '7 days' },
      phone: { text: '', country: 'US +1', phone: '' },
      flow: { text: '', icon: 'DEFAULT', flowId: '', flowName: '', screenType: 'predefined', predefinedScreen: '' },
      copy_code: { code: '' },
    }
    setForm(f => ({ ...f, buttons: [...(f.buttons || []), { id, kind, ...defaults[kind] }] }))
    setShowMenu(false)
  }

  function removeBtn(id) { setForm(f => ({ ...f, buttons: (f.buttons || []).filter(b => b.id !== id) })) }
  function updateBtn(id, patch) { setForm(f => ({ ...f, buttons: (f.buttons || []).map(b => b.id === id ? { ...b, ...patch } : b) })) }

  const qrBtns = buttons.filter(b => b.kind === 'custom')
  const ctaBtns = buttons.filter(b => b.kind !== 'custom')
  const urlCount = buttons.filter(b => b.kind === 'url').length
  const phoneCount = buttons.filter(b => b.kind === 'phone').length
  const waCallCount = buttons.filter(b => b.kind === 'wa_call').length
  const flowCount = buttons.filter(b => b.kind === 'flow').length
  const copyCodeCount = buttons.filter(b => b.kind === 'copy_code').length

  if (subType === 'order_details') {
    return (
      <Section title="Button">
        <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', padding: '8px 10px', background: '#e7f3ff', borderRadius: 6, marginBottom: 12 }}>
          <span style={{ fontSize: 13 }}>ℹ</span>
          <span style={{ fontSize: 12.5, color: '#1c1e21' }}>Only one button is supported for this type of template. The button text is not editable.</span>
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ minWidth: 160 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>TYPE OF ACTION</div>
            <div style={{ padding: '7px 9px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#f0f2f5', color: '#65676b', fontSize: 13 }}>Open order details</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b', marginBottom: 5 }}>BUTTON TEXT</div>
            <div style={{ position: 'relative' }}>
              <div style={{ padding: '7px 50px 7px 9px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#f0f2f5', color: '#65676b', fontSize: 13 }}>Review and Pay</div>
              <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 10.5, color: '#9ca3af' }}>14/25</span>
            </div>
          </div>
        </div>
      </Section>
    )
  }

  if (subType === 'catalog') {
    const btnText = form.catalogFormat === 'catalogue_message' ? 'View catalog' : 'View Items'
    return (
      <Section title="Button">
        <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', padding: '8px 10px', background: '#e7f3ff', borderRadius: 6, marginBottom: 12 }}>
          <span style={{ fontSize: 13 }}>ℹ</span>
          <span style={{ fontSize: 12.5, color: '#1c1e21' }}>Only one button is supported for this type of template. The button text is not editable.</span>
        </div>
        <div style={{ display: 'inline-flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#65676b' }}>BUTTON TEXT</div>
          <div style={{ position: 'relative' }}>
            <div style={{ padding: '7px 50px 7px 9px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#f0f2f5', color: '#65676b', fontSize: 13, minWidth: 140 }}>{btnText}</div>
            <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 10.5, color: '#9ca3af' }}>{btnText.length}/25</span>
          </div>
        </div>
      </Section>
    )
  }

  if (subType === 'calling_permissions') {
    return (
      <Section title="Buttons">
        <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', padding: '8px 10px', background: '#e7f3ff', borderRadius: 6 }}>
          <span style={{ fontSize: 13 }}>ℹ</span>
          <span style={{ fontSize: 12.5, color: '#1c1e21' }}>Only one button is supported for this type of template and the button text is not editable.</span>
        </div>
      </Section>
    )
  }

  const menuItems = [
    { label: 'Custom', kind: 'custom', note: null, disabled: false },
    { label: 'Visit website', kind: 'url', note: `${urlCount}/2 max`, disabled: urlCount >= 2 },
    { label: 'Call on WhatsApp', kind: 'wa_call', note: `${waCallCount}/1 max`, disabled: waCallCount >= 1 },
    { label: 'Call Phone Number', kind: 'phone', note: `${phoneCount}/1 max`, disabled: phoneCount >= 1 },
    { label: 'Complete flow', kind: 'flow', note: `${flowCount}/1 max`, disabled: flowCount >= 1 },
    { label: 'Copy offer code', kind: 'copy_code', note: `${copyCodeCount}/1 max`, disabled: copyCodeCount >= 1 },
  ]

  return (
    <Section title={<>Buttons <span style={{ fontWeight: 400, fontSize: 13, color: '#65676b' }}>· Optional</span></>}
      subtitle="Create buttons that let customers respond to your message or take action. You can add up to ten buttons. If you add more than three buttons, they will appear in a list.">
      <div ref={menuRef} style={{ position: 'relative', display: 'inline-block', marginBottom: 16 }}>
        <button type="button" onClick={() => setShowMenu(m => !m)}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
          + Add button
          <svg width="10" height="6" viewBox="0 0 10 6" style={{ transition: 'transform .2s', transform: showMenu ? 'rotate(180deg)' : 'none' }}>
            <path d="M1 1l4 4 4-4" stroke="#65676b" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        {showMenu && (
          <div style={{ position: 'absolute', top: 'calc(100% + 3px)', left: 0, background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, boxShadow: '0 8px 24px rgba(0,0,0,0.12)', zIndex: 9999, minWidth: 230, overflow: 'hidden' }}>
            {menuItems.map(item => (
              <button key={item.kind} type="button" onClick={() => !item.disabled && addBtn(item.kind)} disabled={item.disabled}
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '10px 14px', border: 'none', background: 'none', cursor: item.disabled ? 'not-allowed' : 'pointer', textAlign: 'left' }}
                onMouseEnter={e => { if (!item.disabled) e.currentTarget.style.background = '#f0f2f5' }}
                onMouseLeave={e => e.currentTarget.style.background = 'none'}
              >
                <span style={{ fontSize: 13.5, color: item.disabled ? '#bcc0c4' : '#1c1e21' }}>{item.label}</span>
                {item.note && <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 12 }}>{item.note}</span>}
              </button>
            ))}
          </div>
        )}
      </div>

      {qrBtns.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#65676b', marginBottom: 8 }}>Quick reply</div>
          {qrBtns.map(b => <ButtonRow key={b.id} btn={b} onUpdate={p => updateBtn(b.id, p)} onRemove={() => removeBtn(b.id)} allButtons={buttons} isQR={true} />)}
        </div>
      )}

      {ctaBtns.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#65676b', marginBottom: 8 }}>Call to action</div>
          {ctaBtns.map(b => <ButtonRow key={b.id} btn={b} onUpdate={p => updateBtn(b.id, p)} onRemove={() => removeBtn(b.id)} allButtons={buttons} isQR={false} />)}
        </div>
      )}

      {buttons.length >= 10 && (
        <div style={{ fontSize: 12.5, color: '#f59e0b', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 6, padding: '7px 10px', marginTop: 8 }}>Maximum 10 buttons reached</div>
      )}
    </Section>
  )
}

/* ─── TTL SECTION ────────────────────────────────────────────────────────── */
function TTLSection({ form, setForm }) {
  const { ttl = {} } = form
  return (
    <Section title="Message validity period">
      <p style={{ fontSize: 13, color: '#65676b', margin: '0 0 12px', lineHeight: 1.55 }}>
        You can set a custom validity period that your marketing message must be delivered before it expires. If a message is not delivered within this time frame, you will not be charged and your customer will not see the message.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: ttl.enabled ? 14 : 0 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21' }}>Set custom validity period for your message</div>
          {!ttl.enabled && <div style={{ fontSize: 12, color: '#65676b', marginTop: 2 }}>If you don't set a custom validity period, the standard 10 minutes WhatsApp message validity period will be applied.</div>}
        </div>
        <label style={{ position: 'relative', display: 'inline-block', width: 40, height: 22, cursor: 'pointer', flexShrink: 0, marginLeft: 20 }}>
          <input type="checkbox" checked={!!ttl.enabled} onChange={e => setForm(f => ({ ...f, ttl: { ...(f.ttl || {}), enabled: e.target.checked } }))} style={{ opacity: 0, width: 0, height: 0, position: 'absolute' }} />
          <span style={{ position: 'absolute', inset: 0, background: ttl.enabled ? '#1877F2' : '#ccd0d5', borderRadius: 11, transition: '.2s' }} />
          <span style={{ position: 'absolute', width: 16, height: 16, background: '#fff', borderRadius: '50%', top: 3, left: ttl.enabled ? 21 : 3, transition: '.2s', boxShadow: '0 1px 3px rgba(0,0,0,.2)' }} />
        </label>
      </div>
      {ttl.enabled && (
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1e21', marginBottom: 6 }}>Validity period</div>
          <CustomSelect value={ttl.duration || '12h'} onChange={v => setForm(f => ({ ...f, ttl: { ...f.ttl, duration: v } }))} options={TTL_OPTIONS} style={{ maxWidth: 260 }} />
        </div>
      )}
    </Section>
  )
}

/* ─── CATALOGUE FORMAT SECTION ───────────────────────────────────────────── */
function CatalogueFormatSection({ form, setForm }) {
  const opts = [
    { value: 'catalogue_message', label: 'Catalogue message', desc: 'Include the entire catalogue to give your users a comprehensive view of all of your products.' },
    { value: 'multi_product_message', label: 'Multi-product message', desc: 'Include up to 30 products from the catalogue. Useful for showcasing new collections or a specific product category.' },
  ]
  return (
    <Section title="Catalogue format" subtitle={<><span style={{ color: '#1877F2', cursor: 'pointer' }}>Choose the message format that best fits your needs.</span></>}>
      {opts.map(o => {
        const sel = form.catalogFormat === o.value
        return (
          <label key={o.value} onClick={() => setForm(f => ({ ...f, catalogFormat: o.value }))} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '8px 0', cursor: 'pointer' }}>
            <div style={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${sel ? '#1877F2' : '#bcc0c4'}`, background: sel ? '#1877F2' : '#fff', flexShrink: 0, marginTop: 3, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {sel && <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fff' }} />}
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: sel ? 600 : 400, color: '#1c1e21' }}>{o.label}</div>
              <div style={{ fontSize: 12, color: '#65676b', marginTop: 2, lineHeight: 1.4 }}>{o.desc}</div>
            </div>
          </label>
        )
      })}
    </Section>
  )
}

/* ─── CATALOGUE SETUP SECTION ────────────────────────────────────────────── */
function CatalogueSetupSection() {
  return (
    <Section title="Catalogue setup" subtitle={<>Connecting a catalogue will allow customers to view, message and send carts containing your products and services via WhatsApp. <span style={{ color: '#1877F2', cursor: 'pointer' }}>Learn more</span></>}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', padding: '9px 12px', background: '#e7f3ff', borderRadius: 6, marginBottom: 12 }}>
        <span style={{ fontSize: 13 }}>ℹ</span>
        <span style={{ fontSize: 12.5, color: '#1c1e21' }}>Please note that you cannot add media to this template. Instead, you can <span style={{ color: '#1877F2', cursor: 'pointer' }}>link your catalogue</span> to showcase your products.</span>
      </div>
      <div style={{ marginBottom: 10 }}>
        <span style={{ fontSize: 13, color: '#1877F2', cursor: 'pointer', fontWeight: 500 }}>My Business Catalogue</span>
      </div>
      <button type="button" style={{ padding: '8px 16px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 13, cursor: 'pointer', fontWeight: 500 }}>Manage catalogue connection</button>
    </Section>
  )
}

/* ─── EDIT STEP ──────────────────────────────────────────────────────────── */
function EditStep({ form, setForm }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)
  const subDef = catDef?.subTypes.find(s => s.value === form.subType)
  const langLabel = LANGUAGES.find(l => l.value === form.language)?.label || 'English'
  const showTTL = ['default', 'calling_permissions'].includes(form.subType) && form.category === 'MARKETING'

  return (
    <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
      {/* Left — scrollable form */}
      <div style={{ flex: 1, overflowY: 'auto', background: '#f0f2f5', padding: '20px 24px' }}>
        <div style={{ maxWidth: 760, margin: '0 auto' }}>

          {/* Breadcrumb */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, padding: '10px 14px', background: '#fff', borderRadius: 8, border: '1px solid #e4e6eb' }}>
            <div style={{ width: 32, height: 32, borderRadius: 6, background: '#e7f3ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
              {catDef?.tabIcon}
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1c1e21' }}>{form.name || 'your_template_name'} <span style={{ color: '#65676b', fontWeight: 400, fontSize: 13 }}>· {langLabel}</span></div>
              <div style={{ fontSize: 12, color: '#65676b', marginTop: 1 }}>{catDef?.label} · {subDef?.label}</div>
            </div>
          </div>

          {/* Template name and language */}
          <Section title="Template name and language">
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div style={{ fontSize: 13, color: '#1c1e21', marginBottom: 6, fontWeight: 500 }}>Name your template</div>
                <div style={{ position: 'relative' }}>
                  <input
                    value={form.name || ''}
                    onChange={e => {
                      const v = e.target.value.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
                      setForm(f => ({ ...f, name: v }))
                    }}
                    placeholder="Enter a template name"
                    maxLength={512}
                    style={{ width: '100%', padding: '9px 60px 9px 10px', border: '1px solid #ccd0d5', borderRadius: 6, fontSize: 13, outline: 'none', boxSizing: 'border-box' }}
                  />
                  <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: '#9ca3af' }}>{(form.name || '').length}/512</span>
                </div>
                {form.name && !/^[a-z0-9_]+$/.test(form.name) && (
                  <div style={{ fontSize: 11, color: '#f02849', marginTop: 4 }}>Only lowercase letters, numbers and underscores allowed</div>
                )}
              </div>
              <div style={{ minWidth: 200 }}>
                <div style={{ fontSize: 13, color: '#1c1e21', marginBottom: 6, fontWeight: 500 }}>Select language</div>
                <SearchableSelect
                  value={form.language || 'en'}
                  onChange={v => setForm(f => ({ ...f, language: v }))}
                  options={LANGUAGES}
                />
              </div>
            </div>
          </Section>

          {/* Catalogue-specific */}
          {form.subType === 'catalog' && (
            <>
              <CatalogueFormatSection form={form} setForm={setForm} />
              <CatalogueSetupSection />
            </>
          )}

          <ContentSection form={form} setForm={setForm} />
          <ButtonsSection form={form} setForm={setForm} />
          {showTTL && <TTLSection form={form} setForm={setForm} />}

          <div style={{ height: 20 }} />
        </div>
      </div>

      {/* Right — sticky: Template preview (matches Meta UI) */}
      <div style={{ width: 280, flexShrink: 0, borderLeft: '1px solid #e4e6eb', background: '#fff', overflowY: 'auto', padding: '16px 14px' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#1c1e21', marginBottom: 12 }}>Template preview</div>
        <PhonePreview form={form} />
        <ValidationPanel form={form} />
        <div style={{ marginTop: 12, background: '#1e1e2e', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '7px 12px', borderBottom: '1px solid #2a2a3e', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 11, color: '#cdd6f4', fontWeight: 700 }}>API Payload</span>
            <button type="button" onClick={() => navigator.clipboard?.writeText(JSON.stringify(buildAPIPayload(form), null, 2))} style={{ fontSize: 10, color: '#89dceb', background: 'none', border: 'none', cursor: 'pointer' }}>📋 Copy</button>
          </div>
          <pre style={{ margin: 0, padding: '10px 12px', fontSize: 9, color: '#cdd6f4', overflowX: 'auto', maxHeight: 200, overflowY: 'auto', lineHeight: 1.6 }}>
            {JSON.stringify(buildAPIPayload(form), null, 2)}
          </pre>
        </div>
      </div>
    </div>
  )
}

/* ─── REVIEW STEP ────────────────────────────────────────────────────────── */
function ReviewStep({ form }) {
  const catDef = CATEGORY_DEFS.find(c => c.value === form.category)
  const subDef = catDef?.subTypes.find(s => s.value === form.subType)
  const payload = buildAPIPayload(form)
  const rows = [
    { label: 'Template name', value: form.name || '—' },
    { label: 'Category', value: `${catDef?.label} · ${subDef?.label}` },
    { label: 'Language', value: LANGUAGES.find(l => l.value === form.language)?.label || form.language },
    { label: 'Header', value: form.mediaSample && form.mediaSample !== 'none' ? form.mediaSample : form.headerText ? `"${form.headerText.slice(0, 40)}"` : 'None' },
    { label: 'Body', value: `${(form.body || '').length} characters · ${extractVariables(form.body || '').length} variable(s)` },
    { label: 'Buttons', value: (form.buttons || []).length > 0 ? (form.buttons || []).map(b => b.text || b.kind).join(', ') : 'None' },
    { label: 'Validity period', value: form.ttl?.enabled ? TTL_OPTIONS.find(o => o.value === form.ttl?.duration)?.label || form.ttl?.duration : 'Default (10 minutes)' },
  ]
  return (
    <div style={{ flex: 1, overflowY: 'auto', background: '#f0f2f5', padding: '24px' }}>
      <div style={{ maxWidth: 680, margin: '0 auto' }}>
        <div style={{ background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, padding: '20px 24px', marginBottom: 14 }}>
          <h2 style={{ fontSize: 17, fontWeight: 700, color: '#1c1e21', margin: '0 0 4px' }}>Submit for Review</h2>
          <p style={{ fontSize: 13, color: '#65676b', margin: '0 0 20px' }}>Review your template before submitting to Meta. Approval typically takes a few minutes to 24 hours.</p>
          {rows.map((row, i) => (
            <div key={i} style={{ display: 'flex', padding: '10px 0', borderBottom: i < rows.length - 1 ? '1px solid #f0f2f5' : 'none' }}>
              <span style={{ width: 150, fontSize: 13, color: '#65676b', flexShrink: 0 }}>{row.label}</span>
              <span style={{ fontSize: 13, color: '#1c1e21', fontWeight: 500 }}>{row.value}</span>
            </div>
          ))}
        </div>
        <div style={{ background: '#1e1e2e', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '9px 14px', borderBottom: '1px solid #2a2a3e', display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 12, color: '#cdd6f4', fontWeight: 700 }}>Meta Cloud API Payload</span>
            <button type="button" onClick={() => navigator.clipboard?.writeText(JSON.stringify(payload, null, 2))} style={{ fontSize: 11, color: '#89dceb', background: 'none', border: 'none', cursor: 'pointer' }}>📋 Copy JSON</button>
          </div>
          <pre style={{ margin: 0, padding: '14px 16px', fontSize: 11, color: '#cdd6f4', overflowX: 'auto', lineHeight: 1.6, maxHeight: 300, overflowY: 'auto' }}>
            {JSON.stringify(payload, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  )
}

/* ─── TEMPLATE BUILDER ───────────────────────────────────────────────────── */
function TemplateBuilder({ onBack }) {
  const [step, setStep] = useState(0)
  const [done, setDone] = useState(false)
  const [form, setForm] = useState({
    category: 'MARKETING', subType: 'default',
    name: '', language: 'en',
    varType: 'number', mediaSample: 'none', mediaUrl: '',
    headerText: '', body: '', footer: '',
    buttons: [], samples: {},
    ttl: { enabled: false, duration: '12h' },
    catalogFormat: 'catalogue_message',
  })

  const hasIssues = !form.name || !/^[a-z0-9_]+$/.test(form.name) || !form.body?.trim()

  if (done) return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 60px)', margin: '-20px', background: '#f0f2f5', overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ fontSize: 52, marginBottom: 16 }}>✅</div>
      <h2 style={{ fontSize: 20, fontWeight: 700, color: '#1c1e21', margin: '0 0 8px' }}>Template submitted!</h2>
      <p style={{ fontSize: 14, color: '#65676b', maxWidth: 400, margin: '0 0 24px', lineHeight: 1.6, textAlign: 'center' }}>
        <strong>{form.name}</strong> has been submitted for Meta review. Approval typically takes a few minutes to 24 hours.
      </p>
      <button type="button" onClick={onBack} style={{ padding: '10px 22px', background: '#1877F2', color: '#fff', border: 'none', borderRadius: 7, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>← Back to Templates</button>
    </div>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 60px)', margin: '-20px', background: '#f0f2f5', overflow: 'hidden' }}>
      {/* Top nav */}
      <div style={{ height: 48, background: '#fff', borderBottom: '1px solid #e4e6eb', display: 'flex', alignItems: 'center', gap: 10, padding: '0 20px', flexShrink: 0 }}>
        <button type="button" onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 10px', fontSize: 13, color: '#1c1e21', background: 'none', border: '1px solid #ccd0d5', borderRadius: 6, cursor: 'pointer' }}>
          ← WhatsApp Manager
        </button>
        <div style={{ width: 1, height: 16, background: '#e4e6eb' }} />
        <span style={{ fontSize: 14, fontWeight: 700, color: '#1c1e21' }}>Create template</span>
      </div>

      <StepBar step={step} />

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {step === 0 && <SetupStep form={form} setForm={setForm} />}
        {step === 1 && <EditStep form={form} setForm={setForm} />}
        {step === 2 && <ReviewStep form={form} />}
      </div>

      {/* Bottom bar */}
      <div style={{ height: 56, background: '#fff', borderTop: '1px solid #e4e6eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', flexShrink: 0 }}>
        {step === 0 && (
          <>
            <button type="button" onClick={onBack} style={{ padding: '8px 18px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 14, cursor: 'pointer', color: '#1c1e21' }}>Discard</button>
            <button type="button" onClick={() => setStep(1)} style={{ padding: '8px 22px', background: '#1877F2', color: '#fff', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>Next</button>
          </>
        )}
        {step === 1 && (
          <>
            <button type="button" onClick={() => setStep(0)} style={{ padding: '8px 18px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 14, cursor: 'pointer', color: '#1c1e21' }}>Previous</button>
            <button type="button" onClick={() => setStep(2)} disabled={hasIssues}
              style={{ padding: '8px 22px', background: hasIssues ? '#e4e6eb' : '#1877F2', color: hasIssues ? '#bcc0c4' : '#fff', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: hasIssues ? 'not-allowed' : 'pointer' }}>
              Submit for Review
            </button>
          </>
        )}
        {step === 2 && (
          <>
            <button type="button" onClick={() => setStep(1)} style={{ padding: '8px 18px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 14, cursor: 'pointer', color: '#1c1e21' }}>Previous</button>
            <button type="button" onClick={() => setDone(true)} disabled={hasIssues}
              style={{ padding: '8px 24px', background: hasIssues ? '#e4e6eb' : '#1877F2', color: hasIssues ? '#bcc0c4' : '#fff', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: hasIssues ? 'not-allowed' : 'pointer' }}>
              Submit for Review
            </button>
          </>
        )}
      </div>
    </div>
  )
}

/* ─── TEMPLATE LIST ──────────────────────────────────────────────────────── */
const STATUS_META = {
  APPROVED: { dot: '#42b72a', bg: '#e6f4ea', color: '#1e7e34', label: 'Active - Quality pending' },
  PENDING:  { dot: '#d97706', bg: '#fef3c7', color: '#92400e', label: 'In review' },
  REJECTED: { dot: '#dc2626', bg: '#fee2e2', color: '#991b1b', label: 'Rejected' },
  DRAFT:    { dot: '#9ca3af', bg: '#f3f4f6', color: '#374151', label: 'Draft' },
}

const DEMO = [
  { id: 1, name: 'elets_leads1', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hey {{1}}! What is your opinion on automating your sales and marketing?', buttons: [{ id: 'b1', kind: 'url', text: 'Visit us' }], mediaSample: 'none', footer: '', samples: {}, delivered: 648, readRate: '59% (383)', topBlock: '—', lastEdited: '20 Apr 2026' },
  { id: 2, name: 'elogic_tech_sample', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hello {{1}}. This is to inform you that a system update is scheduled.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '20 Mar 2026' },
  { id: 3, name: 'email_opens_re3', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'The new academic year is about to begin. Register now for early access.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '16 Mar 2026' },
  { id: 4, name: 'deepaksample', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Deepak', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '13 Mar 2026' },
  { id: 5, name: 'nisus_test', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Hi {{1}}. Welcome to SmartBot! Thanks for joining us.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '10 Mar 2026' },
  { id: 6, name: 'template_click', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'We are testing the clicks and replies, please respond.', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '9 Mar 2026' },
  { id: 7, name: 'lost_deals_2', category: 'MARKETING', status: 'APPROVED', language: 'en', body: 'Just following up on our earlier message. Still interested?', buttons: [], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '9 Mar 2026' },
  { id: 8, name: 'order_confirmation', category: 'UTILITY', status: 'APPROVED', language: 'en_US', body: 'Hi {{1}}, your order #{{2}} is confirmed! Estimated delivery: {{3}}.', buttons: [{ id: 'b1', kind: 'url', text: 'Track Order' }], mediaSample: 'none', footer: '', samples: {}, delivered: 0, readRate: '0', topBlock: '—', lastEdited: '25 Feb 2026' },
]

function TemplateRow({ tpl, onPreview, onEdit, onDelete }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef(null)
  useClickOutside(menuRef, () => setMenuOpen(false))
  const catDef = CATEGORY_DEFS.find(c => c.value === tpl.category)
  const st = STATUS_META[tpl.status] || STATUS_META.DRAFT
  const langLabel = LANGUAGES.find(l => l.value === tpl.language)?.label || tpl.language

  return (
    <tr style={{ borderBottom: '1px solid #f0f2f5', transition: 'background .1s' }}
      onMouseEnter={e => e.currentTarget.style.background = '#f8f9fa'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      <td style={{ padding: '12px 12px', verticalAlign: 'top' }} onClick={e => e.stopPropagation()}>
        <input type="checkbox" style={{ cursor: 'pointer', marginTop: 2 }} />
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', cursor: 'pointer' }} onClick={onPreview}>
        <div style={{ fontSize: 13.5, fontWeight: 700, color: '#1c1e21', marginBottom: 3 }}>{tpl.name}</div>
        <div style={{ fontSize: 12, color: '#65676b', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', maxWidth: 300 }}>
          {tpl.body || 'No body text'}
        </div>
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', fontSize: 13, color: '#1c1e21', cursor: 'pointer' }} onClick={onPreview}>
        {catDef?.label || tpl.category}
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', fontSize: 13, color: '#1c1e21', cursor: 'pointer' }} onClick={onPreview}>
        {langLabel}
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', cursor: 'pointer' }} onClick={onPreview}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 8px', background: st.bg, color: st.color, borderRadius: 100, fontSize: 12, fontWeight: 500, whiteSpace: 'nowrap' }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: st.dot, flexShrink: 0 }} />
          {st.label}
        </span>
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', fontSize: 13, color: '#1c1e21', cursor: 'pointer' }} onClick={onPreview}>
        {tpl.delivered ?? 0}
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', fontSize: 13, color: '#1c1e21', cursor: 'pointer' }} onClick={onPreview}>
        {tpl.readRate ?? '—'}
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top', fontSize: 13, color: '#65676b', cursor: 'pointer' }} onClick={onPreview}>
        {tpl.topBlock ?? '—'}
      </td>
      <td style={{ padding: '12px 12px', verticalAlign: 'top' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
          <span style={{ fontSize: 13, color: '#1c1e21', whiteSpace: 'nowrap', cursor: 'pointer' }} onClick={onPreview}>{tpl.lastEdited || '—'}</span>
          <div ref={menuRef} style={{ position: 'relative' }}>
            <button type="button" onClick={e => { e.stopPropagation(); setMenuOpen(m => !m) }}
              style={{ padding: '3px 6px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: '#65676b', lineHeight: 1 }}>⋯</button>
            {menuOpen && (
              <div style={{ position: 'absolute', right: 0, top: '100%', background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, boxShadow: '0 6px 16px rgba(0,0,0,.12)', zIndex: 1000, minWidth: 160, overflow: 'hidden' }}>
                {[
                  { icon: '👁', label: 'Preview', fn: onPreview },
                  { icon: '✏️', label: 'Edit', fn: onEdit },
                  { icon: '📋', label: 'Duplicate', fn: () => {} },
                  { icon: '🗑', label: 'Delete', fn: onDelete, danger: true },
                ].map(item => (
                  <button key={item.label} type="button" onClick={() => { setMenuOpen(false); item.fn?.() }}
                    style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '9px 12px', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13, color: item.danger ? '#f02849' : '#1c1e21', textAlign: 'left' }}
                    onMouseEnter={e => e.currentTarget.style.background = item.danger ? '#fff0f3' : '#f0f2f5'}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}
                  >{item.icon} {item.label}</button>
                ))}
              </div>
            )}
          </div>
        </div>
      </td>
    </tr>
  )
}

function PreviewModal({ tpl, onClose }) {
  if (!tpl) return null
  const mockForm = { headerText: tpl.headerText || '', mediaSample: tpl.mediaSample || 'none', mediaUrl: '', body: tpl.body || '', footer: tpl.footer || '', buttons: tpl.buttons || [], samples: tpl.samples || {} }
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000, padding: 20 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#f0f2f5', borderRadius: 14, padding: '20px 24px', maxHeight: '90vh', overflowY: 'auto', minWidth: 300 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#1c1e21' }}>{tpl.name}</div>
            <div style={{ fontSize: 12, color: '#65676b', marginTop: 2 }}>{tpl.category} · {LANGUAGES.find(l => l.value === tpl.language)?.label}</div>
          </div>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 22, cursor: 'pointer', color: '#65676b', lineHeight: 1 }}>×</button>
        </div>
        <PhonePreview form={mockForm} />
      </div>
    </div>
  )
}

function TemplateList({ onCreate }) {
  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('ALL')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [templates, setTemplates] = useState(DEMO)
  const [preview, setPreview] = useState(null)
  const [activeTab, setActiveTab] = useState('templates')
  const [sortBy, setSortBy] = useState('lastEdited')
  const [sortDir, setSortDir] = useState('desc')

  const filtered = useMemo(() => {
    let list = templates.filter(t => {
      const q = search.toLowerCase()
      return (!q || t.name.toLowerCase().includes(q) || (t.body || '').toLowerCase().includes(q)) &&
        (catFilter === 'ALL' || t.category === catFilter) &&
        (statusFilter === 'ALL' || t.status === statusFilter)
    })
    list = [...list].sort((a, b) => {
      let av = a[sortBy] ?? '', bv = b[sortBy] ?? ''
      if (typeof av === 'string') { av = av.toLowerCase(); bv = bv.toLowerCase() }
      return sortDir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1)
    })
    return list
  }, [templates, search, catFilter, statusFilter, sortBy, sortDir])

  function toggleSort(col) {
    if (sortBy === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortBy(col); setSortDir('asc') }
  }

  function SortIcon({ col }) {
    return <span style={{ fontSize: 10, color: sortBy === col ? '#1877F2' : '#bcc0c4', marginLeft: 3 }}>{sortBy === col ? (sortDir === 'asc' ? '↑' : '↓') : '↕'}</span>
  }

  const cols = [
    { key: 'name', label: 'Template name', w: '24%' },
    { key: 'category', label: 'Category', w: '9%' },
    { key: 'language', label: 'Language', w: '9%' },
    { key: 'status', label: 'Status', w: '14%' },
    { key: 'delivered', label: 'Messages delivered', w: '10%' },
    { key: 'readRate', label: 'Read rate', w: '9%' },
    { key: 'topBlock', label: 'Top block reason', w: '12%' },
    { key: 'lastEdited', label: 'Last edited', w: '13%' },
  ]

  return (
    <div style={{ minHeight: 'calc(100vh - 60px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#1c1e21', margin: 0 }}>Message templates</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <button type="button" style={{ padding: '8px 16px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', fontSize: 13, cursor: 'pointer', color: '#1c1e21', fontWeight: 500 }}>Compare</button>
          <button type="button" onClick={onCreate} style={{ padding: '8px 16px', background: '#1877F2', color: '#fff', border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Create Template</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid #e4e6eb', marginBottom: 16 }}>
        {[['templates', 'Templates'], ['groups', 'Template groups']].map(([val, lbl]) => (
          <button key={val} type="button" onClick={() => setActiveTab(val)} style={{
            padding: '8px 16px', border: 'none', background: 'none', cursor: 'pointer',
            fontSize: 13.5, color: activeTab === val ? '#1877F2' : '#65676b',
            fontWeight: activeTab === val ? 700 : 400,
            borderBottom: `2px solid ${activeTab === val ? '#1877F2' : 'transparent'}`,
            marginBottom: -1, transition: 'all .15s',
          }}>{lbl}</button>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', fontSize: 12, color: '#9ca3af', pointerEvents: 'none' }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search"
            style={{ padding: '7px 10px 7px 28px', border: '1px solid #ccd0d5', borderRadius: 6, fontSize: 13, outline: 'none', width: 180 }} />
        </div>
        <CustomSelect value={catFilter} onChange={setCatFilter} style={{ width: 140 }}
          options={[{ value: 'ALL', label: 'Category' }, { value: 'MARKETING', label: 'Marketing' }, { value: 'UTILITY', label: 'Utility' }, { value: 'AUTHENTICATION', label: 'Authentication' }]} />
        <CustomSelect value="ALL" onChange={() => {}} style={{ width: 140 }} placeholder="Language"
          options={[{ value: 'ALL', label: 'All languages' }, ...LANGUAGES.slice(0, 10)]} />
        <CustomSelect value={statusFilter} onChange={setStatusFilter} style={{ width: 180 }}
          options={[{ value: 'ALL', label: '8 options selected' }, { value: 'APPROVED', label: 'Active' }, { value: 'PENDING', label: 'In review' }, { value: 'REJECTED', label: 'Rejected' }, { value: 'DRAFT', label: 'Draft' }]} />
        <CustomSelect value="7d" onChange={() => {}} style={{ width: 140 }}
          options={[{ value: '7d', label: 'Last 7 days' }, { value: '30d', label: 'Last 30 days' }, { value: '90d', label: 'Last 90 days' }]} />
        <button type="button" title="Reset filters" onClick={() => { setSearch(''); setCatFilter('ALL'); setStatusFilter('ALL') }}
          style={{ padding: '7px 10px', border: '1px solid #ccd0d5', borderRadius: 6, background: '#fff', cursor: 'pointer', fontSize: 14, color: '#65676b' }}>↺</button>
      </div>

      {/* Table */}
      <div style={{ background: '#fff', border: '1px solid #e4e6eb', borderRadius: 8, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e4e6eb', background: '#f8f9fa' }}>
              <th style={{ width: 40, padding: '10px 12px', textAlign: 'center' }}>
                <input type="checkbox" style={{ cursor: 'pointer' }} />
              </th>
              {cols.map(col => (
                <th key={col.key} onClick={() => toggleSort(col.key)} style={{
                  padding: '10px 12px', textAlign: 'left', fontSize: 12, fontWeight: 700,
                  color: '#65676b', cursor: 'pointer', userSelect: 'none', width: col.w,
                }}>
                  {col.label} <SortIcon col={col.key} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={9} style={{ textAlign: 'center', padding: '48px 20px', color: '#65676b' }}>
                <div style={{ fontSize: 28, marginBottom: 10 }}>📋</div>
                <div style={{ fontWeight: 700, marginBottom: 4, fontSize: 15, color: '#1c1e21' }}>No templates found</div>
                <div style={{ fontSize: 13 }}>Try adjusting your search or filters.</div>
              </td></tr>
            ) : filtered.map(tpl => (
              <TemplateRow key={tpl.id} tpl={tpl}
                onPreview={() => setPreview(tpl)}
                onEdit={onCreate}
                onDelete={() => setTemplates(ts => ts.filter(t => t.id !== tpl.id))}
              />
            ))}
          </tbody>
        </table>
      </div>

      {preview && <PreviewModal tpl={preview} onClose={() => setPreview(null)} />}
    </div>
  )
}

/* ─── MAIN EXPORT ────────────────────────────────────────────────────────── */
export default function Templates() {
  const [view, setView] = useState('list') // 'list' | 'create'
  return view === 'list'
    ? <TemplateList onCreate={() => setView('create')} />
    : <TemplateBuilder onBack={() => setView('list')} />
}
