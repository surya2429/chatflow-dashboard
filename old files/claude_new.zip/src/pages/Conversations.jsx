import { useState, useRef, useEffect } from 'react'
import {
  Search, Bot, UserCheck, CheckCircle2, Send, Paperclip, Mic,
  Smile, MoreVertical, Phone, X, Star, FileText,
  ChevronDown, Settings, Plus, Archive, AlertCircle,
  MessageCircle, PhoneCall, Grid3x3, SlidersHorizontal,
  RefreshCw, Zap, AtSign, Clock, Users, Inbox, Radio,
  Hash, TrendingUp, Activity, ShieldCheck, BarChart2,
  ArrowRightLeft, Bell, BellOff, Globe, Bold, Italic,
  Image, Eye, Filter, Tag, Package, ShoppingBag, ChevronRight,
  RotateCcw, UserPlus,
} from 'lucide-react'
import { useConversations } from '../context/ConversationContext'
import { AGENTS, TEMPLATES, PAST_CONVERSATIONS, MOCK_ORDERS } from '../constants/mockData'
import clsx from 'clsx'

/* ─── Constants ──────────────────────────────────────────────── */
const STATUS_MAP = {
  bot:      { label: 'Bot',      dot: 'bg-primary',     badge: 'badge-blue'  },
  agent:    { label: 'Agent',    dot: 'bg-emerald-500', badge: 'badge-green' },
  resolved: { label: 'Resolved', dot: 'bg-slate-300',   badge: 'badge-gray'  },
}
const AGENT_STATUS_DOT   = { online: 'bg-emerald-500', busy: 'bg-amber-400', offline: 'bg-slate-300' }
const AGENT_STATUS_LABEL = { online: 'Online', busy: 'Busy', offline: 'Offline' }

const CANNED = [
  { key: 'greet',    label: 'Greeting',       body: "Hi {{name}}! 👋 Thanks for reaching out. How can I help you today?" },
  { key: 'order',    label: 'Ask Order ID',    body: "Could you please share your Order ID so I can check the status for you?" },
  { key: 'wait',     label: 'Please Hold',     body: "Thanks for your patience! I'm checking this for you right now — give me just a moment." },
  { key: 'resolve',  label: 'Resolution',      body: "Your issue has been resolved! Let me know if there's anything else I can help with. 😊" },
  { key: 'escalate', label: 'Escalation Note', body: "I'm transferring you to a specialist who can better assist with your request. They'll be with you shortly!" },
]

const CTWA_SOURCES = [
  { key: 'ctwa',   label: 'CTWA',   full: 'Click to WhatsApp',  desc: 'Meta Facebook/Instagram ads → WhatsApp CTA', color: 'text-blue-600',    bg: 'bg-blue-50'    },
  { key: 'g-ctwa', label: 'G-CTWA', full: 'Google Click to WA', desc: 'Google Ads → WhatsApp as click destination', color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { key: 't-ctwa', label: 'T-CTWA', full: 'TikTok Click to WA', desc: 'TikTok Ads → WhatsApp as click destination', color: 'text-pink-600',    bg: 'bg-pink-50'    },
]

const VIEW_FILTERS = [
  { key: 'all',        label: 'All chats',      icon: Inbox         },
  { key: 'active',     label: 'Active chats',   icon: MessageCircle },
  { key: 'assigned',   label: 'Assigned to me', icon: UserCheck     },
  { key: 'unassigned', label: 'Unassigned',     icon: Users         },
]
const MORE_FILTERS = [
  { key: 'last24',     label: 'Last 24 Hours',  icon: Clock,         color: '' },
  { key: 'favorite',   label: 'Favourite only', icon: Star,          color: '' },
  { key: 'open',       label: 'Open',           icon: MessageCircle, color: 'text-emerald-600' },
  { key: 'pending',    label: 'Pending',        icon: AlertCircle,   color: 'text-amber-600'   },
  { key: 'solved',     label: 'Solved',         icon: CheckCircle2,  color: 'text-slate-500'   },
  { key: 'expired',    label: 'Expired',        icon: Archive,       color: 'text-red-500'     },
  { key: 'blocked',    label: 'Blocked Chats',  icon: X,             color: 'text-red-500'     },
  { key: 'broadcasts', label: 'Broadcasts',     icon: Radio,         color: '' },
  { key: 'unread',     label: 'Unread',         icon: Hash,          color: '' },
]
const STATUS_TABS = [
  { key: 'all',      label: 'All'  },
  { key: 'bot',      label: 'Bot'  },
  { key: 'agent',    label: 'Agent'},
  { key: 'resolved', label: 'Done' },
]

const ALL_LABELS = ['vip','lead','support','refund','appointment','order-issue','urgent','follow-up','prospect','payment']

const EMOJIS = ['😊','😂','❤️','👍','🙏','🎉','✅','⭐','🔥','💯','😭','🤔','👀','💪','🙌','😍','🥳','😅','👋','🤝','📦','🛍️','💰','⚡','🚀']

/* ─── Small SVG icons ─────────────────────────────────────────── */
const IgIcon = ({ size = 13 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
  </svg>
)
const ExternalLinkIcon = ({ size = 12, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}>
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
    <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
  </svg>
)

/* ─── Label Picker ────────────────────────────────────────────── */
function LabelPicker({ conversation, onClose }) {
  const { addLabel, removeLabel } = useConversations()
  const labels = conversation.labels || []
  return (
    <div className="absolute top-full right-0 mt-1 w-56 bg-white rounded-xl shadow-modal border border-surface-border z-40 py-2 animate-fade-in">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1.5">Labels</p>
      <div className="px-3 pb-2 flex flex-wrap gap-1.5">
        {ALL_LABELS.map(lbl => {
          const active = labels.includes(lbl)
          return (
            <button key={lbl}
              onClick={() => active ? removeLabel(conversation.id, lbl) : addLabel(conversation.id, lbl)}
              className={clsx(
                'px-2.5 py-1 rounded-full text-[11px] font-semibold border transition-all',
                active
                  ? 'bg-primary text-white border-primary'
                  : 'bg-slate-100 text-slate-600 border-slate-200 hover:border-primary hover:text-primary'
              )}>
              {active && <span className="mr-1">✓</span>}{lbl}
            </button>
          )
        })}
      </div>
      <div className="border-t border-surface-border pt-2 px-3">
        <button onClick={onClose} className="text-xs text-slate-400 hover:text-slate-600">Done</button>
      </div>
    </div>
  )
}

/* ─── Snooze picker ───────────────────────────────────────────── */
function SnoozePicker({ onSnooze, onClose }) {
  const OPTIONS = [
    { label: '30 minutes',   value: '30m'  },
    { label: '1 hour',       value: '1h'   },
    { label: '3 hours',      value: '3h'   },
    { label: 'Tomorrow 9am', value: 'tmrw' },
    { label: 'Next Monday',  value: 'mon'  },
  ]
  return (
    <div className="absolute bottom-full right-0 mb-2 w-44 bg-white rounded-xl shadow-modal border border-surface-border z-30 py-1 animate-fade-in">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1.5">Snooze until…</p>
      {OPTIONS.map(o => (
        <button key={o.value} onClick={() => { onSnooze(o.value); onClose() }}
          className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-primary transition-colors flex items-center gap-2">
          <Clock size={12} className="text-slate-400" /> {o.label}
        </button>
      ))}
    </div>
  )
}

/* ─── Transfer Agent Modal ────────────────────────────────────── */
function TransferModal({ conversation, onClose, adminOnline }) {
  const [selected, setSelected] = useState(null)
  const [note, setNote] = useState('')
  const [search, setSearch] = useState('')
  const { assignAgent } = useConversations()

  const allOptions = [
    ...AGENTS,
    ...(adminOnline ? [{ id: 'admin', name: 'Deepak Kumar', avatar: 'DK', role: 'Admin', status: 'online', assigned: 0, color: 'bg-primary' }] : []),
  ].filter(a => a.name.toLowerCase().includes(search.toLowerCase()))

  function doTransfer() {
    if (!selected) return
    assignAgent(conversation.id, selected.id, selected.name)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-modal animate-fade-in overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
          <div>
            <h3 className="font-bold text-slate-900">Transfer Conversation</h3>
            <p className="text-xs text-slate-500 mt-0.5">Assign to another agent or admin</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><X size={16} /></button>
        </div>
        <div className="px-4 pt-4 pb-2">
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input pl-9 text-sm" placeholder="Search agents..." value={search} onChange={e => setSearch(e.target.value)} autoFocus />
          </div>
        </div>
        <div className="px-4 pb-2 space-y-1 max-h-52 overflow-y-auto">
          {allOptions.map(a => {
            const isSelected = selected?.id === a.id
            const isCurrent  = a.id === conversation.agentId
            return (
              <button key={a.id} disabled={isCurrent} onClick={() => setSelected(isSelected ? null : a)}
                className={clsx(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all border',
                  isCurrent   ? 'opacity-50 cursor-not-allowed border-transparent bg-slate-50'
                  : isSelected ? 'border-primary bg-primary-50'
                  : 'border-transparent hover:bg-surface-hover hover:border-surface-border'
                )}>
                <div className="relative flex-shrink-0">
                  <div className={clsx('w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold', a.color || 'bg-gradient-to-br from-slate-500 to-slate-600')}>{a.avatar}</div>
                  <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', AGENT_STATUS_DOT[a.status])} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-800 truncate">{a.name}</p>
                    {isCurrent && <span className="text-[10px] text-slate-400 italic">current</span>}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={clsx('text-[10px] font-medium', a.status === 'online' ? 'text-emerald-600' : a.status === 'busy' ? 'text-amber-600' : 'text-slate-400')}>● {AGENT_STATUS_LABEL[a.status]}</span>
                    <span className="text-[10px] text-slate-400">{a.role}</span>
                    {a.assigned !== undefined && <span className="text-[10px] text-slate-400">{a.assigned} chats</span>}
                  </div>
                </div>
                {isSelected && <CheckCircle2 size={16} className="text-primary flex-shrink-0" />}
              </button>
            )
          })}
        </div>
        <div className="px-4 pb-4">
          <label className="label mb-1.5 block">Transfer note (optional)</label>
          <textarea className="textarea text-xs" rows={2} placeholder="Add a handover note for the agent…" value={note} onChange={e => setNote(e.target.value)} />
        </div>
        <div className="flex gap-2 px-4 pb-4">
          <button onClick={onClose} className="btn-secondary flex-1 justify-center text-sm">Cancel</button>
          <button onClick={doTransfer} disabled={!selected} className={clsx('flex-1 justify-center text-sm', selected ? 'btn-primary' : 'btn-secondary opacity-50 cursor-not-allowed')}>
            <ArrowRightLeft size={14} /> Transfer
          </button>
        </div>
      </div>
    </div>
  )
}

/* ─── Reassign Modal ──────────────────────────────────────────── */
function ReassignModal({ conversation, onClose, adminOnline }) {
  const [step, setStep]       = useState(1)
  const [selected, setSelected] = useState(null)
  const [search, setSearch]   = useState('')
  const { assignAgent } = useConversations()

  const allOptions = [
    ...AGENTS,
    ...(adminOnline ? [{ id: 'admin', name: 'Deepak Kumar', avatar: 'DK', role: 'Admin', status: 'online', assigned: 0, color: 'bg-primary' }] : []),
  ].filter(a => a.name.toLowerCase().includes(search.toLowerCase()))

  function doReassign() {
    if (!selected) return
    assignAgent(conversation.id, selected.id, selected.name)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-modal animate-fade-in overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
          <div>
            <h3 className="font-bold text-slate-900">Reassign Agent</h3>
            <p className="text-xs text-slate-500 mt-0.5">{step === 1 ? 'Select a new agent' : 'Confirm reassignment'}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><X size={16} /></button>
        </div>

        {step === 1 ? (
          <>
            <div className="px-4 pt-4 pb-2">
              <div className="relative">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input className="input pl-9 text-sm" placeholder="Search agents..." value={search} onChange={e => setSearch(e.target.value)} autoFocus />
              </div>
            </div>
            <div className="px-4 pb-4 space-y-1 max-h-64 overflow-y-auto">
              {allOptions.map(a => {
                const isSelected = selected?.id === a.id
                const isCurrent  = a.id === conversation.agentId
                return (
                  <button key={a.id} disabled={isCurrent} onClick={() => setSelected(isSelected ? null : a)}
                    className={clsx(
                      'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all border',
                      isCurrent   ? 'opacity-50 cursor-not-allowed border-transparent bg-slate-50'
                      : isSelected ? 'border-primary bg-primary-50'
                      : 'border-transparent hover:bg-surface-hover hover:border-surface-border'
                    )}>
                    <div className="relative flex-shrink-0">
                      <div className={clsx('w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold', a.color || 'bg-gradient-to-br from-slate-500 to-slate-600')}>{a.avatar}</div>
                      <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', AGENT_STATUS_DOT[a.status])} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800 truncate">{a.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={clsx('text-[10px] font-medium', a.status === 'online' ? 'text-emerald-600' : a.status === 'busy' ? 'text-amber-600' : 'text-slate-400')}>● {AGENT_STATUS_LABEL[a.status]}</span>
                        <span className="text-[10px] text-slate-400">{a.role}</span>
                        {isCurrent && <span className="text-[10px] text-slate-400 italic">current</span>}
                      </div>
                    </div>
                    {isSelected && <CheckCircle2 size={16} className="text-primary flex-shrink-0" />}
                  </button>
                )
              })}
            </div>
            <div className="flex gap-2 px-4 pb-4">
              <button onClick={onClose} className="btn-secondary flex-1 justify-center text-sm">Cancel</button>
              <button onClick={() => selected && setStep(2)} disabled={!selected}
                className={clsx('flex-1 justify-center text-sm', selected ? 'btn-primary' : 'btn-secondary opacity-50 cursor-not-allowed')}>
                Next <ChevronRight size={14} />
              </button>
            </div>
          </>
        ) : (
          <div className="px-5 py-6 text-center">
            <div className={clsx('w-16 h-16 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4', selected?.color || 'bg-gradient-to-br from-slate-500 to-slate-600')}>
              {selected?.avatar}
            </div>
            <p className="font-bold text-slate-900 text-base mb-1">Reassign to {selected?.name}?</p>
            <p className="text-xs text-slate-500 mb-6">This conversation will be transferred to {selected?.name}. They will be notified.</p>
            <div className="flex gap-2">
              <button onClick={() => setStep(1)} className="btn-secondary flex-1 justify-center">Back</button>
              <button onClick={doReassign} className="btn-primary flex-1 justify-center">
                <UserPlus size={14} /> Confirm
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* ─── Template Picker ─────────────────────────────────────────── */
function TemplatePicker({ onSelect, onClose }) {
  const [search, setSearch] = useState('')
  const [cat, setCat]       = useState('ALL')

  const CATS = ['ALL', 'MARKETING', 'TRANSACTIONAL', 'UTILITY', 'AUTHENTICATION']
  const CAT_COLOR = {
    MARKETING:      'badge-purple',
    TRANSACTIONAL:  'badge-blue',
    UTILITY:        'badge-amber',
    AUTHENTICATION: 'badge-gray',
  }

  const filteredTmpl = TEMPLATES.filter(t =>
    (cat === 'ALL' || t.category === cat) &&
    (t.name.toLowerCase().includes(search.toLowerCase()) || t.body.toLowerCase().includes(search.toLowerCase()))
  ).filter(t => t.status === 'APPROVED')

  return (
    <div className="border-t border-surface-border bg-white flex-shrink-0 shadow-[0_-4px_12px_rgba(0,0,0,0.06)]">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-surface-border">
        <div className="flex items-center gap-2">
          <FileText size={14} className="text-primary" />
          <span className="text-sm font-semibold text-slate-800">Send Template</span>
          <span className="text-[10px] text-slate-400">Approved templates only</span>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><X size={14} /></button>
      </div>
      <div className="px-4 pt-2.5 pb-2 space-y-2">
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-sm pl-8 w-full" placeholder="Search templates…" value={search} onChange={e => setSearch(e.target.value)} autoFocus />
        </div>
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
          {CATS.map(c => (
            <button key={c} onClick={() => setCat(c)}
              className={clsx('flex-shrink-0 px-2.5 py-0.5 rounded-full text-[10px] font-semibold transition-colors',
                cat === c ? 'bg-primary text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200')}>
              {c === 'ALL' ? 'All' : c.charAt(0) + c.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
      </div>
      <div className="max-h-56 overflow-y-auto px-4 pb-3 space-y-2">
        {filteredTmpl.length === 0 && <p className="text-xs text-slate-400 text-center py-4">No approved templates found</p>}
        {filteredTmpl.map(t => (
          <div key={t.id} className="border border-surface-border rounded-xl p-3 hover:border-primary/30 hover:bg-primary-50/40 transition-all group">
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-semibold text-slate-800">{t.name}</span>
                <span className={clsx('badge text-[9px]', CAT_COLOR[t.category] || 'badge-gray')}>
                  {t.category.charAt(0) + t.category.slice(1).toLowerCase()}
                </span>
              </div>
              <button onClick={() => onSelect(t.body)} className="flex-shrink-0 text-[11px] px-3 py-1 rounded-lg bg-primary text-white font-medium opacity-0 group-hover:opacity-100 transition-opacity">Send</button>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed line-clamp-2">{t.body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─── Emoji Picker ────────────────────────────────────────────── */
function EmojiPicker({ onSelect, onClose }) {
  return (
    <div className="absolute bottom-full right-0 mb-2 bg-white rounded-xl shadow-modal border border-surface-border z-40 p-3 w-52 animate-fade-in">
      <div className="grid grid-cols-5 gap-1">
        {EMOJIS.map((em, i) => (
          <button key={i} onClick={() => { onSelect(em); onClose() }}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-surface-hover text-lg transition-colors">
            {em}
          </button>
        ))}
      </div>
    </div>
  )
}

/* ─── Filter sidebar ──────────────────────────────────────────── */
function FilterSidebar({ activeFilter, setActiveFilter, activeChannel, setActiveChannel, activeSource, setActiveSource, adminOnline, setAdminOnline }) {
  const [showMore, setShowMore] = useState(true)
  const CHANNELS = [
    { key: 'all',       label: 'All Channels',   icon: Grid3x3 },
    { key: 'whatsapp',  label: 'WhatsApp',        icon: MessageCircle, count: 5 },
    { key: 'instagram', label: 'Instagram',       icon: null },
    { key: 'calls',     label: 'WhatsApp Calls',  icon: PhoneCall },
  ]
  return (
    <div className="w-48 flex-shrink-0 bg-white border-r border-surface-border flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-3 py-3 border-b border-surface-border flex-shrink-0">
        <span className="text-sm font-bold text-slate-800">Team Inbox</span>
        <button className="p-1 rounded-md hover:bg-surface-hover text-slate-400 transition-colors"><Settings size={13} /></button>
      </div>
      <button
        onClick={() => setAdminOnline(p => !p)}
        className={clsx('flex items-center gap-2 px-3 py-2 text-xs font-semibold border-b transition-colors w-full',
          adminOnline ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-slate-50 border-surface-border text-slate-500 hover:bg-surface-hover')}>
        <span className={clsx('w-2 h-2 rounded-full flex-shrink-0', adminOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300')} />
        {adminOnline ? 'You are Online' : 'Go Online (as Agent)'}
      </button>
      <div className="flex-1 overflow-y-auto py-2">
        <div className="px-3 mb-1">
          <div className="flex items-center gap-1.5 py-1 mb-0.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Channels</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary text-white font-bold leading-none">New</span>
          </div>
          {CHANNELS.map(ch => {
            const Icon = ch.icon
            const isActive = activeChannel === ch.key && activeSource === 'all'
            return (
              <button key={ch.key} onClick={() => { setActiveChannel(ch.key); setActiveSource('all') }}
                className={clsx('w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors text-left',
                  isActive ? 'bg-primary-50 text-primary' : 'text-slate-600 hover:bg-surface-hover')}>
                {ch.key === 'instagram' ? <IgIcon size={13} /> : Icon ? <Icon size={13} /> : null}
                <span className="flex-1 truncate">{ch.label}</span>
                {ch.count && <span className={clsx('text-[10px] font-bold', isActive ? 'text-primary' : 'text-slate-400')}>{ch.count}</span>}
              </button>
            )
          })}
        </div>
        <div className="mx-3 border-t border-surface-border my-1.5" />
        <div className="px-3 mb-1">
          {VIEW_FILTERS.map(f => {
            const Icon = f.icon
            const isActive = activeFilter === f.key && activeSource === 'all'
            return (
              <button key={f.key} onClick={() => { setActiveFilter(f.key); setActiveSource('all') }}
                className={clsx('w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors text-left',
                  isActive ? 'bg-primary-50 text-primary' : 'text-slate-600 hover:bg-surface-hover')}>
                <Icon size={13} />
                <span className="truncate">{f.label}</span>
              </button>
            )
          })}
        </div>
        <div className="mx-3 border-t border-surface-border my-1.5" />
        <div className="px-3">
          <button onClick={() => setShowMore(p => !p)}
            className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-slate-700 font-semibold mb-1 w-full py-1">
            <ChevronDown size={11} className={clsx('transition-transform', !showMore && '-rotate-90')} />
            {showMore ? 'Less' : 'More'}
          </button>
          {showMore && (
            <>
              {MORE_FILTERS.map(f => {
                const Icon = f.icon
                const isActive = activeFilter === f.key && activeSource === 'all'
                return (
                  <button key={f.key} onClick={() => { setActiveFilter(f.key); setActiveSource('all') }}
                    className={clsx('w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors text-left',
                      isActive ? 'bg-primary-50 text-primary' : [f.color || 'text-slate-600', 'hover:bg-surface-hover'])}>
                    <Icon size={13} className="flex-shrink-0" />
                    <span className="truncate">{f.label}</span>
                  </button>
                )
              })}
              <div className="mt-2 pt-2 border-t border-surface-border/60">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider px-2 block mb-1">Ad Sources</span>
                {CTWA_SOURCES.map(src => {
                  const isActive = activeSource === src.key
                  return (
                    <button key={src.key} onClick={() => { setActiveSource(src.key); setActiveFilter('all') }}
                      title={src.desc}
                      className={clsx('w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs transition-colors text-left',
                        isActive ? `${src.bg} ${src.color} font-semibold` : 'text-slate-600 hover:bg-surface-hover')}>
                      <span className={clsx('text-[9px] font-bold px-1.5 py-0.5 rounded border flex-shrink-0',
                        isActive ? `${src.bg} ${src.color} border-current` : 'bg-slate-100 text-slate-500 border-slate-200')}>
                        {src.label}
                      </span>
                      <span className="truncate text-[11px]">{src.full}</span>
                    </button>
                  )
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─── Conversation list panel ─────────────────────────────────── */
function ConversationList({ onSelect, activeId, activeSource, view, setView }) {
  const { conversations, allConversations, search, setFilter, setSearch, setAgentFilter, setSourceFilter } = useConversations()
  const [workspace, setWorkspace]         = useState('ChatFlow')
  const [showWsMenu, setShowWsMenu]       = useState(false)
  const [activeTab, setActiveTab]         = useState('all')
  const [agentSel, setAgentSel]           = useState('all')
  const [showAgentDrop, setShowAgentDrop] = useState(false)
  const agentRef = useRef(null)

  useEffect(() => { setSourceFilter(activeSource === 'all' ? 'all' : activeSource) }, [activeSource])

  useEffect(() => {
    function h(e) { if (agentRef.current && !agentRef.current.contains(e.target)) setShowAgentDrop(false) }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const totalUnread = allConversations.reduce((s, c) => s + (c.unread || 0), 0)
  const unassigned  = allConversations.filter(c => !c.agentId && c.status !== 'resolved').length
  const tabCounts   = {
    all:      allConversations.length,
    bot:      allConversations.filter(c => c.status === 'bot').length,
    agent:    allConversations.filter(c => c.status === 'agent').length,
    resolved: allConversations.filter(c => c.status === 'resolved').length,
  }

  const currentAgent = agentSel === 'all'
    ? null
    : agentSel === 'unassigned'
      ? { name: 'Unassigned' }
      : AGENTS.find(a => a.id === agentSel)

  return (
    <div className="flex flex-col h-full border-r border-surface-border bg-white">
      <div className="px-3 pt-2.5 pb-2 border-b border-surface-border flex-shrink-0 space-y-2">
        <div className="flex items-center justify-between">
          <div className="relative">
            <button onClick={() => setShowWsMenu(p => !p)}
              className="flex items-center gap-1 text-sm font-bold text-slate-800 hover:text-primary transition-colors">
              {workspace} <ChevronDown size={12} className="text-slate-400" />
            </button>
            {showWsMenu && (
              <div className="absolute top-full left-0 mt-1 w-36 bg-white rounded-xl shadow-modal border border-surface-border z-20 py-1">
                {['ChatFlow', 'Support', 'Sales'].map(w => (
                  <button key={w} onClick={() => { setWorkspace(w); setShowWsMenu(false) }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-surface-hover text-slate-700">{w}</button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button className="p-1.5 rounded-lg text-slate-400 hover:bg-surface-hover hover:text-slate-600 transition-colors"><SlidersHorizontal size={12} /></button>
            <button className="p-1.5 rounded-lg text-slate-400 hover:bg-surface-hover hover:text-slate-600 transition-colors"><RefreshCw size={12} /></button>
            <button className="p-1.5 rounded-lg bg-primary text-white hover:bg-primary-hover transition-colors"><Plus size={12} /></button>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span className="font-semibold text-slate-700">{allConversations.length} Chats</span>
          {totalUnread > 0 && <><span className="text-slate-300">·</span><span className="font-semibold text-primary">{totalUnread} Unread</span></>}
          {unassigned > 0 && <><span className="text-slate-300">·</span><span className="font-semibold text-amber-500">{unassigned} Unassigned</span></>}
        </div>
        <div className="flex bg-slate-100 rounded-lg p-0.5">
          {[['chats', MessageCircle, 'Chats'], ['insights', Activity, 'Insights']].map(([k, Icon, lbl]) => (
            <button key={k} onClick={() => setView(k)}
              className={clsx('flex-1 flex items-center justify-center gap-1.5 py-1 rounded-md text-[11px] font-medium transition-colors',
                view === k ? 'bg-white shadow-card text-slate-800' : 'text-slate-500 hover:text-slate-700')}>
              <Icon size={11} /> {lbl}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-sm pl-8 w-full" placeholder="Search conversations…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex items-center gap-1.5">
          <div ref={agentRef} className="relative flex-1">
            <button onClick={() => setShowAgentDrop(p => !p)}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-surface-border bg-white text-xs font-medium text-slate-700 hover:border-primary/30 transition-colors">
              {currentAgent ? (
                <>
                  {currentAgent.status && <span className={clsx('w-1.5 h-1.5 rounded-full flex-shrink-0', AGENT_STATUS_DOT[currentAgent.status])} />}
                  <span className="flex-1 text-left truncate">{currentAgent.name.split(' ')[0]}</span>
                </>
              ) : (
                <>
                  <Users size={11} className="text-slate-400 flex-shrink-0" />
                  <span className="flex-1 text-left text-slate-500">All Agents</span>
                </>
              )}
              <ChevronDown size={11} className="text-slate-400 flex-shrink-0" />
            </button>
            {showAgentDrop && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-modal border border-surface-border z-30 py-1 min-w-[180px]">
                <button onClick={() => { setAgentSel('all'); setAgentFilter('all'); setShowAgentDrop(false) }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-surface-hover text-slate-700 flex items-center gap-2">
                  <Users size={11} className="text-slate-400" /> All Agents
                </button>
                <div className="border-t border-surface-border my-1" />
                {AGENTS.map(a => (
                  <button key={a.id} onClick={() => { setAgentSel(a.id); setAgentFilter(a.id); setShowAgentDrop(false) }}
                    className={clsx('w-full text-left px-3 py-2 text-xs hover:bg-surface-hover transition-colors flex items-center gap-2.5',
                      agentSel === a.id ? 'text-primary bg-primary-50' : 'text-slate-700')}>
                    <div className="relative flex-shrink-0">
                      <div className={clsx('w-6 h-6 rounded-full flex items-center justify-center text-white text-[9px] font-bold', a.color)}>{a.avatar}</div>
                      <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-white', AGENT_STATUS_DOT[a.status])} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{a.name}</p>
                      <p className="text-[10px] text-slate-400">{AGENT_STATUS_LABEL[a.status]} · {a.assigned} chats</p>
                    </div>
                  </button>
                ))}
                <div className="border-t border-surface-border my-1" />
                <button onClick={() => { setAgentSel('unassigned'); setAgentFilter('unassigned'); setShowAgentDrop(false) }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-surface-hover text-amber-600 flex items-center gap-2">
                  <AlertCircle size={11} /> Unassigned
                </button>
              </div>
            )}
          </div>
          <button className="p-1.5 rounded-lg border border-surface-border bg-white text-slate-400 hover:border-primary/30 hover:text-primary transition-colors">
            <Filter size={12} />
          </button>
        </div>
        <div className="flex border border-surface-border rounded-lg overflow-hidden">
          {STATUS_TABS.map((t, i) => (
            <button key={t.key} onClick={() => { setActiveTab(t.key); setFilter(t.key) }}
              className={clsx('flex-1 py-1.5 text-[11px] font-medium transition-colors flex items-center justify-center gap-1',
                i > 0 && 'border-l border-surface-border',
                activeTab === t.key ? 'bg-primary text-white' : 'text-slate-500 hover:bg-surface-hover')}>
              {t.label}
              <span className={clsx('text-[9px] font-bold', activeTab === t.key ? 'opacity-80' : 'text-slate-400')}>{tabCounts[t.key]}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto divide-y divide-surface-border/40">
        {conversations.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center px-4">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
              <MessageCircle size={20} className="text-slate-300" />
            </div>
            <p className="text-sm font-semibold text-slate-600">No chats found</p>
            <p className="text-xs text-slate-400 mt-1">Try a different filter</p>
          </div>
        )}
        {conversations.map(c => {
          const sm = STATUS_MAP[c.status] || STATUS_MAP.bot
          const isActive = c.id === activeId
          const src = CTWA_SOURCES.find(s => s.key === c.source)
          return (
            <div key={c.id} onClick={() => onSelect(c.id)}
              className={clsx('flex items-start gap-2.5 px-3 py-2.5 cursor-pointer transition-colors relative',
                isActive ? 'bg-primary-50' : 'hover:bg-surface-hover')}>
              {isActive && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary rounded-r" />}
              <div className="relative flex-shrink-0">
                <div className={clsx('w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white',
                  isActive ? 'bg-primary' : 'bg-gradient-to-br from-slate-500 to-slate-600')}>
                  {c.avatar}
                </div>
                <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', sm.dot)} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <div className="flex items-center gap-1">
                    <span className={clsx('text-[12px] font-semibold truncate', c.unread > 0 ? 'text-slate-900' : 'text-slate-700')}>{c.name}</span>
                    {c.starred && <Star size={10} className="text-amber-400 fill-amber-400 flex-shrink-0" />}
                  </div>
                  <span className="text-[10px] text-slate-400 flex-shrink-0 ml-1">{c.time}</span>
                </div>
                <p className={clsx('text-[11px] truncate', c.unread > 0 ? 'text-slate-700' : 'text-slate-400')}>{c.lastMessage}</p>
                <div className="flex items-center justify-between mt-1">
                  <div className="flex items-center gap-1 flex-wrap">
                    {c.agentName && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600 border border-blue-100 font-medium">{c.agentName.split(' ')[0]}</span>
                    )}
                    {src && (
                      <span className={clsx('text-[9px] px-1.5 py-0.5 rounded border font-bold', src.bg, src.color)}>{src.label}</span>
                    )}
                    {c.tags.slice(0, 1).map(t => (
                      <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">#{t}</span>
                    ))}
                  </div>
                  {c.unread > 0 && (
                    <span className="min-w-[16px] h-4 rounded-full bg-primary flex items-center justify-center text-white text-[9px] font-bold px-1">{c.unread}</span>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ─── Insights panel ──────────────────────────────────────────── */
function InsightsPanel({ adminOnline }) {
  const { allConversations } = useConversations()
  const open        = allConversations.filter(c => c.status !== 'resolved').length
  const botActive   = allConversations.filter(c => c.status === 'bot').length
  const agentActive = allConversations.filter(c => c.status === 'agent').length
  const unassigned  = allConversations.filter(c => !c.agentId && c.status !== 'resolved').length

  return (
    <div className="flex-1 overflow-y-auto bg-[#f7f8fc] p-5">
      <div className="max-w-3xl mx-auto space-y-5">
        {adminOnline && (
          <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-xl">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <p className="text-sm font-semibold text-emerald-800">You are online as an agent — conversations can be assigned to you</p>
          </div>
        )}
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><Activity size={15} className="text-primary" /> Live Queue</h3>
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Open Chats',   value: open,        color: 'text-primary',     bg: 'bg-primary-50'  },
              { label: 'Bot Handling', value: botActive,   color: 'text-blue-600',    bg: 'bg-blue-50'     },
              { label: 'With Agent',   value: agentActive, color: 'text-emerald-600', bg: 'bg-emerald-50'  },
              { label: 'Unassigned',   value: unassigned,  color: 'text-amber-600',   bg: 'bg-amber-50'    },
            ].map(s => (
              <div key={s.label} className={clsx('rounded-xl p-3.5 border border-white/80 shadow-card', s.bg)}>
                <p className={clsx('text-2xl font-extrabold', s.color)}>{s.value}</p>
                <p className="text-xs text-slate-600 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><Users size={15} className="text-primary" /> Agent Real-time Status</h3>
          <div className="bg-white rounded-xl border border-surface-border overflow-hidden shadow-card">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-surface-border">
                  {['Agent', 'Status', 'Assigned', 'Resolved', 'Avg Reply', 'Actions'].map((h, i) => (
                    <th key={h} className={clsx('px-4 py-2.5 text-slate-500 font-semibold', i === 0 ? 'text-left' : i === 5 ? 'text-right pr-4' : 'text-center')}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border/60">
                {AGENTS.map(a => (
                  <tr key={a.id} className="hover:bg-surface-hover transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className={clsx('w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-bold', a.color)}>{a.avatar}</div>
                          <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', AGENT_STATUS_DOT[a.status])} />
                        </div>
                        <div><p className="font-semibold text-slate-800">{a.name}</p><p className="text-[10px] text-slate-400">{a.role}</p></div>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className={clsx('inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold',
                        a.status === 'online' ? 'bg-emerald-50 text-emerald-700' : a.status === 'busy' ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-500')}>
                        <span className={clsx('w-1.5 h-1.5 rounded-full', AGENT_STATUS_DOT[a.status])} />
                        {AGENT_STATUS_LABEL[a.status]}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-center font-bold text-slate-800">{a.assigned}</td>
                    <td className="px-3 py-3 text-center font-bold text-emerald-600">{a.resolved}</td>
                    <td className="px-3 py-3 text-center text-slate-600">{a.avgReply}</td>
                    <td className="px-4 py-3 text-right">
                      <button className="text-[10px] px-2.5 py-1 rounded-lg bg-primary-50 text-primary border border-primary/20 hover:bg-primary hover:text-white transition-colors font-medium">View Chats</button>
                    </td>
                  </tr>
                ))}
                {adminOnline && (
                  <tr className="bg-primary-50/50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-white text-[10px] font-bold">DK</div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white bg-emerald-500" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p className="font-semibold text-slate-800">Deepak Kumar</p>
                            <span className="text-[9px] bg-primary text-white px-1.5 py-0.5 rounded font-bold">YOU</span>
                          </div>
                          <p className="text-[10px] text-slate-400">Admin</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Online
                      </span>
                    </td>
                    <td colSpan={4} className="px-4 py-3 text-center text-xs text-slate-400 italic">Admin — can handle any chat</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><TrendingUp size={15} className="text-primary" /> Ad Source Breakdown</h3>
          <div className="grid grid-cols-3 gap-3">
            {CTWA_SOURCES.map(src => {
              const count = allConversations.filter(c => c.source === src.key).length
              return (
                <div key={src.key} className={clsx('rounded-xl p-4 border border-white/80 shadow-card', src.bg)}>
                  <div className="flex items-center justify-between mb-2">
                    <span className={clsx('text-[10px] font-bold px-2 py-0.5 rounded border', src.color, src.bg, 'border-current')}>{src.label}</span>
                    <span className={clsx('text-xl font-extrabold', src.color)}>{count}</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-700">{src.full}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">{src.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><BarChart2 size={15} className="text-primary" /> Today's Summary</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Avg First Response', value: '2.8 min', Icon: Clock,        color: 'text-primary',     bg: 'bg-primary-50' },
              { label: 'Resolution Rate',    value: '76%',     Icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
              { label: 'CSAT Score',         value: '4.6 / 5', Icon: Star,         color: 'text-amber-600',   bg: 'bg-amber-50'   },
            ].map(s => (
              <div key={s.label} className={clsx('rounded-xl p-4 border border-white/80 shadow-card', s.bg)}>
                <s.Icon size={18} className={clsx('mb-2', s.color)} />
                <p className={clsx('text-xl font-extrabold', s.color)}>{s.value}</p>
                <p className="text-xs text-slate-600 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Chat Window ─────────────────────────────────────────────── */
function ChatWindow({ conversation, adminOnline }) {
  const [message, setMessage]               = useState('')
  const [replyMode, setReplyMode]           = useState('reply')
  const [showCanned, setShowCanned]         = useState(false)
  const [showTemplate, setShowTemplate]     = useState(false)
  const [showTransfer, setShowTransfer]     = useState(false)
  const [showReassign, setShowReassign]     = useState(false)
  const [showSnooze, setShowSnooze]         = useState(false)
  const [showMoreActions, setShowMoreActions] = useState(false)
  const [showLabelPicker, setShowLabelPicker] = useState(false)
  const [showEmoji, setShowEmoji]           = useState(false)
  const [showTranslate, setShowTranslate]   = useState(false)
  const [archiveConfirm, setArchiveConfirm] = useState(false)

  const {
    sendMessage, takeoverConversation, resolveConversation, returnToBot,
    assignAgent, toggleStar, archiveConversation, snoozeConversation, addNote,
  } = useConversations()

  const endRef    = useRef(null)
  const moreRef   = useRef(null)
  const labelRef  = useRef(null)
  const snoozeRef = useRef(null)
  const emojiRef  = useRef(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [conversation?.messages])

  useEffect(() => {
    function h(e) {
      if (moreRef.current  && !moreRef.current.contains(e.target))  setShowMoreActions(false)
      if (labelRef.current && !labelRef.current.contains(e.target))  setShowLabelPicker(false)
      if (emojiRef.current && !emojiRef.current.contains(e.target))  setShowEmoji(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  if (!conversation) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#f7f8fc] text-center p-8">
        <div className="w-20 h-20 rounded-2xl bg-white border border-surface-border flex items-center justify-center mb-5 shadow-card">
          <MessageCircle size={32} className="text-slate-200" />
        </div>
        <p className="font-semibold text-slate-600">Select a conversation</p>
        <p className="text-sm text-slate-400 mt-1.5 max-w-xs">Choose from the list on the left to start</p>
        <div className="mt-5 flex items-center gap-2 text-xs text-slate-400 bg-white px-4 py-2 rounded-full border border-surface-border shadow-card">
          <ShieldCheck size={13} className="text-primary" />
          Admin view — reply to any conversation
        </div>
      </div>
    )
  }

  const sm  = STATUS_MAP[conversation.status]
  const src = CTWA_SOURCES.find(s => s.key === conversation.source)

  function handleSend() {
    if (!message.trim()) return
    if (replyMode === 'note') {
      addNote(conversation.id, message, 'Deepak Kumar')
    } else {
      sendMessage(conversation.id, message)
    }
    setMessage('')
    setShowCanned(false)
    setShowTemplate(false)
  }

  function renderMessage(m) {
    // Event bubble
    if (m.type === 'event') {
      return (
        <div key={m.id} className="flex items-center justify-center my-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs text-slate-500">
            {m.event === 'ctwa_entry' && (
              <span className="text-blue-600 font-bold text-[10px] px-2 py-0.5 rounded bg-blue-50 border border-blue-200 mr-1">AD</span>
            )}
            {m.event === 'assigned'     && <UserCheck size={11} className="text-emerald-500" />}
            {m.event === 'bot_handover' && <Bot size={11} className="text-primary" />}
            {m.event === 'ctwa_entry'   && <Globe size={11} className="text-blue-500" />}
            {m.text}
          </div>
        </div>
      )
    }

    // Template message
    if (m.type === 'template') {
      const { template } = m
      return (
        <div key={m.id} className="flex justify-end my-2">
          <div className="max-w-xs rounded-2xl border border-surface-border bg-white shadow-card overflow-hidden">
            <div className="flex items-center justify-between px-3 pt-2.5 pb-1">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Template</span>
              <span className="badge badge-blue text-[9px]">{template.category}</span>
            </div>
            <div className="px-3 pb-1"><p className="font-bold text-slate-900 text-sm">{template.header}</p></div>
            <div className="px-3 pb-2"><p className="text-sm text-slate-700 leading-relaxed">{template.body}</p></div>
            {template.footer && <div className="px-3 pb-2"><p className="text-[11px] text-slate-400">{template.footer}</p></div>}
            {template.buttons?.length > 0 && (
              <div className="border-t border-surface-border">
                {template.buttons.map((btn, i) => (
                  <button key={i} className={clsx('w-full py-2 text-xs font-semibold text-primary hover:bg-primary-50 transition-colors', i > 0 ? 'border-t border-surface-border' : '')}>{btn}</button>
                ))}
              </div>
            )}
            <div className="px-3 pb-2 text-right"><span className="text-[10px] text-slate-400">{m.time}</span></div>
          </div>
        </div>
      )
    }

    // Private note
    if (m.type === 'note') {
      return (
        <div key={m.id} className="flex justify-end my-2">
          <div className="max-w-[72%]">
            <div className="flex items-center justify-end gap-1 mb-0.5">
              <span className="text-[10px] text-amber-600 font-medium">🔒 Private Note · {m.sender}</span>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-2xl rounded-tr-sm px-4 py-2.5">
              <p className="text-sm text-amber-900 leading-relaxed">{m.text}</p>
              <p className="text-[10px] text-amber-500 mt-1 text-right">{m.time}</p>
            </div>
          </div>
        </div>
      )
    }

    // Button reply
    if (m.isButtonReply) {
      return (
        <div key={m.id} className="flex justify-start my-1">
          <div>
            <div className="flex items-center gap-1 mb-0.5">
              <span className="text-[9px] text-slate-400 flex items-center gap-0.5">↩ Quick Reply</span>
            </div>
            <div className="bg-white rounded-2xl rounded-tl-sm px-3 py-2 border border-primary/30 shadow-sm">
              <p className="text-sm text-primary font-medium">{m.text}</p>
            </div>
          </div>
        </div>
      )
    }

    // Regular incoming / outgoing
    const isIncoming = m.type === 'incoming'
    return (
      <div key={m.id} className={clsx('flex', isIncoming ? 'justify-start' : 'justify-end')}>
        {isIncoming && (
          <div className="w-7 h-7 rounded-full bg-slate-400 flex items-center justify-center text-white text-xs font-bold mr-2 flex-shrink-0 mt-auto mb-0.5">
            {conversation.avatar[0]}
          </div>
        )}
        <div>
          {isIncoming && showTranslate && (
            <div className="text-[10px] text-blue-600 mb-0.5 flex items-center gap-1">
              <Globe size={10} /> Translated from Hindi
            </div>
          )}
          <div className={clsx('max-w-[72%] rounded-2xl px-4 py-2.5 shadow-sm',
            isIncoming        ? 'bg-white text-slate-800 rounded-tl-sm'
            : m.sender === 'Bot' ? 'bg-primary text-white rounded-tr-sm'
            : 'bg-emerald-500 text-white rounded-tr-sm')}>
            {!isIncoming && (
              <p className="text-[10px] font-medium mb-1 opacity-70">
                {m.sender === 'Bot' ? '🤖 Bot' : m.agentName ? `👤 ${m.agentName}` : '👤 Agent'}
              </p>
            )}
            <p className="text-sm leading-relaxed">{m.text}</p>
            <p className={clsx('text-[10px] mt-1 text-right', isIncoming ? 'text-slate-400' : 'opacity-60')}>{m.time}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col bg-white min-w-0 relative">
      {/* Chat header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-surface-border bg-white flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white text-sm font-bold">{conversation.avatar}</div>
            <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white', sm.dot)} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-semibold text-slate-900 text-sm">{conversation.name}</p>
              {src && <span className={clsx('text-[9px] font-bold px-1.5 py-0.5 rounded border', src.bg, src.color, 'border-current')}>{src.label}</span>}
              {conversation.snoozed && <span className="flex items-center gap-1 text-[9px] font-medium text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200"><BellOff size={9} /> Snoozed</span>}
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={clsx('badge text-[10px]', sm.badge)}>{sm.label}</span>
              <span className="text-[10px] text-slate-400">{conversation.phone}</span>
              {conversation.agentName && <span className="text-[10px] text-slate-500">· {conversation.agentName}</span>}
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1">
          {/* Star */}
          <button onClick={() => toggleStar(conversation.id)}
            className={clsx('p-2 rounded-lg transition-colors', conversation.starred ? 'text-amber-400 hover:bg-amber-50' : 'text-slate-400 hover:bg-surface-hover hover:text-amber-400')}>
            <Star size={15} className={conversation.starred ? 'fill-amber-400' : ''} />
          </button>

          {/* Snooze */}
          <div ref={snoozeRef} className="relative">
            <button onClick={() => setShowSnooze(p => !p)}
              className="p-2 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors">
              <BellOff size={15} />
            </button>
            {showSnooze && (
              <SnoozePicker onSnooze={val => snoozeConversation(conversation.id, val)} onClose={() => setShowSnooze(false)} />
            )}
          </div>

          {conversation.status === 'bot' && (
            <button onClick={() => takeoverConversation(conversation.id)} className="btn-primary text-xs py-1.5 px-3">
              <UserCheck size={13} /> Take Over
            </button>
          )}
          {conversation.status === 'agent' && (
            <button onClick={() => returnToBot(conversation.id)} className="btn-secondary text-xs py-1.5 px-3">
              <Bot size={13} /> Return to Bot
            </button>
          )}
          {conversation.status !== 'resolved' && (
            <button onClick={() => setShowTransfer(true)} className="btn-secondary text-xs py-1.5 px-3">
              <ArrowRightLeft size={13} /> Transfer
            </button>
          )}
          {conversation.status !== 'resolved' && (
            <button onClick={() => resolveConversation(conversation.id)} className="btn-secondary text-xs py-1.5 px-3">
              <CheckCircle2 size={13} className="text-emerald-500" /> Resolve
            </button>
          )}
          {conversation.status === 'resolved' && (
            <button onClick={() => takeoverConversation(conversation.id)} className="btn-secondary text-xs py-1.5 px-3">
              <RotateCcw size={13} /> Reopen
            </button>
          )}
          <button className="p-2 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><Phone size={15} /></button>

          {/* Label picker trigger */}
          <div ref={labelRef} className="relative">
            <button onClick={() => setShowLabelPicker(p => !p)}
              className={clsx('p-2 rounded-lg transition-colors', showLabelPicker ? 'bg-primary-50 text-primary' : 'hover:bg-surface-hover text-slate-400 hover:text-slate-600')}>
              <Tag size={15} />
            </button>
            {showLabelPicker && conversation && (
              <LabelPicker conversation={conversation} onClose={() => setShowLabelPicker(false)} />
            )}
          </div>

          {/* More actions */}
          <div ref={moreRef} className="relative">
            <button onClick={() => setShowMoreActions(p => !p)}
              className="p-2 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors">
              <MoreVertical size={15} />
            </button>
            {showMoreActions && (
              <div className="absolute top-full right-0 mt-1 w-52 bg-white rounded-xl shadow-modal border border-surface-border z-30 py-1 animate-fade-in">
                <button onClick={() => { setShowLabelPicker(true); setShowMoreActions(false) }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-slate-900 transition-colors">
                  <Tag size={13} className="text-slate-400" /> Add Label
                </button>
                <button onClick={() => { setShowTranslate(p => !p); setShowMoreActions(false) }}
                  className={clsx('w-full flex items-center gap-2.5 px-3 py-2 text-xs hover:bg-surface-hover hover:text-slate-900 transition-colors',
                    showTranslate ? 'text-blue-600' : 'text-slate-700')}>
                  <Globe size={13} className={showTranslate ? 'text-blue-500' : 'text-slate-400'} />
                  {showTranslate ? 'Hide Translation' : 'Translate Messages'}
                </button>
                <button onClick={() => { toggleStar(conversation.id); setShowMoreActions(false) }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-slate-900 transition-colors">
                  <Star size={13} className={conversation.starred ? 'text-amber-400 fill-amber-400' : 'text-slate-400'} />
                  {conversation.starred ? 'Unstar Conversation' : 'Star Conversation'}
                </button>
                <button onClick={() => { setShowSnooze(true); setShowMoreActions(false) }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-slate-900 transition-colors">
                  <BellOff size={13} className="text-slate-400" /> Snooze
                </button>
                <button onClick={() => { setArchiveConfirm(true); setShowMoreActions(false) }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-amber-600 hover:bg-amber-50 hover:text-amber-800 transition-colors">
                  <Archive size={13} className="text-amber-400" /> Archive
                </button>
                <button onClick={() => { setShowTemplate(true); setShowMoreActions(false) }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-slate-900 transition-colors">
                  <FileText size={13} className="text-slate-400" /> Send Template
                </button>
                <div className="border-t border-surface-border my-1" />
                <button onClick={() => setShowMoreActions(false)}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-surface-hover hover:text-slate-900 transition-colors">
                  <Eye size={13} className="text-slate-400" /> View Full Contact
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Archive confirm banner */}
      {archiveConfirm && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-amber-50 border-b border-amber-200 flex-shrink-0">
          <Archive size={13} className="text-amber-600" />
          <span className="text-xs text-amber-800 font-medium flex-1">Archive this conversation? It will be moved to archived chats.</span>
          <button onClick={() => { archiveConversation(conversation.id); setArchiveConfirm(false) }}
            className="text-xs font-semibold text-white bg-amber-500 hover:bg-amber-600 px-3 py-1 rounded-lg transition-colors">Archive</button>
          <button onClick={() => setArchiveConfirm(false)} className="text-xs text-slate-500 hover:text-slate-700 font-medium">Cancel</button>
        </div>
      )}

      {/* Status bar */}
      {conversation.status === 'bot' && (
        <div className="flex items-center gap-2 px-4 py-2 bg-primary-50 border-b border-primary/10 flex-shrink-0">
          <Bot size={13} className="text-primary" />
          <span className="text-xs text-primary font-medium">Bot is handling this conversation</span>
          <button onClick={() => takeoverConversation(conversation.id)} className="ml-auto text-xs text-primary font-semibold hover:underline">Take over →</button>
        </div>
      )}
      {conversation.status === 'agent' && (
        <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 border-b border-emerald-100 flex-shrink-0">
          <UserCheck size={13} className="text-emerald-600" />
          <span className="text-xs text-emerald-700 font-medium">{conversation.agentName || 'Agent'} is handling this conversation</span>
          <div className="ml-auto">
            <button onClick={() => setShowReassign(true)}
              className="text-xs px-3 py-1 rounded-lg border border-emerald-200 bg-white text-emerald-700 hover:bg-emerald-50 hover:border-emerald-300 transition-colors font-medium flex items-center gap-1.5">
              <UserPlus size={11} /> Reassign
            </button>
          </div>
        </div>
      )}

      {/* Translate banner */}
      {showTranslate && (
        <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 border-b border-blue-100 flex-shrink-0">
          <Globe size={13} className="text-blue-500" />
          <span className="text-xs text-blue-700 font-medium">Translating incoming messages from Hindi to English</span>
          <button onClick={() => setShowTranslate(false)} className="ml-auto text-xs text-blue-600 hover:underline font-medium">Disable</button>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-2 bg-[#f0f4f8]">
        {conversation.messages.map(m => renderMessage(m))}
        <div ref={endRef} />
      </div>

      {/* Canned responses */}
      {showCanned && (
        <div className="border-t border-surface-border bg-slate-50 px-4 pt-3 pb-2 flex-shrink-0">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"><Zap size={12} className="text-primary" /> Canned Responses</p>
            <button onClick={() => setShowCanned(false)} className="text-slate-400 hover:text-slate-600"><X size={13} /></button>
          </div>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {CANNED.map(c => (
              <button key={c.key} onClick={() => { setMessage(c.body); setShowCanned(false) }}
                className="w-full text-left px-3 py-2 rounded-lg bg-white border border-surface-border hover:border-primary hover:bg-primary-50/60 transition-all group">
                <p className="text-[11px] font-semibold text-slate-700 group-hover:text-primary">{c.label}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{c.body}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Template picker */}
      {showTemplate && (
        <TemplatePicker onSelect={body => { setMessage(body); setShowTemplate(false) }} onClose={() => setShowTemplate(false)} />
      )}

      {/* Composer */}
      <div className="border-t border-surface-border bg-white flex-shrink-0">
        <div className="flex border-b border-surface-border px-4">
          {[['reply', 'Reply'], ['note', 'Private Note']].map(([k, lbl]) => (
            <button key={k} onClick={() => setReplyMode(k)}
              className={clsx('px-4 py-2.5 text-xs font-medium border-b-2 transition-colors',
                replyMode === k ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700')}>
              {lbl}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-1 py-1.5">
            {[Bold, Italic, AtSign].map((Icon, i) => (
              <button key={i} className="p-1.5 rounded hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><Icon size={13} /></button>
            ))}
          </div>
        </div>

        <div className="px-3 py-2.5">
          <div className={clsx('flex items-end gap-2 rounded-xl px-3 py-2 border',
            replyMode === 'note' ? 'bg-amber-50 border-amber-200' : 'bg-surface border-surface-border')}>
            <div className="flex items-center gap-0.5 pb-0.5">
              <button onClick={() => { setShowCanned(p => !p); setShowTemplate(false) }}
                title="Canned Responses"
                className={clsx('p-1.5 rounded-lg transition-colors', showCanned ? 'bg-primary-50 text-primary' : 'hover:bg-surface-hover text-slate-400 hover:text-primary')}>
                <Zap size={15} />
              </button>
              <button onClick={() => { setShowTemplate(p => !p); setShowCanned(false) }}
                title="Send Template"
                className={clsx('p-1.5 rounded-lg transition-colors', showTemplate ? 'bg-primary-50 text-primary' : 'hover:bg-surface-hover text-slate-400 hover:text-primary')}>
                <FileText size={15} />
              </button>
              <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><Paperclip size={15} /></button>
              <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><Image size={15} /></button>
            </div>

            <textarea
              value={message}
              onChange={e => setMessage(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() } }}
              placeholder={replyMode === 'note' ? 'Write a private note… (@mention teammates)' : 'Type a message… (Enter to send)'}
              rows={1}
              className={clsx('flex-1 bg-transparent text-sm placeholder-slate-400 resize-none focus:outline-none py-1 min-h-[28px] max-h-28',
                replyMode === 'note' ? 'text-amber-900' : 'text-slate-800')}
            />

            <div className="flex items-center gap-0.5 pb-0.5">
              {/* Emoji picker */}
              <div ref={emojiRef} className="relative">
                <button onClick={() => setShowEmoji(p => !p)}
                  className={clsx('p-1.5 rounded-lg transition-colors', showEmoji ? 'bg-primary-50 text-primary' : 'hover:bg-surface-hover text-slate-400 hover:text-slate-600')}>
                  <Smile size={15} />
                </button>
                {showEmoji && (
                  <EmojiPicker onSelect={em => setMessage(prev => prev + em)} onClose={() => setShowEmoji(false)} />
                )}
              </div>
              <button className="p-1.5 rounded-lg hover:bg-surface-hover text-slate-400 hover:text-slate-600 transition-colors"><Mic size={15} /></button>
              <button onClick={handleSend} disabled={!message.trim()}
                className={clsx('p-2 rounded-lg transition-all',
                  message.trim() ? 'bg-primary hover:bg-primary-hover text-white shadow-btn' : 'text-slate-300 cursor-not-allowed')}>
                <Send size={15} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {showTransfer && <TransferModal conversation={conversation} onClose={() => setShowTransfer(false)} adminOnline={adminOnline} />}
      {showReassign && <ReassignModal conversation={conversation} onClose={() => setShowReassign(false)} adminOnline={adminOnline} />}
    </div>
  )
}

/* ─── Contact Panel ───────────────────────────────────────────── */
function ContactPanel({ conversation, adminOnline }) {
  const [activeTab, setActiveTab]       = useState('contact')
  const [noteText, setNoteText]         = useState('')
  const [showLabelInline, setShowLabelInline] = useState(false)
  const { assignAgent, addLabel, removeLabel, addNote } = useConversations()

  if (!conversation) return null

  const convNotes     = conversation.messages.filter(m => m.type === 'note')
  const convEvents    = conversation.messages.filter(m => m.type === 'event' || m.type === 'note')
  const pastChats     = PAST_CONVERSATIONS.filter(p => p.contactId === conversation.id)
  const labels        = conversation.labels || []
  const hasCTWA       = conversation.messages.some(m => m.type === 'event' && m.event === 'ctwa_entry')
  const ctwaEvent     = conversation.messages.find(m => m.type === 'event' && m.event === 'ctwa_entry')
  const src           = CTWA_SOURCES.find(s => s.key === conversation.source)

  function handleAddNote() {
    if (!noteText.trim()) return
    addNote(conversation.id, noteText.trim(), 'Deepak Kumar')
    setNoteText('')
  }

  const totalSpent = MOCK_ORDERS.reduce((s, o) => s + parseInt(o.amount.replace(/[₹,]/g, '')), 0)

  return (
    <div className="w-72 border-l border-surface-border bg-white overflow-y-auto flex-shrink-0 hidden xl:flex flex-col">
      {/* Tabs */}
      <div className="flex border-b border-surface-border flex-shrink-0 overflow-x-auto scrollbar-hide">
        {[
          ['contact', 'Contact'],
          ['notes',   'Notes'],
          ['chats',   'Chats'],
          ['orders',  'Orders'],
          ['activity','Activity'],
        ].map(([k, lbl]) => (
          <button key={k} onClick={() => setActiveTab(k)}
            className={clsx('flex-shrink-0 px-3 py-2.5 text-[11px] font-medium transition-colors',
              activeTab === k ? 'text-primary border-b-2 border-primary' : 'text-slate-500 hover:text-slate-700')}>
            {lbl}
          </button>
        ))}
      </div>

      {/* ── Contact tab ── */}
      {activeTab === 'contact' && (
        <div className="p-4 space-y-4">
          {/* Avatar + actions */}
          <div className="text-center">
            <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-white text-xl font-bold mx-auto">{conversation.avatar}</div>
            <h3 className="font-semibold text-slate-900 mt-2 text-sm">{conversation.name}</h3>
            <p className="text-xs text-slate-500">{conversation.phone}</p>
            <div className="flex justify-center gap-2 mt-2">
              <button className="p-2 rounded-lg bg-surface border border-surface-border hover:border-primary/30 text-slate-500 hover:text-primary transition-colors"><Phone size={13} /></button>
              <button className="p-2 rounded-lg bg-surface border border-surface-border hover:border-primary/30 text-slate-500 hover:text-primary transition-colors"><AtSign size={13} /></button>
              <button onClick={() => {}} className={clsx('p-2 rounded-lg border transition-colors',
                conversation.starred ? 'bg-amber-50 border-amber-200 text-amber-400' : 'bg-surface border-surface-border text-slate-500 hover:border-amber-300 hover:text-amber-400')}>
                <Star size={13} className={conversation.starred ? 'fill-amber-400' : ''} />
              </button>
              <button onClick={() => {}} className="p-2 rounded-lg bg-surface border border-surface-border hover:border-blue-300 text-slate-500 hover:text-blue-500 transition-colors">
                <Globe size={13} />
              </button>
            </div>
          </div>

          {/* Labels */}
          <div>
            <p className="label mb-1.5">Labels</p>
            <div className="flex flex-wrap gap-1.5">
              {labels.map(lbl => (
                <span key={lbl} className="flex items-center gap-1 badge badge-blue text-[10px]">
                  #{lbl}
                  <button onClick={() => removeLabel(conversation.id, lbl)} className="ml-0.5 text-blue-400 hover:text-blue-700">×</button>
                </span>
              ))}
              <div className="relative">
                <button onClick={() => setShowLabelInline(p => !p)}
                  className="text-xs px-2 py-0.5 rounded-full border border-dashed border-slate-300 text-slate-400 hover:border-primary hover:text-primary transition-colors">
                  + Add Label
                </button>
                {showLabelInline && (
                  <div className="absolute left-0 top-full mt-1 z-20">
                    <LabelPicker conversation={conversation} onClose={() => setShowLabelInline(false)} />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* WhatsApp Status */}
          <div>
            <p className="label mb-1.5">WhatsApp Status</p>
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-50 border border-emerald-100">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-xs font-semibold text-emerald-700">Opted In</span>
              <span className="text-[10px] text-slate-400 ml-auto">Since Jan 2024</span>
            </div>
          </div>

          {/* Ad Source / CTWA */}
          {hasCTWA && ctwaEvent && (
            <div className="rounded-lg p-3 bg-blue-50 border border-blue-100">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Ad Entry</p>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-700 border border-blue-200">AD</span>
              <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">{ctwaEvent.text}</p>
            </div>
          )}
          {!hasCTWA && src && (
            <div className={clsx('rounded-lg p-3 border', src.bg)}>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Ad Source</p>
              <span className={clsx('text-xs font-bold px-2 py-1 rounded border', src.color, src.bg, 'border-current')}>{src.label}</span>
              <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">{src.desc}</p>
            </div>
          )}

          {/* Contact Info */}
          <div>
            <p className="label mb-1.5">Contact Info</p>
            <div className="space-y-1.5">
              {[
                { key: 'Status',   val: conversation.status.charAt(0).toUpperCase() + conversation.status.slice(1) },
                { key: 'Handler',  val: conversation.agentName || (conversation.status === 'bot' ? 'Bot' : 'Unassigned') },
                { key: 'Source',   val: 'WhatsApp' },
                { key: 'Language', val: 'English' },
                { key: 'Created',  val: 'Apr 15, 2024' },
              ].map(row => (
                <div key={row.key} className="flex justify-between items-center py-1.5 border-b border-surface-border/60">
                  <span className="text-xs text-slate-500">{row.key}</span>
                  <span className="text-xs font-medium text-slate-700">{row.val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Attributes */}
          <div>
            <p className="label mb-1.5">Custom Attributes</p>
            <div className="space-y-1.5">
              {[
                { key: 'City',    val: 'Mumbai'  },
                { key: 'Segment', val: 'Premium' },
                { key: 'Joined',  val: 'Jan 2024'},
              ].map(row => (
                <div key={row.key} className="flex justify-between items-center py-1.5 border-b border-surface-border/60">
                  <span className="text-xs text-slate-500">{row.key}</span>
                  <span className="text-xs font-medium text-slate-700">{row.val}</span>
                </div>
              ))}
            </div>
            <button className="mt-2 text-xs text-primary hover:underline flex items-center gap-1">
              <Plus size={10} /> Add Attribute
            </button>
          </div>

          {/* Assigned Agent */}
          <div>
            <p className="label mb-1.5">Assigned Agent</p>
            <select className="input text-xs" value={conversation.agentId || ''}
              onChange={e => { const a = AGENTS.find(ag => ag.id === e.target.value); if (a) assignAgent(conversation.id, a.id, a.name) }}>
              <option value="">Unassigned</option>
              {AGENTS.map(a => <option key={a.id} value={a.id}>{a.name} ({AGENT_STATUS_LABEL[a.status]})</option>)}
              {adminOnline && <option value="admin">Deepak Kumar (You)</option>}
            </select>
          </div>
        </div>
      )}

      {/* ── Notes tab ── */}
      {activeTab === 'notes' && (
        <div className="p-4 space-y-3">
          <div className="space-y-2">
            <textarea
              className="textarea text-xs"
              rows={4}
              placeholder="Add a private note… (@mention to notify teammates)"
              value={noteText}
              onChange={e => setNoteText(e.target.value)}
            />
            <button onClick={handleAddNote} disabled={!noteText.trim()}
              className={clsx('w-full justify-center text-xs', noteText.trim() ? 'btn-primary' : 'btn-secondary opacity-50 cursor-not-allowed')}>
              <Send size={12} /> Save Note
            </button>
          </div>
          {convNotes.length === 0 && (
            <div className="text-center py-6">
              <p className="text-xs text-slate-400">No notes yet</p>
            </div>
          )}
          {convNotes.map(note => (
            <div key={note.id} className="p-3 rounded-lg bg-amber-50 border border-amber-100 relative group">
              <p className="text-xs text-amber-800 leading-relaxed">{note.text}</p>
              <div className="flex items-center justify-between mt-1.5">
                <p className="text-[10px] text-amber-500">By {note.sender}</p>
                <p className="text-[10px] text-amber-400">{note.time}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Chats tab ── */}
      {activeTab === 'chats' && (
        <div className="p-4 space-y-3">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Past Conversations</p>
          {pastChats.length === 0 && (
            <div className="text-center py-6">
              <MessageCircle size={24} className="text-slate-200 mx-auto mb-2" />
              <p className="text-xs text-slate-400">No past conversations</p>
            </div>
          )}
          {pastChats.map(pc => (
            <div key={pc.id} className="p-3 rounded-xl border border-surface-border hover:border-primary/20 hover:bg-primary-50/30 transition-all cursor-pointer">
              <div className="flex items-center justify-between mb-1">
                <span className="badge badge-green text-[9px]">{pc.status}</span>
                <span className="text-[10px] text-slate-400">{pc.date}</span>
              </div>
              <p className="text-xs text-slate-700 font-medium leading-snug">{pc.snippet}</p>
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[10px] text-slate-400">Agent: {pc.agent}</span>
                <span className="text-[10px] text-slate-400">{pc.msgCount} msgs</span>
              </div>
            </div>
          ))}
          <button className="w-full btn-secondary text-xs justify-center mt-2">
            <Plus size={12} /> Start new conversation
          </button>
        </div>
      )}

      {/* ── Orders tab ── */}
      {activeTab === 'orders' && (
        <div className="p-4 space-y-4">
          {/* Summary cards */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg p-2.5 bg-primary-50 border border-primary/10 text-center">
              <p className="text-sm font-bold text-primary">₹{totalSpent.toLocaleString()}</p>
              <p className="text-[9px] text-slate-500 mt-0.5">Total Spent</p>
            </div>
            <div className="rounded-lg p-2.5 bg-emerald-50 border border-emerald-100 text-center">
              <p className="text-sm font-bold text-emerald-600">{MOCK_ORDERS.length}</p>
              <p className="text-[9px] text-slate-500 mt-0.5">Total Orders</p>
            </div>
            <div className="rounded-lg p-2.5 bg-slate-50 border border-surface-border text-center">
              <p className="text-sm font-bold text-slate-700">Apr 15</p>
              <p className="text-[9px] text-slate-500 mt-0.5">Last Purchase</p>
            </div>
          </div>

          {/* Orders table */}
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Order History</p>
            {MOCK_ORDERS.map(order => (
              <div key={order.id} className="border border-surface-border rounded-xl p-3 hover:border-primary/20 transition-colors">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-800">{order.id}</span>
                  <span className={clsx('badge text-[9px]', order.statusColor)}>{order.status}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>{order.items} item{order.items > 1 ? 's' : ''}</span>
                  <span className="font-semibold text-slate-700">{order.amount}</span>
                  <span>{order.date}</span>
                </div>
                <button className="mt-1.5 text-[10px] text-primary hover:underline flex items-center gap-0.5">
                  View <ExternalLinkIcon size={9} />
                </button>
              </div>
            ))}
          </div>
          <button className="text-xs text-primary hover:underline flex items-center gap-1">
            View in Shopify <ExternalLinkIcon size={10} />
          </button>
        </div>
      )}

      {/* ── Activity tab ── */}
      {activeTab === 'activity' && (
        <div className="p-4 space-y-3">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Timeline</p>
          {/* Events and notes from messages */}
          {convEvents.map((item, i) => {
            const isNote = item.type === 'note'
            return (
              <div key={item.id || i} className="flex items-start gap-2.5">
                <div className={clsx('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5',
                  isNote ? 'bg-amber-100' : 'bg-primary-50')}>
                  {isNote
                    ? <FileText size={11} className="text-amber-600" />
                    : item.event === 'assigned'     ? <UserCheck size={11} className="text-primary" />
                    : item.event === 'bot_handover' ? <Bot size={11} className="text-primary" />
                    : item.event === 'ctwa_entry'   ? <Globe size={11} className="text-blue-500" />
                    : <Activity size={11} className="text-primary" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-700 font-medium leading-snug">{item.text}</p>
                  {isNote && <p className="text-[10px] text-amber-500 mt-0.5">Note by {item.sender}</p>}
                  <p className="text-[10px] text-slate-400 mt-0.5">{item.time}</p>
                </div>
              </div>
            )
          })}
          {/* Static additional events */}
          {[
            { icon: FileText,      text: 'Template "order_confirmation" sent',  time: '10:41 AM', color: 'bg-blue-50',   iconColor: 'text-blue-500' },
            { icon: Tag,           text: 'Labels changed: +vip, +order-issue',  time: '10:43 AM', color: 'bg-slate-50',  iconColor: 'text-slate-500' },
            { icon: CheckCircle2,  text: 'Customer replied to template button', time: '10:42 AM', color: 'bg-emerald-50', iconColor: 'text-emerald-500' },
          ].map((item, i) => (
            <div key={`static-${i}`} className="flex items-start gap-2.5">
              <div className={clsx('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5', item.color)}>
                <item.icon size={11} className={item.iconColor} />
              </div>
              <div>
                <p className="text-xs text-slate-700 font-medium">{item.text}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">{item.time}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── Page ────────────────────────────────────────────────────── */
export default function Conversations() {
  const { selectConversation, active, activeId } = useConversations()
  const [activeFilter, setActiveFilter]   = useState('all')
  const [activeChannel, setActiveChannel] = useState('all')
  const [activeSource, setActiveSource]   = useState('all')
  const [adminOnline, setAdminOnline]     = useState(false)
  const [view, setView]                   = useState('chats')

  return (
    <div className="h-[calc(100vh-60px)] -m-5 flex animate-fade-in overflow-hidden">
      <FilterSidebar
        activeFilter={activeFilter}   setActiveFilter={setActiveFilter}
        activeChannel={activeChannel} setActiveChannel={setActiveChannel}
        activeSource={activeSource}   setActiveSource={setActiveSource}
        adminOnline={adminOnline}     setAdminOnline={setAdminOnline}
      />
      <div className="w-[280px] flex-shrink-0">
        <ConversationList
          onSelect={selectConversation}
          activeId={activeId}
          activeSource={activeSource}
          view={view}
          setView={setView}
        />
      </div>
      {view === 'insights'
        ? <InsightsPanel adminOnline={adminOnline} />
        : <ChatWindow conversation={active} adminOnline={adminOnline} />
      }
      {view === 'chats' && <ContactPanel conversation={active} adminOnline={adminOnline} />}
    </div>
  )
}
