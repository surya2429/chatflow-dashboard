import { useState } from 'react'
import {
  PhoneCall, Mic, Volume2, Clock, CheckCircle2, PhoneMissed,
  GitBranch, Play, Pause, Settings, BarChart2, FileText,
  TrendingUp, Bot, Users, Download, ChevronRight, X,
  RefreshCw, Radio,
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar,
} from 'recharts'
import { CALL_HISTORY, VOICE_STATS, ANALYTICS_DAILY } from '../constants/mockData'
import clsx from 'clsx'

const TABS = ['Configuration', 'Call Routing', 'Call History', 'Analytics']

const STATUS_BADGE = {
  Resolved:    'badge-green',
  Missed:      'badge-red',
  Transferred: 'badge-blue',
}

const STAT_COLORS = {
  purple: 'bg-purple-50 text-purple-600',
  green:  'bg-emerald-50 text-emerald-600',
  blue:   'bg-blue-50 text-blue-600',
  red:    'bg-red-50 text-red-500',
}

const ICON_MAP = { PhoneCall, Bot, Clock, PhoneMissed }

function TranscriptModal({ call, onClose }) {
  const transcript = [
    { role: 'bot',    text: 'Thank you for calling Acme Corp. How can I help you today?', time: '0:00' },
    { role: 'caller', text: 'I want to know the status of my order.', time: '0:04' },
    { role: 'bot',    text: 'Sure! Please say or enter your order ID.', time: '0:07' },
    { role: 'caller', text: 'Order 3821.', time: '0:12' },
    { role: 'bot',    text: 'Order 3821 is confirmed and will be delivered by April 17th. Is there anything else?', time: '0:15' },
    { role: 'caller', text: 'No, thank you.', time: '0:24' },
    { role: 'bot',    text: 'Great! Have a wonderful day. Goodbye!', time: '0:27' },
  ]

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-surface-border rounded-2xl w-full max-w-lg shadow-modal animate-fade-in">
        <div className="flex items-center justify-between p-5 border-b border-surface-border">
          <div>
            <h3 className="font-semibold text-slate-900">Call Transcript</h3>
            <p className="text-xs text-slate-500 mt-0.5">{call.caller} · {call.date} · {call.duration}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded hover:bg-surface-hover">
            <X size={16} />
          </button>
        </div>
        <div className="p-5 space-y-3 max-h-80 overflow-y-auto">
          {transcript.map((t, i) => (
            <div key={i} className={clsx('flex gap-3', t.role === 'caller' ? 'justify-end' : 'justify-start')}>
              <div className={clsx(
                'rounded-2xl px-4 py-2.5 max-w-xs text-sm',
                t.role === 'bot'
                  ? 'bg-primary-50 border border-primary/20 text-slate-700 rounded-tl-sm'
                  : 'bg-slate-100 text-slate-800 rounded-tr-sm'
              )}>
                <p className="text-xs font-medium mb-1 opacity-60">
                  {t.role === 'bot' ? '🤖 Voice Bot' : '👤 Caller'}
                </p>
                <p>{t.text}</p>
                <p className="text-xs opacity-50 text-right mt-1">{t.time}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="p-5 border-t border-surface-border">
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200">
            <CheckCircle2 size={14} className="text-emerald-600" />
            <p className="text-xs text-emerald-700">AI Summary: Customer enquired about order #3821 delivery status. Resolved by bot without escalation. Sentiment: Positive.</p>
          </div>
        </div>
      </div>
    </div>
  )
}

function VoiceConfig() {
  const [testing, setTesting] = useState(false)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div className="space-y-4">
        <div className="card p-5 space-y-4">
          <h3 className="section-title">Voice Bot Identity</h3>
          <div className="form-group">
            <label className="label">Bot Name</label>
            <input className="input" defaultValue="Aria" />
          </div>
          <div className="form-group">
            <label className="label">Language</label>
            <select className="select">
              <option>English (US)</option>
              <option>English (IN)</option>
              <option>Hindi</option>
              <option>Tamil</option>
              <option>Telugu</option>
              <option>Spanish</option>
            </select>
          </div>
          <div className="form-group">
            <label className="label">Voice Style</label>
            <div className="grid grid-cols-2 gap-2">
              {['Neural (Recommended)', 'Standard', 'Wavenet', 'Polyglot'].map(v => (
                <label key={v} className={clsx(
                  'flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors text-xs',
                  v === 'Neural (Recommended)'
                    ? 'border-primary bg-primary-50 text-primary'
                    : 'border-surface-border text-slate-600 hover:border-primary/40'
                )}>
                  <input type="radio" name="voice-style" className="accent-primary" defaultChecked={v === 'Neural (Recommended)'} />
                  {v}
                </label>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label className="label">Voice</label>
            <div className="flex gap-2">
              <select className="select">
                <option>Aria (Female)</option>
                <option>James (Male)</option>
                <option>Priya (Female - Hindi)</option>
                <option>Ravi (Male - Hindi)</option>
              </select>
              <button
                className="btn-secondary flex-shrink-0"
                onClick={() => { setTesting(true); setTimeout(() => setTesting(false), 2000) }}
              >
                {testing ? <Volume2 size={14} className="animate-pulse text-primary" /> : <Play size={14} />}
              </button>
            </div>
          </div>
        </div>

        <div className="card p-5 space-y-4">
          <h3 className="section-title">Greeting & Fallback</h3>
          <div className="form-group">
            <label className="label">Opening Greeting</label>
            <textarea
              className="textarea"
              rows={3}
              defaultValue="Thank you for calling Acme Corp. I'm Aria, your AI assistant. How can I help you today?"
            />
          </div>
          <div className="form-group">
            <label className="label">Fallback (when not understood)</label>
            <textarea
              className="textarea"
              rows={2}
              defaultValue="I'm sorry, I didn't catch that. Could you please repeat?"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="form-group">
              <label className="label">DTMF Timeout</label>
              <select className="select"><option>5 seconds</option><option>10 seconds</option></select>
            </div>
            <div className="form-group">
              <label className="label">Max Retries</label>
              <select className="select"><option>3 attempts</option><option>2 attempts</option><option>5 attempts</option></select>
            </div>
          </div>
          <div className="form-group">
            <label className="label">Fallback Action</label>
            <select className="select">
              <option>Transfer to Live Agent</option>
              <option>Play message & hang up</option>
              <option>Send WhatsApp message</option>
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="card p-5">
          <h3 className="section-title mb-4">Linked Phone Numbers</h3>
          <div className="space-y-3">
            {[
              { number: '+91 98765 00000', label: 'Primary', status: 'active' },
              { number: '+91 98765 00001', label: 'Toll-Free', status: 'active' },
            ].map(p => (
              <div key={p.number} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-surface-border">
                <div>
                  <p className="text-sm font-medium text-slate-900">{p.number}</p>
                  <p className="text-xs text-slate-500">{p.label}</p>
                </div>
                <span className="badge badge-green">Active</span>
              </div>
            ))}
            <button className="w-full py-2.5 rounded-lg border-2 border-dashed border-slate-200 text-slate-400 hover:border-primary/40 hover:text-primary transition-all text-sm">
              + Add Phone Number
            </button>
          </div>
        </div>

        <div className="card p-5 space-y-4">
          <h3 className="section-title">AI Integration</h3>
          <div className="form-group">
            <label className="label">AI Model for Voice</label>
            <select className="select">
              <option>OpenAI GPT-4o (Recommended)</option>
              <option>Claude AI</option>
              <option>Google Gemini</option>
              <option>Dialogflow CX</option>
            </select>
          </div>
          <div className="form-group">
            <label className="label">Speech-to-Text Provider</label>
            <select className="select">
              <option>Google Cloud STT</option>
              <option>AWS Transcribe</option>
              <option>Whisper (OpenAI)</option>
            </select>
          </div>
          <div className="form-group">
            <label className="label">Text-to-Speech Provider</label>
            <select className="select">
              <option>Google Cloud TTS</option>
              <option>AWS Polly</option>
              <option>ElevenLabs (Neural)</option>
            </select>
          </div>
        </div>

        <button className="btn-primary w-full justify-center">
          <Settings size={14} /> Save Configuration
        </button>
      </div>
    </div>
  )
}

function CallRouting() {
  const nodes = [
    { id: 'r1', label: 'Incoming Call',  type: 'entry',  x: 260, y: 30 },
    { id: 'r2', label: 'Play Greeting',  type: 'action', x: 260, y: 130 },
    { id: 'r3', label: 'IVR Menu',       type: 'ivr',    x: 260, y: 230 },
    { id: 'r4', label: '1. Sales',       type: 'route',  x: 60,  y: 360 },
    { id: 'r5', label: '2. Support Bot', type: 'route',  x: 230, y: 360 },
    { id: 'r6', label: '3. Office Hours',type: 'route',  x: 400, y: 360 },
    { id: 'r7', label: '0. Operator',    type: 'route',  x: 570, y: 360 },
  ]
  const edges = [
    { from: 'r1', to: 'r2' },
    { from: 'r2', to: 'r3' },
    { from: 'r3', to: 'r4' },
    { from: 'r3', to: 'r5' },
    { from: 'r3', to: 'r6' },
    { from: 'r3', to: 'r7' },
  ]

  const TYPE_STYLE = {
    entry:  'bg-primary-50 border-primary/30 text-primary',
    action: 'bg-blue-50 border-blue-200 text-blue-700',
    ivr:    'bg-purple-50 border-purple-200 text-purple-700',
    route:  'bg-amber-50 border-amber-200 text-amber-700',
  }

  function getLine(fromId, toId) {
    const f = nodes.find(n => n.id === fromId)
    const t = nodes.find(n => n.id === toId)
    if (!f || !t) return null
    return { x1: f.x + 70, y1: f.y + 36, x2: t.x + 70, y2: t.y }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-slate-500">Configure how incoming calls are routed through your IVR tree.</p>
        <button className="btn-primary"><Play size={14} /> Activate Routing</button>
      </div>

      <div className="card p-5">
        <div className="relative" style={{ height: 460 }}>
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {edges.map((e, i) => {
              const line = getLine(e.from, e.to)
              if (!line) return null
              return (
                <line key={i} x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2}
                  stroke="#e2e8f0" strokeWidth="2" strokeDasharray="4 2" />
              )
            })}
          </svg>
          {nodes.map(node => (
            <div
              key={node.id}
              className={clsx('absolute rounded-xl border-2 px-4 py-2 text-xs font-semibold cursor-pointer hover:scale-105 transition-transform w-36 text-center', TYPE_STYLE[node.type])}
              style={{ left: node.x, top: node.y }}
            >
              {node.label}
            </div>
          ))}
        </div>
      </div>

      <div className="card p-5">
        <h3 className="section-title mb-3">Routing Rules</h3>
        <div className="space-y-2">
          {[
            { key: '1', action: 'Transfer to Sales Team queue', wait: '< 2 min' },
            { key: '2', action: 'Route to Support Bot flow',    wait: 'Instant' },
            { key: '3', action: 'Play office hours recording',  wait: 'Instant' },
            { key: '0', action: 'Connect to operator',          wait: '< 5 min' },
          ].map(r => (
            <div key={r.key} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 border border-surface-border">
              <div className="w-8 h-8 rounded-lg bg-primary-50 border border-primary/20 flex items-center justify-center text-primary text-sm font-bold">
                {r.key}
              </div>
              <span className="text-sm text-slate-700 flex-1">{r.action}</span>
              <span className="text-xs text-slate-400">Est. wait: {r.wait}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function CallHistoryTab() {
  const [transcript, setTranscript] = useState(null)

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-secondary"><Download size={14} /> Export Logs</button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              {['Caller', 'Duration', 'Status', 'Date', 'Transcript', 'Recording'].map(h => (
                <th key={h} className="table-header">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {CALL_HISTORY.map(c => (
              <tr key={c.id} className="table-row">
                <td className="table-cell font-medium text-slate-900">{c.caller}</td>
                <td className="table-cell">{c.duration}</td>
                <td className="table-cell">
                  <span className={clsx('badge', STATUS_BADGE[c.status] || 'badge-gray')}>
                    {c.status}
                  </span>
                </td>
                <td className="table-cell text-slate-500 text-xs">{c.date}</td>
                <td className="table-cell">
                  {c.hasTranscript ? (
                    <button onClick={() => setTranscript(c)} className="text-xs text-primary hover:underline flex items-center gap-1">
                      <FileText size={12} /> View
                    </button>
                  ) : <span className="text-slate-300">—</span>}
                </td>
                <td className="table-cell">
                  {c.hasTranscript ? (
                    <button className="p-1.5 rounded hover:bg-surface-hover text-primary">
                      <Play size={13} />
                    </button>
                  ) : <span className="text-slate-300">—</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {transcript && <TranscriptModal call={transcript} onClose={() => setTranscript(null)} />}
    </div>
  )
}

function VoiceAnalytics() {
  const callData = ANALYTICS_DAILY.slice(-14).map(d => ({
    ...d,
    calls: Math.floor(8 + Math.random() * 18),
    resolved: Math.floor(5 + Math.random() * 12),
  }))

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null
    return (
      <div className="bg-white border border-surface-border rounded-lg p-3 shadow-modal text-xs">
        <p className="font-medium text-slate-600 mb-1.5">{label}</p>
        {payload.map(p => (
          <div key={p.name} className="flex items-center gap-2 mt-0.5">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-slate-500">{p.name}:</span>
            <span className="font-semibold text-slate-800">{p.value}</span>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {VOICE_STATS.map(s => {
          const Icon = ICON_MAP[s.icon]
          return (
            <div key={s.label} className="stat-card">
              <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center mb-3', STAT_COLORS[s.color])}>
                {Icon && <Icon size={15} />}
              </div>
              <p className="text-2xl font-bold text-slate-900">{s.value}</p>
              <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
              <p className={clsx('text-xs mt-1.5 font-medium', s.up ? 'text-emerald-600' : 'text-red-500')}>
                {s.trend}
              </p>
            </div>
          )
        })}
      </div>

      <div className="card p-5">
        <h3 className="section-title mb-4">Daily Call Volume (14 days)</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={callData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="calls" name="Total Calls" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            <Bar dataKey="resolved" name="Bot Resolved" fill="#10b981" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card p-5">
          <h3 className="section-title mb-4">Call Outcomes</h3>
          <div className="space-y-3">
            {[
              { label: 'Bot Resolved',        value: 71, color: 'bg-primary' },
              { label: 'Transferred to Agent',value: 17, color: 'bg-blue-500' },
              { label: 'Missed / Voicemail',  value: 8,  color: 'bg-red-400' },
              { label: 'Caller Hung Up',      value: 4,  color: 'bg-slate-300' },
            ].map(o => (
              <div key={o.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500">{o.label}</span>
                  <span className="text-slate-800 font-medium">{o.value}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={clsx('h-full rounded-full', o.color)} style={{ width: `${o.value}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-4">Peak Call Hours (Today)</h3>
          <div className="grid grid-cols-6 gap-1">
            {Array.from({ length: 24 }, (_, h) => {
              const intensity = h >= 9 && h <= 18 ? Math.random() * 0.8 + 0.2 : Math.random() * 0.2
              return (
                <div key={h} title={`${h}:00`} className="flex flex-col items-center gap-1">
                  <div
                    className="w-full rounded"
                    style={{ height: 40, background: `rgba(0,102,255,${intensity})` }}
                  />
                  {h % 4 === 0 && <span className="text-xs text-slate-400">{h}h</span>}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Voice() {
  const [activeTab, setActiveTab] = useState(0)

  const TAB_CONTENT = [<VoiceConfig />, <CallRouting />, <CallHistoryTab />, <VoiceAnalytics />]
  const TAB_ICONS = [Settings, GitBranch, PhoneCall, BarChart2]

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="bg-gradient-to-r from-purple-50 to-primary-50 border border-purple-200/60 rounded-xl p-5 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
          <PhoneCall size={22} className="text-purple-600" />
        </div>
        <div>
          <h2 className="font-bold text-slate-900">WhatsApp Voice Bot</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            AI-powered voice assistant with natural speech, IVR routing, live transcription & analytics.
          </p>
        </div>
        <div className="ml-auto flex-shrink-0">
          <span className="badge badge-green text-sm px-3 py-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block mr-1 animate-pulse" />
            Active
          </span>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit">
        {TABS.map((tab, i) => {
          const Icon = TAB_ICONS[i]
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(i)}
              className={clsx(
                'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors',
                activeTab === i ? 'bg-white text-slate-900 shadow-card' : 'text-slate-500 hover:text-slate-700'
              )}
            >
              <Icon size={14} />
              {tab}
            </button>
          )
        })}
      </div>

      {TAB_CONTENT[activeTab]}
    </div>
  )
}
