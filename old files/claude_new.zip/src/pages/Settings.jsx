// Settings.jsx — Full-featured settings revamp (Gallabox + WATI + AiSensy + Whatchimp)
import { useState, useRef } from 'react'
import {
  Settings as SettingsIcon, User, MessageSquare, Clock, Bell, Users, Shield, Zap,
  Tag, List, Bot, Code, CreditCard, Lock, FileText, ChevronRight,
  Plus, Trash2, Edit3, Check, X, Copy, Eye, EyeOff, RefreshCw,
  Upload, Download, Search, Filter, MoreVertical, ExternalLink,
  Globe, Phone, Mail, MapPin, Calendar, AlertTriangle, Info,
  CheckCircle2, XCircle, Webhook, Key, Activity, LogOut,
  ToggleLeft, ToggleRight, Star, Hash, AlignLeft, ToggleLeft as TL,
  ChevronDown, ChevronUp, Sliders, UserPlus, Building, Image,
  Archive, Send, Repeat, Timer, Radio,
} from 'lucide-react'

// ─── Constants ────────────────────────────────────────────────────────────────

const SECTIONS = [
  { id:'general',        label:'General',           icon:SettingsIcon,group:'Account'     },
  { id:'whatsapp',       label:'WhatsApp Profile',  icon:MessageSquare,group:'Account'    },
  { id:'business_hours', label:'Business Hours',    icon:Clock,       group:'Account'     },
  { id:'notifications',  label:'Notifications',     icon:Bell,        group:'Account'     },
  { id:'team',           label:'Team Members',      icon:Users,       group:'Team'        },
  { id:'roles',          label:'Roles & Permissions',icon:Shield,     group:'Team'        },
  { id:'sla',            label:'SLA & Routing',     icon:Timer,       group:'Team'        },
  { id:'canned',         label:'Canned Responses',  icon:MessageSquare,group:'Productivity'},
  { id:'tags',           label:'Tags & Labels',     icon:Tag,         group:'Productivity'},
  { id:'custom_fields',  label:'Custom Fields',     icon:List,        group:'Productivity'},
  { id:'auto_reply',     label:'Auto Replies',      icon:Bot,         group:'Productivity'},
  { id:'api',            label:'API & Webhooks',    icon:Code,        group:'Developer'   },
  { id:'billing',        label:'Billing & Plan',    icon:CreditCard,  group:'Billing'     },
  { id:'security',       label:'Security',          icon:Lock,        group:'Security'    },
  { id:'audit',          label:'Audit Log',         icon:FileText,    group:'Security'    },
]

const GROUPS = ['Account','Team','Productivity','Developer','Billing','Security']

const TIMEZONES = ['Asia/Kolkata (IST +5:30)','Asia/Dubai (GST +4:00)','Asia/Singapore (SGT +8:00)',
  'Europe/London (GMT +0:00)','Europe/Paris (CET +1:00)','America/New_York (EST -5:00)',
  'America/Los_Angeles (PST -8:00)','Australia/Sydney (AEST +10:00)']

const LANGUAGES = ['English','Hindi','Arabic','French','Spanish','German','Portuguese','Malay','Indonesian']

const LABEL_COLORS = ['#ef4444','#f97316','#eab308','#22c55e','#06b6d4','#6366f1','#8b5cf6','#ec4899','#64748b']

// ─── Helpers ──────────────────────────────────────────────────────────────────

function Toggle({ value, onChange }) {
  return (
    <button onClick={() => onChange(!value)}
      style={{ width:44, height:24, borderRadius:12, border:'none', cursor:'pointer', position:'relative',
        background: value ? '#6366f1' : '#d1d5db', transition:'background 0.2s', padding:0, flexShrink:0 }}>
      <div style={{ position:'absolute', top:3, left: value?22:3, width:18, height:18, borderRadius:'50%',
        background:'#fff', transition:'left 0.2s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }}/>
    </button>
  )
}

function SaveBar({ onSave, saved }) {
  return (
    <div style={{ display:'flex', justifyContent:'flex-end', gap:10, paddingTop:20, marginTop:20,
      borderTop:'1px solid #e5e7eb' }}>
      {saved && <span style={{ fontSize:13, color:'#10b981', display:'flex', alignItems:'center', gap:5 }}>
        <CheckCircle2 size={14}/> Saved
      </span>}
      <button onClick={onSave} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
        padding:'8px 20px', fontWeight:600, fontSize:13, cursor:'pointer' }}>
        Save Changes
      </button>
    </div>
  )
}

function SectionHeader({ title, desc }) {
  return (
    <div style={{ marginBottom:24 }}>
      <h2 style={{ fontSize:18, fontWeight:700, color:'#111827', margin:0 }}>{title}</h2>
      {desc && <p style={{ fontSize:13, color:'#6b7280', marginTop:4 }}>{desc}</p>}
    </div>
  )
}

function Field({ label, hint, children }) {
  return (
    <div style={{ marginBottom:18 }}>
      <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>{label}</label>
      {children}
      {hint && <p style={{ fontSize:11, color:'#9ca3af', marginTop:4 }}>{hint}</p>}
    </div>
  )
}

function Input({ value, onChange, placeholder, type='text', disabled }) {
  return (
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
      disabled={disabled}
      style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px',
        fontSize:13, color:'#111827', background: disabled?'#f9fafb':'#fff',
        outline:'none', boxSizing:'border-box' }}/>
  )
}

function Select({ value, onChange, options }) {
  return (
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px',
        fontSize:13, color:'#111827', background:'#fff', outline:'none', cursor:'pointer' }}>
      {options.map(o => <option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}
    </select>
  )
}

function Textarea({ value, onChange, placeholder, rows=3 }) {
  return (
    <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows}
      style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px',
        fontSize:13, color:'#111827', outline:'none', resize:'vertical', boxSizing:'border-box' }}/>
  )
}

function Badge({ children, color='#6366f1', bg='#eef2ff' }) {
  return (
    <span style={{ fontSize:11, fontWeight:600, color, background:bg, borderRadius:20,
      padding:'2px 8px', display:'inline-flex', alignItems:'center', gap:3 }}>{children}</span>
  )
}

// ─── Section: General ─────────────────────────────────────────────────────────
function GeneralSection() {
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    name:'ChatFlow Inc.', email:'admin@chatflow.io', phone:'+91 9876543210',
    website:'https://chatflow.io', address:'Mumbai, India',
    timezone:'Asia/Kolkata (IST +5:30)', language:'English',
    dateFormat:'DD/MM/YYYY', currency:'INR', plan:'Growth',
  })
  const f = (k, v) => setForm(p=>({...p,[k]:v}))

  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  return (
    <div>
      <SectionHeader title="General Settings" desc="Manage your workspace profile, timezone, and regional preferences"/>

      {/* Logo */}
      <div style={{ display:'flex', alignItems:'center', gap:20, marginBottom:24, padding:16,
        background:'#f9fafb', borderRadius:12, border:'1px solid #e5e7eb' }}>
        <div style={{ width:72, height:72, borderRadius:16, background:'#6366f1',
          display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <Zap size={32} color="#fff"/>
        </div>
        <div style={{ flex:1 }}>
          <p style={{ fontWeight:600, fontSize:14, color:'#111827', margin:0 }}>Workspace Logo</p>
          <p style={{ fontSize:12, color:'#6b7280', marginTop:3 }}>PNG, JPG up to 2MB. Recommended 256×256px</p>
          <div style={{ display:'flex', gap:8, marginTop:10 }}>
            <button style={{ fontSize:12, fontWeight:600, color:'#6366f1', background:'#eef2ff',
              border:'1px solid #c7d2fe', borderRadius:7, padding:'5px 12px', cursor:'pointer', display:'flex', alignItems:'center', gap:5 }}>
              <Upload size={12}/> Upload Logo
            </button>
            <button style={{ fontSize:12, color:'#ef4444', background:'#fff', border:'1px solid #fecaca',
              borderRadius:7, padding:'5px 12px', cursor:'pointer' }}>Remove</button>
          </div>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        <Field label="Workspace Name"><Input value={form.name} onChange={v=>f('name',v)} placeholder="Your company name"/></Field>
        <Field label="Business Email"><Input value={form.email} onChange={v=>f('email',v)} type="email"/></Field>
        <Field label="Phone Number"><Input value={form.phone} onChange={v=>f('phone',v)}/></Field>
        <Field label="Website"><Input value={form.website} onChange={v=>f('website',v)}/></Field>
      </div>

      <Field label="Business Address">
        <Input value={form.address} onChange={v=>f('address',v)} placeholder="City, Country"/>
      </Field>

      <div style={{ borderTop:'1px solid #e5e7eb', paddingTop:20, marginTop:4, marginBottom:16 }}>
        <p style={{ fontSize:13, fontWeight:600, color:'#374151', marginBottom:14 }}>Regional Settings</p>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
          <Field label="Timezone">
            <Select value={form.timezone} onChange={v=>f('timezone',v)} options={TIMEZONES}/>
          </Field>
          <Field label="Language">
            <Select value={form.language} onChange={v=>f('language',v)} options={LANGUAGES}/>
          </Field>
          <Field label="Date Format">
            <Select value={form.dateFormat} onChange={v=>f('dateFormat',v)}
              options={[{v:'DD/MM/YYYY',l:'DD/MM/YYYY'},{v:'MM/DD/YYYY',l:'MM/DD/YYYY'},{v:'YYYY-MM-DD',l:'YYYY-MM-DD'}]}/>
          </Field>
          <Field label="Currency">
            <Select value={form.currency} onChange={v=>f('currency',v)}
              options={['INR','USD','EUR','GBP','AED','SGD','AUD']}/>
          </Field>
        </div>
      </div>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: WhatsApp Profile ────────────────────────────────────────────────
function WhatsAppSection() {
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    displayName:'ChatFlow Support', about:'We reply within minutes. Available Mon–Sat, 9am–7pm.',
    category:'COMMUNICATION', website:'https://chatflow.io', email:'support@chatflow.io',
    address:'Mumbai, MH 400001, India', description:'',
  })
  const f = (k,v)=>setForm(p=>({...p,[k]:v}))
  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  const CATEGORIES = ['AUTOMOTIVE','BEAUTY_SPA_SALON','CLOTHING_APPAREL','EDUCATION','ENTERTAINMENT',
    'EVENT_PLANNING','FINANCE','FOOD_GROCERY','GOVERNMENT','HEALTH_MEDICAL','HOTEL_LODGING',
    'NONPROFIT','PROFESSIONAL_SERVICES','SHOPPING_RETAIL','TECHNOLOGY','COMMUNICATION','OTHER']

  return (
    <div>
      <SectionHeader title="WhatsApp Business Profile" desc="Manage your public-facing WhatsApp profile visible to customers"/>

      <div style={{ display:'flex', alignItems:'center', gap:20, marginBottom:24, padding:16,
        background:'#f0fdf4', borderRadius:12, border:'1px solid #bbf7d0' }}>
        <div style={{ width:72, height:72, borderRadius:'50%', background:'#22c55e',
          display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <MessageSquare size={28} color="#fff"/>
        </div>
        <div style={{ flex:1 }}>
          <p style={{ fontWeight:700, fontSize:14, color:'#166534', margin:0 }}>Profile Photo</p>
          <p style={{ fontSize:12, color:'#4ade80', marginTop:2 }}>Visible to all WhatsApp users</p>
          <div style={{ display:'flex', gap:8, marginTop:8 }}>
            <button style={{ fontSize:12, fontWeight:600, color:'#16a34a', background:'#dcfce7',
              border:'1px solid #bbf7d0', borderRadius:7, padding:'5px 12px', cursor:'pointer', display:'flex', alignItems:'center', gap:5 }}>
              <Upload size={12}/> Change Photo
            </button>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <Badge color="#16a34a" bg="#dcfce7">✓ Connected</Badge>
          <p style={{ fontSize:11, color:'#6b7280', marginTop:4 }}>+91 98765 43210</p>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        <Field label="Display Name" hint="This appears as your WhatsApp business name">
          <Input value={form.displayName} onChange={v=>f('displayName',v)}/>
        </Field>
        <Field label="Business Category">
          <Select value={form.category} onChange={v=>f('category',v)} options={CATEGORIES}/>
        </Field>
      </div>

      <Field label="About / Status" hint="Max 139 characters. Shown on your profile.">
        <Textarea value={form.about} onChange={v=>f('about',v)} rows={2}/>
        <div style={{ textAlign:'right', fontSize:11, color: form.about.length>139?'#ef4444':'#9ca3af', marginTop:2 }}>
          {form.about.length}/139
        </div>
      </Field>

      <Field label="Business Description">
        <Textarea value={form.description} onChange={v=>f('description',v)}
          placeholder="Describe your business..." rows={3}/>
      </Field>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        <Field label="Website"><Input value={form.website} onChange={v=>f('website',v)}/></Field>
        <Field label="Email"><Input value={form.email} onChange={v=>f('email',v)} type="email"/></Field>
      </div>

      <Field label="Address"><Input value={form.address} onChange={v=>f('address',v)}/></Field>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: Business Hours ──────────────────────────────────────────────────
const DEFAULT_HOURS = {
  monday:    { enabled:true,  open:'09:00', close:'18:00' },
  tuesday:   { enabled:true,  open:'09:00', close:'18:00' },
  wednesday: { enabled:true,  open:'09:00', close:'18:00' },
  thursday:  { enabled:true,  open:'09:00', close:'18:00' },
  friday:    { enabled:true,  open:'09:00', close:'18:00' },
  saturday:  { enabled:true,  open:'10:00', close:'15:00' },
  sunday:    { enabled:false, open:'09:00', close:'18:00' },
}
const DAYS_LIST = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
const DAY_ABBR  = { monday:'Mon',tuesday:'Tue',wednesday:'Wed',thursday:'Thu',friday:'Fri',saturday:'Sat',sunday:'Sun' }

function BusinessHoursSection() {
  const [saved, setSaved] = useState(false)
  const [hours, setHours] = useState(DEFAULT_HOURS)
  const [timezone, setTimezone] = useState('Asia/Kolkata (IST +5:30)')
  const [awayMsg, setAwayMsg] = useState("We're currently offline. We'll get back to you during business hours.")
  const [holidays, setHolidays] = useState([
    { id:1, name:"Republic Day", date:"2026-01-26" },
    { id:2, name:"Independence Day", date:"2026-08-15" },
  ])
  const [newHoliday, setNewHoliday] = useState({ name:'', date:'' })

  function toggleDay(d) { setHours(h=>({...h,[d]:{...h[d],enabled:!h[d].enabled}})) }
  function setTime(d,field,val) { setHours(h=>({...h,[d]:{...h[d],[field]:val}})) }
  function addHoliday() {
    if(!newHoliday.name||!newHoliday.date) return
    setHolidays(p=>[...p,{id:Date.now(),...newHoliday}])
    setNewHoliday({name:'',date:''})
  }
  function removeHoliday(id) { setHolidays(p=>p.filter(h=>h.id!==id)) }
  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  const TIME_OPTIONS = Array.from({length:48},(_,i)=>{
    const h=Math.floor(i/2).toString().padStart(2,'0')
    const m=i%2===0?'00':'30'
    return `${h}:${m}`
  })

  return (
    <div>
      <SectionHeader title="Business Hours" desc="Set when your team is available. Away messages are sent outside these hours."/>

      <Field label="Timezone">
        <Select value={timezone} onChange={setTimezone} options={TIMEZONES}/>
      </Field>

      {/* Day schedule */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden', marginBottom:20 }}>
        {DAYS_LIST.map((day,i)=>{
          const h = hours[day]
          return (
            <div key={day} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 16px',
              background: i%2===0?'#fff':'#f9fafb', borderBottom: i<6?'1px solid #f3f4f6':'none' }}>
              <Toggle value={h.enabled} onChange={()=>toggleDay(day)}/>
              <span style={{ width:36, fontSize:13, fontWeight:600, color: h.enabled?'#111827':'#9ca3af' }}>{DAY_ABBR[day]}</span>
              {h.enabled ? (
                <div style={{ display:'flex', alignItems:'center', gap:8, flex:1 }}>
                  <select value={h.open} onChange={e=>setTime(day,'open',e.target.value)}
                    style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:'5px 10px', fontSize:13, color:'#374151', background:'#fff', cursor:'pointer' }}>
                    {TIME_OPTIONS.map(t=><option key={t}>{t}</option>)}
                  </select>
                  <span style={{ fontSize:12, color:'#9ca3af' }}>to</span>
                  <select value={h.close} onChange={e=>setTime(day,'close',e.target.value)}
                    style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:'5px 10px', fontSize:13, color:'#374151', background:'#fff', cursor:'pointer' }}>
                    {TIME_OPTIONS.map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>
              ) : (
                <span style={{ fontSize:13, color:'#9ca3af', flex:1 }}>Closed</span>
              )}
            </div>
          )
        })}
      </div>

      {/* Away message */}
      <Field label="Away Message" hint="Sent automatically when a message arrives outside business hours">
        <Textarea value={awayMsg} onChange={setAwayMsg} rows={3}/>
      </Field>

      {/* Holidays */}
      <div style={{ marginBottom:20 }}>
        <p style={{ fontSize:13, fontWeight:600, color:'#374151', marginBottom:12 }}>Holidays</p>
        {holidays.map(h=>(
          <div key={h.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 12px',
            background:'#fff', border:'1px solid #e5e7eb', borderRadius:8, marginBottom:8 }}>
            <Calendar size={14} color="#6b7280"/>
            <span style={{ flex:1, fontSize:13, color:'#111827', fontWeight:500 }}>{h.name}</span>
            <span style={{ fontSize:12, color:'#6b7280' }}>{h.date}</span>
            <button onClick={()=>removeHoliday(h.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:4 }}>
              <Trash2 size={13}/>
            </button>
          </div>
        ))}
        <div style={{ display:'flex', gap:8, marginTop:8 }}>
          <input value={newHoliday.name} onChange={e=>setNewHoliday(p=>({...p,name:e.target.value}))}
            placeholder="Holiday name"
            style={{ flex:1, border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px', fontSize:13, outline:'none' }}/>
          <input type="date" value={newHoliday.date} onChange={e=>setNewHoliday(p=>({...p,date:e.target.value}))}
            style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px', fontSize:13, outline:'none' }}/>
          <button onClick={addHoliday} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
            padding:'8px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600 }}>
            <Plus size={13}/> Add
          </button>
        </div>
      </div>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: Notifications ───────────────────────────────────────────────────
function NotificationsSection() {
  const [saved, setSaved] = useState(false)
  const [prefs, setPrefs] = useState({
    browser_new_conv:true, browser_new_msg:true, browser_assign:true, browser_mention:true,
    email_new_conv:false, email_daily_summary:true, email_weekly_report:true, email_assign:true,
    sound_enabled:true, sound_volume:'medium',
    push_enabled:false,
    sla_breach:true, sla_warning:true,
  })
  const p = (k,v)=>setPrefs(pr=>({...pr,[k]:v}))
  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  function NotifRow({ label, desc, k }) {
    return (
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 0',
        borderBottom:'1px solid #f3f4f6' }}>
        <div>
          <p style={{ fontSize:13, fontWeight:500, color:'#111827', margin:0 }}>{label}</p>
          {desc && <p style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>{desc}</p>}
        </div>
        <Toggle value={prefs[k]} onChange={v=>p(k,v)}/>
      </div>
    )
  }

  function Group({ title, children }) {
    return (
      <div style={{ marginBottom:24 }}>
        <p style={{ fontSize:13, fontWeight:700, color:'#374151', marginBottom:4, textTransform:'uppercase',
          letterSpacing:'0.05em', fontSize:11 }}>{title}</p>
        {children}
      </div>
    )
  }

  return (
    <div>
      <SectionHeader title="Notifications" desc="Control how and when you receive alerts"/>

      <Group title="Browser Notifications">
        <NotifRow label="New Conversation" desc="When a new conversation is assigned or created" k="browser_new_conv"/>
        <NotifRow label="New Message" desc="When a customer sends a message" k="browser_new_msg"/>
        <NotifRow label="Assignment" desc="When a conversation is assigned to you" k="browser_assign"/>
        <NotifRow label="Mentions" desc="When someone @mentions you in a note" k="browser_mention"/>
      </Group>

      <Group title="Email Notifications">
        <NotifRow label="New Conversation Assigned" k="email_assign"/>
        <NotifRow label="Daily Summary" desc="End-of-day conversation summary" k="email_daily_summary"/>
        <NotifRow label="Weekly Report" desc="Sent every Monday morning" k="email_weekly_report"/>
        <NotifRow label="New Conversation" k="email_new_conv"/>
      </Group>

      <Group title="Sound">
        <NotifRow label="Enable notification sounds" k="sound_enabled"/>
        {prefs.sound_enabled && (
          <Field label="Volume">
            <Select value={prefs.sound_volume} onChange={v=>p('sound_volume',v)}
              options={['low','medium','high']}/>
          </Field>
        )}
      </Group>

      <Group title="SLA Alerts">
        <NotifRow label="SLA Breach Alert" desc="When a conversation misses SLA" k="sla_breach"/>
        <NotifRow label="SLA Warning (30 min before)" k="sla_warning"/>
      </Group>

      <Group title="Push Notifications">
        <NotifRow label="Mobile Push Notifications" desc="Requires mobile app" k="push_enabled"/>
      </Group>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: Team Members ────────────────────────────────────────────────────
const MOCK_MEMBERS = [
  { id:1, name:'Rahul Mehta',    email:'rahul@chatflow.io',   role:'Admin',    status:'active',   avatar:'RM', lastSeen:'Now'        },
  { id:2, name:'Priya Sharma',   email:'priya@chatflow.io',   role:'Agent',    status:'active',   avatar:'PS', lastSeen:'5 min ago'  },
  { id:3, name:'Arjun Patel',    email:'arjun@chatflow.io',   role:'Agent',    status:'away',     avatar:'AP', lastSeen:'2 hr ago'   },
  { id:4, name:'Sneha Gupta',    email:'sneha@chatflow.io',   role:'Supervisor',status:'active',  avatar:'SG', lastSeen:'1 min ago'  },
  { id:5, name:'Vikram Singh',   email:'vikram@chatflow.io',  role:'Agent',    status:'offline',  avatar:'VS', lastSeen:'Yesterday'  },
  { id:6, name:'Anjali Nair',    email:'anjali@chatflow.io',  role:'Viewer',   status:'active',   avatar:'AN', lastSeen:'Just now'   },
]

const STATUS_COLOR = { active:'#22c55e', away:'#f59e0b', offline:'#9ca3af' }
const ROLE_BADGE = { Admin:{c:'#6366f1',bg:'#eef2ff'}, Agent:{c:'#0ea5e9',bg:'#e0f2fe'},
  Supervisor:{c:'#8b5cf6',bg:'#f5f3ff'}, Viewer:{c:'#6b7280',bg:'#f3f4f6'} }

function TeamSection() {
  const [members, setMembers] = useState(MOCK_MEMBERS)
  const [showInvite, setShowInvite] = useState(false)
  const [invite, setInvite] = useState({ email:'', role:'Agent' })
  const [search, setSearch] = useState('')

  const filtered = members.filter(m=>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.email.toLowerCase().includes(search.toLowerCase())
  )

  function sendInvite() {
    if(!invite.email) return
    const newM = { id:Date.now(), name:invite.email.split('@')[0], email:invite.email,
      role:invite.role, status:'offline', avatar:invite.email[0].toUpperCase(), lastSeen:'Invited' }
    setMembers(p=>[...p,newM])
    setInvite({email:'',role:'Agent'}); setShowInvite(false)
  }

  function removeMember(id) { setMembers(p=>p.filter(m=>m.id!==id)) }
  function changeRole(id, role) { setMembers(p=>p.map(m=>m.id===id?{...m,role}:m)) }

  return (
    <div>
      <SectionHeader title="Team Members" desc="Manage who has access to your workspace"/>

      {/* Stats row */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        {[
          { label:'Total Members', value:members.length, color:'#6366f1' },
          { label:'Active Now', value:members.filter(m=>m.status==='active').length, color:'#22c55e' },
          { label:'Agents', value:members.filter(m=>m.role==='Agent').length, color:'#0ea5e9' },
          { label:'Admins', value:members.filter(m=>m.role==='Admin').length, color:'#f59e0b' },
        ].map(s=>(
          <div key={s.label} style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10, padding:'12px 14px' }}>
            <p style={{ fontSize:11, color:'#6b7280', margin:0 }}>{s.label}</p>
            <p style={{ fontSize:22, fontWeight:700, color:s.color, margin:'4px 0 0' }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Top bar */}
      <div style={{ display:'flex', gap:10, marginBottom:14 }}>
        <div style={{ flex:1, position:'relative' }}>
          <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }}/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search members..."
            style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px 8px 32px',
              fontSize:13, outline:'none', boxSizing:'border-box' }}/>
        </div>
        <button onClick={()=>setShowInvite(true)} style={{ background:'#6366f1', color:'#fff', border:'none',
          borderRadius:8, padding:'8px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600 }}>
          <UserPlus size={14}/> Invite Member
        </button>
      </div>

      {/* Invite form */}
      {showInvite && (
        <div style={{ background:'#f0f9ff', border:'1px solid #bae6fd', borderRadius:10, padding:16, marginBottom:16 }}>
          <p style={{ fontSize:13, fontWeight:600, color:'#0369a1', marginBottom:12 }}>Invite New Member</p>
          <div style={{ display:'flex', gap:10 }}>
            <input value={invite.email} onChange={e=>setInvite(p=>({...p,email:e.target.value}))}
              placeholder="colleague@company.com" type="email"
              style={{ flex:1, border:'1px solid #bae6fd', borderRadius:8, padding:'8px 12px', fontSize:13, outline:'none' }}/>
            <select value={invite.role} onChange={e=>setInvite(p=>({...p,role:e.target.value}))}
              style={{ border:'1px solid #bae6fd', borderRadius:8, padding:'8px 12px', fontSize:13, color:'#374151', background:'#fff' }}>
              {['Admin','Supervisor','Agent','Viewer'].map(r=><option key={r}>{r}</option>)}
            </select>
            <button onClick={sendInvite} style={{ background:'#0ea5e9', color:'#fff', border:'none',
              borderRadius:8, padding:'8px 14px', cursor:'pointer', fontSize:13, fontWeight:600 }}>
              Send Invite
            </button>
            <button onClick={()=>setShowInvite(false)} style={{ background:'none', border:'1px solid #bae6fd',
              borderRadius:8, padding:'8px', cursor:'pointer', color:'#0369a1' }}>
              <X size={14}/>
            </button>
          </div>
        </div>
      )}

      {/* Members table */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#f9fafb', borderBottom:'1px solid #e5e7eb' }}>
              {['Member','Role','Status','Last Seen','Actions'].map(h=>(
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700,
                  color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((m,i)=>(
              <tr key={m.id} style={{ borderBottom: i<filtered.length-1?'1px solid #f3f4f6':'none',
                background: i%2===0?'#fff':'#fafafa' }}>
                <td style={{ padding:'12px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <div style={{ width:34, height:34, borderRadius:'50%', background:'#6366f1',
                      display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:700, color:'#fff', flexShrink:0 }}>
                      {m.avatar}
                    </div>
                    <div>
                      <p style={{ fontSize:13, fontWeight:600, color:'#111827', margin:0 }}>{m.name}</p>
                      <p style={{ fontSize:11, color:'#9ca3af', margin:0 }}>{m.email}</p>
                    </div>
                  </div>
                </td>
                <td style={{ padding:'12px 14px' }}>
                  <select value={m.role} onChange={e=>changeRole(m.id,e.target.value)}
                    style={{ border:'none', background:'transparent', fontSize:13, cursor:'pointer',
                      color: ROLE_BADGE[m.role]?.c||'#374151', fontWeight:600 }}>
                    {['Admin','Supervisor','Agent','Viewer'].map(r=><option key={r}>{r}</option>)}
                  </select>
                </td>
                <td style={{ padding:'12px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                    <div style={{ width:7, height:7, borderRadius:'50%', background:STATUS_COLOR[m.status] }}/>
                    <span style={{ fontSize:12, color:'#374151', textTransform:'capitalize' }}>{m.status}</span>
                  </div>
                </td>
                <td style={{ padding:'12px 14px', fontSize:12, color:'#6b7280' }}>{m.lastSeen}</td>
                <td style={{ padding:'12px 14px' }}>
                  <button onClick={()=>removeMember(m.id)}
                    style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:4 }}>
                    <Trash2 size={14}/>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Section: Roles & Permissions ────────────────────────────────────────────
const PERMISSIONS = [
  { group:'Conversations', items:['View conversations','Reply to conversations','Assign conversations','Delete conversations','Export conversations'] },
  { group:'Contacts', items:['View contacts','Create contacts','Edit contacts','Delete contacts','Import/Export contacts'] },
  { group:'Broadcasts', items:['View broadcasts','Create broadcasts','Send broadcasts','Delete broadcasts'] },
  { group:'Templates', items:['View templates','Create templates','Submit for approval','Delete templates'] },
  { group:'Flows / Automation', items:['View flows','Create/Edit flows','Publish flows','Delete flows'] },
  { group:'Analytics', items:['View reports','Export reports'] },
  { group:'Settings', items:['View settings','Edit workspace settings','Manage team members','Manage billing'] },
]

const ROLES_DEF = {
  Admin:      { color:'#6366f1', desc:'Full access to all features and settings' },
  Supervisor: { color:'#8b5cf6', desc:'Team management + all agent capabilities' },
  Agent:      { color:'#0ea5e9', desc:'Handle conversations and contacts' },
  Viewer:     { color:'#6b7280', desc:'Read-only access to conversations and reports' },
}

const DEFAULT_PERMS = {
  Admin:      { all: true },
  Supervisor: { 'View conversations':1,'Reply to conversations':1,'Assign conversations':1,'Delete conversations':1,'Export conversations':1,'View contacts':1,'Create contacts':1,'Edit contacts':1,'Delete contacts':1,'Import/Export contacts':1,'View broadcasts':1,'Create broadcasts':1,'Send broadcasts':1,'View templates':1,'Create templates':1,'Submit for approval':1,'View flows':1,'Create/Edit flows':1,'Publish flows':1,'View reports':1,'Export reports':1,'View settings':1,'Manage team members':1 },
  Agent:      { 'View conversations':1,'Reply to conversations':1,'Assign conversations':1,'View contacts':1,'Create contacts':1,'Edit contacts':1,'View broadcasts':1,'View templates':1,'View flows':1,'View reports':1 },
  Viewer:     { 'View conversations':1,'View contacts':1,'View broadcasts':1,'View templates':1,'View flows':1,'View reports':1 },
}

function RolesSection() {
  const [activeRole, setActiveRole] = useState('Agent')
  const [perms, setPerms] = useState(DEFAULT_PERMS)
  const [saved, setSaved] = useState(false)
  function toggle(role, perm) {
    setPerms(p=>({ ...p, [role]:{ ...p[role], [perm]: p[role][perm]?0:1 } }))
  }
  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }
  const isAdmin = activeRole==='Admin'

  return (
    <div>
      <SectionHeader title="Roles & Permissions" desc="Define what each role can do in your workspace"/>

      {/* Role tabs */}
      <div style={{ display:'flex', gap:8, marginBottom:20 }}>
        {Object.keys(ROLES_DEF).map(r=>(
          <button key={r} onClick={()=>setActiveRole(r)}
            style={{ border:`2px solid ${activeRole===r?ROLES_DEF[r].color:'#e5e7eb'}`,
              borderRadius:10, padding:'8px 16px', cursor:'pointer', background: activeRole===r?ROLES_DEF[r].color+'11':'#fff',
              display:'flex', flexDirection:'column', alignItems:'center', gap:3, minWidth:110 }}>
            <span style={{ fontSize:13, fontWeight:700, color: activeRole===r?ROLES_DEF[r].color:'#374151' }}>{r}</span>
            <span style={{ fontSize:10, color:'#9ca3af', textAlign:'center' }}>{ROLES_DEF[r].desc}</span>
          </button>
        ))}
      </div>

      {isAdmin ? (
        <div style={{ padding:20, background:'#f0fdf4', border:'1px solid #bbf7d0', borderRadius:10,
          display:'flex', alignItems:'center', gap:10 }}>
          <CheckCircle2 size={20} color="#22c55e"/>
          <p style={{ fontSize:13, color:'#166534', margin:0 }}>Admins have full access to all features. Permissions cannot be modified.</p>
        </div>
      ) : (
        <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
          {PERMISSIONS.map((g, gi)=>(
            <div key={g.group}>
              <div style={{ background:'#f9fafb', padding:'8px 16px', borderTop: gi>0?'1px solid #e5e7eb':'none' }}>
                <span style={{ fontSize:12, fontWeight:700, color:'#374151', textTransform:'uppercase', letterSpacing:'0.05em' }}>{g.group}</span>
              </div>
              {g.items.map(item=>(
                <div key={item} style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                  padding:'10px 16px', borderTop:'1px solid #f3f4f6' }}>
                  <span style={{ fontSize:13, color:'#374151' }}>{item}</span>
                  <Toggle value={!!(perms[activeRole]?.[item])} onChange={()=>toggle(activeRole,item)}/>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {!isAdmin && <SaveBar onSave={save} saved={saved}/>}
    </div>
  )
}

// ─── Section: SLA & Routing ───────────────────────────────────────────────────
function SLASection() {
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    frt: '5', frtUnit:'minutes',
    tat: '24', tatUnit:'hours',
    assignment:'round_robin', maxConvsPerAgent:'20', autoReassign:true,
    slaEnabled:true, slaBreachNotify:true, slaPauseOnHoliday:true,
  })
  const f = (k,v)=>setForm(p=>({...p,[k]:v}))
  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  function Row({ label, desc, children }) {
    return (
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', padding:'14px 0',
        borderBottom:'1px solid #f3f4f6', gap:20 }}>
        <div style={{ flex:1 }}>
          <p style={{ fontSize:13, fontWeight:600, color:'#111827', margin:0 }}>{label}</p>
          {desc && <p style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>{desc}</p>}
        </div>
        <div style={{ flexShrink:0 }}>{children}</div>
      </div>
    )
  }

  return (
    <div>
      <SectionHeader title="SLA & Routing" desc="Configure response time targets and conversation assignment rules"/>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16,
        padding:'12px 16px', background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10 }}>
        <span style={{ fontSize:13, fontWeight:600, color:'#374151' }}>Enable SLA Tracking</span>
        <Toggle value={form.slaEnabled} onChange={v=>f('slaEnabled',v)}/>
      </div>

      {form.slaEnabled && (
        <div style={{ marginBottom:20 }}>
          <p style={{ fontSize:12, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:12 }}>Response Targets</p>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
            <div style={{ border:'1px solid #e5e7eb', borderRadius:10, padding:14 }}>
              <p style={{ fontSize:12, fontWeight:600, color:'#6b7280', marginBottom:10 }}>First Response Time (FRT)</p>
              <div style={{ display:'flex', gap:8 }}>
                <input value={form.frt} onChange={e=>f('frt',e.target.value)} type="number" min="1"
                  style={{ flex:1, border:'1px solid #e5e7eb', borderRadius:7, padding:'7px 10px', fontSize:13, outline:'none' }}/>
                <select value={form.frtUnit} onChange={e=>f('frtUnit',e.target.value)}
                  style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:'7px 10px', fontSize:13, background:'#fff' }}>
                  <option value="minutes">Minutes</option>
                  <option value="hours">Hours</option>
                </select>
              </div>
            </div>
            <div style={{ border:'1px solid #e5e7eb', borderRadius:10, padding:14 }}>
              <p style={{ fontSize:12, fontWeight:600, color:'#6b7280', marginBottom:10 }}>Total Resolution Time (TAT)</p>
              <div style={{ display:'flex', gap:8 }}>
                <input value={form.tat} onChange={e=>f('tat',e.target.value)} type="number" min="1"
                  style={{ flex:1, border:'1px solid #e5e7eb', borderRadius:7, padding:'7px 10px', fontSize:13, outline:'none' }}/>
                <select value={form.tatUnit} onChange={e=>f('tatUnit',e.target.value)}
                  style={{ border:'1px solid #e5e7eb', borderRadius:7, padding:'7px 10px', fontSize:13, background:'#fff' }}>
                  <option value="hours">Hours</option>
                  <option value="days">Days</option>
                </select>
              </div>
            </div>
          </div>

          <Row label="SLA Breach Notification" desc="Alert agents when SLA is about to be breached">
            <Toggle value={form.slaBreachNotify} onChange={v=>f('slaBreachNotify',v)}/>
          </Row>
          <Row label="Pause SLA on Holidays" desc="Don't count holiday hours toward SLA">
            <Toggle value={form.slaPauseOnHoliday} onChange={v=>f('slaPauseOnHoliday',v)}/>
          </Row>
        </div>
      )}

      <p style={{ fontSize:12, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:12 }}>Conversation Routing</p>

      <Field label="Assignment Mode" hint="How new conversations are distributed to agents">
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
          {[
            { v:'round_robin',   l:'Round Robin',    desc:'Evenly distributed' },
            { v:'load_balanced', l:'Load Balanced',  desc:'Least conversations' },
            { v:'manual',        l:'Manual',         desc:'Assign yourself' },
          ].map(opt=>(
            <button key={opt.v} onClick={()=>f('assignment',opt.v)}
              style={{ border:`2px solid ${form.assignment===opt.v?'#6366f1':'#e5e7eb'}`,
                borderRadius:10, padding:'10px 12px', cursor:'pointer', textAlign:'center',
                background: form.assignment===opt.v?'#eef2ff':'#fff' }}>
              <p style={{ fontSize:13, fontWeight:600, color: form.assignment===opt.v?'#6366f1':'#374151', margin:0 }}>{opt.l}</p>
              <p style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>{opt.desc}</p>
            </button>
          ))}
        </div>
      </Field>

      <Row label="Max Conversations per Agent" desc="Limit simultaneous open conversations">
        <input value={form.maxConvsPerAgent} onChange={e=>f('maxConvsPerAgent',e.target.value)} type="number" min="1" max="999"
          style={{ width:70, border:'1px solid #e5e7eb', borderRadius:7, padding:'7px 10px', fontSize:13, outline:'none', textAlign:'center' }}/>
      </Row>
      <Row label="Auto-Reassign on Away" desc="Redistribute conversations when agent goes offline">
        <Toggle value={form.autoReassign} onChange={v=>f('autoReassign',v)}/>
      </Row>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: Canned Responses ────────────────────────────────────────────────
const MOCK_CANNED = [
  { id:1, shortcut:'/hi',       name:'Greeting',         message:'Hello! 👋 Welcome to ChatFlow support. How can I help you today?',               category:'Greetings' },
  { id:2, shortcut:'/thanks',   name:'Thank You',        message:'Thank you for reaching out! Your query has been noted. 🙏',                       category:'Greetings' },
  { id:3, shortcut:'/wait',     name:'Please Wait',      message:'Please give me a moment to check on this for you. I\'ll be right back! ⏳',      category:'Support'   },
  { id:4, shortcut:'/order',    name:'Order Status',     message:'To check your order status, please share your Order ID and we\'ll look into it.', category:'Sales'     },
  { id:5, shortcut:'/resolve',  name:'Issue Resolved',   message:'Your issue has been resolved. If you face any further trouble, feel free to reach out. Have a great day! ✅', category:'Support' },
  { id:6, shortcut:'/pricing',  name:'Pricing Info',     message:'Our pricing plans start at ₹999/month. You can view the complete plans at chatflow.io/pricing 💰', category:'Sales' },
]

function CannedSection() {
  const [items, setItems] = useState(MOCK_CANNED)
  const [search, setSearch] = useState('')
  const [editId, setEditId] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ shortcut:'', name:'', message:'', category:'Support' })
  const ff = (k,v)=>setForm(p=>({...p,[k]:v}))

  const categories = [...new Set(items.map(i=>i.category))]
  const filtered = items.filter(i=> !search ||
    i.name.toLowerCase().includes(search.toLowerCase()) ||
    i.shortcut.toLowerCase().includes(search.toLowerCase()) ||
    i.message.toLowerCase().includes(search.toLowerCase())
  )

  function save() {
    if(!form.shortcut||!form.message) return
    if(editId) {
      setItems(p=>p.map(i=>i.id===editId?{...i,...form}:i))
      setEditId(null)
    } else {
      setItems(p=>[...p,{id:Date.now(),...form}])
    }
    setForm({shortcut:'',name:'',message:'',category:'Support'}); setShowForm(false)
  }

  function startEdit(item) {
    setForm({shortcut:item.shortcut,name:item.name,message:item.message,category:item.category})
    setEditId(item.id); setShowForm(true)
  }

  function remove(id) { setItems(p=>p.filter(i=>i.id!==id)) }

  return (
    <div>
      <SectionHeader title="Canned Responses" desc="Save and reuse frequent reply templates. Type the shortcut in chat to insert."/>

      <div style={{ display:'flex', gap:10, marginBottom:16 }}>
        <div style={{ flex:1, position:'relative' }}>
          <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }}/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by name, shortcut, or content..."
            style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px 8px 32px', fontSize:13, outline:'none', boxSizing:'border-box' }}/>
        </div>
        <button onClick={()=>{setShowForm(true);setEditId(null);setForm({shortcut:'',name:'',message:'',category:'Support'})}}
          style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
            padding:'8px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600 }}>
          <Plus size={14}/> New Response
        </button>
      </div>

      {showForm && (
        <div style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:16 }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#374151', marginBottom:14 }}>
            {editId ? 'Edit Response' : 'New Canned Response'}
          </p>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12, marginBottom:12 }}>
            <Field label="Shortcut (e.g. /hi)">
              <Input value={form.shortcut} onChange={v=>ff('shortcut',v)} placeholder="/shortcut"/>
            </Field>
            <Field label="Name">
              <Input value={form.name} onChange={v=>ff('name',v)} placeholder="Response name"/>
            </Field>
            <Field label="Category">
              <input value={form.category} onChange={e=>ff('category',e.target.value)} list="cat-list"
                style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px', fontSize:13, outline:'none', boxSizing:'border-box' }}/>
              <datalist id="cat-list">{categories.map(c=><option key={c} value={c}/>)}</datalist>
            </Field>
          </div>
          <Field label="Message">
            <Textarea value={form.message} onChange={v=>ff('message',v)} placeholder="Type your response..." rows={4}/>
          </Field>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={save} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
              padding:'8px 18px', cursor:'pointer', fontSize:13, fontWeight:600 }}>
              {editId?'Update':'Save'} Response
            </button>
            <button onClick={()=>{setShowForm(false);setEditId(null)}}
              style={{ background:'#fff', color:'#374151', border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 14px', cursor:'pointer', fontSize:13 }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
        {filtered.map(item=>(
          <div key={item.id} style={{ display:'flex', alignItems:'flex-start', gap:12, padding:'12px 14px',
            background:'#fff', border:'1px solid #e5e7eb', borderRadius:10 }}>
            <div style={{ background:'#eef2ff', color:'#6366f1', borderRadius:7, padding:'3px 9px',
              fontSize:12, fontWeight:700, fontFamily:'monospace', flexShrink:0, marginTop:1 }}>
              {item.shortcut}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                <span style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{item.name}</span>
                <Badge color="#6b7280" bg="#f3f4f6">{item.category}</Badge>
              </div>
              <p style={{ fontSize:12, color:'#6b7280', margin:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {item.message}
              </p>
            </div>
            <div style={{ display:'flex', gap:4, flexShrink:0 }}>
              <button onClick={()=>startEdit(item)} style={{ border:'none', background:'none', cursor:'pointer', color:'#6b7280', padding:4 }}>
                <Edit3 size={14}/>
              </button>
              <button onClick={()=>remove(item.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:4 }}>
                <Trash2 size={14}/>
              </button>
            </div>
          </div>
        ))}
        {filtered.length===0 && (
          <div style={{ textAlign:'center', padding:'30px 0', color:'#9ca3af', fontSize:13 }}>No canned responses found</div>
        )}
      </div>
    </div>
  )
}

// ─── Section: Tags & Labels ───────────────────────────────────────────────────
const MOCK_TAGS = [
  { id:1, name:'VIP',       color:'#f59e0b', type:'contact',      count:34 },
  { id:2, name:'Hot Lead',  color:'#ef4444', type:'conversation', count:12 },
  { id:3, name:'Support',   color:'#3b82f6', type:'conversation', count:87 },
  { id:4, name:'Refund',    color:'#8b5cf6', type:'conversation', count:9  },
  { id:5, name:'Premium',   color:'#6366f1', type:'contact',      count:23 },
  { id:6, name:'Follow Up', color:'#22c55e', type:'conversation', count:41 },
  { id:7, name:'Escalated', color:'#ef4444', type:'conversation', count:6  },
  { id:8, name:'Newsletter',color:'#06b6d4', type:'contact',      count:156},
]

function TagsSection() {
  const [tags, setTags] = useState(MOCK_TAGS)
  const [filter, setFilter] = useState('all')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name:'', color:LABEL_COLORS[0], type:'conversation' })
  const ff = (k,v)=>setForm(p=>({...p,[k]:v}))

  const filtered = tags.filter(t=> filter==='all' || t.type===filter)

  function addTag() {
    if(!form.name.trim()) return
    setTags(p=>[...p,{id:Date.now(),count:0,...form}])
    setForm({name:'',color:LABEL_COLORS[0],type:'conversation'}); setShowForm(false)
  }

  return (
    <div>
      <SectionHeader title="Tags & Labels" desc="Organize conversations and contacts with color-coded labels"/>

      <div style={{ display:'flex', gap:8, marginBottom:16 }}>
        <div style={{ display:'flex', gap:4, flex:1 }}>
          {['all','conversation','contact'].map(t=>(
            <button key={t} onClick={()=>setFilter(t)}
              style={{ border:`1px solid ${filter===t?'#6366f1':'#e5e7eb'}`, borderRadius:8, padding:'6px 14px',
                cursor:'pointer', background: filter===t?'#eef2ff':'#fff',
                color: filter===t?'#6366f1':'#374151', fontSize:13, fontWeight:500, textTransform:'capitalize' }}>
              {t==='all'?'All':t+'s'}
            </button>
          ))}
        </div>
        <button onClick={()=>setShowForm(true)}
          style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
            padding:'6px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600 }}>
          <Plus size={14}/> New Tag
        </button>
      </div>

      {showForm && (
        <div style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10, padding:14, marginBottom:14 }}>
          <div style={{ display:'flex', alignItems:'flex-end', gap:12 }}>
            <Field label="Tag Name" style={{flex:1}}>
              <Input value={form.name} onChange={v=>ff('name',v)} placeholder="Enter tag name"/>
            </Field>
            <div style={{ marginBottom:18 }}>
              <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>Color</label>
              <div style={{ display:'flex', gap:6 }}>
                {LABEL_COLORS.map(c=>(
                  <button key={c} onClick={()=>ff('color',c)}
                    style={{ width:24, height:24, borderRadius:'50%', background:c, border: form.color===c?'3px solid #111':'2px solid transparent', cursor:'pointer', flexShrink:0 }}/>
                ))}
              </div>
            </div>
            <div style={{ marginBottom:18 }}>
              <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>Type</label>
              <select value={form.type} onChange={e=>ff('type',e.target.value)}
                style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px', fontSize:13, background:'#fff' }}>
                <option value="conversation">Conversation</option>
                <option value="contact">Contact</option>
              </select>
            </div>
            <div style={{ marginBottom:18, display:'flex', gap:8 }}>
              <button onClick={addTag} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
                padding:'9px 16px', cursor:'pointer', fontSize:13, fontWeight:600 }}>Add</button>
              <button onClick={()=>setShowForm(false)} style={{ background:'#fff', color:'#374151',
                border:'1px solid #e5e7eb', borderRadius:8, padding:'9px 12px', cursor:'pointer' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:10 }}>
        {filtered.map(tag=>(
          <div key={tag.id} style={{ border:'1px solid #e5e7eb', borderRadius:10, padding:'12px 14px',
            background:'#fff', display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:12, height:12, borderRadius:'50%', background:tag.color, flexShrink:0 }}/>
            <div style={{ flex:1, minWidth:0 }}>
              <p style={{ fontSize:13, fontWeight:600, color:'#111827', margin:0, truncate:true }}>{tag.name}</p>
              <p style={{ fontSize:11, color:'#9ca3af', margin:0, textTransform:'capitalize' }}>{tag.type} · {tag.count}</p>
            </div>
            <button onClick={()=>setTags(p=>p.filter(t=>t.id!==tag.id))}
              style={{ border:'none', background:'none', cursor:'pointer', color:'#d1d5db', padding:2 }}>
              <X size={13}/>
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Section: Custom Fields ───────────────────────────────────────────────────
const FIELD_TYPES = [
  {v:'text',     l:'Text',     icon:'Aa' },
  {v:'number',   l:'Number',   icon:'#'  },
  {v:'date',     l:'Date',     icon:'📅' },
  {v:'boolean',  l:'Yes/No',   icon:'✓'  },
  {v:'dropdown', l:'Dropdown', icon:'▾'  },
  {v:'url',      l:'URL',      icon:'🔗' },
  {v:'phone',    l:'Phone',    icon:'📱' },
  {v:'email',    l:'Email',    icon:'@'  },
]

const MOCK_FIELDS = {
  contact:[
    { id:1, name:'Company Size', key:'company_size', type:'dropdown', required:false, options:['1-10','11-50','51-200','201+'] },
    { id:2, name:'Industry',     key:'industry',     type:'text',     required:false },
    { id:3, name:'Lead Score',   key:'lead_score',   type:'number',   required:false },
    { id:4, name:'Date of Birth',key:'dob',          type:'date',     required:false },
    { id:5, name:'Newsletter',   key:'newsletter',   type:'boolean',  required:false },
  ],
  conversation:[
    { id:6, name:'Priority',    key:'priority',     type:'dropdown', required:false, options:['Low','Medium','High','Urgent'] },
    { id:7, name:'Order ID',    key:'order_id',     type:'text',     required:false },
    { id:8, name:'Product SKU', key:'product_sku',  type:'text',     required:false },
  ],
}

function CustomFieldsSection() {
  const [tab, setTab] = useState('contact')
  const [fields, setFields] = useState(MOCK_FIELDS)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name:'', key:'', type:'text', required:false, options:'' })
  const ff = (k,v)=>setForm(p=>({...p,[k]:v}))

  function autoKey(name) { return name.toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9_]/g,'') }

  function addField() {
    if(!form.name) return
    const newField = { id:Date.now(), ...form, key:form.key||autoKey(form.name),
      options: form.type==='dropdown' ? form.options.split('\n').filter(Boolean) : undefined }
    setFields(p=>({...p,[tab]:[...p[tab],newField]}))
    setForm({name:'',key:'',type:'text',required:false,options:''}); setShowForm(false)
  }

  function removeField(id) { setFields(p=>({...p,[tab]:p[tab].filter(f=>f.id!==id)})) }

  const TYPE_COLOR = {text:'#6366f1',number:'#f59e0b',date:'#3b82f6',boolean:'#22c55e',dropdown:'#8b5cf6',url:'#06b6d4',phone:'#10b981',email:'#ef4444'}

  return (
    <div>
      <SectionHeader title="Custom Fields" desc="Add extra data fields to contacts and conversations"/>

      <div style={{ display:'flex', gap:4, marginBottom:16 }}>
        {['contact','conversation'].map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{ border:`1px solid ${tab===t?'#6366f1':'#e5e7eb'}`, borderRadius:8, padding:'7px 16px',
              cursor:'pointer', background: tab===t?'#eef2ff':'#fff',
              color: tab===t?'#6366f1':'#374151', fontSize:13, fontWeight:500, textTransform:'capitalize' }}>
            {t} Fields ({fields[t].length})
          </button>
        ))}
        <button onClick={()=>setShowForm(true)}
          style={{ marginLeft:'auto', background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
            padding:'7px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:6, fontSize:13, fontWeight:600 }}>
          <Plus size={14}/> Add Field
        </button>
      </div>

      {showForm && (
        <div style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10, padding:16, marginBottom:16 }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12, marginBottom:12 }}>
            <Field label="Field Name">
              <Input value={form.name} onChange={v=>{ff('name',v);if(!form.key)ff('key',autoKey(v))}} placeholder="e.g. Company Size"/>
            </Field>
            <Field label="Field Key" hint="Auto-generated, used in API">
              <Input value={form.key} onChange={v=>ff('key',v)} placeholder="company_size"/>
            </Field>
            <Field label="Field Type">
              <Select value={form.type} onChange={v=>ff('type',v)} options={FIELD_TYPES}/>
            </Field>
          </div>
          {form.type==='dropdown' && (
            <Field label="Options (one per line)">
              <Textarea value={form.options} onChange={v=>ff('options',v)} placeholder={"Option 1\nOption 2\nOption 3"} rows={4}/>
            </Field>
          )}
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
            <Toggle value={form.required} onChange={v=>ff('required',v)}/>
            <span style={{ fontSize:13, color:'#374151' }}>Required field</span>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={addField} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
              padding:'8px 18px', cursor:'pointer', fontSize:13, fontWeight:600 }}>Add Field</button>
            <button onClick={()=>setShowForm(false)} style={{ background:'#fff', color:'#374151',
              border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 14px', cursor:'pointer', fontSize:13 }}>Cancel</button>
          </div>
        </div>
      )}

      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
        <div style={{ background:'#f9fafb', padding:'8px 14px', display:'grid',
          gridTemplateColumns:'2fr 1.5fr 1fr 80px 60px', gap:12, borderBottom:'1px solid #e5e7eb' }}>
          {['Field Name','API Key','Type','Required',''].map(h=>(
            <span key={h} style={{ fontSize:11, fontWeight:700, color:'#6b7280', textTransform:'uppercase' }}>{h}</span>
          ))}
        </div>
        {fields[tab].map((f,i)=>(
          <div key={f.id} style={{ display:'grid', gridTemplateColumns:'2fr 1.5fr 1fr 80px 60px', gap:12,
            padding:'11px 14px', alignItems:'center',
            borderBottom: i<fields[tab].length-1?'1px solid #f3f4f6':'none', background: i%2===0?'#fff':'#fafafa' }}>
            <span style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{f.name}</span>
            <code style={{ fontSize:11, color:'#6b7280', background:'#f3f4f6', padding:'2px 7px', borderRadius:5 }}>{f.key}</code>
            <span style={{ display:'flex', alignItems:'center', gap:5 }}>
              <span style={{ width:8, height:8, borderRadius:'50%', background:TYPE_COLOR[f.type]||'#9ca3af', display:'inline-block' }}/>
              <span style={{ fontSize:12, color:'#374151', textTransform:'capitalize' }}>{f.type}</span>
            </span>
            <span style={{ fontSize:12, color: f.required?'#ef4444':'#9ca3af' }}>{f.required?'Yes':'No'}</span>
            <button onClick={()=>removeField(f.id)} style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:4 }}>
              <Trash2 size={13}/>
            </button>
          </div>
        ))}
        {fields[tab].length===0 && (
          <div style={{ textAlign:'center', padding:'24px 0', color:'#9ca3af', fontSize:13 }}>No custom fields yet</div>
        )}
      </div>
    </div>
  )
}

// ─── Section: Auto Replies ────────────────────────────────────────────────────
function AutoReplySection() {
  const [saved, setSaved] = useState(false)
  const [welcome, setWelcome] = useState({ enabled:true, message:"Hi {{contact.name}}! 👋 Thanks for messaging us. We'll get back to you shortly." })
  const [away, setAway] = useState({ enabled:true, message:"Hi there! We're currently away. Our business hours are Mon–Sat, 9am–7pm IST. We'll reply soon! 🙏" })
  const [oos, setOos] = useState({ enabled:false, message:"Thanks for reaching out! Our team is currently unavailable. We'll respond during the next business day." })
  const [keywords, setKeywords] = useState([
    { id:1, trigger:'price|pricing|cost|charges', response:'Our plans start at ₹999/month. Visit chatflow.io/pricing for details!', matchType:'any' },
    { id:2, trigger:'refund|money back|cancel',   response:"We're sorry to hear that! Please share your order ID and we'll process the refund within 3-5 days.", matchType:'any' },
    { id:3, trigger:'hello|hi|hey|hola',          response:"Hello! 👋 Welcome to ChatFlow. How can I assist you today?", matchType:'any' },
  ])
  const [kForm, setKForm] = useState({ trigger:'', response:'', matchType:'any' })
  const [showKForm, setShowKForm] = useState(false)
  const kf = (k,v)=>setKForm(p=>({...p,[k]:v}))

  function addKeyword() {
    if(!kForm.trigger||!kForm.response) return
    setKeywords(p=>[...p,{id:Date.now(),...kForm}])
    setKForm({trigger:'',response:'',matchType:'any'}); setShowKForm(false)
  }

  function save() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  function ReplyCard({ title, desc, state, setState }) {
    return (
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:14 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
          <div>
            <p style={{ fontSize:14, fontWeight:700, color:'#111827', margin:0 }}>{title}</p>
            <p style={{ fontSize:12, color:'#9ca3af', marginTop:2 }}>{desc}</p>
          </div>
          <Toggle value={state.enabled} onChange={v=>setState(p=>({...p,enabled:v}))}/>
        </div>
        {state.enabled && (
          <Textarea value={state.message} onChange={v=>setState(p=>({...p,message:v}))} rows={3}
            placeholder="Type your auto-reply message... Use {{contact.name}} for personalization"/>
        )}
      </div>
    )
  }

  return (
    <div>
      <SectionHeader title="Auto Replies" desc="Set up automatic responses for greetings, away periods, and keywords"/>

      <p style={{ fontSize:12, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:12 }}>Automated Messages</p>
      <ReplyCard title="Welcome Message" desc="Sent when a contact messages for the first time" state={welcome} setState={setWelcome}/>
      <ReplyCard title="Away Message" desc="Sent outside business hours" state={away} setState={setAway}/>
      <ReplyCard title="Out-of-Office" desc="Sent when all agents are offline" state={oos} setState={setOos}/>

      <div style={{ marginTop:8 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
          <div>
            <p style={{ fontSize:13, fontWeight:700, color:'#374151', margin:0 }}>Keyword Auto-Replies</p>
            <p style={{ fontSize:12, color:'#9ca3af', marginTop:2 }}>Trigger automatic replies based on message keywords</p>
          </div>
          <button onClick={()=>setShowKForm(true)} style={{ background:'#6366f1', color:'#fff', border:'none',
            borderRadius:8, padding:'7px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600 }}>
            <Plus size={13}/> Add Rule
          </button>
        </div>

        {showKForm && (
          <div style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10, padding:14, marginBottom:12 }}>
            <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:12, marginBottom:10 }}>
              <Field label="Keywords (comma or | separated)">
                <Input value={kForm.trigger} onChange={v=>kf('trigger',v)} placeholder="price|pricing|cost"/>
              </Field>
              <Field label="Match Type">
                <Select value={kForm.matchType} onChange={v=>kf('matchType',v)}
                  options={[{v:'any',l:'Any keyword'},{v:'exact',l:'Exact phrase'},{v:'all',l:'All keywords'}]}/>
              </Field>
            </div>
            <Field label="Auto Reply Message">
              <Textarea value={kForm.response} onChange={v=>kf('response',v)} placeholder="Response message..." rows={3}/>
            </Field>
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={addKeyword} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
                padding:'8px 16px', cursor:'pointer', fontSize:13, fontWeight:600 }}>Add Rule</button>
              <button onClick={()=>setShowKForm(false)} style={{ background:'#fff', color:'#374151',
                border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 14px', cursor:'pointer', fontSize:13 }}>Cancel</button>
            </div>
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {keywords.map(k=>(
            <div key={k.id} style={{ border:'1px solid #e5e7eb', borderRadius:10, padding:'11px 14px',
              background:'#fff', display:'flex', gap:12 }}>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
                  <span style={{ fontSize:11, fontWeight:700, color:'#6366f1', background:'#eef2ff',
                    padding:'2px 7px', borderRadius:5, fontFamily:'monospace' }}>
                    {k.trigger}
                  </span>
                  <Badge color="#6b7280" bg="#f3f4f6">{k.matchType}</Badge>
                </div>
                <p style={{ fontSize:12, color:'#6b7280', margin:0 }}>{k.response}</p>
              </div>
              <button onClick={()=>setKeywords(p=>p.filter(kw=>kw.id!==k.id))}
                style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:4, alignSelf:'flex-start' }}>
                <Trash2 size={13}/>
              </button>
            </div>
          ))}
        </div>
      </div>

      <SaveBar onSave={save} saved={saved}/>
    </div>
  )
}

// ─── Section: API & Webhooks ──────────────────────────────────────────────────
const MOCK_KEYS = [
  { id:1, name:'Production Key',  key:'cf_live_a8b3c91d2e4f5678901234567890abcd', created:'Jan 12, 2026', lastUsed:'2 min ago',  scope:'full' },
  { id:2, name:'Read-Only Key',   key:'cf_live_b9c4d02e3f5g6789012345678901bcde', created:'Feb 3, 2026',  lastUsed:'5 days ago', scope:'read' },
]

const WEBHOOK_EVENTS = ['message.received','message.sent','message.delivered','message.read','message.failed',
  'conversation.assigned','conversation.resolved','conversation.created','contact.created','contact.updated',
  'broadcast.sent','broadcast.delivered','template.approved','template.rejected']

function APISection() {
  const [keys, setKeys] = useState(MOCK_KEYS)
  const [showKey, setShowKey] = useState({})
  const [copied, setCopied] = useState('')
  const [webhookUrl, setWebhookUrl] = useState('https://your-server.com/webhook')
  const [webhookSecret, setWebhookSecret] = useState('whsec_a1b2c3d4e5f6')
  const [selectedEvents, setSelectedEvents] = useState(['message.received','conversation.assigned','conversation.resolved'])
  const [newKeyName, setNewKeyName] = useState('')
  const [showNewKey, setShowNewKey] = useState(false)
  const [saved, setSaved] = useState(false)

  function copy(val, id) {
    navigator.clipboard.writeText(val)
    setCopied(id); setTimeout(()=>setCopied(''),2000)
  }

  function generateKey() {
    if(!newKeyName) return
    const raw = 'cf_live_'+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)
    setKeys(p=>[...p,{id:Date.now(),name:newKeyName,key:raw,created:'Today',lastUsed:'Never',scope:'full'}])
    setNewKeyName(''); setShowNewKey(false)
  }

  function toggleEvent(ev) {
    setSelectedEvents(p=>p.includes(ev)?p.filter(e=>e!==ev):[...p,ev])
  }

  function saveWebhook() { setSaved(true); setTimeout(()=>setSaved(false),2500) }

  return (
    <div>
      <SectionHeader title="API & Webhooks" desc="Manage API keys and configure webhook endpoints for real-time events"/>

      {/* API Keys */}
      <div style={{ marginBottom:28 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#374151', margin:0 }}>API Keys</p>
          <button onClick={()=>setShowNewKey(true)} style={{ background:'#6366f1', color:'#fff', border:'none',
            borderRadius:8, padding:'7px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:5, fontSize:13, fontWeight:600 }}>
            <Plus size={13}/> New Key
          </button>
        </div>

        {showNewKey && (
          <div style={{ background:'#f9fafb', border:'1px solid #e5e7eb', borderRadius:10, padding:14, marginBottom:14 }}>
            <div style={{ display:'flex', gap:10 }}>
              <input value={newKeyName} onChange={e=>setNewKeyName(e.target.value)} placeholder="Key name (e.g. Production)"
                style={{ flex:1, border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px', fontSize:13, outline:'none' }}/>
              <button onClick={generateKey} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
                padding:'8px 14px', cursor:'pointer', fontSize:13, fontWeight:600 }}>Generate</button>
              <button onClick={()=>setShowNewKey(false)} style={{ border:'1px solid #e5e7eb', background:'#fff',
                borderRadius:8, padding:'8px', cursor:'pointer', color:'#6b7280' }}><X size={14}/></button>
            </div>
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {keys.map(k=>(
            <div key={k.id} style={{ border:'1px solid #e5e7eb', borderRadius:10, padding:'14px 16px', background:'#fff' }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
                <div>
                  <p style={{ fontSize:13, fontWeight:700, color:'#111827', margin:0 }}>{k.name}</p>
                  <p style={{ fontSize:11, color:'#9ca3af', marginTop:2 }}>Created {k.created} · Last used {k.lastUsed}</p>
                </div>
                <div style={{ display:'flex', gap:8 }}>
                  <Badge color={k.scope==='full'?'#6366f1':'#0ea5e9'} bg={k.scope==='full'?'#eef2ff':'#e0f2fe'}>
                    {k.scope==='full'?'Full Access':'Read Only'}
                  </Badge>
                  <button onClick={()=>setKeys(p=>p.filter(kk=>kk.id!==k.id))}
                    style={{ border:'none', background:'none', cursor:'pointer', color:'#ef4444', padding:2 }}>
                    <Trash2 size={13}/>
                  </button>
                </div>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <code style={{ flex:1, fontSize:12, background:'#f9fafb', border:'1px solid #f3f4f6', borderRadius:7,
                  padding:'6px 12px', color:'#374151', fontFamily:'monospace',
                  letterSpacing: showKey[k.id]?'0':'0.1em' }}>
                  {showKey[k.id] ? k.key : k.key.slice(0,12)+'•'.repeat(20)}
                </code>
                <button onClick={()=>setShowKey(p=>({...p,[k.id]:!p[k.id]}))}
                  style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'6px 9px', cursor:'pointer', color:'#6b7280' }}>
                  {showKey[k.id]?<EyeOff size={13}/>:<Eye size={13}/>}
                </button>
                <button onClick={()=>copy(k.key,k.id)}
                  style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'6px 9px', cursor:'pointer', color:'#6b7280' }}>
                  {copied===k.id?<Check size={13} color="#22c55e"/>:<Copy size={13}/>}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Webhooks */}
      <div>
        <p style={{ fontSize:13, fontWeight:700, color:'#374151', marginBottom:14 }}>Webhook Configuration</p>

        <Field label="Webhook URL" hint="We'll POST event payloads to this URL">
          <Input value={webhookUrl} onChange={setWebhookUrl} placeholder="https://your-server.com/webhook"/>
        </Field>

        <Field label="Webhook Secret" hint="Used to sign webhook payloads (verify with HMAC-SHA256)">
          <div style={{ display:'flex', gap:8 }}>
            <Input value={webhookSecret} onChange={setWebhookSecret}/>
            <button onClick={()=>setWebhookSecret('whsec_'+Math.random().toString(36).slice(2))}
              style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:8, padding:'8px 12px',
                cursor:'pointer', color:'#6b7280', flexShrink:0, display:'flex', alignItems:'center', gap:5, fontSize:13 }}>
              <RefreshCw size={13}/> Rotate
            </button>
          </div>
        </Field>

        <div style={{ marginBottom:16 }}>
          <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:10 }}>Subscribed Events</label>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:6 }}>
            {WEBHOOK_EVENTS.map(ev=>(
              <label key={ev} style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer',
                padding:'7px 10px', borderRadius:7, border:`1px solid ${selectedEvents.includes(ev)?'#c7d2fe':'#e5e7eb'}`,
                background: selectedEvents.includes(ev)?'#eef2ff':'#fff' }}>
                <input type="checkbox" checked={selectedEvents.includes(ev)} onChange={()=>toggleEvent(ev)}
                  style={{ accentColor:'#6366f1' }}/>
                <code style={{ fontSize:12, color: selectedEvents.includes(ev)?'#6366f1':'#374151' }}>{ev}</code>
              </label>
            ))}
          </div>
        </div>

        <div style={{ display:'flex', gap:10 }}>
          <button onClick={saveWebhook} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
            padding:'9px 20px', cursor:'pointer', fontSize:13, fontWeight:600, display:'flex', alignItems:'center', gap:5 }}>
            {saved?<><Check size={13}/> Saved</>:<>Save Webhook</>}
          </button>
          <button style={{ background:'#fff', color:'#374151', border:'1px solid #e5e7eb', borderRadius:8,
            padding:'9px 14px', cursor:'pointer', fontSize:13, display:'flex', alignItems:'center', gap:5 }}>
            <Send size={13}/> Test Webhook
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Section: Billing & Plan ──────────────────────────────────────────────────
const PLANS = [
  { id:'starter', name:'Starter', price:'₹999', period:'/mo', color:'#6b7280', features:['1 WhatsApp Number','3 Agents','5,000 messages/mo','Basic Flows','Email Support'] },
  { id:'growth',  name:'Growth',  price:'₹2,999',period:'/mo', color:'#6366f1', features:['3 WhatsApp Numbers','15 Agents','50,000 messages/mo','Advanced Flows','GPT Integration','Priority Support'], current:true },
  { id:'scale',   name:'Scale',   price:'₹7,999',period:'/mo', color:'#8b5cf6', features:['Unlimited Numbers','Unlimited Agents','Unlimited messages','All Integrations','Custom Branding','Dedicated CSM'] },
]

const INVOICES = [
  { id:'INV-2026-04', date:'Apr 1, 2026', amount:'₹2,999', status:'Paid' },
  { id:'INV-2026-03', date:'Mar 1, 2026', amount:'₹2,999', status:'Paid' },
  { id:'INV-2026-02', date:'Feb 1, 2026', amount:'₹2,999', status:'Paid' },
  { id:'INV-2026-01', date:'Jan 1, 2026', amount:'₹2,999', status:'Paid' },
]

function BillingSection() {
  return (
    <div>
      <SectionHeader title="Billing & Plan" desc="Manage your subscription, usage, and payment history"/>

      {/* Current plan summary */}
      <div style={{ background:'linear-gradient(135deg,#6366f1,#8b5cf6)', borderRadius:14, padding:20, color:'#fff', marginBottom:20 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
          <div>
            <p style={{ fontSize:12, opacity:0.8, margin:0 }}>Current Plan</p>
            <p style={{ fontSize:24, fontWeight:800, margin:'4px 0' }}>Growth Plan</p>
            <p style={{ fontSize:13, opacity:0.9 }}>₹2,999/month · Renews May 1, 2026</p>
          </div>
          <div style={{ textAlign:'right' }}>
            <Badge color="#fff" bg="rgba(255,255,255,0.2)">Active</Badge>
          </div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginTop:18 }}>
          {[
            { l:'Messages Used', v:'23,481', t:'50,000' },
            { l:'Active Agents', v:'6', t:'15' },
            { l:'Contacts', v:'1,284', t:'Unlimited' },
            { l:'Flows Active', v:'12', t:'Unlimited' },
          ].map(u=>(
            <div key={u.l} style={{ background:'rgba(255,255,255,0.15)', borderRadius:10, padding:'10px 12px' }}>
              <p style={{ fontSize:11, opacity:0.8, margin:0 }}>{u.l}</p>
              <p style={{ fontSize:16, fontWeight:700, margin:'3px 0 0' }}>{u.v}</p>
              <p style={{ fontSize:10, opacity:0.7, margin:0 }}>of {u.t}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Usage bar */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:20 }}>
        <p style={{ fontSize:13, fontWeight:600, color:'#374151', marginBottom:14 }}>Messages Usage</p>
        <div style={{ marginBottom:6, display:'flex', justifyContent:'space-between', fontSize:12, color:'#6b7280' }}>
          <span>23,481 used</span><span>50,000 limit</span>
        </div>
        <div style={{ height:8, background:'#e5e7eb', borderRadius:4, overflow:'hidden' }}>
          <div style={{ width:'46.96%', height:'100%', background:'linear-gradient(90deg,#6366f1,#8b5cf6)', borderRadius:4 }}/>
        </div>
        <p style={{ fontSize:11, color:'#9ca3af', marginTop:6 }}>47% used · 26,519 messages remaining this month</p>
      </div>

      {/* Plan cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:24 }}>
        {PLANS.map(plan=>(
          <div key={plan.id} style={{ border:`2px solid ${plan.current?plan.color:'#e5e7eb'}`,
            borderRadius:14, padding:16, background: plan.current?plan.color+'08':'#fff',
            position:'relative' }}>
            {plan.current && (
              <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)',
                background:plan.color, color:'#fff', fontSize:10, fontWeight:700, padding:'3px 10px',
                borderRadius:20, whiteSpace:'nowrap' }}>CURRENT PLAN</div>
            )}
            <p style={{ fontSize:16, fontWeight:800, color:plan.color, margin:'0 0 4px' }}>{plan.name}</p>
            <p style={{ fontSize:20, fontWeight:700, color:'#111827', margin:'0 0 12px' }}>
              {plan.price}<span style={{ fontSize:12, color:'#9ca3af', fontWeight:400 }}>{plan.period}</span>
            </p>
            <div style={{ display:'flex', flexDirection:'column', gap:5, marginBottom:16 }}>
              {plan.features.map(f=>(
                <div key={f} style={{ display:'flex', gap:7, alignItems:'flex-start' }}>
                  <CheckCircle2 size={13} color={plan.color} style={{ flexShrink:0, marginTop:1 }}/>
                  <span style={{ fontSize:12, color:'#374151' }}>{f}</span>
                </div>
              ))}
            </div>
            <button style={{ width:'100%', border: plan.current?'none':'1px solid '+plan.color,
              borderRadius:8, padding:'8px 0', cursor: plan.current?'default':'pointer',
              background: plan.current?plan.color:'transparent',
              color: plan.current?'#fff':plan.color, fontSize:13, fontWeight:600 }}>
              {plan.current?'Current Plan':'Upgrade'}
            </button>
          </div>
        ))}
      </div>

      {/* Invoice history */}
      <div>
        <p style={{ fontSize:13, fontWeight:700, color:'#374151', marginBottom:12 }}>Invoice History</p>
        <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
          {INVOICES.map((inv,i)=>(
            <div key={inv.id} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 16px',
              borderBottom: i<INVOICES.length-1?'1px solid #f3f4f6':'none', background: i%2===0?'#fff':'#fafafa' }}>
              <span style={{ fontSize:13, fontWeight:600, color:'#111827', flex:1, fontFamily:'monospace' }}>{inv.id}</span>
              <span style={{ fontSize:12, color:'#6b7280' }}>{inv.date}</span>
              <span style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{inv.amount}</span>
              <Badge color="#16a34a" bg="#dcfce7">{inv.status}</Badge>
              <button style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:7, padding:'5px 10px',
                cursor:'pointer', fontSize:12, color:'#374151', display:'flex', alignItems:'center', gap:4 }}>
                <Download size={12}/> PDF
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Section: Security ────────────────────────────────────────────────────────
const MOCK_SESSIONS = [
  { id:1, device:'Chrome on Windows', ip:'103.21.50.14', location:'Mumbai, IN', current:true, lastActive:'Now' },
  { id:2, device:'Safari on iPhone',   ip:'49.36.99.102', location:'Delhi, IN',  current:false, lastActive:'3 hr ago' },
  { id:3, device:'Firefox on Mac',     ip:'74.125.0.99',  location:'Bangalore, IN', current:false, lastActive:'2 days ago' },
]

function SecuritySection() {
  const [saved, setSaved] = useState(false)
  const [twoFA, setTwoFA] = useState(true)
  const [ipWhitelist, setIpWhitelist] = useState(false)
  const [sessions, setSessions] = useState(MOCK_SESSIONS)
  const [ipList, setIpList] = useState('103.21.50.0/24\n192.168.1.0/24')
  const [pwForm, setPwForm] = useState({ current:'', newPw:'', confirm:'' })
  const pwf = (k,v)=>setPwForm(p=>({...p,[k]:v}))
  const [pwSaved, setPwSaved] = useState(false)

  function revokeSession(id) { setSessions(p=>p.filter(s=>s.id!==id)) }
  function saveSec() { setSaved(true); setTimeout(()=>setSaved(false),2500) }
  function savePw() { setPwSaved(true); setPwForm({current:'',newPw:'',confirm:''}); setTimeout(()=>setPwSaved(false),2500) }

  return (
    <div>
      <SectionHeader title="Security" desc="Manage authentication, active sessions, and access controls"/>

      {/* 2FA */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:16 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: twoFA?14:0 }}>
          <div>
            <p style={{ fontSize:14, fontWeight:700, color:'#111827', margin:0 }}>Two-Factor Authentication (2FA)</p>
            <p style={{ fontSize:12, color:'#9ca3af', marginTop:2 }}>Require OTP verification on login for all team members</p>
          </div>
          <Toggle value={twoFA} onChange={setTwoFA}/>
        </div>
        {twoFA && (
          <div style={{ background:'#f0fdf4', border:'1px solid #bbf7d0', borderRadius:8, padding:'10px 14px',
            display:'flex', alignItems:'center', gap:8 }}>
            <CheckCircle2 size={16} color="#22c55e"/>
            <span style={{ fontSize:13, color:'#166534' }}>2FA is enabled. All admins must use an authenticator app.</span>
          </div>
        )}
      </div>

      {/* Change password */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:16 }}>
        <p style={{ fontSize:14, fontWeight:700, color:'#111827', marginBottom:14 }}>Change Password</p>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12 }}>
          <Field label="Current Password"><Input value={pwForm.current} onChange={v=>pwf('current',v)} type="password" placeholder="••••••••"/></Field>
          <Field label="New Password"><Input value={pwForm.newPw} onChange={v=>pwf('newPw',v)} type="password" placeholder="••••••••"/></Field>
          <Field label="Confirm Password"><Input value={pwForm.confirm} onChange={v=>pwf('confirm',v)} type="password" placeholder="••••••••"/></Field>
        </div>
        <button onClick={savePw} style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:8,
          padding:'8px 18px', cursor:'pointer', fontSize:13, fontWeight:600, display:'flex', alignItems:'center', gap:5 }}>
          {pwSaved?<><Check size={13}/> Updated!</>:<>Update Password</>}
        </button>
      </div>

      {/* IP Whitelist */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, padding:16, marginBottom:16 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: ipWhitelist?14:0 }}>
          <div>
            <p style={{ fontSize:14, fontWeight:700, color:'#111827', margin:0 }}>IP Whitelist</p>
            <p style={{ fontSize:12, color:'#9ca3af', marginTop:2 }}>Restrict login to specific IP addresses or CIDR ranges</p>
          </div>
          <Toggle value={ipWhitelist} onChange={setIpWhitelist}/>
        </div>
        {ipWhitelist && (
          <Field label="Allowed IPs / CIDR ranges (one per line)" hint="e.g. 103.21.50.14 or 192.168.1.0/24">
            <Textarea value={ipList} onChange={setIpList} rows={4}/>
          </Field>
        )}
      </div>

      {/* Active sessions */}
      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden', marginBottom:16 }}>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid #e5e7eb', background:'#f9fafb',
          display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#374151', margin:0 }}>Active Sessions</p>
          <button onClick={()=>setSessions(p=>p.filter(s=>s.current))}
            style={{ fontSize:12, color:'#ef4444', background:'none', border:'none', cursor:'pointer', fontWeight:600 }}>
            Revoke All Others
          </button>
        </div>
        {sessions.map((s,i)=>(
          <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px',
            borderBottom: i<sessions.length-1?'1px solid #f3f4f6':'none' }}>
            <div style={{ width:36, height:36, borderRadius:8, background: s.current?'#eef2ff':'#f9fafb',
              display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <Activity size={16} color={s.current?'#6366f1':'#9ca3af'}/>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                <span style={{ fontSize:13, fontWeight:600, color:'#111827' }}>{s.device}</span>
                {s.current && <Badge color="#16a34a" bg="#dcfce7">Current</Badge>}
              </div>
              <span style={{ fontSize:11, color:'#9ca3af' }}>{s.ip} · {s.location} · {s.lastActive}</span>
            </div>
            {!s.current && (
              <button onClick={()=>revokeSession(s.id)} style={{ fontSize:12, color:'#ef4444', background:'none',
                border:'1px solid #fecaca', borderRadius:7, padding:'5px 10px', cursor:'pointer', fontWeight:600 }}>
                Revoke
              </button>
            )}
          </div>
        ))}
      </div>

      <SaveBar onSave={saveSec} saved={saved}/>
    </div>
  )
}

// ─── Section: Audit Log ───────────────────────────────────────────────────────
const AUDIT_EVENTS = [
  { id:1,  actor:'Rahul Mehta',  action:'Updated workspace settings',      target:'General',        time:'2 min ago',  ip:'103.21.50.14', type:'settings' },
  { id:2,  actor:'Priya Sharma', action:'Invited team member',             target:'vikram@chatflow.io',time:'18 min ago',ip:'49.36.99.102', type:'team'     },
  { id:3,  actor:'Rahul Mehta',  action:'Generated API key',               target:'Production Key', time:'1 hr ago',   ip:'103.21.50.14', type:'api'      },
  { id:4,  actor:'Sneha Gupta',  action:'Published automation flow',       target:'Lead Capture',   time:'2 hr ago',   ip:'117.55.4.12',  type:'flow'     },
  { id:5,  actor:'Arjun Patel',  action:'Exported contact list',           target:'All Contacts',   time:'3 hr ago',   ip:'49.36.99.102', type:'data'     },
  { id:6,  actor:'Rahul Mehta',  action:'Changed billing plan',            target:'Starter → Growth',time:'1 day ago',  ip:'103.21.50.14', type:'billing'  },
  { id:7,  actor:'Priya Sharma', action:'Created canned response',         target:'/pricing',       time:'1 day ago',  ip:'49.36.99.102', type:'settings' },
  { id:8,  actor:'Rahul Mehta',  action:'Enabled two-factor authentication',target:'Security',      time:'2 days ago', ip:'103.21.50.14', type:'security' },
  { id:9,  actor:'System',       action:'SLA breach detected',             target:'Conv #2841',     time:'2 days ago', ip:'—',            type:'sla'      },
  { id:10, actor:'Vikram Singh',  action:'Resolved conversation',          target:'Conv #2810',     time:'3 days ago', ip:'117.55.9.87',  type:'conv'     },
]

const AUDIT_TYPE_COLORS = {
  settings:{ c:'#6366f1', bg:'#eef2ff' }, team:{ c:'#0ea5e9', bg:'#e0f2fe' },
  api:{ c:'#8b5cf6', bg:'#f5f3ff' },      flow:{ c:'#22c55e', bg:'#dcfce7' },
  data:{ c:'#f59e0b', bg:'#fef3c7' },     billing:{ c:'#ef4444', bg:'#fee2e2' },
  security:{ c:'#dc2626', bg:'#fee2e2' }, sla:{ c:'#f97316', bg:'#ffedd5' },
  conv:{ c:'#6b7280', bg:'#f3f4f6' },
}

function AuditSection() {
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')

  const filtered = AUDIT_EVENTS.filter(e=>{
    const matchSearch = !search || e.actor.toLowerCase().includes(search.toLowerCase()) || e.action.toLowerCase().includes(search.toLowerCase())
    const matchType = typeFilter==='all' || e.type===typeFilter
    return matchSearch && matchType
  })

  const types = ['all',...new Set(AUDIT_EVENTS.map(e=>e.type))]

  return (
    <div>
      <SectionHeader title="Audit Log" desc="Track all actions performed in your workspace"/>

      <div style={{ display:'flex', gap:10, marginBottom:16, flexWrap:'wrap' }}>
        <div style={{ flex:1, minWidth:200, position:'relative' }}>
          <Search size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }}/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by actor or action..."
            style={{ width:'100%', border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px 8px 32px',
              fontSize:13, outline:'none', boxSizing:'border-box' }}/>
        </div>
        <select value={typeFilter} onChange={e=>setTypeFilter(e.target.value)}
          style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:'8px 12px', fontSize:13, background:'#fff', color:'#374151', textTransform:'capitalize' }}>
          {types.map(t=><option key={t} value={t}>{t==='all'?'All Types':t}</option>)}
        </select>
        <button style={{ border:'1px solid #e5e7eb', background:'#fff', borderRadius:8, padding:'8px 14px',
          cursor:'pointer', fontSize:13, color:'#374151', display:'flex', alignItems:'center', gap:5 }}>
          <Download size={13}/> Export CSV
        </button>
      </div>

      <div style={{ border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden' }}>
        <div style={{ display:'grid', gridTemplateColumns:'2fr 2fr 1.5fr 1fr 1fr', gap:12, padding:'8px 16px',
          background:'#f9fafb', borderBottom:'1px solid #e5e7eb' }}>
          {['Actor','Action','Target','Time','IP'].map(h=>(
            <span key={h} style={{ fontSize:11, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.04em' }}>{h}</span>
          ))}
        </div>
        {filtered.map((e,i)=>(
          <div key={e.id} style={{ display:'grid', gridTemplateColumns:'2fr 2fr 1.5fr 1fr 1fr', gap:12,
            padding:'11px 16px', alignItems:'center', borderTop:'1px solid #f3f4f6',
            background: i%2===0?'#fff':'#fafafa' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:28, height:28, borderRadius:'50%', background:'#6366f1',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:'#fff', flexShrink:0 }}>
                {e.actor==='System'?'⚙':e.actor.split(' ').map(w=>w[0]).join('').slice(0,2)}
              </div>
              <span style={{ fontSize:12, fontWeight:600, color:'#111827' }}>{e.actor}</span>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <Badge color={AUDIT_TYPE_COLORS[e.type]?.c||'#6b7280'} bg={AUDIT_TYPE_COLORS[e.type]?.bg||'#f3f4f6'}>{e.type}</Badge>
              <span style={{ fontSize:12, color:'#374151' }}>{e.action}</span>
            </div>
            <span style={{ fontSize:12, color:'#6b7280', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{e.target}</span>
            <span style={{ fontSize:12, color:'#9ca3af' }}>{e.time}</span>
            <span style={{ fontSize:11, color:'#9ca3af', fontFamily:'monospace' }}>{e.ip}</span>
          </div>
        ))}
        {filtered.length===0 && (
          <div style={{ textAlign:'center', padding:'28px 0', color:'#9ca3af', fontSize:13 }}>No events found</div>
        )}
      </div>
    </div>
  )
}

// ─── Section Map ─────────────────────────────────────────────────────────────
const SECTION_COMPONENTS = {
  general: GeneralSection, whatsapp: WhatsAppSection, business_hours: BusinessHoursSection,
  notifications: NotificationsSection, team: TeamSection, roles: RolesSection,
  sla: SLASection, canned: CannedSection, tags: TagsSection, custom_fields: CustomFieldsSection,
  auto_reply: AutoReplySection, api: APISection, billing: BillingSection,
  security: SecuritySection, audit: AuditSection,
}

// ─── Main Settings Page ────────────────────────────────────────────────────────
export default function Settings() {
  const [active, setActive] = useState('general')

  const grouped = GROUPS.reduce((acc, g) => {
    acc[g] = SECTIONS.filter(s => s.group === g)
    return acc
  }, {})

  const ActiveComponent = SECTION_COMPONENTS[active] || GeneralSection

  return (
    <div style={{ display:'flex', height:'calc(100vh - 120px)', gap:0, background:'#f9fafb',
      borderRadius:16, border:'1px solid #e5e7eb', overflow:'hidden' }}>

      {/* ── Left sidebar ── */}
      <div style={{ width:220, flexShrink:0, background:'#fff', borderRight:'1px solid #e5e7eb',
        overflowY:'auto', padding:'16px 0' }}>
        <div style={{ padding:'0 14px 12px', display:'flex', alignItems:'center', gap:8 }}>
          <SettingsIcon size={16} color="#6366f1"/>
          <span style={{ fontSize:15, fontWeight:700, color:'#111827' }}>Settings</span>
        </div>

        {GROUPS.map(group=>(
          <div key={group}>
            <p style={{ fontSize:10, fontWeight:700, color:'#9ca3af', textTransform:'uppercase',
              letterSpacing:'0.06em', padding:'10px 16px 4px', margin:0 }}>{group}</p>
            {grouped[group].map(sec=>{
              const Icon = sec.icon
              const isActive = active === sec.id
              return (
                <button key={sec.id} onClick={()=>setActive(sec.id)}
                  style={{ display:'flex', alignItems:'center', gap:9, width:'100%', border:'none', textAlign:'left',
                    padding:'8px 16px', cursor:'pointer', borderRadius:0,
                    background: isActive?'#eef2ff':'transparent',
                    color: isActive?'#6366f1':'#374151',
                    borderLeft: isActive?'3px solid #6366f1':'3px solid transparent',
                    transition:'all 0.15s' }}>
                  <Icon size={15} style={{ flexShrink:0 }}/>
                  <span style={{ fontSize:13, fontWeight: isActive?600:400 }}>{sec.label}</span>
                </button>
              )
            })}
          </div>
        ))}
      </div>

      {/* ── Right content ── */}
      <div style={{ flex:1, overflowY:'auto', padding:28, background:'#fff' }}>
        <ActiveComponent key={active}/>
      </div>
    </div>
  )
}
