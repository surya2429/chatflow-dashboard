import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import { ConversationProvider } from './context/ConversationContext'
import MainLayout from './layouts/MainLayout'
import Home from './pages/Home'
import Conversations from './pages/Conversations'
import Contacts from './pages/Contacts'
import Templates from './pages/Templates'
import FlowSetup from './pages/FlowSetup'
import Catalog from './pages/Catalog'
import Broadcasting from './pages/Broadcasting'
import Analytics from './pages/Analytics'
import Integrations from './pages/Integrations'
import Voice from './pages/Voice'
import Installation from './pages/Installation'
import ConnectWhatsApp from './pages/ConnectWhatsApp'
import Settings from './pages/Settings'

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <ConversationProvider>
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Home />} />
              <Route path="conversations" element={<Conversations />} />
              <Route path="contacts" element={<Contacts />} />
              <Route path="templates" element={<Templates />} />
              <Route path="flows" element={<FlowSetup />} />
              <Route path="catalog" element={<Catalog />} />
              <Route path="broadcasting" element={<Broadcasting />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="integrations" element={<Integrations />} />
              <Route path="voice" element={<Voice />} />
              <Route path="installation" element={<Installation />} />
              <Route path="channels" element={<ConnectWhatsApp />} />
              <Route path="settings" element={<Settings />} />
            </Route>
          </Routes>
        </ConversationProvider>
      </AppProvider>
    </BrowserRouter>
  )
}
