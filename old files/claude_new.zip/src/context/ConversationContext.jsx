import { createContext, useContext, useState } from 'react'
import { CONVERSATIONS } from '../constants/mockData'

const ConversationContext = createContext(null)

export function ConversationProvider({ children }) {
  const [conversations, setConversations] = useState(CONVERSATIONS)
  const [activeId, setActiveId] = useState(null)
  const [filter, setFilter] = useState('all')       // all | bot | agent | resolved
  const [agentFilter, setAgentFilter] = useState('all') // all | a1 | a2 | ...
  const [sourceFilter, setSourceFilter] = useState('all') // all | direct | ctwa | g-ctwa | t-ctwa
  const [search, setSearch] = useState('')

  const active = conversations.find(c => c.id === activeId) || null

  const filtered = conversations.filter(c => {
    const matchStatus = filter === 'all' || c.status === filter
    const matchAgent  = agentFilter === 'all' || c.agentId === agentFilter || (agentFilter === 'unassigned' && !c.agentId)
    const matchSource = sourceFilter === 'all' || c.source === sourceFilter
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
                        c.lastMessage.toLowerCase().includes(search.toLowerCase())
    return matchStatus && matchAgent && matchSource && matchSearch
  })

  function selectConversation(id) {
    setActiveId(id)
    setConversations(prev => prev.map(c => c.id === id ? { ...c, unread: 0 } : c))
  }

  function sendMessage(conversationId, text) {
    const newMsg = {
      id: `m${Date.now()}`,
      type: 'outgoing',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sender: 'Agent',
    }
    setConversations(prev =>
      prev.map(c => c.id === conversationId
        ? { ...c, messages: [...c.messages, newMsg], lastMessage: text }
        : c
      )
    )
  }

  function takeoverConversation(id) {
    setConversations(prev =>
      prev.map(c => c.id === id ? { ...c, status: 'agent', agentId: 'admin', agentName: 'Deepak Kumar' } : c)
    )
  }

  function resolveConversation(id) {
    setConversations(prev =>
      prev.map(c => c.id === id ? { ...c, status: 'resolved', unread: 0 } : c)
    )
  }

  function returnToBot(id) {
    setConversations(prev =>
      prev.map(c => c.id === id ? { ...c, status: 'bot', agentId: null, agentName: null } : c)
    )
  }

  function assignAgent(conversationId, agentId, agentName) {
    setConversations(prev =>
      prev.map(c => c.id === conversationId
        ? { ...c, status: 'agent', agentId, agentName }
        : c
      )
    )
  }

  function toggleStar(id) {
    setConversations(prev => prev.map(c => c.id === id ? { ...c, starred: !c.starred } : c))
  }

  function archiveConversation(id) {
    setConversations(prev => prev.map(c => c.id === id ? { ...c, archived: true } : c))
  }

  function snoozeConversation(id, until) {
    setConversations(prev => prev.map(c => c.id === id ? { ...c, snoozed: until } : c))
  }

  function addLabel(id, label) {
    setConversations(prev => prev.map(c =>
      c.id === id && !c.labels?.includes(label)
        ? { ...c, labels: [...(c.labels || []), label] }
        : c
    ))
  }

  function removeLabel(id, label) {
    setConversations(prev => prev.map(c =>
      c.id === id
        ? { ...c, labels: (c.labels || []).filter(l => l !== label) }
        : c
    ))
  }

  function addNote(id, text, sender) {
    const note = {
      id: `n${Date.now()}`,
      type: 'note',
      text,
      sender,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }
    setConversations(prev => prev.map(c =>
      c.id === id ? { ...c, messages: [...c.messages, note] } : c
    ))
  }

  return (
    <ConversationContext.Provider value={{
      conversations: filtered,
      allConversations: conversations,
      active,
      activeId,
      filter,
      agentFilter,
      sourceFilter,
      search,
      setFilter,
      setAgentFilter,
      setSourceFilter,
      setSearch,
      selectConversation,
      sendMessage,
      takeoverConversation,
      resolveConversation,
      returnToBot,
      assignAgent,
      toggleStar,
      archiveConversation,
      snoozeConversation,
      addLabel,
      removeLabel,
      addNote,
    }}>
      {children}
    </ConversationContext.Provider>
  )
}

export function useConversations() {
  const ctx = useContext(ConversationContext)
  if (!ctx) throw new Error('useConversations must be used within ConversationProvider')
  return ctx
}
