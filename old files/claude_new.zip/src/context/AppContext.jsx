import { createContext, useContext, useState } from 'react'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [notifications, setNotifications] = useState([
    { id: 1, text: 'Campaign "Flash Sale" sent to 1,204 contacts', time: '2 min ago', read: false },
    { id: 2, text: 'New lead: Rahul Mehta from WhatsApp', time: '14 min ago', read: false },
    { id: 3, text: 'Shopify integration connected', time: '1 hr ago', read: true },
    { id: 4, text: 'Voice bot handled 12 calls today', time: '3 hr ago', read: true },
  ])

  const user = {
    name: 'Deepak Kumar',
    email: 'deepak@acmecorp.com',
    initials: 'DK',
    role: 'Admin',
    workspace: { name: 'Acme Corp', phone: '+91 98765 00000', plan: 'Growth' },
    creditBalance: 4250,
  }

  const unreadCount = notifications.filter(n => !n.read).length

  function toggleSidebar() {
    setSidebarCollapsed(prev => !prev)
  }

  function markAllRead() {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
  }

  return (
    <AppContext.Provider value={{
      user,
      sidebarCollapsed,
      toggleSidebar,
      notifications,
      unreadCount,
      markAllRead,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
