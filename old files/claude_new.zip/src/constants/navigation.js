export const NAV_ITEMS = [
  { id: 'home',          label: 'Dashboard',    icon: 'LayoutDashboard', path: '/' },
  { id: 'conversations', label: 'Inbox',         icon: 'MessageSquare',   path: '/conversations', badge: '12', badgeColor: 'blue' },
  { id: 'contacts',      label: 'Contacts',      icon: 'Users',           path: '/contacts' },
  { id: 'broadcasting',  label: 'Broadcasts',    icon: 'Radio',           path: '/broadcasting' },
  { id: 'flows',         label: 'Automation',    icon: 'Workflow',        path: '/flows' },
  { id: 'templates',     label: 'Templates',     icon: 'FileText',        path: '/templates' },
  { id: 'catalog',       label: 'Catalog',       icon: 'ShoppingBag',     path: '/catalog' },
  { id: 'analytics',     label: 'Analytics',     icon: 'BarChart2',       path: '/analytics' },
  { id: 'integrations',  label: 'Integrations',  icon: 'Puzzle',          path: '/integrations', badge: '45+', badgeColor: 'green' },
  { id: 'voice',         label: 'Voice Bot',     icon: 'PhoneCall',       path: '/voice', badge: 'NEW', badgeColor: 'purple' },
  { id: 'channels',      label: 'Channels',      icon: 'PhoneCall',       path: '/channels',     dividerBefore: true },
  { id: 'settings',      label: 'Settings',      icon: 'Settings',        path: '/settings' },
]
