import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import {
  MessageSquare, Settings, Smartphone, Monitor, Tablet,
  Check, ChevronDown, ChevronUp, Zap, Plus, X,
  Star, Send, Paperclip, Mail, Calendar, Info,
  MapPin, Upload, CreditCard,
  Clock, ArrowRight, ExternalLink, Eye,
  Edit2, Image, Bot, Users,
  ChevronRight, Palette, Shield, MessageCircle, DollarSign,
  AlignLeft, LocateFixed,
  Pencil, Smile, Bell, Volume2, Sun, Moon, Sparkles,
  Search, Package, LifeBuoy, MessageCircleMore,
  Minus, VolumeX, Mic, Download, MoreVertical, HelpCircle,
  CalendarDays, ShoppingBag, Layers, Maximize2, Minimize2, Type as TypeIcon,
} from 'lucide-react'
import clsx from 'clsx'
import { QUESTION_TYPES, QUESTION_CATS } from '../constants/webchatQuestionTypes'

/* ─── Constants ─────────────────────────────────────────────── */
const COLORS = ['#0066ff','#8B5CF6','#10B981','#F59E0B','#EF4444','#EC4899','#06B6D4','#1D4ED8']
const GOOGLE_FONTS = ['System Default','Inter','Roboto','Poppins','Nunito','Manrope','Work Sans','Sora','Plus Jakarta Sans','Lato','DM Sans']
const FONT_SIZE_SCALE = { sm: 0.88, md: 1, lg: 1.2 }
const BUBBLE_STYLES = ['modern','classic','minimal','ios']

/* Loads a Google Font stylesheet on demand — cached by id so switching back and forth doesn't re-fetch. */
function useGoogleFont(family) {
  useEffect(() => {
    if (!family || family === 'System Default') return
    const id = `gf-${family.replace(/\s+/g,'-')}`
    if (document.getElementById(id)) return
    const link = document.createElement('link')
    link.id = id
    link.rel = 'stylesheet'
    link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}:wght@400;600;700;800&display=swap`
    document.head.appendChild(link)
  }, [family])
}

function Toggle({ checked, onChange }) {
  return (
    <button onClick={()=>onChange(!checked)} style={{
      width:34, height:18, borderRadius:9, border:'none', cursor:'pointer', position:'relative',
      background: checked ? '#0066ff' : '#d1d5db', transition:'background 0.2s', padding:0, flexShrink:0,
    }}>
      <div style={{ position:'absolute', top:2, left: checked ? 16 : 2, width:14, height:14, borderRadius:'50%',
        background:'#fff', transition:'left 0.2s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }}/>
    </button>
  )
}

const CORNER_PX  = { sharp: 6, soft: 14, round: 24 }
/* Real-world messenger widths — Intercom ≈ 400px, chatbot.com ≈ 380px.
   The old 236/264/300 values were far too narrow and caused text to wrap badly. */
const SIZE_PX    = { compact: 340, standard: 384, large: 420 }

function WidgetPreview({ cfg, screen, device }) {
  useGoogleFont(cfg.fontFamily)
  const [maximized, setMaximized] = useState(false)
  const [muted, setMuted] = useState(!cfg.sound)
  const [moreOpen, setMoreOpen] = useState(false)
  const [recording, setRecording] = useState(false)
  const [savedFlash, setSavedFlash] = useState(false)
  const [activeTab, setActiveTab] = useState(screen === 'chat' ? 'chat' : 'home')
  useEffect(() => { setActiveTab(screen === 'chat' ? 'chat' : 'home') }, [screen])
  const tabsEnabled = cfg.showFaqTab || cfg.showBookingTab
  const currentScreenKey = tabsEnabled ? activeTab : (screen === 'chat' ? 'chat' : 'home')

  const isOpen = screen !== 'closed'
  const isLeft = cfg.position?.endsWith('left')
  const isTop  = cfg.position?.startsWith('top')
  const initials = (cfg.botName||'Bot').slice(0,2).toUpperCase()
  const headerBg = cfg.colorMode === 'gradient' ? `linear-gradient(135deg, ${cfg.color} 0%, ${cfg.colorEnd||cfg.color} 100%)` : cfg.color
  const cornerR = CORNER_PX[cfg.corner] ?? 24
  const winW = maximized ? 468 : (SIZE_PX[cfg.size] ?? 384)
  const dark = cfg.theme === 'dark'
  const fontScale = FONT_SIZE_SCALE[cfg.fontSize] ?? 1
  const fs = base => `${Math.round(base * fontScale * 10) / 10}px`
  const fontFamilyCss = cfg.fontFamily && cfg.fontFamily !== 'System Default' ? `'${cfg.fontFamily}', sans-serif` : undefined

  /* Message-bubble skin, driven by the Bubble Style picker */
  const bubbleIsMinimal = cfg.bubbleStyle === 'minimal'
  function bubbleRadius(isUser) {
    const tailCorner = isUser ? 'borderBottomRightRadius' : 'borderBottomLeftRadius'
    switch (cfg.bubbleStyle) {
      case 'classic': return { borderRadius: 14, [tailCorner]: 3 }
      case 'ios':      return { borderRadius: 18 }
      case 'minimal':  return { borderRadius: cornerR*0.7 }
      case 'modern':
      default:         return { borderRadius: cornerR*0.9, [tailCorner]: 6 }
    }
  }

  const Avatar = ({ size = 8, textSize = '11px' }) => (
    <div className={clsx('rounded-xl flex items-center justify-center flex-shrink-0', dark ? 'bg-white/15' : 'bg-white/25')}
      style={{ width: size*4, height: size*4 }}>
      {cfg.avatarStyle === 'emoji'
        ? <span style={{ fontSize: textSize === '11px' ? 15 : 12 }}>{cfg.avatarEmoji || '🤖'}</span>
        : cfg.avatarStyle === 'icon'
          ? <Bot size={textSize === '11px' ? 15 : 12} className="text-white"/>
          : <span className="text-white font-black" style={{fontSize: textSize}}>{initials}</span>}
    </div>
  )

  /* mock website bg shimmer blocks */
  const WebBg = () => (
    <div className="absolute inset-0 p-5 space-y-3 pointer-events-none select-none">
      {/* nav */}
      <div className="flex items-center justify-between mb-4">
        <div className="h-3 w-16 bg-slate-200 rounded-md"/>
        <div className="flex gap-2">{[40,32,28].map(w=><div key={w} style={{width:w}} className="h-2.5 bg-slate-200 rounded-md"/>)}</div>
      </div>
      {/* hero */}
      <div className="h-5 w-2/3 bg-slate-300 rounded-md"/>
      <div className="h-3 w-full bg-slate-200 rounded-md"/>
      <div className="h-3 w-5/6 bg-slate-200 rounded-md"/>
      <div className="h-3 w-3/4 bg-slate-200 rounded-md"/>
      <div className="mt-2 flex gap-2">
        <div className="h-7 w-20 bg-slate-300 rounded-lg"/>
        <div className="h-7 w-16 bg-slate-200 rounded-lg"/>
      </div>
      {/* cards row */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[1,2,3].map(i=><div key={i} className="h-14 bg-slate-200 rounded-xl"/>)}
      </div>
    </div>
  )

  /* ── Home screen (open, not yet chatting) — modeled directly on the live Intercom
     and chatbot.com widgets: a COMPACT color header (not a full-height hero block),
     bold two-line greeting, and the primary action as a white CARD with an avatar
     cluster — not a solid colored button. ── */
  const HomeScreen = () => (
    <div className="flex flex-col h-full">
      {/* Compact header — color/gradient is an accent band, not the dominant surface.
          Layered soft circles fake the depth real widgets get from a photo header. */}
      <div className="flex-shrink-0 relative overflow-hidden px-5 pt-4 pb-11" style={{background: headerBg}}>
        <div className="absolute -top-12 -right-12 w-36 h-36 rounded-full bg-white/10"/>
        <div className="absolute top-8 -right-2 w-16 h-16 rounded-full bg-white/10"/>
        <div className="absolute bottom-0 left-10 w-10 h-10 rounded-full bg-black/5"/>
        <div className="flex items-center justify-between mb-4 relative">
          <Avatar size={8} textSize="12px"/>
          <button className="w-6 h-6 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors flex-shrink-0">
            <X size={11} className="text-white"/>
          </button>
        </div>
        <p style={{fontSize: fs(20), fontFamily: fontFamilyCss}} className="text-white font-extrabold leading-[1.15] tracking-tight relative">
          {cfg.greeting?.split(/(?<=[!.?])\s/)[0] || 'Hi there 👋'}
        </p>
        <p style={{fontSize: fs(20), fontFamily: fontFamilyCss}} className="text-white/70 font-extrabold leading-[1.15] tracking-tight relative">
          How can we help?
        </p>
      </div>

      {/* White (or dark) card pulled up over header — dominant surface, like real products */}
      <div className={clsx('flex-1 -mt-6 overflow-y-auto relative flex flex-col', dark ? 'bg-slate-900' : 'bg-white')}
        style={{ borderTopLeftRadius: cornerR*1.3, borderTopRightRadius: cornerR*1.3, fontFamily: fontFamilyCss }}>

        <div className="px-4 pt-5 flex-1">
          {/* Primary action as a CARD with a team avatar cluster — not a solid button */}
          <button style={{borderRadius: cornerR*0.8, boxShadow: dark ? '0 8px 24px -6px rgba(0,0,0,0.5)' : '0 12px 28px -8px rgba(15,23,42,0.16)'}}
            className={clsx('w-full flex items-center gap-3 p-4 border text-left transition-transform hover:-translate-y-0.5',
              dark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100')}>
            <div className="flex-1 min-w-0">
              <p style={{fontSize: fs(13.5)}} className={clsx('font-bold', dark ? 'text-slate-100' : 'text-slate-800')}>Send us a message</p>
              <p style={{fontSize: fs(10.5)}} className={clsx('mt-0.5', dark ? 'text-slate-500' : 'text-slate-400')}>We typically reply in a few minutes</p>
            </div>
            <div className="flex items-center flex-shrink-0" style={{marginRight: 2}}>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] font-black ring-2 relative" style={{background: `linear-gradient(135deg, ${cfg.color}, ${cfg.colorEnd||cfg.color})`, ringColor: dark?'#0f172a':'#fff', zIndex:3}}>{initials}</div>
              <div className={clsx('w-8 h-8 rounded-full flex items-center justify-center -ml-2.5 ring-2 relative', dark ? 'ring-slate-900' : 'ring-white')}
                style={{background:'linear-gradient(135deg,#F59E0B,#EF4444)', zIndex:2}}>
                <span className="text-white text-[10px] font-black">AI</span>
              </div>
              <div className={clsx('w-8 h-8 rounded-full flex items-center justify-center -ml-2.5 ring-2', dark ? 'bg-slate-700 ring-slate-900' : 'bg-slate-200 ring-white')}>
                <Bot size={13} className={dark ? 'text-slate-300' : 'text-slate-500'}/>
              </div>
            </div>
          </button>

          {/* Continue an existing conversation — Intercom surfaces this right under
              the primary action, with an unread dot and relative timestamp. */}
          <div className="mt-5">
            <p className={clsx('text-[10px] font-bold uppercase tracking-wide mb-2', dark ? 'text-slate-500' : 'text-slate-400')}>Recent message</p>
            <button style={{borderRadius: cornerR*0.6}}
              className={clsx('w-full flex items-center gap-2.5 p-2.5 border text-left transition-colors',
                dark ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-200 hover:bg-slate-50')}>
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[9px] font-black flex-shrink-0" style={{background: headerBg}}>{initials}</div>
              <div className="flex-1 min-w-0">
                <p style={{fontSize: fs(11)}} className={clsx('font-semibold truncate', dark ? 'text-slate-200' : 'text-slate-700')}>Order status inquiry</p>
                <p style={{fontSize: fs(10)}} className={clsx('truncate mt-0.5', dark ? 'text-slate-500' : 'text-slate-400')}>Your order #4821 is on the way…</p>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                <span className={clsx('text-[9px]', dark ? 'text-slate-600' : 'text-slate-400')}>2h</span>
                <span className="w-1.5 h-1.5 rounded-full" style={{background: cfg.color}}/>
              </div>
            </button>
          </div>

          {/* Light-touch starter suggestions */}
          <div className="mt-5">
            <p className={clsx('text-[10px] font-bold uppercase tracking-wide mb-2', dark ? 'text-slate-500' : 'text-slate-400')}>Or ask about</p>
            <div className="space-y-1.5">
              {['How does pricing work?', 'Track my order', 'Talk to a human'].map(q=>(
                <div key={q} style={{borderRadius: cornerR*0.55}}
                  className={clsx('flex items-center justify-between px-3.5 py-2.5 border cursor-pointer transition-colors',
                    dark ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-200 hover:bg-slate-50')}>
                  <span style={{fontSize: fs(11.5)}} className={clsx('font-medium', dark ? 'text-slate-300' : 'text-slate-600')}>{q}</span>
                  <ChevronRight size={12} className={dark ? 'text-slate-600' : 'text-slate-300'}/>
                </div>
              ))}
            </div>
          </div>

          {/* Search entry to the help center — the last row of Intercom's home */}
          <div className="mt-5 mb-2">
            <div style={{borderRadius: cornerR*0.6}}
              className={clsx('flex items-center gap-2 px-3.5 py-2.5 border cursor-pointer transition-colors',
                dark ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-slate-50 border-slate-200 hover:bg-slate-100')}>
              <Search size={13} className={dark ? 'text-slate-500' : 'text-slate-400'}/>
              <span style={{fontSize: fs(11.5)}} className={clsx(dark ? 'text-slate-500' : 'text-slate-400')}>Search for help</span>
            </div>
          </div>
        </div>

        {cfg.showBranding && (
          <div className="px-4 py-3.5 text-center flex-shrink-0">
            <p className={clsx('text-[9px]', dark ? 'text-slate-600' : 'text-slate-300')}>Powered by <span className={clsx('font-semibold', dark ? 'text-slate-500' : 'text-slate-400')}>ChatFlow</span></p>
          </div>
        )}
      </div>
    </div>
  )

  /* ── Chat screen ── */
  const ChatScreen = () => (
    <div className="flex flex-col h-full">
      {/* Compact header — light surface with a small colored avatar accent, matching
          real production widgets (Intercom, chatbot.com) rather than a filled color bar */}
      <div className={clsx('flex-shrink-0 px-4 py-2.5 flex items-center gap-2.5 border-b relative',
        dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100')}>
        <button className={clsx('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0', dark ? 'hover:bg-slate-800' : 'hover:bg-slate-100')} title="Back to Home">
          <ChevronDown size={13} className={dark ? 'text-slate-400' : 'text-slate-500'}/>
        </button>
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[11px] font-black flex-shrink-0 relative" style={{background: headerBg}}>
          {cfg.avatarStyle === 'emoji' ? <span style={{fontSize:14}}>{cfg.avatarEmoji||'🤖'}</span> : cfg.avatarStyle === 'icon' ? <Bot size={14}/> : initials}
          <span className={clsx('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2', dark ? 'border-slate-900' : 'border-white')}/>
        </div>
        <div className="flex-1 min-w-0">
          <p style={{fontSize: fs(12)}} className={clsx('font-bold leading-none truncate', dark ? 'text-slate-100' : 'text-slate-800')}>{cfg.botName||'ChatBot'}</p>
          <p className={clsx('text-[9.5px] mt-0.5', dark ? 'text-slate-500' : 'text-slate-400')}>Online</p>
        </div>

        {/* Window controls: overflow menu (minimize/maximize/mute/save) + close */}
        <div className="relative flex-shrink-0">
          <button onClick={()=>setMoreOpen(o=>!o)} title="More options"
            className={clsx('w-6 h-6 rounded-full flex items-center justify-center transition-colors', dark ? 'hover:bg-slate-800' : 'hover:bg-slate-100')}>
            <MoreVertical size={14} className={dark ? 'text-slate-400' : 'text-slate-500'}/>
          </button>
          {moreOpen && (
            <div className="absolute right-0 top-8 w-44 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-30 text-left">
              <button onClick={()=>setMoreOpen(false)}
                className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium text-slate-700 hover:bg-slate-50">
                <Minus size={12} className="text-slate-400"/> Minimize
              </button>
              {device !== 'mobile' && (
                <button onClick={()=>{ setMaximized(m=>!m); setMoreOpen(false) }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium text-slate-700 hover:bg-slate-50 border-t border-slate-100">
                  {maximized ? <Minimize2 size={12} className="text-slate-400"/> : <Maximize2 size={12} className="text-slate-400"/>}
                  {maximized ? 'Restore size' : 'Maximize'}
                </button>
              )}
              <button onClick={()=>{ setMuted(m=>!m); setMoreOpen(false) }}
                className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium text-slate-700 hover:bg-slate-50 border-t border-slate-100">
                {muted ? <VolumeX size={12} className="text-slate-400"/> : <Volume2 size={12} className="text-slate-400"/>}
                {muted ? 'Unmute sounds' : 'Mute sounds'}
              </button>
              {cfg.saveChat && (
                <button onClick={()=>{ setSavedFlash(true); setMoreOpen(false); setTimeout(()=>setSavedFlash(false), 2000) }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium text-slate-700 hover:bg-slate-50 border-t border-slate-100">
                  <Download size={12} className="text-slate-400"/> Save transcript
                </button>
              )}
            </div>
          )}
        </div>
        <button className={clsx('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-colors', dark ? 'hover:bg-slate-800' : 'hover:bg-slate-100')} title="Close">
          <X size={13} className={dark ? 'text-slate-400' : 'text-slate-500'}/>
        </button>
        {savedFlash && (
          <span className="absolute -bottom-6 right-2 text-[9px] font-semibold text-emerald-600 bg-white px-2 py-0.5 rounded-full shadow-sm z-20">
            Transcript saved ✓
          </span>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2" style={{background: dark ? '#0f172a' : '#f8f9fb', fontFamily: fontFamilyCss}}>
        {/* timestamp */}
        <p className={clsx('text-center text-[8px] font-medium py-1', dark ? 'text-slate-600' : 'text-slate-400')}>Today, 2:14 PM</p>

        {/* bot greeting */}
        <div className="flex items-end gap-1.5">
          <div className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-white text-[8px] font-black mb-0.5" style={{background:cfg.color}}>{initials}</div>
          <div className="max-w-[78%]">
            <div style={{...bubbleRadius(false), fontSize: fs(11.5)}} className={clsx('px-3.5 py-2.5 leading-relaxed border',
              bubbleIsMinimal ? (dark ? 'bg-transparent text-slate-100 border-slate-600' : 'bg-transparent text-slate-800 border-slate-300')
              : dark ? 'bg-slate-800 text-slate-100 border-slate-700' : 'bg-slate-100 text-slate-800 border-slate-100')}>
              {cfg.greeting || 'Hi! 👋 How can I help you today?'}
            </div>
            <p className={clsx('text-[9px] mt-1 ml-1', dark ? 'text-slate-600' : 'text-slate-400')}>2:14 PM</p>
          </div>
        </div>

        {/* user message */}
        <div className="flex justify-end">
          <div className="max-w-[78%]">
            <div style={{...bubbleRadius(true), fontSize: fs(11.5), background: bubbleIsMinimal ? 'transparent' : cfg.color,
                color: bubbleIsMinimal ? cfg.color : '#fff', border: bubbleIsMinimal ? `1.5px solid ${cfg.color}` : 'none'}}
              className="px-3.5 py-2.5 leading-relaxed">
              I have a question about pricing
            </div>
            <p className={clsx('text-[9px] mt-1 text-right mr-1', dark ? 'text-slate-600' : 'text-slate-400')}>2:15 PM{cfg.readReceipts ? ' ✓✓' : ''}</p>
          </div>
        </div>

        {/* bot with quick-reply options */}
        <div className="flex items-end gap-1.5">
          <div className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-white text-[8px] font-black mb-0.5" style={{background:cfg.color}}>{initials}</div>
          <div className="max-w-[78%] space-y-1.5">
            <div style={{...bubbleRadius(false), fontSize: fs(11.5)}} className={clsx('px-3.5 py-2.5 border',
              bubbleIsMinimal ? (dark ? 'bg-transparent text-slate-100 border-slate-600' : 'bg-transparent text-slate-800 border-slate-300')
              : dark ? 'bg-slate-800 text-slate-100 border-slate-700' : 'bg-slate-100 text-slate-800 border-slate-100')}>
              Sure! Which plan are you looking at? 🎯
            </div>
            <div className="flex flex-wrap gap-1.5">
              {['Starter','Growth','Enterprise'].map((p,i)=>(
                <div key={p} className={clsx('text-[10px] font-semibold px-2.5 py-1.5 rounded-full border cursor-pointer transition-all',
                  i===0 ? 'text-white border-transparent' : dark ? 'bg-slate-800 text-slate-300 border-slate-700' : 'bg-white text-slate-600 border-slate-200')}
                  style={i===0 ? {background:cfg.color} : {}}>
                  {p}
                </div>
              ))}
            </div>
            <p className={clsx('text-[9px] ml-1', dark ? 'text-slate-600' : 'text-slate-400')}>2:15 PM</p>
          </div>
        </div>

        {/* typing indicator */}
        {cfg.typingIndicator && (
          <div className="flex items-end gap-1.5">
            <div className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-white text-[8px] font-black" style={{background:cfg.color}}>{initials}</div>
            <div style={bubbleRadius(false)} className={clsx('px-3.5 py-3 border', dark ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-100')}>
              <div className="flex gap-1 items-center">
                {[0,1,2].map(i=>(
                  <div key={i} className={clsx('w-1.5 h-1.5 rounded-full', dark ? 'bg-slate-500' : 'bg-slate-400')}
                    style={{animation:`bounce 1.2s ease-in-out ${i*0.2}s infinite`}}/>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input bar */}
      <div className={clsx('flex-shrink-0 border-t px-3 py-2.5 flex items-center gap-2', dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100')}>
        {cfg.attach && (
          <button className={clsx('w-7 h-7 rounded-full border flex items-center justify-center flex-shrink-0', dark ? 'border-slate-700' : 'border-slate-300')}>
            <Plus size={14} className={dark ? 'text-slate-400' : 'text-slate-500'}/>
          </button>
        )}
        <div className={clsx('flex-1 border rounded-full px-3.5 py-2 flex items-center gap-2', dark ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-100')}>
          <input readOnly placeholder={recording ? 'Listening…' : 'Type a message…'}
            style={{fontSize: fs(11), fontFamily: fontFamilyCss}}
            className={clsx('flex-1 bg-transparent outline-none min-w-0', dark ? 'placeholder-slate-500' : 'placeholder-slate-400')}/>
          {cfg.gifPicker && (
            <span className={clsx('text-[8.5px] font-black tracking-tight px-1 rounded border flex-shrink-0', dark ? 'text-slate-500 border-slate-600' : 'text-slate-400 border-slate-300')}>GIF</span>
          )}
          {cfg.emoji && <Smile size={13} className={clsx('flex-shrink-0', dark ? 'text-slate-500' : 'text-slate-400')}/>}
          {cfg.voiceInput && (
            <button onClick={()=>setRecording(r=>!r)} className="flex-shrink-0">
              <Mic size={13} className={recording ? 'text-red-500' : dark ? 'text-slate-500' : 'text-slate-400'}/>
            </button>
          )}
        </div>
        <button className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
          style={{background: cfg.color}}>
          <Send size={11} className="text-white" style={{marginLeft:1}}/>
        </button>
      </div>
      {recording && (
        <div className={clsx('flex-shrink-0 px-3 pb-2 -mt-1 flex items-center gap-1.5', dark ? 'bg-slate-900' : 'bg-white')}>
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"/>
          <span className={clsx('text-[9px] font-medium', dark ? 'text-slate-500' : 'text-slate-400')}>Recording voice message…</span>
        </div>
      )}
    </div>
  )

  /* ── FAQ screen (optional tab) ── */
  const FAQ_ITEMS = [
    { q:'What are your business hours?', a:"We're online Mon–Fri, 9am–6pm. Outside those hours the bot still answers common questions." },
    { q:'How do I get a refund?', a:'Go to Orders → select the order → Request Refund. Refunds land back in 5–7 business days.' },
    { q:'Do you ship internationally?', a:'Yes — we ship to 40+ countries. Shipping cost is calculated at checkout.' },
  ]
  const FaqScreen = () => {
    const [openIdx, setOpenIdx] = useState(0)
    return (
      <div className="flex flex-col h-full">
        <div className="flex-shrink-0 px-4 py-3.5 flex items-center justify-between" style={{background: headerBg}}>
          <p className="text-white text-[13px] font-bold">Help Center</p>
          <button className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center"><X size={10} className="text-white"/></button>
        </div>
        <div className={clsx('flex-1 overflow-y-auto p-3 space-y-2', dark ? 'bg-slate-900' : 'bg-white')} style={{fontFamily: fontFamilyCss}}>
          {FAQ_ITEMS.map((item,i)=>(
            <div key={item.q} className={clsx('border rounded-xl overflow-hidden', dark ? 'border-slate-700' : 'border-slate-200')}>
              <button onClick={()=>setOpenIdx(openIdx===i?-1:i)}
                className={clsx('w-full flex items-center justify-between px-3 py-2.5 text-left', dark ? 'bg-slate-800' : 'bg-slate-50')}>
                <span style={{fontSize: fs(11.5)}} className={clsx('font-semibold pr-2', dark ? 'text-slate-100' : 'text-slate-700')}>{item.q}</span>
                <ChevronDown size={13} className={clsx('flex-shrink-0 transition-transform', dark ? 'text-slate-500' : 'text-slate-400', openIdx===i && 'rotate-180')}/>
              </button>
              {openIdx===i && (
                <p style={{fontSize: fs(11)}} className={clsx('px-3 py-2.5 leading-relaxed', dark ? 'text-slate-400' : 'text-slate-500')}>{item.a}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    )
  }

  /* ── Booking screen (optional tab) — same realtime date+slot picker ── */
  const BookingScreen = () => (
    <div className="flex flex-col h-full">
      <div className="flex-shrink-0 px-4 py-3.5" style={{background: headerBg}}>
        <p className="text-white text-[13px] font-bold">Book an Appointment</p>
        <p className="text-white/80 text-[10.5px] mt-0.5">Pick a date — available times update instantly</p>
      </div>
      <div className={clsx('flex-1 overflow-y-auto p-3', dark ? 'bg-slate-900' : 'bg-white')} style={{fontFamily: fontFamilyCss}}>
        <AppointmentPicker/>
      </div>
    </div>
  )

  /* ── Bottom tab bar — only when FAQ/Booking tabs are enabled ── */
  const TabBar = () => {
    const TABS = [
      { k:'home', l:'Home', icon: MessageCircleMore },
      { k:'chat', l:'Chat', icon: MessageSquare, badge: 1 },
      ...(cfg.showFaqTab ? [{ k:'faq', l:'Help', icon: HelpCircle }] : []),
      ...(cfg.showBookingTab ? [{ k:'book', l:'Book', icon: CalendarDays }] : []),
    ]
    return (
      <div className={clsx('flex-shrink-0 flex items-stretch border-t', dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100')}>
        {TABS.map(t=>{
          const active = activeTab===t.k
          return (
            <button key={t.k} onClick={()=>setActiveTab(t.k)}
              className={clsx('flex-1 flex flex-col items-center gap-1 py-2.5 transition-colors relative',
                active ? (dark ? 'text-white' : 'text-slate-900') : dark ? 'text-slate-600' : 'text-slate-400')}>
              <div className="relative">
                <t.icon size={17} strokeWidth={active ? 2.4 : 1.8}/>
                {!active && t.badge && (
                  <span className="absolute -top-1 -right-1.5 w-3.5 h-3.5 rounded-full bg-red-500 text-white text-[7.5px] font-bold flex items-center justify-center">{t.badge}</span>
                )}
              </div>
              <span className={clsx('text-[8.5px]', active ? 'font-bold' : 'font-medium')}>{t.l}</span>
            </button>
          )
        })}
      </div>
    )
  }

  const screenH = device === 'mobile' ? 620 : 580

  return (
    <div className="flex items-center justify-center w-full h-full" style={{minHeight: 520}}>
      {/* The mock "page" fills whatever stage width is available instead of a fixed
          width, so the widget always renders at true size and the frame adapts to
          the screen rather than clipping the widget. */}
      <div className="transition-all duration-300 w-full"
        style={{ maxWidth: device === 'mobile' ? 360 : device === 'tablet' ? 480 : 720 }}>

        {/* Browser / Phone chrome */}
        {device !== 'mobile' ? (
          <div className="bg-[#e8eaed] rounded-t-xl px-3 pt-2.5 pb-0 border border-b-0 border-slate-200 flex items-center gap-2">
            <div className="flex gap-1.5 pb-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-[#ff5f57]"/>
              <div className="w-2.5 h-2.5 rounded-full bg-[#febc2e]"/>
              <div className="w-2.5 h-2.5 rounded-full bg-[#28c840]"/>
            </div>
            <div className="flex-1 pb-2.5 px-1">
              <div className="bg-white rounded-md px-2 py-1 text-[9px] text-slate-400 font-mono flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"/>
                yourwebsite.com
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-slate-800 rounded-t-2xl px-4 py-2 flex items-center justify-between">
            <div className="w-8 h-1 bg-slate-600 rounded-full mx-auto"/>
          </div>
        )}

        {/* Screen */}
        <div className="relative border border-slate-200 overflow-hidden bg-white"
          style={{
            height: screenH,
            borderRadius: device === 'mobile' ? '0 0 1.5rem 1.5rem' : '0 0 0.75rem 0.75rem',
          }}>

          {/* Page background */}
          <div className="opacity-20"><WebBg/></div>

          {/* ── Closed: launcher ── */}
          {!isOpen && (
            <div className={clsx('absolute flex flex-col gap-2',
              isTop ? 'top-4' : 'bottom-4', isLeft ? 'left-4 items-start' : 'right-4 items-end')}>
              {/* Launcher button */}
              <div className="relative">
                {/* pulse ring — thin, subtle, on-brand */}
                {cfg.pulseAnimation && (
                  <div className={clsx('absolute inset-0 animate-ping', cfg.launcherShape==='square' ? 'rounded-2xl' : 'rounded-full')}
                    style={{background: cfg.color, opacity: 0.25}}/>
                )}
                <button className={clsx('w-14 h-14 flex items-center justify-center relative transition-transform hover:scale-105',
                  cfg.launcherShape==='square' ? 'rounded-2xl' : 'rounded-full')}
                  style={{background: headerBg, boxShadow: `0 8px 24px -4px ${cfg.color}66, 0 4px 10px -2px rgba(0,0,0,0.15)`}}>
                  {cfg.avatarStyle === 'emoji'
                    ? <span style={{fontSize: 24}}>{cfg.avatarEmoji || '🤖'}</span>
                    : cfg.avatarStyle === 'icon'
                      ? <Bot size={22} className="text-white"/>
                      : <MessageCircleMore size={23} className="text-white"/>}
                  {/* unread badge */}
                  <span className="absolute -top-1 -right-1 w-4.5 h-4.5 min-w-[18px] min-h-[18px] rounded-full bg-red-500 border-2 flex items-center justify-center"
                    style={{borderColor: dark ? '#0f172a' : '#fff'}}>
                    <span className="text-white text-[9px] font-bold leading-none">1</span>
                  </span>
                </button>
              </div>
              {/* Launcher text pill */}
              {cfg.launcherText && (
                <div className="flex items-center gap-1.5 text-[10.5px] font-semibold text-white px-3.5 py-2 rounded-full"
                  style={{background: dark ? '#1e293b' : '#0f172a', boxShadow: '0 8px 20px -4px rgba(0,0,0,0.35)'}}>
                  {cfg.launcherText}
                </div>
              )}
              {cfg.autoOpenDelay > 0 && (
                <span className="text-[9px] font-semibold text-slate-400 bg-white/80 px-2 py-0.5 rounded-full shadow-sm">
                  Auto-opens in {cfg.autoOpenDelay}s
                </span>
              )}
            </div>
          )}

          {/* ── Open widget window ── */}
          {isOpen && (
            <div className={clsx(
              'absolute flex flex-col shadow-2xl overflow-hidden',
              isTop ? 'top-3' : 'bottom-3',
              isLeft ? 'left-2' : 'right-2',
              device === 'mobile' && 'inset-x-0 bottom-0 top-auto rounded-b-none'
            )} style={{
              width: device === 'mobile' ? undefined : winW,
              height: device === 'mobile' ? '96%' : (maximized ? '98%' : '92%'),
              borderRadius: device === 'mobile' ? 0 : cornerR,
              boxShadow: '0 25px 60px rgba(0,0,0,0.18), 0 10px 25px rgba(0,0,0,0.12)',
              transition: 'width 0.25s ease, height 0.25s ease',
            }}>
              <div className="flex-1 min-h-0">
                {currentScreenKey === 'home' ? <HomeScreen/>
                  : currentScreenKey === 'chat' ? <ChatScreen/>
                  : currentScreenKey === 'faq' ? <FaqScreen/>
                  : <BookingScreen/>}
              </div>
              {tabsEnabled && <TabBar/>}
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%,60%,100%{transform:translateY(0)}
          30%{transform:translateY(-4px)}
        }
      `}</style>
    </div>
  )
}

/* ─── Builder Tab ─────────────────────────────────────────────── */
const GRADIENT_PRESETS = [
  ['#0066ff','#8B5CF6'], ['#EC4899','#F59E0B'], ['#10B981','#06B6D4'],
  ['#8B5CF6','#EC4899'], ['#1D4ED8','#06B6D4'], ['#EF4444','#EC4899'],
]

function SwatchGrid({ value, onChange, label }) {
  return (
    <div>
      <label className="label">{label}</label>
      <div className="flex flex-wrap gap-2 mt-1">
        {COLORS.map(c=>(
          <button key={c} onClick={()=>onChange(c)}
            className="w-7 h-7 rounded-full border-2 transition-all"
            style={{background:c, borderColor: value===c ? c : 'transparent', boxShadow: value===c ? `0 0 0 2px white, 0 0 0 4px ${c}` : 'none'}}/>
        ))}
        <label className="w-7 h-7 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center cursor-pointer hover:border-slate-400 relative overflow-hidden">
          <span className="text-slate-400 text-lg leading-none">+</span>
          <input type="color" value={value} onChange={e=>onChange(e.target.value)} className="sr-only"/>
        </label>
      </div>
    </div>
  )
}

function PillGroup({ value, onChange, options, cols = 3 }) {
  return (
    <div className={clsx('grid gap-1.5', cols===2 ? 'grid-cols-2' : cols===4 ? 'grid-cols-4' : 'grid-cols-3')}>
      {options.map(o=>(
        <button key={o.v} onClick={()=>onChange(o.v)}
          className={clsx('py-2 px-2 rounded-lg border text-[11px] font-semibold transition-all flex flex-col items-center gap-1',
            value===o.v ? 'border-primary bg-primary/5 text-primary' : 'border-surface-border text-slate-600 hover:border-slate-300')}>
          {o.icon && <o.icon size={13}/>}
          {o.swatch}
          <span className="leading-none">{o.l}</span>
        </button>
      ))}
    </div>
  )
}

function NativeFontSelect({ value, onChange }) {
  useGoogleFont(value)
  return (
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{fontFamily: value && value !== 'System Default' ? `'${value}', sans-serif` : undefined}}
      className="input mt-1 w-full">
      {GOOGLE_FONTS.map(f => <option key={f} value={f} style={{fontFamily: f !== 'System Default' ? `'${f}', sans-serif` : undefined}}>{f}</option>)}
    </select>
  )
}

function BuilderSectionBody({ section, cfg, set }) {
  return (
    <>
        {/* Theme */}
        {section==='theme' && (
          <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-surface-border">
              <p className="text-xs font-semibold text-slate-800">Theme &amp; Style</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Colors, shape and layout of your widget</p>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="label">Header Style</label>
                <div className="grid grid-cols-2 gap-1.5 mt-1">
                  {[{v:'solid',l:'Solid'},{v:'gradient',l:'Gradient'}].map(o=>(
                    <button key={o.v} onClick={()=>set('colorMode',o.v)}
                      className={clsx('py-2 px-3 rounded-lg border text-[11px] font-semibold transition-all flex items-center justify-center gap-1.5',
                        cfg.colorMode===o.v ? 'border-primary bg-primary/5 text-primary' : 'border-surface-border text-slate-600 hover:border-slate-300')}>
                      {o.v==='gradient' && <Sparkles size={11}/>}{o.l}
                    </button>
                  ))}
                </div>
              </div>

              <SwatchGrid label="Primary Color" value={cfg.color} onChange={v=>set('color',v)}/>

              {cfg.colorMode==='gradient' && (
                <div>
                  <SwatchGrid label="Gradient End Color" value={cfg.colorEnd} onChange={v=>set('colorEnd',v)}/>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {GRADIENT_PRESETS.map(([a,b])=>(
                      <button key={a+b} onClick={()=>{set('color',a); set('colorEnd',b)}}
                        className="w-10 h-6 rounded-md border border-white shadow-sm ring-1 ring-slate-200"
                        style={{background:`linear-gradient(135deg, ${a}, ${b})`}}/>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="label">Appearance Mode</label>
                <PillGroup cols={2} value={cfg.theme} onChange={v=>set('theme',v)}
                  options={[{v:'light',l:'Light',icon:Sun},{v:'dark',l:'Dark',icon:Moon}]}/>
              </div>

              <div>
                <label className="label">Corner Style</label>
                <PillGroup value={cfg.corner} onChange={v=>set('corner',v)}
                  options={[
                    {v:'sharp', l:'Sharp', swatch:<div className="w-5 h-5 bg-slate-300" style={{borderRadius:2}}/>},
                    {v:'soft',  l:'Soft',  swatch:<div className="w-5 h-5 bg-slate-300" style={{borderRadius:6}}/>},
                    {v:'round', l:'Round', swatch:<div className="w-5 h-5 bg-slate-300" style={{borderRadius:10}}/>},
                  ]}/>
              </div>

              <div>
                <label className="label">Widget Size</label>
                <PillGroup value={cfg.size} onChange={v=>set('size',v)}
                  options={[{v:'compact',l:'Compact'},{v:'standard',l:'Standard'},{v:'large',l:'Large'}]}/>
              </div>

              <div>
                <label className="label">Launcher Shape</label>
                <PillGroup cols={2} value={cfg.launcherShape} onChange={v=>set('launcherShape',v)}
                  options={[
                    {v:'circle', l:'Circle', swatch:<div className="w-5 h-5 bg-slate-300 rounded-full"/>},
                    {v:'square', l:'Rounded Square', swatch:<div className="w-5 h-5 bg-slate-300 rounded-md"/>},
                  ]}/>
              </div>

              <div>
                <label className="label">Widget Position</label>
                <PillGroup cols={2} value={cfg.position} onChange={v=>set('position',v)}
                  options={[
                    {v:'bottom-right',l:'Bottom Right'},{v:'bottom-left',l:'Bottom Left'},
                    {v:'top-right',l:'Top Right'},{v:'top-left',l:'Top Left'},
                  ]}/>
              </div>

              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="text-xs font-medium text-slate-800">Pulse Animation</p>
                  <p className="text-[10px] text-slate-400">Animated ring around the launcher</p>
                </div>
                <Toggle checked={cfg.pulseAnimation} onChange={v=>set('pulseAnimation',v)}/>
              </div>

              <div>
                <label className="label">Launcher Text <span className="text-slate-400 font-normal">(optional)</span></label>
                <input className="input mt-1" value={cfg.launcherText}
                  onChange={e=>set('launcherText',e.target.value)} placeholder="Chat with us"/>
              </div>

              <div className="border-t border-surface-border -mx-4 px-4 pt-4"/>

              <div>
                <label className="label">Message Bubble Style</label>
                <PillGroup cols={2} value={cfg.bubbleStyle} onChange={v=>set('bubbleStyle',v)}
                  options={[
                    {v:'modern',  l:'Modern',  swatch:<div className="w-8 h-4 bg-slate-300 rounded-[8px_8px_8px_2px]"/>},
                    {v:'classic', l:'Classic', swatch:<div className="w-8 h-4 bg-slate-300 rounded-[10px_10px_10px_1px]"/>},
                    {v:'ios',     l:'Rounded (iOS)', swatch:<div className="w-8 h-4 bg-slate-300 rounded-full"/>},
                    {v:'minimal', l:'Minimal (Outline)', swatch:<div className="w-8 h-4 bg-transparent border-2 border-slate-300 rounded-lg"/>},
                  ]}/>
              </div>

              <div>
                <label className="label">Font Family <span className="text-slate-400 font-normal">(Google Fonts)</span></label>
                <NativeFontSelect value={cfg.fontFamily} onChange={v=>set('fontFamily',v)}/>
              </div>

              <div>
                <label className="label">Font Size</label>
                <PillGroup cols={3} value={cfg.fontSize} onChange={v=>set('fontSize',v)}
                  options={[{v:'sm',l:'Small'},{v:'md',l:'Medium'},{v:'lg',l:'Large'}]}/>
              </div>
            </div>
          </div>
        )}

        {/* Branding */}
        {section==='branding' && (
          <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-surface-border">
              <p className="text-xs font-semibold text-slate-800">Branding</p>
              <p className="text-[10px] text-slate-400 mt-0.5">How your bot introduces itself</p>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="label">Avatar Style</label>
                <div className="grid grid-cols-3 gap-1.5 mt-1">
                  {[{v:'initials',l:'Initials'},{v:'emoji',l:'Emoji'},{v:'icon',l:'Bot Icon'}].map(o=>(
                    <button key={o.v} onClick={()=>set('avatarStyle',o.v)}
                      className={clsx('py-2 px-2 rounded-lg border text-[11px] font-semibold transition-all flex flex-col items-center gap-1',
                        cfg.avatarStyle===o.v ? 'border-primary bg-primary/5 text-primary' : 'border-surface-border text-slate-600 hover:border-slate-300')}>
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-[10px] font-black"
                        style={{background: cfg.colorMode==='gradient' ? `linear-gradient(135deg, ${cfg.color}, ${cfg.colorEnd})` : cfg.color}}>
                        {o.v==='initials' ? (cfg.botName||'Bot').slice(0,2).toUpperCase() : o.v==='emoji' ? (cfg.avatarEmoji||'🤖') : <Bot size={12}/>}
                      </div>
                      {o.l}
                    </button>
                  ))}
                </div>
                {cfg.avatarStyle==='emoji' && (
                  <input className="input mt-2" value={cfg.avatarEmoji} maxLength={4}
                    onChange={e=>set('avatarEmoji',e.target.value)} placeholder="🤖"/>
                )}
              </div>
              <div>
                <label className="label">Bot Name</label>
                <input className="input mt-1" value={cfg.botName}
                  onChange={e=>set('botName',e.target.value)} placeholder="ChatBot"/>
              </div>
              <div>
                <label className="label">Tagline</label>
                <input className="input mt-1" value={cfg.tagline}
                  onChange={e=>set('tagline',e.target.value)} placeholder="We reply instantly"/>
              </div>
              <div>
                <label className="label">Welcome Greeting</label>
                <textarea className="input mt-1 resize-none" rows={3} value={cfg.greeting}
                  onChange={e=>set('greeting',e.target.value)} placeholder="Hi! 👋 How can I help?"/>
              </div>
              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="text-xs font-medium text-slate-800">Show "Powered by ChatFlow"</p>
                  <p className="text-[10px] text-slate-400">Remove branding on paid plans</p>
                </div>
                <Toggle checked={cfg.showBranding} onChange={v=>set('showBranding',v)}/>
              </div>
            </div>
          </div>
        )}

        {/* Behavior */}
        {section==='behavior' && (
          <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-surface-border">
              <p className="text-xs font-semibold text-slate-800">Behavior</p>
            </div>
            <div className="divide-y divide-surface-border">
              {[
                {k:'sound',           l:'Sound notifications',   sub:'Play a sound when new message arrives'},
                {k:'emoji',           l:'Emoji picker',           sub:'Allow users to send emojis'},
                {k:'attach',          l:'File attachments',       sub:'Let users upload files in chat'},
                {k:'rating',          l:'Post-chat rating',       sub:'Ask for satisfaction rating after chat'},
                {k:'typingIndicator', l:'Typing indicator',       sub:'Show animated dots while bot is "typing"'},
                {k:'readReceipts',    l:'Read receipts',          sub:'Show ✓✓ once a message is read'},
                {k:'gifPicker',       l:'GIF picker',              sub:'Let visitors send GIFs in chat'},
                {k:'voiceInput',      l:'Voice-to-text input',     sub:'Mic button to send voice messages'},
                {k:'saveChat',        l:'Save / email transcript', sub:'Let visitors save a copy of the conversation'},
              ].map(item=>(
                <div key={item.k} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-xs font-medium text-slate-800">{item.l}</p>
                    <p className="text-[10px] text-slate-400">{item.sub}</p>
                  </div>
                  <Toggle checked={cfg[item.k]} onChange={v=>set(item.k,v)}/>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-surface-border">
              <label className="label flex items-center gap-1.5"><Clock size={11}/>Auto-open After <span className="text-slate-400 font-normal">(seconds, 0 = off)</span></label>
              <input type="number" min={0} max={120} className="input mt-1 w-28" value={cfg.autoOpenDelay}
                onChange={e=>set('autoOpenDelay', Math.max(0, +e.target.value))}/>
            </div>
            <div className="p-4 border-t border-surface-border space-y-1">
              <label className="label">Extra Widget Tabs <span className="text-slate-400 font-normal">(optional)</span></label>
              <p className="text-[10px] text-slate-400 mb-2">Adds a bottom tab bar to the widget window</p>
              {[
                {k:'showFaqTab',     l:'FAQs tab',            sub:'Searchable help articles as their own tab', icon:HelpCircle},
                {k:'showBookingTab', l:'Book Appointment tab', sub:'Dedicated tab for the date/slot picker',    icon:CalendarDays},
              ].map(item=>(
                <div key={item.k} className="flex items-center justify-between py-1.5">
                  <div className="flex items-center gap-2">
                    <item.icon size={13} className="text-slate-400 flex-shrink-0"/>
                    <div>
                      <p className="text-xs font-medium text-slate-800">{item.l}</p>
                      <p className="text-[10px] text-slate-400">{item.sub}</p>
                    </div>
                  </div>
                  <Toggle checked={cfg[item.k]} onChange={v=>set(item.k,v)}/>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Lead capture */}
        {section==='lead' && (
          <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-surface-border">
              <p className="text-xs font-semibold text-slate-800">Lead Capture Fields</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Collect visitor info before chat starts</p>
            </div>
            <div className="divide-y divide-surface-border">
              {[
                {k:'leadName',  l:'Full Name',    sub:'Ask for visitor name'},
                {k:'leadEmail', l:'Email Address',sub:'Ask for email address'},
                {k:'leadPhone', l:'Phone Number', sub:'Ask for phone number'},
              ].map(item=>(
                <div key={item.k} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-xs font-medium text-slate-800">{item.l}</p>
                    <p className="text-[10px] text-slate-400">{item.sub}</p>
                  </div>
                  <Toggle checked={cfg[item.k]} onChange={v=>set(item.k,v)}/>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-surface-border space-y-1.5">
              <label className="label">Capture Timing</label>
              <PillGroup cols={2} value={cfg.leadTiming} onChange={v=>set('leadTiming',v)}
                options={[{v:'before',l:'Before chat'},{v:'during',l:'During chat'}]}/>
              <p className="text-[10px] text-slate-400 pt-1">
                {cfg.leadTiming==='before' ? 'Shown as a form before the conversation starts.' : "Bot asks for these naturally as the conversation goes on."}
              </p>
            </div>
          </div>
        )}
    </>
  )
}

/* ─── Question Types Tab ──────────────────────────────────────── */
/* ─── Appointment booking — date + realtime available slots in ONE view ──
   Picking a date instantly refreshes the slot grid right below it; no separate
   "step 2" screen. Different days show genuinely different slot sets so the
   realtime update is visible when clicking through dates. ── */
const APPT_SLOT_SETS = [
  ['9:00 AM','11:00 AM','2:00 PM'],
  ['9:00 AM','10:00 AM','11:00 AM','3:00 PM','4:00 PM'],
  ['10:00 AM','1:00 PM','3:00 PM','4:30 PM'],
  ['9:00 AM','12:00 PM'],
  ['9:00 AM','10:00 AM','2:00 PM','3:00 PM','4:00 PM'],
  ['11:00 AM','2:00 PM'],
  [],
]
function AppointmentPicker() {
  const [selectedDay, setSelectedDay] = useState(1)
  const [selectedSlot, setSelectedSlot] = useState(null)
  const days = Array.from({length:7}, (_,i)=>{
    const d = new Date(); d.setDate(d.getDate()+i)
    return { i, label: d.toLocaleDateString('en-US',{weekday:'short'}), num: d.getDate() }
  })
  const slots = APPT_SLOT_SETS[selectedDay % APPT_SLOT_SETS.length]
  const picked = days.find(d=>d.i===selectedDay)

  function pickDay(i) { setSelectedDay(i); setSelectedSlot(null) }

  return (
    <div className="mt-2 border border-slate-200 rounded-xl bg-white p-3">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Select a date</p>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {days.map(d=>(
          <button key={d.i} onClick={()=>pickDay(d.i)}
            className={clsx('flex flex-col items-center justify-center flex-shrink-0 w-11 h-14 rounded-lg border transition-colors',
              selectedDay===d.i ? 'bg-primary border-primary text-white' : 'border-slate-200 text-slate-600 hover:border-slate-300')}>
            <span className="text-[9px] font-medium opacity-80">{d.label}</span>
            <span className="text-[13px] font-bold">{d.num}</span>
          </button>
        ))}
      </div>

      {/* Slots update immediately below — same card, no extra step */}
      <div className="mt-3">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">
          Available times {picked ? `— ${picked.label} ${picked.num}` : ''}
        </p>
        {slots.length === 0 ? (
          <p className="text-[11px] text-slate-400 italic py-2">No slots available this day — try another date.</p>
        ) : (
          <div className="grid grid-cols-3 gap-1.5">
            {slots.map(t=>(
              <button key={t} onClick={()=>setSelectedSlot(t)}
                className={clsx('border rounded-lg py-1.5 text-[10px] font-bold text-center transition-colors',
                  selectedSlot===t ? 'bg-primary border-primary text-white' : 'border-slate-200 text-slate-600 hover:border-primary/40 hover:text-primary')}>
                {t}
              </button>
            ))}
          </div>
        )}
      </div>

      {selectedSlot && (
        <button className="w-full mt-3 bg-primary text-white text-[11px] font-bold py-2 rounded-lg">
          Confirm {picked.label} {picked.num} at {selectedSlot}
        </button>
      )}
    </div>
  )
}

function QuestionPreview({ type }) {
  const previewMap = {
    'short':    <input readOnly placeholder="Type your answer…" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white mt-2"/>,
    'long':     <textarea readOnly rows={2} placeholder="Type your message…" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white resize-none mt-2"/>,
    'number':   <input type="number" readOnly placeholder="0" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white mt-2"/>,
    'email':    <input readOnly placeholder="you@example.com" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white mt-2"/>,
    'phone':    <div className="flex gap-1.5 mt-2"><div className="border border-slate-200 rounded-lg px-2 py-2 text-[11px] text-slate-500 bg-white">🇮🇳 +91</div><input readOnly placeholder="Phone number" className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white"/></div>,
    'url':      <input readOnly placeholder="https://yoursite.com" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white mt-2"/>,
    'single':   <div className="mt-2 space-y-1.5">{['Option A','Option B','Option C'].map(o=><div key={o} className="border border-slate-200 rounded-lg px-3 py-1.5 text-[11px] text-slate-600 bg-white flex items-center gap-2"><div className="w-3 h-3 rounded-full border-2 border-slate-300 flex-shrink-0"/>{o}</div>)}</div>,
    'multi':    <div className="mt-2 space-y-1.5">{['Option A','Option B','Option C'].map(o=><div key={o} className="border border-slate-200 rounded-lg px-3 py-1.5 text-[11px] text-slate-600 bg-white flex items-center gap-2"><div className="w-3 h-3 rounded border-2 border-slate-300 flex-shrink-0"/>{o}</div>)}</div>,
    'dropdown': <div className="mt-2 border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white flex items-center justify-between"><span>Select an option</span><ChevronDown size={12}/></div>,
    'yesno':    <div className="mt-2 grid grid-cols-2 gap-2"><div className="border-2 border-emerald-400 rounded-lg py-2 text-[11px] font-bold text-emerald-600 text-center bg-emerald-50">Yes</div><div className="border-2 border-slate-200 rounded-lg py-2 text-[11px] font-bold text-slate-500 text-center bg-white">No</div></div>,
    'rating':   <div className="mt-2 flex gap-1">{[1,2,3,4,5].map(n=><Star key={n} size={22} className={n<=3?'text-amber-400 fill-amber-400':'text-slate-200'}/>)}</div>,
    'nps':      <div className="mt-2"><div className="flex gap-0.5">{Array.from({length:11},(_,i)=>{const nc=i<=6?'bg-slate-50 border-slate-200 text-slate-600':i<=8?'bg-amber-50 border-amber-200 text-amber-600':'bg-emerald-50 border-emerald-200 text-emerald-600';return <div key={i} className={clsx('flex-1 py-1.5 text-[9px] font-bold text-center rounded border',nc)}>{i}</div>})}</div><div className="flex justify-between text-[9px] text-slate-400 mt-1"><span>Not likely</span><span>Very likely</span></div></div>,
    'date':     <div className="mt-2 border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-2"><Calendar size={12}/><span>Pick a date</span></div>,
    'daterange':<div className="mt-2 flex gap-2"><div className="flex-1 border border-slate-200 rounded-lg px-2 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-1.5"><Calendar size={11}/>Start</div><div className="flex-1 border border-slate-200 rounded-lg px-2 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-1.5"><Calendar size={11}/>End</div></div>,
    'time':     <div className="mt-2 border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-2"><Clock size={12}/><span>Select time</span></div>,
    'appt':     <AppointmentPicker/>,
    'file':     <div className="mt-2 border-2 border-dashed border-slate-200 rounded-xl py-5 flex flex-col items-center gap-1.5 text-slate-400"><Upload size={18}/><span className="text-[10px]">Drop file or click to upload</span></div>,
    'image':    <div className="mt-2 border-2 border-dashed border-slate-200 rounded-xl py-5 flex flex-col items-center gap-1.5 text-slate-400"><Image size={18}/><span className="text-[10px]">Upload image (PNG, JPG)</span></div>,
    'signature':<div className="mt-2 border-2 border-dashed border-slate-200 rounded-xl py-6 flex flex-col items-center gap-1.5 text-slate-400"><Pencil size={18}/><span className="text-[10px]">Sign here</span></div>,
    'location': <div className="mt-2 border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-2"><MapPin size={12}/><span>Search address or pin location</span></div>,
    'payment':  <div className="mt-2 space-y-2"><div className="border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white flex items-center gap-2"><CreditCard size={12}/><span>Card number</span></div><div className="grid grid-cols-2 gap-2"><div className="border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white">MM/YY</div><div className="border border-slate-200 rounded-lg px-3 py-2 text-[11px] text-slate-400 bg-white">CVV</div></div></div>,
    'otp':      <div className="mt-2 flex gap-2 justify-center">{[1,2,3,4,5,6].map(i=><div key={i} className="w-8 h-10 border-2 border-slate-200 rounded-lg flex items-center justify-center text-sm font-bold text-slate-700 bg-white">{i===1?'4':''}</div>)}</div>,
    'form':     <div className="mt-2 border border-slate-200 rounded-xl bg-white p-3 space-y-2">
      {[{l:'Full Name',ph:'Priya Sharma'},{l:'Email',ph:'priya@email.com'},{l:'Phone',ph:'+91 98765 43210'}].map(f=>(
        <div key={f.l}>
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wide mb-1">{f.l}</p>
          <input readOnly placeholder={f.ph} className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-[11px] text-slate-400 bg-slate-50"/>
        </div>
      ))}
      <button className="w-full bg-primary text-white text-[11px] font-bold py-2 rounded-lg mt-1">Submit</button>
    </div>,
    'carousel': <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
      {[
        {t:'Starter Plan',   d:'Best for individuals', c:'#93C5FD'},
        {t:'Growth Plan',    d:'For growing teams',    c:'#C4B5FD'},
        {t:'Enterprise Plan',d:'Custom & scalable',    c:'#6EE7B7'},
      ].map(card=>(
        <div key={card.t} className="w-32 flex-shrink-0 border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm">
          <div className="h-16" style={{background:card.c}}/>
          <div className="p-2">
            <p className="text-[10.5px] font-bold text-slate-800 truncate">{card.t}</p>
            <p className="text-[9px] text-slate-400 truncate mt-0.5">{card.d}</p>
          </div>
        </div>
      ))}
    </div>,
    'carousel_buttons': <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
      {[
        {t:'Starter',    p:'$19/mo', c:'#93C5FD'},
        {t:'Growth',     p:'$49/mo', c:'#C4B5FD'},
        {t:'Enterprise', p:'Custom', c:'#6EE7B7'},
      ].map(card=>(
        <div key={card.t} className="w-32 flex-shrink-0 border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm">
          <div className="h-14 flex items-center justify-center" style={{background:card.c}}>
            <p className="text-[13px] font-black text-white">{card.p}</p>
          </div>
          <div className="p-2">
            <p className="text-[10.5px] font-bold text-slate-800 truncate mb-1.5">{card.t}</p>
            <button className="w-full border border-primary text-primary text-[9.5px] font-bold py-1 rounded-md">Select</button>
          </div>
        </div>
      ))}
    </div>,
    'catalog':  <div className="mt-2 grid grid-cols-2 gap-2">
      {[
        {n:'Classic Tee',   p:'₹799',  c:'#FDE68A'},
        {n:'Denim Jacket',  p:'₹2,499',c:'#BFDBFE'},
        {n:'Canvas Bag',    p:'₹999',  c:'#FBCFE8'},
        {n:'Running Shoes', p:'₹3,199',c:'#C7D2FE'},
      ].map(item=>(
        <div key={item.n} className="border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm">
          <div className="h-14" style={{background:item.c}}/>
          <div className="p-1.5">
            <p className="text-[10px] font-semibold text-slate-800 truncate">{item.n}</p>
            <div className="flex items-center justify-between mt-1">
              <span className="text-[10px] font-bold text-slate-700">{item.p}</span>
              <button className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center"><Plus size={10}/></button>
            </div>
          </div>
        </div>
      ))}
    </div>,
  }
  const botQuestions = {
    short:'What is your full name?', long:'Please describe your issue in detail.',
    number:'How many units do you need?', email:"What's your email address?",
    phone:"What's your phone number?", url:'What is your website URL?',
    single:'Which plan are you interested in?', multi:'Which features do you need?',
    dropdown:'What is your industry?', yesno:'Have you used our product before?',
    rating:'How would you rate your experience?', nps:'How likely are you to recommend us?',
    date:'When would you like to schedule?', daterange:'What are your travel dates?',
    time:'What time works for you?', appt:'Pick a date and time that works for you.',
    file:'Please upload your document.', image:'Upload a screenshot of the issue.',
    signature:'Please provide your signature.', location:"What's your delivery address?",
    payment:'Complete your payment.', otp:"Enter the OTP sent to your phone.",
    form:'Just need a few details to get started:', carousel:'Here are a few options that might interest you:',
    carousel_buttons:'Here are our plans — pick one to continue:', catalog:'Here are some products you might like:',
  }
  return (
    <div className="bg-slate-50 rounded-xl p-3 border border-surface-border">
      <div className="flex items-start gap-2.5">
        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot size={12} className="text-white"/>
        </div>
        <div className="flex-1 min-w-0">
          <div className="bg-white rounded-xl rounded-tl-none px-3 py-2 text-[11px] text-slate-800 border border-surface-border shadow-sm">
            {botQuestions[type.id] || 'Please answer this question.'}
          </div>
          {previewMap[type.id] || null}
        </div>
      </div>
    </div>
  )
}

function QuestionTypesTab() {
  const [cat,   setCat]   = useState('All')
  const [sel,   setSel]   = useState(null)
  const filtered = cat==='All' ? QUESTION_TYPES : QUESTION_TYPES.filter(q=>q.cat===cat)
  const selType  = QUESTION_TYPES.find(q=>q.id===sel)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <p className="text-[13px] font-semibold text-slate-900">{QUESTION_TYPES.length} Question Types</p>
          <p className="text-[11px] text-slate-400">Click any type to preview how it appears in the chat widget</p>
        </div>
        <Link to="/webchat"
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary text-white text-xs font-semibold hover:bg-primary-hover transition-colors shadow-sm">
          <Zap size={12}/> Open Flow Designer
        </Link>
      </div>

      {/* Category filter */}
      <div className="flex items-center gap-0.5 bg-slate-100 p-1 rounded-xl w-fit overflow-x-auto">
        {QUESTION_CATS.map(c=>(
          <button key={c} onClick={()=>setCat(c)}
            className={clsx('px-3 py-1.5 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all',
              cat===c ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700')}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-5">
        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {filtered.map(q=>(
            <button key={q.id} onClick={()=>setSel(sel===q.id?null:q.id)}
              className={clsx('text-left p-4 rounded-xl border transition-all',
                sel===q.id
                  ? 'border-primary bg-primary/5 shadow-sm'
                  : 'border-surface-border bg-white hover:border-slate-300 hover:shadow-sm')}>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-3"
                style={{background: q.color+'18'}}>
                <q.icon size={15} style={{color: q.color}}/>
              </div>
              <p className="text-xs font-semibold text-slate-800 leading-tight">{q.name}</p>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">{q.desc}</p>
              <div className="mt-2">
                <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full"
                  style={{background: q.color+'18', color: q.color}}>
                  {q.cat}
                </span>
              </div>
            </button>
          ))}
        </div>

        {/* Preview pane */}
        <div className="space-y-3">
          {selType ? (
            <div className="bg-white border border-surface-border rounded-xl overflow-hidden sticky top-4">
              <div className="px-4 py-3 border-b border-surface-border flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{background: selType.color+'18'}}>
                  <selType.icon size={14} style={{color: selType.color}}/>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-800">{selType.name}</p>
                  <p className="text-[10px] text-slate-400">{selType.cat}</p>
                </div>
              </div>
              <div className="p-4">
                <p className="text-[11px] text-slate-500 mb-3">{selType.desc}</p>
                <QuestionPreview type={selType}/>
              </div>
              <div className="px-4 py-3 border-t border-surface-border bg-slate-50 flex gap-2">
                <Link to="/webchat" className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-surface-border bg-white text-[11px] font-semibold text-slate-600 hover:bg-slate-50 transition-colors">
                  <Zap size={11}/> Add to Flow
                </Link>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-surface-border rounded-xl p-8 flex flex-col items-center text-center sticky top-4">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mb-3">
                <MessageCircle size={20} className="text-slate-400"/>
              </div>
              <p className="text-sm font-semibold text-slate-700">Select a question type</p>
              <p className="text-[11px] text-slate-400 mt-1">Click any card to preview how it looks in the chat widget</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─── Settings Tab ────────────────────────────────────────────── */
function SettingsTab() {
  const [offline, setOffline] = useState('message')
  const [saved, setSaved] = useState(false)
  const [s, setS] = useState({
    gdpr:true, workingHours:false,
  })
  const set = (k,v) => setS(p=>({...p,[k]:v}))

  const [urlMode, setUrlMode] = useState('all') // 'all' | 'whitelist' | 'blacklist'
  const [whitelistUrls, setWhitelistUrls] = useState(['/pricing', '/features'])
  const [blacklistUrls, setBlacklistUrls] = useState(['/admin/*', '/checkout'])
  const [urlDraft, setUrlDraft] = useState('')
  const activeUrls    = urlMode === 'whitelist' ? whitelistUrls : blacklistUrls
  const setActiveUrls = urlMode === 'whitelist' ? setWhitelistUrls : setBlacklistUrls

  function addUrl() {
    const v = urlDraft.trim()
    if (!v || activeUrls.includes(v)) return
    setActiveUrls(u => [...u, v])
    setUrlDraft('')
  }
  function removeUrl(u) { setActiveUrls(list => list.filter(x => x !== u)) }

  function save() { setSaved(true); setTimeout(()=>setSaved(false), 2500) }

  return (
    <div className="space-y-5 max-w-2xl">

      {/* Toggles */}
      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border">
          <p className="text-[13px] font-semibold text-slate-900">Widget Behavior</p>
        </div>
        <div className="divide-y divide-surface-border">
          {[
            {k:'gdpr',           l:'GDPR Consent Notice',       sub:'Show consent message before chat starts'},
            {k:'workingHours',   l:'Working Hours Only',        sub:'Hide widget outside business hours'},
          ].map(item=>(
            <div key={item.k} className="flex items-center justify-between px-5 py-3.5">
              <div>
                <p className="text-xs font-medium text-slate-800">{item.l}</p>
                <p className="text-[11px] text-slate-400">{item.sub}</p>
              </div>
              <Toggle checked={s[item.k]} onChange={v=>set(item.k,v)}/>
            </div>
          ))}
        </div>
      </div>

      {/* Page visibility — whitelist/blacklist URLs */}
      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border">
          <p className="text-[13px] font-semibold text-slate-900">Page Visibility</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Control which pages the widget shows on</p>
        </div>
        <div className="p-4 space-y-3">
          {[
            { v:'all',       l:'Show on all pages',           sub:'Widget appears everywhere on your site' },
            { v:'whitelist', l:'Show only on specific pages',  sub:'Whitelist — widget appears only on the URLs below' },
            { v:'blacklist', l:'Hide on specific pages',       sub:'Blacklist — widget appears everywhere except the URLs below' },
          ].map(r=>(
            <button key={r.v} onClick={()=>setUrlMode(r.v)}
              className={clsx('w-full flex items-start gap-3 p-3 rounded-lg border text-left transition-all',
                urlMode===r.v ? 'border-primary bg-primary/5' : 'border-surface-border hover:border-slate-300')}>
              <div className={clsx('w-4 h-4 rounded-full border-2 flex-shrink-0 mt-0.5',
                urlMode===r.v ? 'border-primary bg-primary' : 'border-slate-300')}>
                {urlMode===r.v && <div className="w-full h-full rounded-full flex items-center justify-center"><div className="w-1.5 h-1.5 rounded-full bg-white"/></div>}
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-800">{r.l}</p>
                <p className="text-[11px] text-slate-400">{r.sub}</p>
              </div>
            </button>
          ))}

          {urlMode !== 'all' && (
            <div className="pt-1 space-y-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                {urlMode==='whitelist' ? 'Whitelisted URLs' : 'Blacklisted URLs'}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {activeUrls.map(u => (
                  <span key={u} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-mono">
                    {u}
                    <button onClick={()=>removeUrl(u)} className="text-slate-400 hover:text-red-500"><X size={10}/></button>
                  </span>
                ))}
                {activeUrls.length === 0 && <p className="text-[11px] text-slate-400 italic">No URLs added yet</p>}
              </div>
              <div className="flex gap-1.5">
                <input value={urlDraft} onChange={e=>setUrlDraft(e.target.value)}
                  onKeyDown={e=>{ if(e.key==='Enter'){ e.preventDefault(); addUrl() } }}
                  placeholder="e.g. /pricing or /blog/*" className="input-sm flex-1 font-mono"/>
                <button onClick={addUrl} className="px-3 rounded-lg bg-primary-50 text-primary text-[11px] font-semibold hover:bg-primary/10">Add</button>
              </div>
              <p className="text-[10px] text-slate-400">Use <code className="font-mono bg-slate-100 px-1 rounded">*</code> as a wildcard, e.g. <code className="font-mono bg-slate-100 px-1 rounded">/blog/*</code> matches every blog page.</p>
            </div>
          )}
        </div>
      </div>

      {/* Offline behavior */}
      <div className="bg-white border border-surface-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-surface-border">
          <p className="text-[13px] font-semibold text-slate-900">Offline Behavior</p>
          <p className="text-[11px] text-slate-400 mt-0.5">What happens when no agents are available</p>
        </div>
        <div className="p-4 space-y-2">
          {[
            { v:'message', l:'Show offline message', sub:'Display a custom "We are offline" message' },
            { v:'form',    l:'Show contact form',    sub:'Collect name, email and message offline'   },
            { v:'hide',    l:'Hide widget',          sub:'Don\'t show the widget when offline'        },
          ].map(r=>(
            <button key={r.v} onClick={()=>setOffline(r.v)}
              className={clsx('w-full flex items-start gap-3 p-3 rounded-lg border text-left transition-all',
                offline===r.v ? 'border-primary bg-primary/5' : 'border-surface-border hover:border-slate-300')}>
              <div className={clsx('w-4 h-4 rounded-full border-2 flex-shrink-0 mt-0.5',
                offline===r.v ? 'border-primary bg-primary' : 'border-slate-300')}>
                {offline===r.v && <div className="w-full h-full rounded-full flex items-center justify-center"><div className="w-1.5 h-1.5 rounded-full bg-white"/></div>}
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-800">{r.l}</p>
                <p className="text-[11px] text-slate-400">{r.sub}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Save */}
      <div className="flex items-center justify-end gap-3">
        {saved && <span className="flex items-center gap-1.5 text-[11px] text-emerald-600 font-semibold"><Check size={12}/>Saved</span>}
        <button onClick={save} className="btn-primary flex items-center gap-1.5">
          <Check size={13}/> Save Settings
        </button>
      </div>
    </div>
  )
}

/* ─── Main Page ──────────────────────────────────────────────── */
const NAV_GROUPS = [
  { label:'Widget Builder', items:[
    { id:'theme',    label:'Theme',        icon:Palette      },
    { id:'branding', label:'Branding',     icon:Sparkles     },
    { id:'behavior', label:'Behavior',     icon:Zap          },
    { id:'lead',     label:'Lead Capture', icon:Users        },
  ]},
  { label:'Configure', items:[
    { id:'questions', label:'Question Types', icon:MessageCircle },
    { id:'settings',  label:'Settings',       icon:Settings      },
  ]},
]
const SECTION_META = {
  theme:    { title:'Theme & Style',        sub:'Colors, shape and layout of your widget' },
  branding: { title:'Branding',             sub:'How your bot introduces itself' },
  behavior: { title:'Behavior',             sub:'Notifications, receipts and auto-open timing' },
  lead:     { title:'Lead Capture Fields',  sub:'Collect visitor info before or during chat' },
  questions:{ title:'Question Types',       sub:'Browse the question blocks available in Flows' },
  settings: { title:'Settings',             sub:'Routing, visibility and offline behavior' },
}
const BUILDER_SECTIONS = ['theme','branding','behavior','lead']

export default function WebChatAppearance() {
  const [section, setSection] = useState('theme')
  const [cfg, setCfg] = useState({
    // Theme
    colorMode: 'gradient', color: '#0066ff', colorEnd: '#8B5CF6',
    theme: 'light', corner: 'round', size: 'standard', launcherShape: 'circle',
    position: 'bottom-right', launcherText: 'Chat with us', pulseAnimation: true,
    bubbleStyle: 'modern', fontFamily: 'Inter', fontSize: 'md',
    // Branding
    botName: 'ChatBot', tagline: 'We reply instantly',
    greeting: 'Hi! 👋 How can I help you today?', avatarStyle: 'initials', avatarEmoji: '🤖',
    showBranding: true,
    // Behavior
    sound: true, emoji: true, attach: true, rating: true,
    typingIndicator: true, readReceipts: true, autoOpenDelay: 0,
    gifPicker: true, voiceInput: true, saveChat: true,
    // Optional widget tabs
    showFaqTab: false, showBookingTab: false,
    // Lead capture
    leadName: true, leadEmail: true, leadPhone: false, leadTiming: 'before',
  })
  const set = (k, v) => setCfg(p => ({...p, [k]:v}))
  const [device, setDevice] = useState('desktop')
  const [screen, setScreen] = useState('open')
  const isBuilder = BUILDER_SECTIONS.includes(section)
  const meta = SECTION_META[section]

  return (
    <div className="h-[calc(100vh-48px)] md:h-screen -mx-3 -mt-3 -mb-3 sm:-mx-5 sm:-mt-5 sm:-mb-5 flex overflow-hidden">
      {/* ── Section nav rail ── */}
      <div className="w-full md:w-[240px] flex-shrink-0 border-r border-surface-border bg-white flex flex-col">
        <div className="px-4 py-3 border-b border-surface-border">
          <div className="flex items-center gap-2 mb-0.5">
            <p className="text-sm font-bold text-slate-800">Widget Appearance</p>
            <span className="text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded-full flex items-center gap-1 flex-shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse"/>Active
            </span>
          </div>
          <p className="text-[10px] text-slate-400">Design, configure and preview</p>
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          {NAV_GROUPS.map(g=>(
            <div key={g.label} className="mb-1">
              <p className="px-4 pt-2 pb-1 text-[9px] font-bold text-slate-400 uppercase tracking-wider">{g.label}</p>
              {g.items.map(it=>(
                <button key={it.id} onClick={()=>setSection(it.id)}
                  className={clsx('w-full flex items-center gap-2.5 px-4 py-2 text-left text-[12px] font-semibold transition-colors border-r-2',
                    section===it.id ? 'bg-primary-50 text-primary border-primary' : 'text-slate-600 hover:bg-surface-hover border-transparent')}>
                  <it.icon size={14} className="flex-shrink-0"/>{it.label}
                </button>
              ))}
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-surface-border space-y-1.5 flex-shrink-0">
          <Link to="/webchat"
            className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-surface-border bg-white text-slate-600 text-[11px] font-semibold hover:bg-surface-hover transition-colors">
            <Zap size={12}/> Flow Designer
          </Link>
          <button className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-primary text-white text-[11px] font-semibold hover:bg-primary-hover transition-colors">
            <ExternalLink size={12}/> Preview Widget
          </button>
        </div>
      </div>

      {/* ── Content panel ── */}
      {/* Always visible. This was `hidden md:flex`, which made the whole config +
          preview area vanish below 768 CSS px — including on normal screens at
          150–200% browser zoom, where only the section rail remained. */}
      <div className="flex-1 flex flex-col bg-white overflow-hidden min-w-0">
        <div className="h-14 flex items-center justify-between px-5 border-b border-surface-border flex-shrink-0">
          <div>
            <p className="text-[13px] font-bold text-slate-800 leading-tight">{meta.title}</p>
            <p className="text-[10px] text-slate-400">{meta.sub}</p>
          </div>
          {isBuilder && (
            <div className="flex items-center gap-3">
              {/* Screen switcher */}
              <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded-lg">
                {[{s:'closed',l:'Closed'},{s:'open',l:'Home'},{s:'chat',l:'Chat'}].map(sc=>(
                  <button key={sc.s} onClick={()=>setScreen(sc.s)}
                    className={clsx('px-2.5 py-1 rounded-md text-[10px] font-semibold transition-all',
                      screen===sc.s ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500')}>
                    {sc.l}
                  </button>
                ))}
              </div>
              {/* Device switcher */}
              <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded-lg">
                {[{d:'desktop',I:Monitor},{d:'tablet',I:Tablet},{d:'mobile',I:Smartphone}].map(({d,I})=>(
                  <button key={d} onClick={()=>setDevice(d)}
                    className={clsx('p-1.5 rounded-md transition-all',
                      device===d ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400')}>
                    <I size={13}/>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {isBuilder ? (
          /* Two independent columns — config scrolls on its own, the widget preview
             stays pinned in view. A CSS grid with an `xl:` breakpoint collapsed to a
             single column here (the content area is only ~700px wide once the app
             sidebar + section rail are subtracted), which pushed the preview far
             below the fold. Flex avoids the breakpoint trap entirely. */
          <div className="flex-1 flex flex-col lg:flex-row-reverse overflow-y-auto lg:overflow-hidden min-h-0">
            {/* Preview first in the DOM so it sits on top when stacked on narrow
                screens; `lg:flex-row-reverse` puts it back on the right on desktop.
                The explicit min-height stops the stage collapsing to ~0 when stacked. */}
            <div className="flex-1 min-w-0 lg:overflow-auto flex items-center justify-center p-4 min-h-[620px] lg:min-h-0"
              style={{ background: 'radial-gradient(circle at 30% 20%, #eef2f7 0%, #e6ebf2 100%)' }}>
              <WidgetPreview cfg={cfg} screen={screen} device={device}/>
            </div>
            <div className="w-full lg:w-[300px] flex-shrink-0 lg:overflow-y-auto border-t lg:border-t-0 lg:border-r border-surface-border bg-white">
              <div className="p-4 space-y-3">
                <BuilderSectionBody section={section} cfg={cfg} set={set}/>
                <button className="btn-primary w-full justify-center gap-2">
                  <Check size={13}/> Save Widget Settings
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-5 bg-slate-50/40">
            {section==='questions' ? <QuestionTypesTab/> : <SettingsTab/>}
          </div>
        )}
      </div>
    </div>
  )
}
